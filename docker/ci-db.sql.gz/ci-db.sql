--
-- PostgreSQL database dump
--

\restrict AZyNHf6cS8Vq5wOXzkWubN06zyWp85c5G8SveYyQ0MPVT7MDGJGIwuzaOVnave9

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg12+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg12+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: kb_norm(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.kb_norm(value text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE
    AS $$
    SELECT regexp_replace(lower(value), '[^a-z0-9]', '', 'g');
$$;


--
-- Name: italian_unaccent; Type: TEXT SEARCH CONFIGURATION; Schema: public; Owner: -
--

CREATE TEXT SEARCH CONFIGURATION public.italian_unaccent (
    PARSER = pg_catalog."default" );

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR asciiword WITH italian_stem;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR word WITH public.unaccent, italian_stem;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR numword WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR email WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR url WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR host WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR sfloat WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR version WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR hword_numpart WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR hword_part WITH public.unaccent, italian_stem;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR hword_asciipart WITH italian_stem;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR numhword WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR asciihword WITH italian_stem;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR hword WITH public.unaccent, italian_stem;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR url_path WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR file WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR "float" WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR "int" WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.italian_unaccent
    ADD MAPPING FOR uint WITH simple;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    admin_user_id character varying NOT NULL,
    email text NOT NULL,
    action text NOT NULL,
    tournament_id character varying,
    player_id character varying,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: assist_blade_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assist_blade_stats (
    assist_blade text NOT NULL,
    primi_posti integer DEFAULT 0 NOT NULL,
    secondi_posti integer DEFAULT 0 NOT NULL,
    terzi_posti integer DEFAULT 0 NOT NULL,
    punteggio_totale double precision DEFAULT 0 NOT NULL,
    season text NOT NULL,
    quarti_posti integer DEFAULT 0 NOT NULL
);


--
-- Name: bit_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bit_stats (
    "bit" text NOT NULL,
    primi_posti integer DEFAULT 0 NOT NULL,
    secondi_posti integer DEFAULT 0 NOT NULL,
    terzi_posti integer DEFAULT 0 NOT NULL,
    punteggio_totale double precision DEFAULT 0 NOT NULL,
    is_ratchet_less boolean DEFAULT false NOT NULL,
    season text NOT NULL,
    quarti_posti integer DEFAULT 0 NOT NULL
);


--
-- Name: blade_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blade_stats (
    blade text NOT NULL,
    primi_posti integer DEFAULT 0 NOT NULL,
    secondi_posti integer DEFAULT 0 NOT NULL,
    terzi_posti integer DEFAULT 0 NOT NULL,
    punteggio_totale double precision DEFAULT 0 NOT NULL,
    season text NOT NULL,
    quarti_posti integer DEFAULT 0 NOT NULL
);


--
-- Name: challonge_match_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.challonge_match_results (
    id integer NOT NULL,
    tournament_id text NOT NULL,
    data jsonb NOT NULL,
    fetched_at timestamp without time zone DEFAULT now()
);


--
-- Name: challonge_match_results_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.challonge_match_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: challonge_match_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.challonge_match_results_id_seq OWNED BY public.challonge_match_results.id;


--
-- Name: challonge_players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.challonge_players (
    id character varying NOT NULL,
    nickname text NOT NULL,
    avatar text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: challonge_reported_combos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.challonge_reported_combos (
    id integer NOT NULL,
    user_id character varying NOT NULL,
    tournament_id text NOT NULL,
    tournament_name text,
    combo_number integer NOT NULL,
    blade text NOT NULL,
    assist_blade text,
    ratchet text NOT NULL,
    "bit" text NOT NULL,
    lock_chip text,
    rank integer NOT NULL,
    season text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: challonge_reported_combos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.challonge_reported_combos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: challonge_reported_combos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.challonge_reported_combos_id_seq OWNED BY public.challonge_reported_combos.id;


--
-- Name: chat_error; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_error (
    id bigint NOT NULL,
    reference text NOT NULL,
    kind text NOT NULL,
    detail text DEFAULT ''::text NOT NULL,
    traceback text,
    endpoint text,
    session_id bigint,
    client_ip inet,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: chat_error_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_error_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chat_error_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_error_id_seq OWNED BY public.chat_error.id;


--
-- Name: chat_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_message (
    id bigint NOT NULL,
    session_id bigint NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    sources jsonb DEFAULT '[]'::jsonb NOT NULL,
    tool_calls jsonb DEFAULT '[]'::jsonb NOT NULL,
    abstained boolean DEFAULT false NOT NULL,
    phantom_citations jsonb DEFAULT '[]'::jsonb NOT NULL,
    model text,
    input_tokens integer,
    output_tokens integer,
    latency_ms integer,
    feedback smallint DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    retrieval jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT chat_message_feedback_check CHECK (((feedback >= '-1'::integer) AND (feedback <= 1))),
    CONSTRAINT chat_message_role_check CHECK ((role = ANY (ARRAY['user'::text, 'assistant'::text])))
);


--
-- Name: chat_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chat_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_message_id_seq OWNED BY public.chat_message.id;


--
-- Name: chat_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_session (
    id bigint NOT NULL,
    user_id text,
    title text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_message_at timestamp with time zone DEFAULT now() NOT NULL,
    client_ip inet
);


--
-- Name: chat_session_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chat_session_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: chat_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.chat_session_id_seq OWNED BY public.chat_session.id;


--
-- Name: clubs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clubs (
    id character varying NOT NULL,
    name text NOT NULL,
    region text,
    logo text,
    created_at timestamp without time zone DEFAULT now(),
    city text
);


--
-- Name: clubs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clubs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clubs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clubs_id_seq OWNED BY public.clubs.id;


--
-- Name: cm_match_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cm_match_results (
    tournament_id character varying NOT NULL,
    player_id character varying NOT NULL,
    combo_number integer NOT NULL,
    blade text NOT NULL,
    assist_blade text NOT NULL,
    ratchet text NOT NULL,
    "bit" text NOT NULL,
    lock_chip text NOT NULL,
    piazzamento integer NOT NULL,
    numero_partecipanti integer NOT NULL,
    data_torneo date NOT NULL,
    punti_guadagnati double precision NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: cm_players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cm_players (
    id character varying NOT NULL,
    nickname text NOT NULL,
    avatar text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: combo_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.combo_stats (
    blade text NOT NULL,
    assist_blade text NOT NULL,
    ratchet text NOT NULL,
    "bit" text NOT NULL,
    lock_chip text NOT NULL,
    primi_posti integer DEFAULT 0 NOT NULL,
    secondi_posti integer DEFAULT 0 NOT NULL,
    terzi_posti integer DEFAULT 0 NOT NULL,
    punteggio_totale double precision DEFAULT 0 NOT NULL,
    data_creazione timestamp with time zone DEFAULT now() NOT NULL,
    season text NOT NULL,
    quarti_posti integer DEFAULT 0 NOT NULL
);


--
-- Name: component_alias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.component_alias (
    alias_norm text NOT NULL,
    alias text NOT NULL,
    slug text NOT NULL,
    kind text DEFAULT 'exact'::text NOT NULL,
    CONSTRAINT component_alias_kind_check CHECK ((kind = ANY (ARRAY['exact'::text, 'spaced'::text, 'slug'::text, 'abbrev'::text, 'typo'::text, 'localized'::text])))
);


--
-- Name: component_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.component_registry (
    slug text NOT NULL,
    canonical_name text NOT NULL,
    slot text NOT NULL,
    system text,
    attributes jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT component_registry_slot_check CHECK ((slot = ANY (ARRAY['blade'::text, 'assist_blade'::text, 'ratchet'::text, 'bit'::text, 'lock_chip'::text]))),
    CONSTRAINT component_registry_system_check CHECK ((system = ANY (ARRAY['BX'::text, 'UX'::text, 'CX'::text])))
);


--
-- Name: external_api_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_api_cache (
    cache_key text NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: external_player_combos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_player_combos (
    tournament_id character varying NOT NULL,
    player_id character varying NOT NULL,
    combo_number integer NOT NULL,
    blade text NOT NULL,
    assist_blade text NOT NULL,
    ratchet text NOT NULL,
    "bit" text NOT NULL,
    lock_chip text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    placement integer,
    total_participants integer,
    tournament_date date,
    season text,
    platform text DEFAULT 'challengermode'::text NOT NULL
);


--
-- Name: favorite_combos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.favorite_combos (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    blade text NOT NULL,
    assist_blade text NOT NULL,
    ratchet text NOT NULL,
    "bit" text NOT NULL,
    lock_chip text NOT NULL
);


--
-- Name: favorite_deck_combos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.favorite_deck_combos (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    deck_id character varying NOT NULL,
    combo_number integer NOT NULL,
    blade text NOT NULL,
    assist_blade text NOT NULL,
    ratchet text NOT NULL,
    "bit" text NOT NULL,
    lock_chip text NOT NULL
);


--
-- Name: favorite_decks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.favorite_decks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL
);


--
-- Name: kb_chunk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kb_chunk (
    id bigint NOT NULL,
    document_id bigint NOT NULL,
    ordinal integer NOT NULL,
    heading text,
    text text NOT NULL,
    context_header text,
    chunk_hash text NOT NULL,
    embedding public.vector(1024),
    embedding_model text,
    code_tokens text[] DEFAULT '{}'::text[] NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    token_count integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    tsv tsvector GENERATED ALWAYS AS (to_tsvector('public.italian_unaccent'::regconfig, ((COALESCE(context_header, ''::text) || ' '::text) || text))) STORED
);


--
-- Name: kb_chunk_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kb_chunk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kb_chunk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kb_chunk_id_seq OWNED BY public.kb_chunk.id;


--
-- Name: kb_document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kb_document (
    id bigint NOT NULL,
    source_path text NOT NULL,
    doc_type text NOT NULL,
    slug text,
    lang text DEFAULT 'it'::text NOT NULL,
    frontmatter jsonb DEFAULT '{}'::jsonb NOT NULL,
    content_hash text NOT NULL,
    doc_version integer DEFAULT 1 NOT NULL,
    git_sha text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    superseded_at timestamp with time zone,
    CONSTRAINT kb_document_doc_type_check CHECK ((doc_type = ANY (ARRAY['component'::text, 'rule'::text, 'guide'::text, 'meta_snapshot'::text])))
);


--
-- Name: kb_document_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kb_document_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kb_document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kb_document_id_seq OWNED BY public.kb_document.id;


--
-- Name: kb_ingest_run; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kb_ingest_run (
    id bigint NOT NULL,
    git_sha text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    docs_seen integer DEFAULT 0 NOT NULL,
    docs_changed integer DEFAULT 0 NOT NULL,
    chunks_embedded integer DEFAULT 0 NOT NULL,
    chunks_skipped integer DEFAULT 0 NOT NULL,
    error text
);


--
-- Name: kb_ingest_run_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kb_ingest_run_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kb_ingest_run_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kb_ingest_run_id_seq OWNED BY public.kb_ingest_run.id;


--
-- Name: lock_chip_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lock_chip_stats (
    lock_chip text NOT NULL,
    primi_posti integer DEFAULT 0 NOT NULL,
    secondi_posti integer DEFAULT 0 NOT NULL,
    terzi_posti integer DEFAULT 0 NOT NULL,
    punteggio_totale double precision DEFAULT 0 NOT NULL,
    season text NOT NULL,
    quarti_posti integer DEFAULT 0 NOT NULL
);


--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_attempts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ip_address text NOT NULL,
    email text,
    attempted_at timestamp without time zone DEFAULT now() NOT NULL,
    success boolean DEFAULT false NOT NULL
);


--
-- Name: meta_snapshot; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meta_snapshot (
    id bigint NOT NULL,
    source text NOT NULL,
    source_ref text,
    captured_at date NOT NULL,
    lock_chip text,
    over_blade text,
    blade text,
    assist_blade text,
    ratchet text,
    "bit" text,
    points numeric,
    win_count integer,
    combo_rank integer,
    rank_change text,
    imported_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: meta_snapshot_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meta_snapshot_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meta_snapshot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meta_snapshot_id_seq OWNED BY public.meta_snapshot.id;


--
-- Name: user_aliases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_aliases (
    id integer NOT NULL,
    user_id text NOT NULL,
    alias text NOT NULL,
    platform text DEFAULT 'challonge'::text NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    display_name text NOT NULL,
    photo_url text,
    is_admin boolean DEFAULT false NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    verification_token text,
    verification_token_expires_at timestamp with time zone,
    challenger_id text,
    challonge_id text,
    challengermode_username text,
    challonge_username text
);


--
-- Name: player_platform_stats; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.player_platform_stats AS
 WITH cm_source AS (
         SELECT p.id AS player_id,
            p.nickname,
            'challengermode'::text AS platform,
            COALESCE(u.photo_url, p.avatar) AS avatar,
            sum(m.punti_guadagnati) AS total_points,
            (count(DISTINCT m.tournament_id))::integer AS tournaments_played,
            (count(DISTINCT
                CASE
                    WHEN (m.piazzamento = 1) THEN m.tournament_id
                    ELSE NULL::character varying
                END))::integer AS tournaments_won,
            (count(DISTINCT
                CASE
                    WHEN (m.piazzamento <= 3) THEN m.tournament_id
                    ELSE NULL::character varying
                END))::integer AS top3_finishes,
            (count(DISTINCT
                CASE
                    WHEN (m.piazzamento <= 4) THEN m.tournament_id
                    ELSE NULL::character varying
                END))::integer AS top4_finishes
           FROM ((public.cm_match_results m
             JOIN public.cm_players p ON (((m.player_id)::text = (p.id)::text)))
             LEFT JOIN public.users u ON ((u.challenger_id = (p.id)::text)))
          WHERE (NOT ((m.tournament_id)::text IN ( SELECT challonge_match_results.tournament_id
                   FROM public.challonge_match_results)))
          GROUP BY p.id, p.nickname, p.avatar, u.photo_url
        ), challonge_raw AS (
         SELECT COALESCE(((s.value -> 'participant'::text) ->> 'name'::text), (s.value ->> 'name'::text)) AS raw_name,
            COALESCE(((s.value -> 'participant'::text) ->> 'id'::text), (s.value ->> 'id'::text), (s.value ->> 'name'::text)) AS challonge_player_id,
            COALESCE(((s.value -> 'participant'::text) ->> 'user_id'::text), (s.value ->> 'user_id'::text)) AS challonge_user_id,
            ((s.value ->> 'rank'::text))::integer AS rank,
            COALESCE(((c.data ->> 'participants_count'::text))::integer, ((c.data ->> 'total_players'::text))::integer, jsonb_array_length((c.data -> 'standings'::text))) AS total_participants,
            c.tournament_id,
            COALESCE(((s.value -> 'participant'::text) ->> 'avatar_url'::text), (s.value ->> 'avatar_url'::text)) AS avatar
           FROM public.challonge_match_results c,
            LATERAL jsonb_array_elements((c.data -> 'standings'::text)) s(value)
        ), challonge_scored AS (
         SELECT challonge_raw.raw_name,
            challonge_raw.challonge_player_id,
            challonge_raw.challonge_user_id,
            challonge_raw.avatar,
            challonge_raw.tournament_id,
            challonge_raw.rank,
                CASE
                    WHEN ((challonge_raw.total_participants >= 49) AND (challonge_raw.total_participants <= 64)) THEN
                    CASE
                        WHEN (challonge_raw.rank = 1) THEN 400
                        WHEN (challonge_raw.rank = 2) THEN 280
                        WHEN (challonge_raw.rank = 3) THEN 160
                        WHEN (challonge_raw.rank = 4) THEN 120
                        WHEN ((challonge_raw.rank >= 5) AND (challonge_raw.rank <= 8)) THEN 90
                        WHEN ((challonge_raw.rank >= 9) AND (challonge_raw.rank <= 12)) THEN 65
                        WHEN ((challonge_raw.rank >= 13) AND (challonge_raw.rank <= 16)) THEN 50
                        WHEN ((challonge_raw.rank >= 17) AND (challonge_raw.rank <= 24)) THEN 40
                        WHEN ((challonge_raw.rank >= 25) AND (challonge_raw.rank <= 32)) THEN 30
                        WHEN ((challonge_raw.rank >= 33) AND (challonge_raw.rank <= 48)) THEN 15
                        WHEN ((challonge_raw.rank >= 49) AND (challonge_raw.rank <= 64)) THEN 10
                        ELSE 0
                    END
                    WHEN ((challonge_raw.total_participants >= 33) AND (challonge_raw.total_participants <= 48)) THEN
                    CASE
                        WHEN (challonge_raw.rank = 1) THEN 350
                        WHEN (challonge_raw.rank = 2) THEN 240
                        WHEN (challonge_raw.rank = 3) THEN 140
                        WHEN (challonge_raw.rank = 4) THEN 110
                        WHEN ((challonge_raw.rank >= 5) AND (challonge_raw.rank <= 8)) THEN 80
                        WHEN ((challonge_raw.rank >= 9) AND (challonge_raw.rank <= 12)) THEN 55
                        WHEN ((challonge_raw.rank >= 13) AND (challonge_raw.rank <= 16)) THEN 40
                        WHEN ((challonge_raw.rank >= 17) AND (challonge_raw.rank <= 24)) THEN 30
                        WHEN ((challonge_raw.rank >= 25) AND (challonge_raw.rank <= 32)) THEN 15
                        WHEN ((challonge_raw.rank >= 33) AND (challonge_raw.rank <= 48)) THEN 10
                        ELSE 0
                    END
                    WHEN ((challonge_raw.total_participants >= 25) AND (challonge_raw.total_participants <= 32)) THEN
                    CASE
                        WHEN (challonge_raw.rank = 1) THEN 300
                        WHEN (challonge_raw.rank = 2) THEN 200
                        WHEN (challonge_raw.rank = 3) THEN 120
                        WHEN (challonge_raw.rank = 4) THEN 90
                        WHEN ((challonge_raw.rank >= 5) AND (challonge_raw.rank <= 8)) THEN 70
                        WHEN ((challonge_raw.rank >= 9) AND (challonge_raw.rank <= 12)) THEN 45
                        WHEN ((challonge_raw.rank >= 13) AND (challonge_raw.rank <= 16)) THEN 30
                        WHEN ((challonge_raw.rank >= 17) AND (challonge_raw.rank <= 24)) THEN 15
                        WHEN ((challonge_raw.rank >= 25) AND (challonge_raw.rank <= 32)) THEN 10
                        ELSE 0
                    END
                    WHEN ((challonge_raw.total_participants >= 17) AND (challonge_raw.total_participants <= 24)) THEN
                    CASE
                        WHEN (challonge_raw.rank = 1) THEN 250
                        WHEN (challonge_raw.rank = 2) THEN 160
                        WHEN (challonge_raw.rank = 3) THEN 100
                        WHEN (challonge_raw.rank = 4) THEN 80
                        WHEN ((challonge_raw.rank >= 5) AND (challonge_raw.rank <= 8)) THEN 60
                        WHEN ((challonge_raw.rank >= 9) AND (challonge_raw.rank <= 12)) THEN 30
                        WHEN ((challonge_raw.rank >= 13) AND (challonge_raw.rank <= 16)) THEN 15
                        WHEN ((challonge_raw.rank >= 17) AND (challonge_raw.rank <= 24)) THEN 10
                        ELSE 0
                    END
                    WHEN ((challonge_raw.total_participants >= 13) AND (challonge_raw.total_participants <= 16)) THEN
                    CASE
                        WHEN (challonge_raw.rank = 1) THEN 200
                        WHEN (challonge_raw.rank = 2) THEN 120
                        WHEN (challonge_raw.rank = 3) THEN 80
                        WHEN (challonge_raw.rank = 4) THEN 60
                        WHEN ((challonge_raw.rank >= 5) AND (challonge_raw.rank <= 8)) THEN 30
                        WHEN ((challonge_raw.rank >= 9) AND (challonge_raw.rank <= 12)) THEN 15
                        WHEN ((challonge_raw.rank >= 13) AND (challonge_raw.rank <= 16)) THEN 10
                        ELSE 0
                    END
                    WHEN ((challonge_raw.total_participants >= 8) AND (challonge_raw.total_participants <= 12)) THEN
                    CASE
                        WHEN (challonge_raw.rank = 1) THEN 150
                        WHEN (challonge_raw.rank = 2) THEN 80
                        WHEN (challonge_raw.rank = 3) THEN 60
                        WHEN (challonge_raw.rank = 4) THEN 40
                        WHEN ((challonge_raw.rank >= 5) AND (challonge_raw.rank <= 8)) THEN 20
                        WHEN ((challonge_raw.rank >= 9) AND (challonge_raw.rank <= 12)) THEN 10
                        ELSE 0
                    END
                    WHEN ((challonge_raw.total_participants >= 6) AND (challonge_raw.total_participants <= 7)) THEN
                    CASE
                        WHEN (challonge_raw.rank = 1) THEN 100
                        WHEN (challonge_raw.rank = 2) THEN 70
                        WHEN (challonge_raw.rank = 3) THEN 50
                        WHEN (challonge_raw.rank = 4) THEN 30
                        WHEN ((challonge_raw.rank >= 5) AND (challonge_raw.rank <= 7)) THEN 10
                        ELSE 0
                    END
                    ELSE 0
                END AS points
           FROM challonge_raw
        ), challonge_resolved AS (
         SELECT COALESCE(p.id, u.id, u_direct.id, u_name.id, (lower(TRIM(BOTH FROM cs.raw_name)))::character varying) AS final_player_id,
            COALESCE(p.nickname, u.display_name, u_direct.display_name, u_name.display_name, cs.raw_name) AS final_nickname,
            'challonge'::text AS platform,
            COALESCE(u_direct.photo_url, u_name.photo_url, u.photo_url, cp_auth.avatar, p.avatar, cs.avatar) AS avatar,
            cs.points,
            cs.tournament_id,
            cs.rank
           FROM ((((((challonge_scored cs
             LEFT JOIN public.user_aliases ua ON (((lower(TRIM(BOTH FROM ua.alias)) = lower(TRIM(BOTH FROM cs.raw_name))) AND (ua.is_verified = true))))
             LEFT JOIN public.users u ON ((ua.user_id = (u.id)::text)))
             LEFT JOIN public.users u_direct ON ((u_direct.challonge_id = cs.challonge_user_id)))
             LEFT JOIN public.users u_name ON ((lower(u_name.challonge_username) = lower(TRIM(BOTH FROM cs.raw_name)))))
             LEFT JOIN public.cm_players p ON (((u.challenger_id = (p.id)::text) OR (u_direct.challenger_id = (p.id)::text) OR (u_name.challenger_id = (p.id)::text))))
             LEFT JOIN public.challonge_players cp_auth ON (((u.challonge_id = (cp_auth.id)::text) OR (u_direct.challonge_id = (cp_auth.id)::text))))
        ), challonge_stats AS (
         SELECT challonge_resolved.final_player_id AS player_id,
            challonge_resolved.final_nickname AS nickname,
            challonge_resolved.platform,
            max(challonge_resolved.avatar) AS avatar,
            (sum(challonge_resolved.points))::double precision AS total_points,
            (count(DISTINCT challonge_resolved.tournament_id))::integer AS tournaments_played,
            (count(DISTINCT
                CASE
                    WHEN (challonge_resolved.rank = 1) THEN challonge_resolved.tournament_id
                    ELSE NULL::text
                END))::integer AS tournaments_won,
            (count(DISTINCT
                CASE
                    WHEN (challonge_resolved.rank <= 3) THEN challonge_resolved.tournament_id
                    ELSE NULL::text
                END))::integer AS top3_finishes,
            (count(DISTINCT
                CASE
                    WHEN (challonge_resolved.rank <= 4) THEN challonge_resolved.tournament_id
                    ELSE NULL::text
                END))::integer AS top4_finishes
           FROM challonge_resolved
          WHERE (challonge_resolved.final_nickname IS NOT NULL)
          GROUP BY challonge_resolved.final_player_id, challonge_resolved.final_nickname, challonge_resolved.platform
        )
 SELECT cm_source.player_id,
    cm_source.nickname,
    cm_source.platform,
    cm_source.avatar,
    cm_source.total_points,
    cm_source.tournaments_played,
    cm_source.tournaments_won,
    cm_source.top3_finishes,
    cm_source.top4_finishes
   FROM cm_source
UNION ALL
 SELECT challonge_stats.player_id,
    challonge_stats.nickname,
    challonge_stats.platform,
    challonge_stats.avatar,
    challonge_stats.total_points,
    challonge_stats.tournaments_played,
    challonge_stats.tournaments_won,
    challonge_stats.top3_finishes,
    challonge_stats.top4_finishes
   FROM challonge_stats
  WITH NO DATA;


--
-- Name: player_leaderboard; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.player_leaderboard AS
 SELECT nickname,
    max((player_id)::text) AS player_id,
    COALESCE(max(
        CASE
            WHEN (platform = 'challengermode'::text) THEN avatar
            ELSE NULL::text
        END), max(avatar)) AS avatar,
    sum(total_points) AS total_points,
    (sum(tournaments_played))::integer AS tournaments_played,
    (sum(tournaments_won))::integer AS tournaments_won,
    (sum(top3_finishes))::integer AS top3_finishes,
    (sum(top4_finishes))::integer AS top4_finishes
   FROM public.player_platform_stats
  GROUP BY nickname
  ORDER BY (sum(total_points)) DESC;


--
-- Name: player_regional_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_regional_stats (
    player_id text NOT NULL,
    player_name text NOT NULL,
    region text NOT NULL,
    season text DEFAULT 'Season 2026'::text NOT NULL,
    points integer DEFAULT 0 NOT NULL,
    tournaments_played integer DEFAULT 0 NOT NULL,
    wins integer DEFAULT 0 NOT NULL,
    top4 integer DEFAULT 0 NOT NULL,
    updated_at timestamp without time zone DEFAULT now(),
    platform text DEFAULT 'challengermode'::text NOT NULL
);


--
-- Name: ratchet_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ratchet_stats (
    ratchet text NOT NULL,
    primi_posti integer DEFAULT 0 NOT NULL,
    secondi_posti integer DEFAULT 0 NOT NULL,
    terzi_posti integer DEFAULT 0 NOT NULL,
    punteggio_totale double precision DEFAULT 0 NOT NULL,
    season text NOT NULL,
    quarti_posti integer DEFAULT 0 NOT NULL
);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version text NOT NULL,
    name text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


--
-- Name: top_component_snapshot; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.top_component_snapshot AS
 SELECT 'blade'::text AS component_type,
    blade_stats.blade AS name,
    blade_stats.season,
    blade_stats.primi_posti,
    blade_stats.secondi_posti,
    blade_stats.terzi_posti,
    blade_stats.punteggio_totale
   FROM public.blade_stats
UNION ALL
 SELECT 'assist-blade'::text AS component_type,
    assist_blade_stats.assist_blade AS name,
    assist_blade_stats.season,
    assist_blade_stats.primi_posti,
    assist_blade_stats.secondi_posti,
    assist_blade_stats.terzi_posti,
    assist_blade_stats.punteggio_totale
   FROM public.assist_blade_stats
UNION ALL
 SELECT 'ratchet'::text AS component_type,
    ratchet_stats.ratchet AS name,
    ratchet_stats.season,
    ratchet_stats.primi_posti,
    ratchet_stats.secondi_posti,
    ratchet_stats.terzi_posti,
    ratchet_stats.punteggio_totale
   FROM public.ratchet_stats
UNION ALL
 SELECT 'bit'::text AS component_type,
    bit_stats."bit" AS name,
    bit_stats.season,
    bit_stats.primi_posti,
    bit_stats.secondi_posti,
    bit_stats.terzi_posti,
    bit_stats.punteggio_totale
   FROM public.bit_stats
UNION ALL
 SELECT 'lock-chip'::text AS component_type,
    lock_chip_stats.lock_chip AS name,
    lock_chip_stats.season,
    lock_chip_stats.primi_posti,
    lock_chip_stats.secondi_posti,
    lock_chip_stats.terzi_posti,
    lock_chip_stats.punteggio_totale
   FROM public.lock_chip_stats
  WITH NO DATA;


--
-- Name: tournaments_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.tournaments_view AS
 SELECT (cache.data ->> 'id'::text) AS id,
    (cache.data ->> 'name'::text) AS name,
    (((cache.data -> 'schedule'::text) ->> 'startedAt'::text))::date AS date,
    ((((cache.data -> 'hosts'::text) -> 'spaces'::text) -> 0) ->> 'name'::text) AS organizer_name,
    clubs.region,
    clubs.city
   FROM (public.external_api_cache cache
     LEFT JOIN public.clubs ON ((clubs.name = ((((cache.data -> 'hosts'::text) -> 'spaces'::text) -> 0) ->> 'name'::text))))
  WHERE (cache.cache_key ~~ 'cm:tournamentDetail:%'::text);


--
-- Name: unified_meta_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.unified_meta_view AS
 SELECT (((((external_player_combos.tournament_id)::text || '_'::text) || (external_player_combos.player_id)::text) || '_'::text) || external_player_combos.combo_number) AS unique_id,
    external_player_combos.blade,
    external_player_combos.assist_blade,
    external_player_combos.ratchet,
    external_player_combos."bit",
    external_player_combos.lock_chip,
    external_player_combos.placement AS rank,
    (external_player_combos.tournament_date)::timestamp without time zone AS date,
    external_player_combos.total_participants AS participant_count,
    external_player_combos.platform,
    external_player_combos.season
   FROM public.external_player_combos
  WHERE (external_player_combos.placement <= 3)
UNION ALL
 SELECT ('ch_'::text || r.id) AS unique_id,
    r.blade,
    r.assist_blade,
    r.ratchet,
    r."bit",
    r.lock_chip,
    r.rank,
    ((m.data ->> 'start_date'::text))::timestamp without time zone AS date,
    COALESCE(((m.data ->> 'total_players'::text))::integer, 0) AS participant_count,
    'challonge'::text AS platform,
    r.season
   FROM (public.challonge_reported_combos r
     JOIN public.challonge_match_results m ON ((r.tournament_id = m.tournament_id)))
  WHERE (r.rank <= 3);


--
-- Name: user_aliases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_aliases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_aliases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_aliases_id_seq OWNED BY public.user_aliases.id;


--
-- Name: challonge_match_results id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challonge_match_results ALTER COLUMN id SET DEFAULT nextval('public.challonge_match_results_id_seq'::regclass);


--
-- Name: challonge_reported_combos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challonge_reported_combos ALTER COLUMN id SET DEFAULT nextval('public.challonge_reported_combos_id_seq'::regclass);


--
-- Name: chat_error id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_error ALTER COLUMN id SET DEFAULT nextval('public.chat_error_id_seq'::regclass);


--
-- Name: chat_message id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message ALTER COLUMN id SET DEFAULT nextval('public.chat_message_id_seq'::regclass);


--
-- Name: chat_session id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_session ALTER COLUMN id SET DEFAULT nextval('public.chat_session_id_seq'::regclass);


--
-- Name: clubs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clubs ALTER COLUMN id SET DEFAULT nextval('public.clubs_id_seq'::regclass);


--
-- Name: kb_chunk id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_chunk ALTER COLUMN id SET DEFAULT nextval('public.kb_chunk_id_seq'::regclass);


--
-- Name: kb_document id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_document ALTER COLUMN id SET DEFAULT nextval('public.kb_document_id_seq'::regclass);


--
-- Name: kb_ingest_run id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_ingest_run ALTER COLUMN id SET DEFAULT nextval('public.kb_ingest_run_id_seq'::regclass);


--
-- Name: meta_snapshot id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_snapshot ALTER COLUMN id SET DEFAULT nextval('public.meta_snapshot_id_seq'::regclass);


--
-- Name: user_aliases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_aliases ALTER COLUMN id SET DEFAULT nextval('public.user_aliases_id_seq'::regclass);


--
-- Data for Name: assist_blade_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assist_blade_stats (assist_blade, primi_posti, secondi_posti, terzi_posti, punteggio_totale, season, quarti_posti) FROM stdin;
Bumper	0	0	0	0	Off Season 2025	0
Charge	0	0	0	0	Off Season 2025	0
Dual	0	0	0	0	Off Season 2025	0
Massive	0	0	0	0	Off Season 2025	0
Round	0	0	0	0	Off Season 2025	0
Turn	0	0	0	0	Off Season 2025	0
Wheel	0	0	0	0	Off Season 2025	0
Slash	1	0	0	240	Off Season 2025	0
Jaggy	0	1	0	168	Off Season 2025	0
Heavy	1	2	0	524	Off Season 2025	0
Assault	0	1	0	63	Off Season 2025	0
None	28	26	57	13789	Off Season 2025	0
\.


--
-- Data for Name: bit_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bit_stats ("bit", primi_posti, secondi_posti, terzi_posti, punteggio_totale, is_ratchet_less, season, quarti_posti) FROM stdin;
LowRush	4	7	7	2542	f	Off Season 2025	0
Merge	0	0	0	0	f	Off Season 2025	0
MetalNeedle	0	0	0	0	f	Off Season 2025	0
Needle	0	0	0	0	f	Off Season 2025	0
Operate	0	1	0	56	t	Off Season 2025	0
Orb	0	0	0	0	f	Off Season 2025	0
Point	2	0	1	250	f	Off Season 2025	0
Quake	0	0	0	0	f	Off Season 2025	0
RubberAccel	0	0	0	0	f	Off Season 2025	0
Rush	5	6	10	2424	f	Off Season 2025	0
Spike	0	0	0	0	f	Off Season 2025	0
Taper	1	0	2	405	f	Off Season 2025	0
TransPoint	0	0	0	0	f	Off Season 2025	0
Turbo	0	0	0	0	t	Off Season 2025	0
UnderFlat	1	0	1	185	f	Off Season 2025	0
UnderNeedle	0	0	1	120	f	Off Season 2025	0
Unite	0	0	0	0	f	Off Season 2025	0
Vortex	0	0	0	0	f	Off Season 2025	0
Wedge	1	0	0	240	f	Off Season 2025	0
Zap	0	0	0	0	f	Off Season 2025	0
Accel	0	0	0	0	f	Off Season 2025	0
Ball	0	2	5	980	f	Off Season 2025	0
BoundSpike	0	0	0	0	f	Off Season 2025	0
Cyclone	0	0	0	0	f	Off Season 2025	0
DiskBall	0	0	0	0	f	Off Season 2025	0
Dot	0	0	0	0	f	Off Season 2025	0
Elevate	2	2	3	1086	f	Off Season 2025	0
Flat	0	0	0	0	f	Off Season 2025	0
FreeBall	4	3	9	2246	f	Off Season 2025	0
GearBall	0	0	0	0	f	Off Season 2025	0
GearFlat	0	0	0	0	f	Off Season 2025	0
GearNeedle	0	0	0	0	f	Off Season 2025	0
GearPoint	0	0	0	0	f	Off Season 2025	0
GearRush	0	0	0	0	f	Off Season 2025	0
Glide	0	0	0	0	f	Off Season 2025	0
Hexa	6	5	7	2363	f	Off Season 2025	0
HighNeedle	0	0	0	0	f	Off Season 2025	0
HighTaper	0	0	0	0	f	Off Season 2025	0
Kick	2	2	8	1157	f	Off Season 2025	0
Level	1	1	0	364	f	Off Season 2025	0
LowFlat	0	1	3	236	f	Off Season 2025	0
LowOrb	1	0	0	130	f	Off Season 2025	0
\.


--
-- Data for Name: blade_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blade_stats (blade, primi_posti, secondi_posti, terzi_posti, punteggio_totale, season, quarti_posti) FROM stdin;
AeroPegasus	0	0	0	0	Off Season 2025	0
Arc	0	0	0	0	Off Season 2025	0
BearScratch	0	0	0	0	Off Season 2025	0
BlackShell	0	0	0	0	Off Season 2025	0
Bolt	0	0	0	0	Off Season 2025	0
Brave	0	0	0	0	Off Season 2025	0
Brush	0	0	0	0	Off Season 2025	0
CobaltDrake	0	0	0	0	Off Season 2025	0
CrimsonGaruda	0	0	0	0	Off Season 2025	0
CrocCrunch	0	0	0	0	Off Season 2025	0
Dark	0	0	0	0	Off Season 2025	0
DarthVader	0	0	0	0	Off Season 2025	0
DracielShield	0	0	0	0	Off Season 2025	0
DragoonStorm	0	0	0	0	Off Season 2025	0
DranBuster	0	0	1	60	Off Season 2025	0
DranSword	0	0	1	120	Off Season 2025	0
ShelterDrake	0	0	0	0	Off Season 2025	0
ShinobiKnife	0	0	0	0	Off Season 2025	0
ShinobiShadow	0	0	0	0	Off Season 2025	0
SilverWolf	4	3	8	2116	Off Season 2025	0
SphinxCowl	0	0	0	0	Off Season 2025	0
Spider-Man	0	0	0	0	Off Season 2025	0
Spinosaurus	0	0	0	0	Off Season 2025	0
StormPegasus	0	0	0	0	Off Season 2025	0
TackleGoat	0	0	0	0	Off Season 2025	0
Thanos	0	0	0	0	Off Season 2025	0
TriceraPress	0	0	0	0	Off Season 2025	0
TyrannoRoar	0	0	1	60	Off Season 2025	0
UnicornSting	0	0	0	0	Off Season 2025	0
Venom	0	0	0	0	Off Season 2025	0
VictoryValkyrie	0	0	0	0	Off Season 2025	0
ViperTail	0	0	0	0	Off Season 2025	0
WeissTiger	0	0	0	0	Off Season 2025	0
WhaleWave	0	0	0	0	Off Season 2025	0
WizardArrow	0	0	0	0	Off Season 2025	0
WizardRod	7	9	10	3560	Off Season 2025	0
WyvernGale	0	0	0	0	Off Season 2025	0
XenoXcalibur	0	0	0	0	Off Season 2025	0
YellKong	0	0	0	0	Off Season 2025	0
KnightLance	0	0	0	0	Off Season 2025	0
KnightMail	2	0	4	715	Off Season 2025	0
Kraken	0	0	0	0	Off Season 2025	0
LeonClaw	0	0	0	0	Off Season 2025	0
LeonCrest	0	0	0	0	Off Season 2025	0
LightningL-Drago	0	0	0	0	Off Season 2025	0
MammothTusk	0	0	0	0	Off Season 2025	0
Might	0	0	0	0	Off Season 2025	0
MoffGideon	0	0	0	0	Off Season 2025	0
Mosasaurus	0	0	0	0	Off Season 2025	0
OptimusPrimal	0	0	0	0	Off Season 2025	0
OptimusPrime	0	0	0	0	Off Season 2025	0
PhoenixFeather	0	0	0	0	Off Season 2025	0
PhoenixRudder	0	0	0	0	Off Season 2025	0
Blast	2	4	0	995	Off Season 2025	0
ClockMirage	0	0	0	0	Off Season 2025	0
CobaltDragoon	2	2	3	1086	Off Season 2025	0
DranDagger	0	0	2	105	Off Season 2025	0
DranzerSpiral	0	0	0	0	Off Season 2025	0
DrigerSlash	0	0	0	0	Off Season 2025	0
Eclipse	0	0	0	0	Off Season 2025	0
Flame	0	0	0	0	Off Season 2025	0
PhoenixWing	3	5	4	1230	Off Season 2025	0
GeneralGrievous	0	0	0	0	Off Season 2025	0
GhostCircle	0	0	0	0	Off Season 2025	0
GillShark	0	0	0	0	Off Season 2025	0
GolemRock	0	0	1	150	Off Season 2025	0
HellsChain	0	0	0	0	Off Season 2025	0
HellsHammer	0	0	0	0	Off Season 2025	0
HellsScythe	0	0	0	0	Off Season 2025	0
Hornet	0	0	0	0	Off Season 2025	0
HoverWyvern	1	1	3	424	Off Season 2025	0
ImpactDrake	0	1	1	350	Off Season 2025	0
Reaper	0	0	0	0	Off Season 2025	0
RhinoHorn	0	0	0	0	Off Season 2025	0
RockLeone	0	0	0	0	Off Season 2025	0
SamuraiCalibur	0	0	0	0	Off Season 2025	0
SamuraiSaber	0	0	4	205	Off Season 2025	0
SamuraiSteel	0	0	0	0	Off Season 2025	0
ScorpioSpear	0	0	0	0	Off Season 2025	0
SharkEdge	0	0	3	145	Off Season 2025	0
SharkScale	7	5	9	2938	Off Season 2025	0
KnightShield	0	0	0	0	Off Season 2025	0
PteraSwing	0	0	0	0	Off Season 2025	0
TyrannoBeat	2	0	2	525	Off Season 2025	0
\.


--
-- Data for Name: challonge_match_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.challonge_match_results (id, tournament_id, data, fetched_at) FROM stdin;
730	6xr4urpr	{"id": "6xr4urpr", "standings": [{"name": "Hyskel", "rank": 1, "is_top_cut": true}, {"name": "Zanna85", "rank": 2, "is_top_cut": true}, {"name": "_arAle_", "rank": 3, "is_top_cut": true}, {"name": "Raidenkiuby", "rank": 4, "is_top_cut": true}, {"name": "Xliga", "rank": 5, "is_top_cut": true}, {"name": "masterpippo", "rank": 6, "is_top_cut": true}, {"name": "edomark", "rank": 7, "is_top_cut": true}, {"name": "Twins_2016", "rank": 8, "is_top_cut": true}, {"name": "POWDER_07", "rank": 9, "is_top_cut": false}, {"name": "BladerX1", "rank": 10, "is_top_cut": false}, {"name": "Pr1m0s", "rank": 11, "is_top_cut": false}, {"name": "Edo2016", "rank": 12, "is_top_cut": false}, {"name": "Fried_Toxic_Rice", "rank": 13, "is_top_cut": false}, {"name": "leogiova", "rank": 14, "is_top_cut": false}, {"name": "Dheidhara", "rank": 15, "is_top_cut": false}, {"name": "Alexsp93", "rank": 16, "is_top_cut": false}, {"name": "FranciBerto", "rank": 17, "is_top_cut": false}, {"name": "Scarlet25", "rank": 18, "is_top_cut": false}, {"name": "Bellaccia", "rank": 19, "is_top_cut": false}, {"name": "Giaruto", "rank": 20, "is_top_cut": false}, {"name": "RikuGG_", "rank": 21, "is_top_cut": false}, {"name": "Draxler811_", "rank": 22, "is_top_cut": false}, {"name": "Cosetta00", "rank": 23, "is_top_cut": false}, {"name": "Chef_Rossini", "rank": 24, "is_top_cut": false}, {"name": "Enri2016", "rank": 25, "is_top_cut": false}, {"name": "MetalClover", "rank": 26, "is_top_cut": false}, {"name": "Sarina01", "rank": 27, "is_top_cut": false}, {"name": "LeohLKing", "rank": 28, "is_top_cut": false}, {"name": "#MaiunaGioia", "rank": 29, "is_top_cut": false}, {"name": "Vergio101", "rank": 30, "is_top_cut": false}, {"name": "AndrewLKing", "rank": 31, "is_top_cut": false}, {"name": "KinomiyaTakao", "rank": 32, "is_top_cut": false}, {"name": "Ehisnam", "rank": 33, "is_top_cut": false}, {"name": "SledgeHammer94", "rank": 34, "is_top_cut": false}, {"name": "India_Pale_Ale", "rank": 35, "is_top_cut": false}, {"name": "Xtiranno", "rank": 36, "is_top_cut": false}, {"name": "Tomax09", "rank": 37, "is_top_cut": false}, {"name": "SpaceGirlfriend", "rank": 38, "is_top_cut": false}, {"name": "Blader N", "rank": 39, "is_top_cut": false}, {"name": "Asriel2", "rank": 40, "is_top_cut": false}, {"name": "Pevons", "rank": 41, "is_top_cut": false}, {"name": "Idignio", "rank": 42, "is_top_cut": false}], "start_date": "2026-02-07T00:00:00", "total_players": 42, "tournament_name": "07/02 Rhino Revenge - Ranked B4M - IBNA - Classifiche"}	2026-08-21 16:54:31.70504
731	z15r7cvs	{"id": "z15r7cvs", "standings": [{"name": "DrHats", "rank": 1, "is_top_cut": true}, {"name": "Pr1m0s", "rank": 2, "is_top_cut": true}, {"name": "Fried_Toxic_Rice", "rank": 3, "is_top_cut": true}, {"name": "Buscaduto", "rank": 4, "is_top_cut": true}, {"name": "BLÅCKJÅCK", "rank": 5, "is_top_cut": true}, {"name": "GerroBlader", "rank": 6, "is_top_cut": true}, {"name": "Enri2016", "rank": 7, "is_top_cut": true}, {"name": "Sarina01", "rank": 8, "is_top_cut": true}, {"name": "Twins_2016", "rank": 9, "is_top_cut": true}, {"name": "KaghemushaSama", "rank": 10, "is_top_cut": true}, {"name": "ToMs0", "rank": 11, "is_top_cut": true}, {"name": "Jimmy1996", "rank": 12, "is_top_cut": true}, {"name": "Vinci31", "rank": 13, "is_top_cut": true}, {"name": "Laura19", "rank": 14, "is_top_cut": true}, {"name": "Cricco", "rank": 15, "is_top_cut": true}, {"name": "4RTV", "rank": 16, "is_top_cut": true}, {"name": "Edo2016", "rank": 17, "is_top_cut": false}, {"name": "Gabrimarche", "rank": 18, "is_top_cut": false}, {"name": "Cobralori", "rank": 19, "is_top_cut": false}, {"name": "FrancisFordTrottola", "rank": 20, "is_top_cut": false}, {"name": "BladerX1", "rank": 21, "is_top_cut": false}, {"name": "KPopBlade", "rank": 22, "is_top_cut": false}, {"name": "cosonakking3000", "rank": 23, "is_top_cut": false}, {"name": "Tiresia_", "rank": 24, "is_top_cut": false}, {"name": "Sapux", "rank": 25, "is_top_cut": false}, {"name": "Ros Bey", "rank": 26, "is_top_cut": false}, {"name": "Superabo56", "rank": 27, "is_top_cut": false}, {"name": "TirannoNico", "rank": 28, "is_top_cut": false}, {"name": "Mazinga2016", "rank": 29, "is_top_cut": false}, {"name": "smvr8", "rank": 30, "is_top_cut": false}, {"name": "Jakson", "rank": 31, "is_top_cut": false}, {"name": "Shadow", "rank": 32, "is_top_cut": false}, {"name": "Nico13", "rank": 33, "is_top_cut": false}], "start_date": "2026-03-08T00:00:00", "total_players": 33, "tournament_name": "TORNEO RISING PHOENIX RANKED 08/03 - IBNA STANDARD 2026 - Classifiche"}	2026-08-21 16:54:32.201834
732	wy6r80ia	{"id": "wy6r80ia", "standings": [{"name": "Deca96", "rank": 1, "is_top_cut": true}, {"name": "4RTV", "rank": 2, "is_top_cut": true}, {"name": "Laura19", "rank": 3, "is_top_cut": true}, {"name": "Alnas", "rank": 4, "is_top_cut": true}, {"name": "_Eva01", "rank": 5, "is_top_cut": true}, {"name": "Pobaz98", "rank": 5, "is_top_cut": true}, {"name": "Pr1m0s", "rank": 5, "is_top_cut": true}, {"name": "SaltyKessi", "rank": 5, "is_top_cut": true}, {"name": "ROSBLADE", "rank": 9, "is_top_cut": false}, {"name": "Maestro_Miyagi", "rank": 10, "is_top_cut": false}, {"name": "DrHats", "rank": 11, "is_top_cut": false}, {"name": "RingLords", "rank": 12, "is_top_cut": false}, {"name": "AlanLee86", "rank": 13, "is_top_cut": false}, {"name": "Nico13", "rank": 14, "is_top_cut": false}, {"name": "beerdcello66", "rank": 15, "is_top_cut": false}, {"name": "Matty92bey", "rank": 16, "is_top_cut": false}, {"name": "Gabrimarche", "rank": 17, "is_top_cut": false}], "start_date": "2026-03-17T00:00:00", "total_players": 17, "tournament_name": "TORNEO MIYAGI-DO e RISING PHOENIX RANKED 17/03 - IBNA 2026 - Classifiche"}	2026-08-21 16:54:32.759471
733	lw5fru8v	{"id": "lw5fru8v", "standings": [{"name": "Bicbo", "rank": 1, "is_top_cut": true}, {"name": "JuliusHyodo", "rank": 2, "is_top_cut": true}, {"name": "AuraTaccons", "rank": 3, "is_top_cut": true}, {"name": "ShonBeyXx", "rank": 4, "is_top_cut": true}, {"name": "Ubekage", "rank": 5, "is_top_cut": true}, {"name": "Emmet77", "rank": 6, "is_top_cut": true}, {"name": "Nerkio", "rank": 7, "is_top_cut": true}, {"name": "Mr_Fuffolone", "rank": 8, "is_top_cut": true}, {"name": "Massimassi", "rank": 9, "is_top_cut": false}, {"name": "Miani83", "rank": 10, "is_top_cut": false}, {"name": "Jonathan2011", "rank": 11, "is_top_cut": false}, {"name": "Gabbob", "rank": 12, "is_top_cut": false}, {"name": "Newteam91", "rank": 13, "is_top_cut": false}, {"name": "Ludix96", "rank": 14, "is_top_cut": false}, {"name": "Federeeeco", "rank": 15, "is_top_cut": false}, {"name": "Bastoos", "rank": 16, "is_top_cut": false}, {"name": "Marty20xx", "rank": 17, "is_top_cut": false}, {"name": "Jay_Mugiwara", "rank": 18, "is_top_cut": false}, {"name": "Brian303", "rank": 19, "is_top_cut": false}, {"name": "Crusblade", "rank": 20, "is_top_cut": false}, {"name": "Red", "rank": 21, "is_top_cut": false}, {"name": "Barone83", "rank": 22, "is_top_cut": false}, {"name": "Musshu", "rank": 23, "is_top_cut": false}, {"name": "Mr_Tuna_Head", "rank": 24, "is_top_cut": false}, {"name": "Gringo", "rank": 25, "is_top_cut": false}, {"name": "Brettbbx", "rank": 26, "is_top_cut": false}, {"name": "_M1RAGE_", "rank": 27, "is_top_cut": false}, {"name": "JohnBey", "rank": 28, "is_top_cut": false}, {"name": "Paolomu_99", "rank": 29, "is_top_cut": false}, {"name": "_D_Hakkai", "rank": 30, "is_top_cut": false}, {"name": "SoraKurosaki", "rank": 31, "is_top_cut": false}, {"name": "idril20xx", "rank": 32, "is_top_cut": false}, {"name": "Toncho04", "rank": 33, "is_top_cut": false}, {"name": "Anatra_finale", "rank": 34, "is_top_cut": false}, {"name": "GengisChad", "rank": 35, "is_top_cut": false}, {"name": "SoLollo", "rank": 36, "is_top_cut": false}, {"name": "Alicino_AFST", "rank": 37, "is_top_cut": false}, {"name": "Balentine_AFST", "rank": 38, "is_top_cut": false}], "start_date": "2026-02-28T00:00:00", "total_players": 38, "tournament_name": "Torneo Wildfire - 28/02/26 - Standard Tappa Beyleague 16/16 - Classifiche"}	2026-08-21 16:54:33.24549
735	a2h0jk6t	{"id": "a2h0jk6t", "standings": [{"name": "Rednoe", "rank": 1, "is_top_cut": true}, {"name": "leogiova", "rank": 2, "is_top_cut": true}, {"name": "Twins_2016", "rank": 3, "is_top_cut": true}, {"name": "JerryUomoFagiolo", "rank": 4, "is_top_cut": true}, {"name": "SledgeHammer94", "rank": 5, "is_top_cut": true}, {"name": "ell_deablo", "rank": 6, "is_top_cut": true}, {"name": "Raidenkiuby", "rank": 7, "is_top_cut": true}, {"name": "Edo2016", "rank": 8, "is_top_cut": true}, {"name": "HADES93", "rank": 9, "is_top_cut": false}, {"name": "Matty93", "rank": 10, "is_top_cut": false}, {"name": "Simojr98", "rank": 11, "is_top_cut": false}, {"name": "Thalor", "rank": 12, "is_top_cut": false}, {"name": "Cippi", "rank": 13, "is_top_cut": false}, {"name": "Mr.Co", "rank": 14, "is_top_cut": false}, {"name": "Sara_loca_99", "rank": 15, "is_top_cut": false}, {"name": "Xliga", "rank": 16, "is_top_cut": false}, {"name": "Belair_", "rank": 17, "is_top_cut": false}, {"name": "ManuBart", "rank": 18, "is_top_cut": false}, {"name": "Hyskel", "rank": 19, "is_top_cut": false}, {"name": "gidio96", "rank": 20, "is_top_cut": false}, {"name": "Idignio", "rank": 21, "is_top_cut": false}, {"name": "CAMSO", "rank": 22, "is_top_cut": false}, {"name": "Moffone", "rank": 23, "is_top_cut": false}, {"name": "SeregonX", "rank": 24, "is_top_cut": false}, {"name": "Furia888", "rank": 25, "is_top_cut": false}, {"name": "The_brother_91", "rank": 26, "is_top_cut": false}, {"name": "Pevons", "rank": 27, "is_top_cut": false}, {"name": "#MaiunaGioia", "rank": 28, "is_top_cut": false}, {"name": "TheGreat_Kurama", "rank": 29, "is_top_cut": false}, {"name": "Pacis", "rank": 30, "is_top_cut": false}, {"name": "Corinzio", "rank": 31, "is_top_cut": false}, {"name": "Korise", "rank": 32, "is_top_cut": false}, {"name": "Remio", "rank": 33, "is_top_cut": false}, {"name": "B14g10", "rank": 34, "is_top_cut": false}, {"name": "MuLaN_X", "rank": 35, "is_top_cut": false}, {"name": "Filiphs24", "rank": 36, "is_top_cut": false}, {"name": "Fumo95", "rank": 37, "is_top_cut": false}, {"name": "Sephiroth555", "rank": 38, "is_top_cut": false}, {"name": "BladerX1", "rank": 39, "is_top_cut": false}, {"name": "Rmastu", "rank": 40, "is_top_cut": false}, {"name": "bas1", "rank": 41, "is_top_cut": false}, {"name": "Bellaccia", "rank": 42, "is_top_cut": false}, {"name": "AleCecca", "rank": 43, "is_top_cut": false}, {"name": "Enri2016", "rank": 44, "is_top_cut": false}, {"name": "Tomax09", "rank": 45, "is_top_cut": false}, {"name": "Pr1m0s", "rank": 46, "is_top_cut": false}, {"name": "Alexsp93", "rank": 47, "is_top_cut": false}, {"name": "Sarina01", "rank": 48, "is_top_cut": false}, {"name": "OffTravel", "rank": 49, "is_top_cut": false}, {"name": "polly91mat", "rank": 50, "is_top_cut": false}, {"name": "KinomiyaTakao", "rank": 51, "is_top_cut": false}, {"name": "Cosetta00", "rank": 52, "is_top_cut": false}, {"name": "BladderN", "rank": 53, "is_top_cut": false}, {"name": "Edèku", "rank": 54, "is_top_cut": false}], "start_date": "2026-02-22T00:00:00", "total_players": 54, "tournament_name": "Ice Wolf Club Ancona x B4M"}	2026-08-21 16:54:34.22655
749	zrsiawkk	{"id": "zrsiawkk", "standings": [{"name": "Simorux", "rank": 1, "is_top_cut": true}, {"name": "MGNathan", "rank": 2, "is_top_cut": true}, {"name": "FLOGGY_THE_WIZARD", "rank": 3, "is_top_cut": true}, {"name": "Pivessio", "rank": 4, "is_top_cut": true}, {"name": "ataler_f2", "rank": 5, "is_top_cut": true}, {"name": "Ennardo", "rank": 5, "is_top_cut": true}, {"name": "MZtore", "rank": 5, "is_top_cut": true}, {"name": "Ryzer_og", "rank": 5, "is_top_cut": true}, {"name": "DonLopez", "rank": 9, "is_top_cut": true}, {"name": "Tijen", "rank": 9, "is_top_cut": true}, {"name": "KhromeRyughu67", "rank": 3, "is_top_cut": false}, {"name": "AlessioC_05", "rank": 3, "is_top_cut": false}, {"name": "alberto_ruffy", "rank": 3, "is_top_cut": false}, {"name": "Euge7198", "rank": 3, "is_top_cut": false}, {"name": "KUROSU10", "rank": 3, "is_top_cut": false}, {"name": "Cerys04", "rank": 4, "is_top_cut": false}, {"name": "Izba_prj", "rank": 4, "is_top_cut": false}, {"name": "Niihon", "rank": 4, "is_top_cut": false}, {"name": "Niko2410", "rank": 4, "is_top_cut": false}, {"name": "Zaelion", "rank": 4, "is_top_cut": false}, {"name": "zero_90", "rank": 5, "is_top_cut": false}, {"name": "Kapparella", "rank": 5, "is_top_cut": false}, {"name": "Ranur", "rank": 5, "is_top_cut": false}, {"name": "Loris", "rank": 5, "is_top_cut": false}, {"name": "Dallaio", "rank": 5, "is_top_cut": false}, {"name": "Limboh", "rank": 6, "is_top_cut": false}, {"name": "EXO358", "rank": 6, "is_top_cut": false}, {"name": "youngsta1017", "rank": 6, "is_top_cut": false}, {"name": "Isabey", "rank": 6, "is_top_cut": false}, {"name": "IMEØN", "rank": 6, "is_top_cut": false}, {"name": "Andrephoenix", "rank": 7, "is_top_cut": false}, {"name": "_Freezer_", "rank": 7, "is_top_cut": false}, {"name": "johnnyrobomeka", "rank": 7, "is_top_cut": false}, {"name": "Hammer_Savio", "rank": 7, "is_top_cut": false}, {"name": "donnola_17", "rank": 7, "is_top_cut": false}, {"name": "Cris391", "rank": 8, "is_top_cut": false}, {"name": "ABBACS", "rank": 8, "is_top_cut": false}, {"name": "Jonny_21", "rank": 8, "is_top_cut": false}, {"name": "Avventuriero", "rank": 8, "is_top_cut": false}, {"name": "1V0", "rank": 8, "is_top_cut": false}, {"name": "_aletreecko_", "rank": 9, "is_top_cut": false}, {"name": "Bey_Sabbath", "rank": 9, "is_top_cut": false}, {"name": "Jean_05", "rank": 9, "is_top_cut": false}, {"name": "__ENGINE__", "rank": 9, "is_top_cut": false}, {"name": "ElbryanXV", "rank": 9, "is_top_cut": false}], "start_date": "2026-02-08T00:00:00", "total_players": 45, "tournament_name": "GamesInn Torino 08/02 - SteelFangs - Classifiche"}	2026-08-21 16:54:41.374589
750	d16ujxqy	{"id": "d16ujxqy", "standings": [{"name": "Imperatore_Level22", "rank": 1, "is_top_cut": true}, {"name": "Ikigai06", "rank": 2, "is_top_cut": true}, {"name": "PennaRigata", "rank": 3, "is_top_cut": true}, {"name": "Acesword", "rank": 4, "is_top_cut": true}, {"name": "AlphaXEND", "rank": 5, "is_top_cut": false}, {"name": "robb_430", "rank": 6, "is_top_cut": false}, {"name": "alessandro_iv", "rank": 7, "is_top_cut": false}, {"name": "BladerLui", "rank": 8, "is_top_cut": false}, {"name": "louissan", "rank": 9, "is_top_cut": false}, {"name": "Aster94", "rank": 10, "is_top_cut": false}, {"name": "GyroRad", "rank": 11, "is_top_cut": false}, {"name": "duemilaventitre", "rank": 12, "is_top_cut": false}, {"name": "P_Rocka", "rank": 13, "is_top_cut": false}, {"name": "B3rserker", "rank": 14, "is_top_cut": false}, {"name": "ToninoX", "rank": 15, "is_top_cut": false}, {"name": "Manty72", "rank": 16, "is_top_cut": false}, {"name": "Sharkina😈", "rank": 17, "is_top_cut": false}, {"name": "LaLacrimaDeFragtrap", "rank": 18, "is_top_cut": false}, {"name": "Masèō_8", "rank": 19, "is_top_cut": false}, {"name": "Adrixp08", "rank": 20, "is_top_cut": false}, {"name": "Scavabuchi", "rank": 21, "is_top_cut": false}, {"name": "Blader126", "rank": 22, "is_top_cut": false}, {"name": "Stabi23", "rank": 23, "is_top_cut": false}, {"name": "Miba88", "rank": 24, "is_top_cut": false}, {"name": "mariovongola", "rank": 25, "is_top_cut": false}, {"name": "Cool_man01", "rank": 26, "is_top_cut": false}], "start_date": "2026-02-01T00:00:00", "total_players": 26, "tournament_name": "Gan Gan Galaxy Tournament- 01/02 Standard 2026 - Classifiche"}	2026-08-21 16:54:41.904003
736	gcb2ydvb	{"id": "gcb2ydvb", "standings": [{"name": "Blaster_Hydra", "rank": 1, "is_top_cut": true}, {"name": "EsDeeShark", "rank": 2, "is_top_cut": true}, {"name": "Giann19", "rank": 3, "is_top_cut": true}, {"name": "Sunshine", "rank": 4, "is_top_cut": true}, {"name": "3NTØNY", "rank": 5, "is_top_cut": true}, {"name": "FrancisFordTrottola", "rank": 6, "is_top_cut": true}, {"name": "Myridar", "rank": 7, "is_top_cut": true}, {"name": "Souten_no_ken", "rank": 8, "is_top_cut": true}, {"name": "Bronev", "rank": 9, "is_top_cut": true}, {"name": "Deledea", "rank": 10, "is_top_cut": true}, {"name": "DooMS20", "rank": 11, "is_top_cut": true}, {"name": "MaT1806", "rank": 12, "is_top_cut": true}, {"name": "Orticoltore", "rank": 13, "is_top_cut": true}, {"name": "SfornaPatateDolci", "rank": 14, "is_top_cut": true}, {"name": "Snoop17", "rank": 15, "is_top_cut": true}, {"name": "Ste67_Motivated", "rank": 16, "is_top_cut": true}, {"name": "Fyxit", "rank": 17, "is_top_cut": false}, {"name": "Suaveeee", "rank": 18, "is_top_cut": false}, {"name": "Ispanico1986", "rank": 19, "is_top_cut": false}, {"name": "Jaypoy", "rank": 20, "is_top_cut": false}, {"name": "Xaldin99", "rank": 21, "is_top_cut": false}, {"name": "EOT_Negros", "rank": 22, "is_top_cut": false}, {"name": "Chriss18", "rank": 23, "is_top_cut": false}, {"name": "SnoopDoggX", "rank": 24, "is_top_cut": false}, {"name": "Ryckylyck", "rank": 25, "is_top_cut": false}, {"name": "SIGLA", "rank": 26, "is_top_cut": false}, {"name": "Tiziano_Banano", "rank": 27, "is_top_cut": false}, {"name": "SyNC0", "rank": 28, "is_top_cut": false}, {"name": "Laura19", "rank": 29, "is_top_cut": false}, {"name": "_J_O_K_E_R_", "rank": 30, "is_top_cut": false}, {"name": "CrudeliaDeMon", "rank": 31, "is_top_cut": false}, {"name": "Enrico_Pakinko", "rank": 32, "is_top_cut": false}, {"name": "KaghemushaSama", "rank": 33, "is_top_cut": false}, {"name": "Mr_baobab", "rank": 34, "is_top_cut": false}, {"name": "Gique", "rank": 35, "is_top_cut": false}, {"name": "Fried_Toxic_Rice", "rank": 36, "is_top_cut": false}, {"name": "chicosnef", "rank": 37, "is_top_cut": false}, {"name": "EarvS", "rank": 38, "is_top_cut": false}, {"name": "Blade_Sabbath", "rank": 39, "is_top_cut": false}, {"name": "ChiperZero1", "rank": 40, "is_top_cut": false}, {"name": "Lore_knight", "rank": 41, "is_top_cut": false}, {"name": "Santa89", "rank": 42, "is_top_cut": false}, {"name": "ToRoAdry", "rank": 43, "is_top_cut": false}, {"name": "Donkeymax", "rank": 44, "is_top_cut": false}, {"name": "Giammi", "rank": 45, "is_top_cut": false}, {"name": "Renegaderene", "rank": 46, "is_top_cut": false}, {"name": "Giko89", "rank": 47, "is_top_cut": false}, {"name": "Alo_thegunsl1nger", "rank": 48, "is_top_cut": false}], "start_date": "2026-02-27T00:00:00", "total_players": 48, "tournament_name": "AEROSPHYNX - RANKED 27/02/2026"}	2026-08-21 16:54:34.741357
737	xbo831ib	{"id": "xbo831ib", "standings": [{"name": "_Snoozer", "rank": 1, "is_top_cut": true}, {"name": "duemilaventitre", "rank": 2, "is_top_cut": true}, {"name": "Eziusnanni", "rank": 3, "is_top_cut": true}, {"name": "Masèō_8", "rank": 4, "is_top_cut": true}, {"name": "Ganga", "rank": 5, "is_top_cut": false}, {"name": "Imperatore_Level22", "rank": 6, "is_top_cut": false}, {"name": "B3rserker", "rank": 7, "is_top_cut": false}, {"name": "Mara", "rank": 8, "is_top_cut": false}], "start_date": "2026-02-27T00:00:00", "total_players": 8, "tournament_name": "Aghislow - Classifiche"}	2026-08-21 16:54:35.242258
738	helr1zdy	{"id": "helr1zdy", "standings": [{"name": "Tiziano_Banano", "rank": 1, "is_top_cut": true}, {"name": "ELCULON", "rank": 2, "is_top_cut": true}, {"name": "Xaldin99", "rank": 3, "is_top_cut": true}, {"name": "_J_O_K_E_R_", "rank": 4, "is_top_cut": true}, {"name": "_Greta_96", "rank": 5, "is_top_cut": true}, {"name": "_Kenzo", "rank": 5, "is_top_cut": true}, {"name": "Beltram", "rank": 5, "is_top_cut": true}, {"name": "CrudeliaDeMon", "rank": 5, "is_top_cut": true}, {"name": "Dante9053", "rank": 9, "is_top_cut": true}, {"name": "Dedours", "rank": 9, "is_top_cut": true}, {"name": "Donkeymax", "rank": 9, "is_top_cut": true}, {"name": "MaT1806", "rank": 9, "is_top_cut": true}, {"name": "Nonnonanni", "rank": 9, "is_top_cut": true}, {"name": "nova", "rank": 9, "is_top_cut": true}, {"name": "Palissandro", "rank": 9, "is_top_cut": true}, {"name": "RoboBarat", "rank": 9, "is_top_cut": true}, {"name": "SIGLA", "rank": 17, "is_top_cut": false}, {"name": "RingLords", "rank": 18, "is_top_cut": false}, {"name": "CrispyDanger", "rank": 19, "is_top_cut": false}, {"name": "Escariota", "rank": 20, "is_top_cut": false}, {"name": "ll_Ezecutor-iBh", "rank": 21, "is_top_cut": false}, {"name": "LucaZambro", "rank": 22, "is_top_cut": false}, {"name": "_Marks", "rank": 23, "is_top_cut": false}, {"name": "ToRoAdry", "rank": 24, "is_top_cut": false}, {"name": "Merca94", "rank": 25, "is_top_cut": false}, {"name": "DemonSampei", "rank": 26, "is_top_cut": false}, {"name": "Enrico_Pakinko", "rank": 27, "is_top_cut": false}, {"name": "PhilRy", "rank": 28, "is_top_cut": false}, {"name": "Viper X", "rank": 29, "is_top_cut": false}, {"name": "Wolverine", "rank": 30, "is_top_cut": false}, {"name": "Myridar", "rank": 31, "is_top_cut": false}, {"name": "SyNC0", "rank": 32, "is_top_cut": false}, {"name": "IronGabry", "rank": 33, "is_top_cut": false}, {"name": "Giammi08", "rank": 34, "is_top_cut": false}, {"name": "Charizard_18", "rank": 35, "is_top_cut": false}, {"name": "Adri_81", "rank": 36, "is_top_cut": false}, {"name": "Blade_Sabbath", "rank": 37, "is_top_cut": false}, {"name": "PrincipessaPeach", "rank": 38, "is_top_cut": false}, {"name": "DeadSpall", "rank": 39, "is_top_cut": false}, {"name": "Scrotobleyder", "rank": 40, "is_top_cut": false}, {"name": "TeoBerto", "rank": 41, "is_top_cut": false}, {"name": "Fra86170", "rank": 42, "is_top_cut": false}, {"name": "SfornaPatate", "rank": 43, "is_top_cut": false}, {"name": "BruteForce", "rank": 44, "is_top_cut": false}, {"name": "ChiperZero1", "rank": 45, "is_top_cut": false}, {"name": "Redd0", "rank": 46, "is_top_cut": false}, {"name": "LL_blader_15", "rank": 47, "is_top_cut": false}, {"name": "Skizzo10", "rank": 48, "is_top_cut": false}, {"name": "StormPrelude", "rank": 49, "is_top_cut": false}, {"name": "gioepifani", "rank": 50, "is_top_cut": false}], "start_date": "2026-02-07T00:00:00", "total_players": 50, "tournament_name": "Alma Draco Bologna 1° Ranked IBNA 07/02/2026 - Classifiche"}	2026-08-21 16:54:35.707607
739	bzlpagcr	{"id": "bzlpagcr", "standings": [{"name": "CrudeliaDeMon", "rank": 1, "is_top_cut": true}, {"name": "ContactBlader", "rank": 2, "is_top_cut": true}, {"name": "Deledea", "rank": 3, "is_top_cut": true}, {"name": "Oh_Nico", "rank": 4, "is_top_cut": true}, {"name": "Skizzo10", "rank": 5, "is_top_cut": true}, {"name": "SIGLA", "rank": 6, "is_top_cut": true}, {"name": "Sunshine", "rank": 7, "is_top_cut": true}, {"name": "Escariota", "rank": 8, "is_top_cut": true}, {"name": "ELCULON", "rank": 9, "is_top_cut": true}, {"name": "Dedours", "rank": 10, "is_top_cut": true}, {"name": "Tiziano_Banano", "rank": 11, "is_top_cut": true}, {"name": "Leventiel", "rank": 12, "is_top_cut": true}, {"name": "EOT_Negros", "rank": 13, "is_top_cut": true}, {"name": "Wm7", "rank": 14, "is_top_cut": true}, {"name": "SfornaPatate", "rank": 15, "is_top_cut": true}, {"name": "Renegaderene", "rank": 16, "is_top_cut": true}, {"name": "♤PhilRy♤", "rank": 17, "is_top_cut": false}, {"name": "LucaZambro", "rank": 18, "is_top_cut": false}, {"name": "Bigsimmy", "rank": 19, "is_top_cut": false}, {"name": "StormPrelude", "rank": 20, "is_top_cut": false}, {"name": "Spartaco31", "rank": 21, "is_top_cut": false}, {"name": "Bronev", "rank": 22, "is_top_cut": false}, {"name": "ChiperZero1", "rank": 23, "is_top_cut": false}, {"name": "Nonnonanni", "rank": 24, "is_top_cut": false}, {"name": "TreZLionS", "rank": 25, "is_top_cut": false}, {"name": "NOVA", "rank": 26, "is_top_cut": false}, {"name": "Xaldin99", "rank": 27, "is_top_cut": false}, {"name": "Jaypoy", "rank": 28, "is_top_cut": false}, {"name": "Khaleesi07", "rank": 29, "is_top_cut": false}, {"name": "EarvS", "rank": 30, "is_top_cut": false}, {"name": "Anna70", "rank": 31, "is_top_cut": false}, {"name": "Beltram", "rank": 32, "is_top_cut": false}, {"name": "Suaveeee", "rank": 33, "is_top_cut": false}, {"name": "Papadriou", "rank": 34, "is_top_cut": false}, {"name": "Pikachu_16", "rank": 35, "is_top_cut": false}, {"name": "Cico", "rank": 36, "is_top_cut": false}, {"name": "MaT1806", "rank": 37, "is_top_cut": false}, {"name": "CrispyDanger", "rank": 38, "is_top_cut": false}, {"name": "Skǫll", "rank": 39, "is_top_cut": false}, {"name": "Condor15", "rank": 40, "is_top_cut": false}, {"name": "Myridar", "rank": 41, "is_top_cut": false}, {"name": "ToRoAdry", "rank": 42, "is_top_cut": false}, {"name": "_Marks", "rank": 43, "is_top_cut": false}, {"name": "GZeta", "rank": 44, "is_top_cut": false}, {"name": "BonnyBong", "rank": 45, "is_top_cut": false}, {"name": "Mikelone", "rank": 46, "is_top_cut": false}, {"name": "Viper X", "rank": 47, "is_top_cut": false}, {"name": "Charizard_18", "rank": 48, "is_top_cut": false}, {"name": "RedBandicoot", "rank": 49, "is_top_cut": false}, {"name": "Giovermir", "rank": 50, "is_top_cut": false}], "start_date": "2026-02-021T00:00:00", "total_players": 50, "tournament_name": "Alma Draco RANKED 2026 x IBNA 21/02"}	2026-08-21 16:54:36.20943
740	n23gukyu	{"id": "n23gukyu", "standings": [{"name": "Justjack90", "rank": 1, "is_top_cut": true}, {"name": "TeoBerto", "rank": 2, "is_top_cut": true}, {"name": "ToRoAdry", "rank": 3, "is_top_cut": true}, {"name": "Spartaco31", "rank": 4, "is_top_cut": true}, {"name": "_Ezecutor_iBh", "rank": 5, "is_top_cut": true}, {"name": "ContactBlader", "rank": 5, "is_top_cut": true}, {"name": "Khaleesi07", "rank": 5, "is_top_cut": true}, {"name": "Tiziano_Banano", "rank": 5, "is_top_cut": true}, {"name": "_Greta_96", "rank": 9, "is_top_cut": true}, {"name": "Anna70", "rank": 9, "is_top_cut": true}, {"name": "CrudeliaDeMon", "rank": 9, "is_top_cut": true}, {"name": "DeadSpall", "rank": 9, "is_top_cut": true}, {"name": "ELCULON", "rank": 9, "is_top_cut": true}, {"name": "IronGabry", "rank": 9, "is_top_cut": true}, {"name": "PhilRy", "rank": 9, "is_top_cut": true}, {"name": "Sunshine", "rank": 9, "is_top_cut": true}, {"name": "Suaveeee", "rank": 17, "is_top_cut": false}, {"name": "Myridar", "rank": 18, "is_top_cut": false}, {"name": "Pikachu_16", "rank": 19, "is_top_cut": false}, {"name": "Dante9053", "rank": 20, "is_top_cut": false}, {"name": "Scrotobleyder", "rank": 21, "is_top_cut": false}, {"name": "Bronev", "rank": 22, "is_top_cut": false}, {"name": "SyNC0", "rank": 23, "is_top_cut": false}, {"name": "KaghemushaSama", "rank": 24, "is_top_cut": false}, {"name": "Bigsimmy", "rank": 25, "is_top_cut": false}, {"name": "KOB_14", "rank": 26, "is_top_cut": false}, {"name": "_Kenzo", "rank": 27, "is_top_cut": false}, {"name": "Renegaderene", "rank": 28, "is_top_cut": false}, {"name": "Skizzo10", "rank": 29, "is_top_cut": false}, {"name": "EarvS", "rank": 30, "is_top_cut": false}, {"name": "Giko89", "rank": 31, "is_top_cut": false}, {"name": "Jaypoy", "rank": 32, "is_top_cut": false}, {"name": "Giammi", "rank": 33, "is_top_cut": false}, {"name": "Fra86170", "rank": 34, "is_top_cut": false}, {"name": "Linkin_Shark", "rank": 35, "is_top_cut": false}, {"name": "Wolverine", "rank": 36, "is_top_cut": false}, {"name": "RedBandicoot", "rank": 37, "is_top_cut": false}, {"name": "_Marks", "rank": 38, "is_top_cut": false}, {"name": "N3k019", "rank": 39, "is_top_cut": false}, {"name": "RoboBarat", "rank": 40, "is_top_cut": false}, {"name": "Aaronjulz", "rank": 41, "is_top_cut": false}, {"name": "SIGLA", "rank": 42, "is_top_cut": false}, {"name": "Wm7", "rank": 43, "is_top_cut": false}, {"name": "nova", "rank": 44, "is_top_cut": false}, {"name": "Charizard_18", "rank": 45, "is_top_cut": false}, {"name": "Nanibleyder", "rank": 46, "is_top_cut": false}, {"name": "Cannyburst", "rank": 47, "is_top_cut": false}, {"name": "YoshiroDaiShi_26_teo", "rank": 48, "is_top_cut": false}], "start_date": "2026-02-28T00:00:00", "total_players": 48, "tournament_name": "Alma Draco RANKED 2026 x IBNA 28/02 - Classifiche"}	2026-08-21 16:54:36.725516
734	7u40oymp	{"id": "7u40oymp", "standings": [{"name": "Frakki", "rank": 1, "is_top_cut": true}, {"name": "Dase05_", "rank": 2, "is_top_cut": true}, {"name": "Piramide_", "rank": 3, "is_top_cut": true}, {"name": "Vexel666", "rank": 4, "is_top_cut": true}, {"name": "Andy_bbx", "rank": 5, "is_top_cut": true}, {"name": "ILDISTO", "rank": 6, "is_top_cut": true}, {"name": "AuraFarming", "rank": 7, "is_top_cut": true}, {"name": "Matzuda", "rank": 8, "is_top_cut": true}, {"name": "Giacomo_Proiettile", "rank": 9, "is_top_cut": true}, {"name": "Banaleo49", "rank": 10, "is_top_cut": true}, {"name": "Halloween5264", "rank": 11, "is_top_cut": true}, {"name": "Sofi19", "rank": 12, "is_top_cut": true}, {"name": "IamVulgus", "rank": 13, "is_top_cut": true}, {"name": "Raula97", "rank": 14, "is_top_cut": true}, {"name": "Mago_Nero", "rank": 15, "is_top_cut": true}, {"name": "Mergimiliano", "rank": 16, "is_top_cut": true}, {"name": "Fambrini", "rank": 17, "is_top_cut": false}, {"name": "Doctor_monkey", "rank": 18, "is_top_cut": false}, {"name": "JustPlus", "rank": 19, "is_top_cut": false}, {"name": "RyoSaeba", "rank": 20, "is_top_cut": false}, {"name": "CrystalClod", "rank": 21, "is_top_cut": false}, {"name": "Firefre", "rank": 22, "is_top_cut": false}, {"name": "Dipi999", "rank": 23, "is_top_cut": false}, {"name": "Cosciu", "rank": 24, "is_top_cut": false}, {"name": "Giakos98", "rank": 25, "is_top_cut": false}, {"name": "Debyx", "rank": 26, "is_top_cut": false}, {"name": "Indian_Chey7", "rank": 27, "is_top_cut": false}, {"name": "Brandix", "rank": 28, "is_top_cut": false}, {"name": "LeleGianne", "rank": 29, "is_top_cut": false}, {"name": "Tiamat27", "rank": 30, "is_top_cut": false}, {"name": "_vic_", "rank": 31, "is_top_cut": false}, {"name": "Jacksoncross2017", "rank": 32, "is_top_cut": false}, {"name": "Loreo_", "rank": 33, "is_top_cut": false}, {"name": "Kiokka", "rank": 34, "is_top_cut": false}, {"name": "Edoardo23", "rank": 35, "is_top_cut": false}, {"name": "Mattia17", "rank": 36, "is_top_cut": false}, {"name": "Giovanni_Stempy", "rank": 37, "is_top_cut": false}, {"name": "Solfa3", "rank": 38, "is_top_cut": false}, {"name": "Abbandono_97", "rank": 39, "is_top_cut": false}, {"name": "Lirlandese", "rank": 40, "is_top_cut": false}, {"name": "Tanjiro67", "rank": 41, "is_top_cut": false}, {"name": "Kriperus", "rank": 42, "is_top_cut": false}, {"name": "Matteilpro15", "rank": 43, "is_top_cut": false}, {"name": "Danki0_0", "rank": 44, "is_top_cut": false}, {"name": "Hanayrim", "rank": 45, "is_top_cut": false}, {"name": "Kira45", "rank": 46, "is_top_cut": false}, {"name": "FrancescoLuti", "rank": 47, "is_top_cut": false}, {"name": "Eliopuccinelli", "rank": 48, "is_top_cut": false}, {"name": "Righello", "rank": 49, "is_top_cut": false}, {"name": "Liam2016", "rank": 50, "is_top_cut": false}, {"name": "Aldo_Abbaglio", "rank": 51, "is_top_cut": false}, {"name": "GS9", "rank": 52, "is_top_cut": false}, {"name": "Gabriele10", "rank": 53, "is_top_cut": false}, {"name": "Danielx17", "rank": 54, "is_top_cut": false}, {"name": "YouHateBryan", "rank": 55, "is_top_cut": false}], "start_date": "2026-02-22T00:00:00", "total_players": 55, "tournament_name": "ASTRANOVA - Funside Lucca - 22/02"}	2026-08-21 16:54:37.240063
748	6io456df	{"id": "6io456df", "standings": [{"name": "Twins_2016", "rank": 1, "is_top_cut": true}, {"name": "Fried_Toxic_Rice", "rank": 2, "is_top_cut": true}, {"name": "Ispanico1986", "rank": 3, "is_top_cut": true}, {"name": "GerroBlader", "rank": 4, "is_top_cut": true}, {"name": "Deca96", "rank": 5, "is_top_cut": true}, {"name": "eldefensor", "rank": 6, "is_top_cut": true}, {"name": "Kein_Tamerg", "rank": 7, "is_top_cut": true}, {"name": "Riccio97", "rank": 8, "is_top_cut": true}, {"name": "Shagor", "rank": 9, "is_top_cut": true}, {"name": "AlanLee86", "rank": 10, "is_top_cut": true}, {"name": "Farinella", "rank": 11, "is_top_cut": true}, {"name": "Ceci91", "rank": 12, "is_top_cut": true}, {"name": "Pr1m0s", "rank": 13, "is_top_cut": true}, {"name": "Gabrimarche", "rank": 14, "is_top_cut": true}, {"name": "cosonakking3000", "rank": 15, "is_top_cut": true}, {"name": "Giovy", "rank": 16, "is_top_cut": true}, {"name": "Vinci31", "rank": 17, "is_top_cut": false}, {"name": "Santa89", "rank": 18, "is_top_cut": false}, {"name": "RòX", "rank": 19, "is_top_cut": false}, {"name": "MrLoba29", "rank": 20, "is_top_cut": false}, {"name": "_Eva01", "rank": 21, "is_top_cut": false}, {"name": "Cricco", "rank": 22, "is_top_cut": false}, {"name": "Laura19", "rank": 23, "is_top_cut": false}, {"name": "Sarina01", "rank": 24, "is_top_cut": false}, {"name": "ToMs0", "rank": 25, "is_top_cut": false}, {"name": "drramik", "rank": 26, "is_top_cut": false}, {"name": "DrHats", "rank": 27, "is_top_cut": false}, {"name": "Nicolino1977", "rank": 28, "is_top_cut": false}, {"name": "Mazinga2016", "rank": 29, "is_top_cut": false}, {"name": "FrancisFordTrottola", "rank": 30, "is_top_cut": false}, {"name": "Laura90", "rank": 31, "is_top_cut": false}, {"name": "RingLords", "rank": 32, "is_top_cut": false}, {"name": "KKLord", "rank": 33, "is_top_cut": false}, {"name": "Nastyyy27", "rank": 34, "is_top_cut": false}, {"name": "Francy", "rank": 35, "is_top_cut": false}, {"name": "Jiimmyyy", "rank": 36, "is_top_cut": false}, {"name": "Alo_thegunsl1nger", "rank": 37, "is_top_cut": false}, {"name": "Enri2016", "rank": 38, "is_top_cut": false}, {"name": "ThunderMatthew", "rank": 39, "is_top_cut": false}, {"name": "Trexgiulio", "rank": 40, "is_top_cut": false}, {"name": "keg0", "rank": 41, "is_top_cut": false}, {"name": "Nico13", "rank": 42, "is_top_cut": false}, {"name": "Nunze", "rank": 43, "is_top_cut": false}, {"name": "Edo2016", "rank": 44, "is_top_cut": false}, {"name": "Conralori", "rank": 45, "is_top_cut": false}], "start_date": "2026-02-15T00:00:00", "total_players": 45, "tournament_name": "FUSION EXTREME Ranked RisingPhoenix & Hollow Kraken"}	2026-08-21 16:54:40.845397
742	is7ylxow	{"id": "is7ylxow", "standings": [{"name": "LBladerLui", "rank": 1, "is_top_cut": true}, {"name": "alessandro_iv", "rank": 2, "is_top_cut": true}, {"name": "Nonnechik99", "rank": 3, "is_top_cut": true}, {"name": "Imperatore_Level22", "rank": 4, "is_top_cut": true}, {"name": "robb_430", "rank": 5, "is_top_cut": true}, {"name": "duemilaventitre", "rank": 6, "is_top_cut": true}, {"name": "yuriymo", "rank": 7, "is_top_cut": true}, {"name": "louissan", "rank": 8, "is_top_cut": true}, {"name": "Atarassìa - spacegames-bus", "rank": 9, "is_top_cut": false}, {"name": "Diletta", "rank": 10, "is_top_cut": false}, {"name": "SoloBuildEsotiche", "rank": 11, "is_top_cut": false}, {"name": "LaLacrimaDeFragtrap", "rank": 12, "is_top_cut": false}, {"name": "Eziusnanni", "rank": 13, "is_top_cut": false}, {"name": "Umbeole", "rank": 14, "is_top_cut": false}, {"name": "AlphaXEND", "rank": 15, "is_top_cut": false}, {"name": "Konjo92", "rank": 16, "is_top_cut": false}, {"name": "BlueMida", "rank": 17, "is_top_cut": false}, {"name": "The Watcher", "rank": 18, "is_top_cut": false}, {"name": "Ridnegar", "rank": 19, "is_top_cut": false}, {"name": "D3M1GR4", "rank": 20, "is_top_cut": false}, {"name": "GinTony", "rank": 21, "is_top_cut": false}, {"name": "Cool_man01", "rank": 22, "is_top_cut": false}, {"name": "Ravezim", "rank": 23, "is_top_cut": false}, {"name": "Tano_Ferblade16", "rank": 24, "is_top_cut": false}], "start_date": "2026-02-28T00:00:00", "total_players": 24, "tournament_name": "Cosplay & Games Tournament Gan Gan Galaxy"}	2026-08-21 16:54:37.767275
743	2q9ohfp2	{"id": "2q9ohfp2", "standings": [{"name": "Doungeons &Dragons Niihon", "rank": 1, "is_top_cut": true}, {"name": "magteo", "rank": 2, "is_top_cut": true}, {"name": "Izba_prj", "rank": 3, "is_top_cut": true}, {"name": "Ryzer_og", "rank": 4, "is_top_cut": true}, {"name": "EXO358", "rank": 5, "is_top_cut": true}, {"name": "GorillaZ_98", "rank": 5, "is_top_cut": true}, {"name": "KhromeRyughu67", "rank": 5, "is_top_cut": true}, {"name": "Minerol1", "rank": 5, "is_top_cut": true}, {"name": "Leviatano95", "rank": 9, "is_top_cut": true}, {"name": "Simorux", "rank": 9, "is_top_cut": true}, {"name": "Slide_Off", "rank": 9, "is_top_cut": true}, {"name": "TanoST", "rank": 9, "is_top_cut": true}, {"name": "Doungeons&Dragons Niihon", "rank": 1, "is_top_cut": false}, {"name": "Grizzly_97", "rank": 5, "is_top_cut": false}, {"name": "RUMI", "rank": 5, "is_top_cut": false}, {"name": "Bore33", "rank": 5, "is_top_cut": false}, {"name": "Antonio Rinaldi", "rank": 6, "is_top_cut": false}, {"name": "Loris_Phoenix", "rank": 6, "is_top_cut": false}, {"name": "Fedeco98", "rank": 6, "is_top_cut": false}, {"name": "Soar_Ale", "rank": 7, "is_top_cut": false}, {"name": "Skio69", "rank": 7, "is_top_cut": false}, {"name": "LukeMcWall", "rank": 7, "is_top_cut": false}, {"name": "Malviobbld", "rank": 8, "is_top_cut": false}, {"name": "ataler_f2", "rank": 8, "is_top_cut": false}, {"name": "BLAYDER X", "rank": 8, "is_top_cut": false}, {"name": "NathLL", "rank": 9, "is_top_cut": false}, {"name": "Ennardo", "rank": 9, "is_top_cut": false}, {"name": "Jonny_21", "rank": 9, "is_top_cut": false}, {"name": "1V0", "rank": 10, "is_top_cut": false}, {"name": "PietroMerola", "rank": 10, "is_top_cut": false}, {"name": "FLOGGY_THE_WIZARD", "rank": 10, "is_top_cut": false}, {"name": "Tijen", "rank": 11, "is_top_cut": false}], "start_date": "2026-02-21T00:00:00", "total_players": 31, "tournament_name": "Dark Comics 21/02 SteelFangs - Classifiche"}	2026-08-21 16:54:38.267522
744	dqs8w6n5	{"id": "dqs8w6n5", "standings": [{"name": "riiching901", "rank": 1, "is_top_cut": true}, {"name": "SoraKurosaki", "rank": 2, "is_top_cut": true}, {"name": "_D_Hakkai", "rank": 3, "is_top_cut": true}, {"name": "Leo140419", "rank": 4, "is_top_cut": true}, {"name": "Bicbo", "rank": 5, "is_top_cut": true}, {"name": "Gabbob", "rank": 5, "is_top_cut": true}, {"name": "LucaNP", "rank": 5, "is_top_cut": true}, {"name": "Toncho04", "rank": 5, "is_top_cut": true}, {"name": "Daniele_S", "rank": 9, "is_top_cut": true}, {"name": "Depa19", "rank": 9, "is_top_cut": true}, {"name": "FReechain", "rank": 9, "is_top_cut": true}, {"name": "Geco91", "rank": 9, "is_top_cut": true}, {"name": "IRObb", "rank": 9, "is_top_cut": true}, {"name": "Mad_Blade", "rank": 9, "is_top_cut": true}, {"name": "Monkey_King_Tattoo", "rank": 9, "is_top_cut": true}, {"name": "Shaka1985", "rank": 9, "is_top_cut": true}, {"name": "GHOST__23", "rank": 17, "is_top_cut": false}, {"name": "Miani83", "rank": 18, "is_top_cut": false}, {"name": "SickNova", "rank": 19, "is_top_cut": false}, {"name": "Ho_pianto_sono_triste_datemi_BlastRosso", "rank": 20, "is_top_cut": false}, {"name": "Jonathan2011", "rank": 21, "is_top_cut": false}, {"name": "_M1RAGE_", "rank": 22, "is_top_cut": false}, {"name": "Brettbbx", "rank": 23, "is_top_cut": false}, {"name": "plus_exe", "rank": 24, "is_top_cut": false}, {"name": "JuliusHyodo", "rank": 25, "is_top_cut": false}, {"name": "Nomade7", "rank": 26, "is_top_cut": false}, {"name": "Ludix96", "rank": 27, "is_top_cut": false}, {"name": "Nerkio", "rank": 28, "is_top_cut": false}, {"name": "elbisc", "rank": 29, "is_top_cut": false}, {"name": "Musshu", "rank": 30, "is_top_cut": false}, {"name": "SoLollo", "rank": 31, "is_top_cut": false}, {"name": "ShonBeyXx", "rank": 32, "is_top_cut": false}, {"name": "Prof_Lele", "rank": 33, "is_top_cut": false}, {"name": "Podas", "rank": 34, "is_top_cut": false}, {"name": "_Vento", "rank": 35, "is_top_cut": false}, {"name": "ChrisZec", "rank": 36, "is_top_cut": false}, {"name": "BladerXF", "rank": 37, "is_top_cut": false}, {"name": "Leni17", "rank": 38, "is_top_cut": false}, {"name": "Ubekage", "rank": 39, "is_top_cut": false}, {"name": "Mr_Tuna_Head", "rank": 40, "is_top_cut": false}, {"name": "Tramu_BV", "rank": 41, "is_top_cut": false}, {"name": "Federeeeco", "rank": 42, "is_top_cut": false}, {"name": "Jay_Mugiwara", "rank": 43, "is_top_cut": false}, {"name": "Barone83", "rank": 44, "is_top_cut": false}, {"name": "Caramella72", "rank": 45, "is_top_cut": false}, {"name": "Bastoos", "rank": 46, "is_top_cut": false}, {"name": "Gullit23", "rank": 47, "is_top_cut": false}, {"name": "RionX", "rank": 48, "is_top_cut": false}, {"name": "black0vt_TMN", "rank": 49, "is_top_cut": false}, {"name": "DOMN", "rank": 50, "is_top_cut": false}, {"name": "Eclissatore", "rank": 51, "is_top_cut": false}, {"name": "Emmet77", "rank": 52, "is_top_cut": false}, {"name": "Massimassi", "rank": 53, "is_top_cut": false}, {"name": "_inghetta_", "rank": 54, "is_top_cut": false}, {"name": "Vittorino81rm", "rank": 55, "is_top_cut": false}, {"name": "GerardoDelia", "rank": 56, "is_top_cut": false}, {"name": "Manuelo_", "rank": 57, "is_top_cut": false}], "start_date": "2026-02-13T00:00:00", "total_players": 57, "tournament_name": "Dran Gladius 11/02/26 BEYLEAGUE 14 di 16 - Classifiche"}	2026-08-21 16:54:38.783781
745	29vwmsjf	{"id": "29vwmsjf", "standings": [{"name": "Miani83", "rank": 1, "is_top_cut": true}, {"name": "LucaNP", "rank": 2, "is_top_cut": true}, {"name": "GerardoDelia", "rank": 3, "is_top_cut": true}, {"name": "Nerkio", "rank": 4, "is_top_cut": true}, {"name": "Brettbbx", "rank": 5, "is_top_cut": true}, {"name": "Jay_Mugiwara", "rank": 5, "is_top_cut": true}, {"name": "Massimassi", "rank": 5, "is_top_cut": true}, {"name": "ShonBeyXx", "rank": 5, "is_top_cut": true}, {"name": "Ludix96", "rank": 9, "is_top_cut": false}, {"name": "Federeeeco", "rank": 10, "is_top_cut": false}, {"name": "Red", "rank": 11, "is_top_cut": false}, {"name": "Bicbo", "rank": 12, "is_top_cut": false}, {"name": "JuliusHyodo", "rank": 13, "is_top_cut": false}, {"name": "Hachiko_", "rank": 14, "is_top_cut": false}, {"name": "Brian303", "rank": 15, "is_top_cut": false}, {"name": "Mad_Blade", "rank": 16, "is_top_cut": false}, {"name": "Eclissatore", "rank": 17, "is_top_cut": false}, {"name": "DARIONEOLLARE", "rank": 18, "is_top_cut": false}, {"name": "LorenzoLSD", "rank": 19, "is_top_cut": false}, {"name": "_D_Hakkai", "rank": 20, "is_top_cut": false}, {"name": "Monkey_King_Tattoo", "rank": 21, "is_top_cut": false}, {"name": "_M1RAGE_", "rank": 22, "is_top_cut": false}, {"name": "Toncho04", "rank": 23, "is_top_cut": false}, {"name": "LeoRyu", "rank": 24, "is_top_cut": false}, {"name": "Emmet77", "rank": 25, "is_top_cut": false}, {"name": "Akkaw1", "rank": 26, "is_top_cut": false}, {"name": "Stupeficium", "rank": 27, "is_top_cut": false}, {"name": "Turbo73", "rank": 28, "is_top_cut": false}, {"name": "LolloNanairo", "rank": 29, "is_top_cut": false}, {"name": "elbisc", "rank": 30, "is_top_cut": false}, {"name": "Daniele_S", "rank": 31, "is_top_cut": false}, {"name": "Jonathan2011", "rank": 32, "is_top_cut": false}, {"name": "Killva", "rank": 33, "is_top_cut": false}], "start_date": "2026-02-06T00:00:00", "total_players": 33, "tournament_name": "Dran Gladius Beyleague tappa 13 di 16 del 06/02/26 - Classifiche"}	2026-08-21 16:54:39.311978
746	ontx3ymh	{"id": "ontx3ymh", "standings": [{"name": "_D_Hakkai", "rank": 1, "is_top_cut": true}, {"name": "SickNova", "rank": 2, "is_top_cut": true}, {"name": "Mi_ha_costretto_Lorenzo", "rank": 3, "is_top_cut": true}, {"name": "_M1RAGE_", "rank": 4, "is_top_cut": true}, {"name": "Gullit23", "rank": 5, "is_top_cut": true}, {"name": "LucaNP", "rank": 5, "is_top_cut": true}, {"name": "Tramu_BV", "rank": 5, "is_top_cut": true}, {"name": "VaultBoy91", "rank": 5, "is_top_cut": true}, {"name": "Miani83", "rank": 9, "is_top_cut": false}, {"name": "Akkaw1", "rank": 10, "is_top_cut": false}, {"name": "PePe49", "rank": 11, "is_top_cut": false}, {"name": "Hachiko_", "rank": 12, "is_top_cut": false}, {"name": "Monkey_King_Tattoo", "rank": 13, "is_top_cut": false}, {"name": "SeccoD91", "rank": 14, "is_top_cut": false}, {"name": "ShonBeyXx", "rank": 15, "is_top_cut": false}, {"name": "Federeeeco", "rank": 16, "is_top_cut": false}, {"name": "RascalNBC", "rank": 17, "is_top_cut": false}, {"name": "BestiaGiallaX", "rank": 18, "is_top_cut": false}, {"name": "riiching901", "rank": 19, "is_top_cut": false}, {"name": "Eclissatore", "rank": 20, "is_top_cut": false}, {"name": "Bicbo", "rank": 21, "is_top_cut": false}, {"name": "Mhasik", "rank": 22, "is_top_cut": false}, {"name": "Racche210", "rank": 23, "is_top_cut": false}, {"name": "elbisc", "rank": 24, "is_top_cut": false}, {"name": "Jonathan2011", "rank": 25, "is_top_cut": false}, {"name": "GerardoDelia", "rank": 26, "is_top_cut": false}, {"name": "Emmet77", "rank": 27, "is_top_cut": false}, {"name": "Barone83", "rank": 28, "is_top_cut": false}, {"name": "ErConfy_BV", "rank": 29, "is_top_cut": false}, {"name": "Massimassi", "rank": 30, "is_top_cut": false}, {"name": "Paolomu_99", "rank": 31, "is_top_cut": false}, {"name": "Brian303", "rank": 32, "is_top_cut": false}, {"name": "Seppiozzo", "rank": 33, "is_top_cut": false}], "start_date": "2026-02-24T00:00:00", "total_players": 33, "tournament_name": "Dran Gladius BYLEAGUE 16/16 del 24/02/26 - Classifiche"}	2026-08-21 16:54:39.813348
747	otply5yd	{"id": "otply5yd", "standings": [{"name": "_Zein", "rank": 1, "is_top_cut": true}, {"name": "Taccons", "rank": 2, "is_top_cut": true}, {"name": "Monkey_King_Tattoo", "rank": 3, "is_top_cut": true}, {"name": "Jonathan2011", "rank": 4, "is_top_cut": true}, {"name": "Barone83", "rank": 5, "is_top_cut": true}, {"name": "Federeeeco", "rank": 5, "is_top_cut": true}, {"name": "Lucifero88", "rank": 5, "is_top_cut": true}, {"name": "Toncho04", "rank": 5, "is_top_cut": true}, {"name": "BromisS", "rank": 9, "is_top_cut": false}, {"name": "Massimassi", "rank": 10, "is_top_cut": false}, {"name": "Domiziano", "rank": 11, "is_top_cut": false}, {"name": "Andrea_90", "rank": 12, "is_top_cut": false}, {"name": "Donpi2", "rank": 13, "is_top_cut": false}, {"name": "Dains_Celance", "rank": 14, "is_top_cut": false}, {"name": "22baymax", "rank": 15, "is_top_cut": false}, {"name": "RascalNBC", "rank": 16, "is_top_cut": false}, {"name": "Brettbbx", "rank": 17, "is_top_cut": false}, {"name": "ShonBeyXx", "rank": 18, "is_top_cut": false}], "start_date": "2026-02-02T00:00:00", "total_players": 18, "tournament_name": "FireBall Beyblade Club - Ranked BeyLeague 02 Febbraio 2026 - Classifiche"}	2026-08-21 16:54:40.329898
751	1sbvgclb	{"id": "1sbvgclb", "standings": [{"name": "SpaceGirlfriend", "rank": 1, "is_top_cut": true}, {"name": "DarkMagici4n", "rank": 2, "is_top_cut": true}, {"name": "EdoLaFenice", "rank": 3, "is_top_cut": true}, {"name": "Blader_F_2018", "rank": 4, "is_top_cut": true}, {"name": "BeshtiOne", "rank": 5, "is_top_cut": true}, {"name": "Nicolas_14", "rank": 6, "is_top_cut": true}, {"name": "TommyBX", "rank": 7, "is_top_cut": true}, {"name": "Guerins98", "rank": 8, "is_top_cut": true}, {"name": "ZyroBeastPink", "rank": 9, "is_top_cut": false}, {"name": "Luffy15", "rank": 10, "is_top_cut": false}, {"name": "xSam16", "rank": 11, "is_top_cut": false}, {"name": "whiteknight_", "rank": 12, "is_top_cut": false}, {"name": "Raffy2016", "rank": 13, "is_top_cut": false}, {"name": "Lorenzix", "rank": 14, "is_top_cut": false}, {"name": "FRENCK", "rank": 15, "is_top_cut": false}, {"name": "GabYoshi", "rank": 16, "is_top_cut": false}, {"name": "LoSportivo", "rank": 17, "is_top_cut": false}, {"name": "Daruma86", "rank": 18, "is_top_cut": false}, {"name": "ItsImogen", "rank": 19, "is_top_cut": false}, {"name": "Fede2016", "rank": 20, "is_top_cut": false}, {"name": "MarioShark", "rank": 21, "is_top_cut": false}, {"name": "Chef_Rossini", "rank": 22, "is_top_cut": false}, {"name": "Edoardodg", "rank": 23, "is_top_cut": false}, {"name": "loleva", "rank": 24, "is_top_cut": false}], "start_date": "2026-02-08T00:00:00", "total_players": 24, "tournament_name": "Shiny Knights RANKED IBNA 08/02/26 - Classifiche"}	2026-08-21 16:54:42.464205
752	i0o5vpj0	{"id": "i0o5vpj0", "standings": [{"name": "Unhunexio", "rank": 1, "is_top_cut": true}, {"name": "SansOnne", "rank": 2, "is_top_cut": true}, {"name": "sdwDancer", "rank": 3, "is_top_cut": true}, {"name": "Daruma86", "rank": 4, "is_top_cut": true}, {"name": "xSam16", "rank": 5, "is_top_cut": false}, {"name": "DarkMagici4n", "rank": 6, "is_top_cut": false}, {"name": "Scooby_Nac", "rank": 7, "is_top_cut": false}, {"name": "FranLu", "rank": 8, "is_top_cut": false}, {"name": "Vincenzo68", "rank": 9, "is_top_cut": false}, {"name": "NordicPain", "rank": 10, "is_top_cut": false}, {"name": "Chef_Rossini", "rank": 11, "is_top_cut": false}, {"name": "Allessio1702", "rank": 12, "is_top_cut": false}, {"name": "whiteknight_", "rank": 13, "is_top_cut": false}, {"name": "SpaceGirlfriend", "rank": 14, "is_top_cut": false}, {"name": "Karletto", "rank": 15, "is_top_cut": false}, {"name": "Giuseppe2018", "rank": 16, "is_top_cut": false}, {"name": "ItsImogen", "rank": 17, "is_top_cut": false}, {"name": "Mattia16", "rank": 18, "is_top_cut": false}, {"name": "TommyBX", "rank": 19, "is_top_cut": false}, {"name": "RikiAndrea", "rank": 20, "is_top_cut": false}, {"name": "GIOMASKpro355", "rank": 21, "is_top_cut": false}, {"name": "Luffy15", "rank": 22, "is_top_cut": false}], "start_date": "2026-02-01T00:00:00", "total_players": 22, "tournament_name": "Shiny Knights Ranked Standard IBNA 01/02/26 - Classifiche"}	2026-08-21 16:54:43.009527
753	qpzf2tvd	{"id": "qpzf2tvd", "standings": [{"name": "FrancisFordTrottola", "rank": 1, "is_top_cut": true}, {"name": "Supporto_Emotivo", "rank": 2, "is_top_cut": true}, {"name": "Dadolow98", "rank": 3, "is_top_cut": true}, {"name": "DemonSampei", "rank": 4, "is_top_cut": true}, {"name": "Sikaka", "rank": 5, "is_top_cut": true}, {"name": "Kute", "rank": 6, "is_top_cut": true}, {"name": "EsDeeShark", "rank": 7, "is_top_cut": true}, {"name": "Palissandro", "rank": 8, "is_top_cut": true}, {"name": "Casper14", "rank": 9, "is_top_cut": true}, {"name": "Tiziano_Banano", "rank": 10, "is_top_cut": true}, {"name": "xXAX96Xx", "rank": 11, "is_top_cut": true}, {"name": "eldefensor", "rank": 12, "is_top_cut": true}, {"name": "Gigigi_", "rank": 13, "is_top_cut": true}, {"name": "ELCULON", "rank": 14, "is_top_cut": true}, {"name": "Mr_baobab", "rank": 15, "is_top_cut": true}, {"name": "lil_LOTC", "rank": 16, "is_top_cut": true}, {"name": "Orticoltore", "rank": 17, "is_top_cut": false}, {"name": "Tomahhh", "rank": 18, "is_top_cut": false}, {"name": "ilFaraone96", "rank": 19, "is_top_cut": false}, {"name": "Thiass", "rank": 20, "is_top_cut": false}, {"name": "Ma_stro_nzo", "rank": 21, "is_top_cut": false}, {"name": "Sarcai", "rank": 22, "is_top_cut": false}, {"name": "Benobeno", "rank": 23, "is_top_cut": false}, {"name": "Bass96", "rank": 24, "is_top_cut": false}, {"name": "Serse", "rank": 25, "is_top_cut": false}, {"name": "Bosco027", "rank": 26, "is_top_cut": false}, {"name": "_Aeonax_", "rank": 27, "is_top_cut": false}, {"name": "Teschio96", "rank": 28, "is_top_cut": false}, {"name": "N_O_X_", "rank": 29, "is_top_cut": false}, {"name": "GrazyGip", "rank": 30, "is_top_cut": false}, {"name": "Don Lorenzo", "rank": 31, "is_top_cut": false}, {"name": "Marmaxx", "rank": 32, "is_top_cut": false}, {"name": "Citpit", "rank": 33, "is_top_cut": false}, {"name": "Squalessandro", "rank": 34, "is_top_cut": false}], "start_date": "2026-02-10T00:00:00", "total_players": 34, "tournament_name": "STREET SHARKS TORNEO RANKED 10-2-2026 Hell's Chain - Classifiche"}	2026-08-21 16:54:43.525527
754	3twowg4v	{"id": "3twowg4v", "standings": [{"name": "Kute_", "rank": 1, "is_top_cut": true}, {"name": "EsDeeShark", "rank": 2, "is_top_cut": true}, {"name": "Palissandro", "rank": 3, "is_top_cut": true}, {"name": "Ma_stro_nzo", "rank": 4, "is_top_cut": true}, {"name": "_Aeonax_", "rank": 5, "is_top_cut": true}, {"name": "Benobeno", "rank": 6, "is_top_cut": true}, {"name": "Gigigi_", "rank": 7, "is_top_cut": true}, {"name": "Ivoboye", "rank": 8, "is_top_cut": true}, {"name": "Bass96", "rank": 9, "is_top_cut": false}, {"name": "Sikaka", "rank": 10, "is_top_cut": false}, {"name": "Serse", "rank": 11, "is_top_cut": false}, {"name": "Supporto_Emotivo", "rank": 12, "is_top_cut": false}, {"name": "Orticoltore", "rank": 13, "is_top_cut": false}, {"name": "ilFaraone96", "rank": 14, "is_top_cut": false}, {"name": "Kh0zaky", "rank": 15, "is_top_cut": false}, {"name": "DemonSampei", "rank": 16, "is_top_cut": false}, {"name": "N_O_X_", "rank": 17, "is_top_cut": false}, {"name": "Mr_baobab", "rank": 18, "is_top_cut": false}, {"name": "Tomahhh", "rank": 19, "is_top_cut": false}, {"name": "Teschio96", "rank": 20, "is_top_cut": false}, {"name": "Squalessandro", "rank": 21, "is_top_cut": false}, {"name": "Yurix01", "rank": 22, "is_top_cut": false}, {"name": "La_Jade", "rank": 23, "is_top_cut": false}, {"name": "Sarcai", "rank": 24, "is_top_cut": false}, {"name": "EdoPambi", "rank": 25, "is_top_cut": false}], "start_date": "2026-02-17T23:11:00", "total_players": 25, "tournament_name": "Torneo STREET SHARKS 17-02-26 FREE "}	2026-08-21 16:54:44.049859
755	casza2k9	{"id": "casza2k9", "standings": [{"name": "DemonSampei", "rank": 1, "is_top_cut": true}, {"name": "nova", "rank": 2, "is_top_cut": true}, {"name": "SigIvan", "rank": 3, "is_top_cut": true}, {"name": "Merca94", "rank": 4, "is_top_cut": true}, {"name": "Gigigi_", "rank": 5, "is_top_cut": true}, {"name": "KaghemushaSama", "rank": 6, "is_top_cut": true}, {"name": "_Aeonax_", "rank": 7, "is_top_cut": true}, {"name": "Gibby14", "rank": 8, "is_top_cut": true}, {"name": "_Ezecutor_iBh", "rank": 9, "is_top_cut": false}, {"name": "Salas_1", "rank": 10, "is_top_cut": false}, {"name": "Mr_baobab", "rank": 11, "is_top_cut": false}, {"name": "Benobeno", "rank": 12, "is_top_cut": false}, {"name": "Don Lorenzo", "rank": 13, "is_top_cut": false}, {"name": "Ma_stron_zo", "rank": 14, "is_top_cut": false}, {"name": "Sikaka", "rank": 15, "is_top_cut": false}, {"name": "Palissandro", "rank": 16, "is_top_cut": false}, {"name": "Citpit", "rank": 17, "is_top_cut": false}, {"name": "Sarcai", "rank": 18, "is_top_cut": false}, {"name": "Gabrimarche", "rank": 19, "is_top_cut": false}, {"name": "FrancisFordTrottola", "rank": 20, "is_top_cut": false}, {"name": "Casper14", "rank": 21, "is_top_cut": false}, {"name": "EsDeeShark", "rank": 22, "is_top_cut": false}, {"name": "Orticoltore", "rank": 23, "is_top_cut": false}, {"name": "gorillaz", "rank": 24, "is_top_cut": false}, {"name": "Malevolovo", "rank": 25, "is_top_cut": false}, {"name": "Bass96", "rank": 26, "is_top_cut": false}, {"name": "Toaultra", "rank": 27, "is_top_cut": false}, {"name": "Tomahhh", "rank": 28, "is_top_cut": false}, {"name": "Blade_Sabbath", "rank": 29, "is_top_cut": false}, {"name": "FrancisRookie96", "rank": 30, "is_top_cut": false}], "start_date": "2026-02-24T00:00:00", "total_players": 30, "tournament_name": "STREET SHARKS TORNEO RANKED 24-2-2026 Emperor Blast - Classifiche"}	2026-08-21 16:54:44.575251
756	150fn0qc	{"id": "150fn0qc", "standings": [{"name": "Mr_baobab", "rank": 1, "is_top_cut": true}, {"name": "Vitto95", "rank": 2, "is_top_cut": true}, {"name": "lil_LOTC", "rank": 3, "is_top_cut": true}, {"name": "Talion99", "rank": 4, "is_top_cut": true}, {"name": "Davide", "rank": 5, "is_top_cut": true}, {"name": "Kute_", "rank": 6, "is_top_cut": true}, {"name": "xXAX96Xx", "rank": 7, "is_top_cut": true}, {"name": "Midorina", "rank": 8, "is_top_cut": true}, {"name": "Orticoltore", "rank": 9, "is_top_cut": false}, {"name": "Palissandro", "rank": 10, "is_top_cut": false}, {"name": "DemonSampei", "rank": 11, "is_top_cut": false}, {"name": "Citpit", "rank": 12, "is_top_cut": false}, {"name": "Coppyy", "rank": 13, "is_top_cut": false}, {"name": "Bass96", "rank": 14, "is_top_cut": false}, {"name": "Salas_1", "rank": 15, "is_top_cut": false}, {"name": "KaghemushaSama", "rank": 16, "is_top_cut": false}, {"name": "Sarcai", "rank": 17, "is_top_cut": false}, {"name": "Yurix01", "rank": 18, "is_top_cut": false}, {"name": "Tomahhh", "rank": 19, "is_top_cut": false}, {"name": "Benobeno", "rank": 20, "is_top_cut": false}, {"name": "Claudio94", "rank": 21, "is_top_cut": false}, {"name": "Bigsimmy", "rank": 22, "is_top_cut": false}, {"name": "EdoPambi", "rank": 23, "is_top_cut": false}, {"name": "EsDeeShark", "rank": 24, "is_top_cut": false}, {"name": "Scrotobleyder", "rank": 25, "is_top_cut": false}, {"name": "Marmaxx", "rank": 26, "is_top_cut": false}, {"name": "Alemartini", "rank": 27, "is_top_cut": false}, {"name": "Fra86170", "rank": 28, "is_top_cut": false}], "start_date": "2026-03-03T00:00:00", "total_players": 28, "tournament_name": "STREET SHARKS TORNEO RANKED 3-3-2026 FREE"}	2026-08-21 16:54:45.087261
757	puud1w74	{"id": "puud1w74", "standings": [{"name": "PerSempre", "rank": 1, "is_top_cut": true}, {"name": "Luca_Capoch", "rank": 2, "is_top_cut": true}, {"name": "Sagro", "rank": 3, "is_top_cut": true}, {"name": "Batmann91", "rank": 4, "is_top_cut": true}, {"name": "Blair888", "rank": 5, "is_top_cut": true}, {"name": "Ilbadrone", "rank": 5, "is_top_cut": true}, {"name": "Luca_Bellaveglia", "rank": 5, "is_top_cut": true}, {"name": "NovaBless", "rank": 5, "is_top_cut": true}, {"name": "Alicino_AFST", "rank": 9, "is_top_cut": false}, {"name": "CALPISREDCOMET", "rank": 10, "is_top_cut": false}, {"name": "ChrisZec", "rank": 11, "is_top_cut": false}, {"name": "Pika__27", "rank": 12, "is_top_cut": false}, {"name": "Edo", "rank": 13, "is_top_cut": false}, {"name": "Darkmok", "rank": 14, "is_top_cut": false}, {"name": "Lallalalla", "rank": 15, "is_top_cut": false}, {"name": "Konau", "rank": 16, "is_top_cut": false}, {"name": "Fle95a", "rank": 17, "is_top_cut": false}], "start_date": "2026-02-04T22:40:00", "total_players": 17, "tournament_name": "Torneo LA CIVETTA - RANKED 04/02 - IBNA STANDARD 2026 - Classifiche"}	2026-08-21 16:54:45.583104
758	c650b1zh	{"id": "c650b1zh", "standings": [{"name": "Luca_Bellaveglia", "rank": 1, "is_top_cut": true}, {"name": "Freud911", "rank": 2, "is_top_cut": true}, {"name": "Batmann91", "rank": 3, "is_top_cut": true}, {"name": "BigRicco", "rank": 4, "is_top_cut": true}, {"name": "Darkmok", "rank": 5, "is_top_cut": true}, {"name": "Deku90", "rank": 5, "is_top_cut": true}, {"name": "Fle95a", "rank": 5, "is_top_cut": true}, {"name": "Konau", "rank": 5, "is_top_cut": true}, {"name": "PerSempre", "rank": 9, "is_top_cut": false}, {"name": "NovaBless", "rank": 10, "is_top_cut": false}, {"name": "Luca_Capoch", "rank": 11, "is_top_cut": false}, {"name": "Lucacolt", "rank": 12, "is_top_cut": false}, {"name": "Blair888", "rank": 13, "is_top_cut": false}, {"name": "CALPISREDCOMET", "rank": 14, "is_top_cut": false}, {"name": "Rosefield95", "rank": 15, "is_top_cut": false}, {"name": "Bio__", "rank": 16, "is_top_cut": false}, {"name": "TheNask", "rank": 17, "is_top_cut": false}, {"name": "Pika__27", "rank": 18, "is_top_cut": false}, {"name": "ChrisZec", "rank": 19, "is_top_cut": false}, {"name": "Dragosandro", "rank": 20, "is_top_cut": false}], "start_date": "2026-02-11T22:39:00", "total_players": 20, "tournament_name": "Torneo LA CIVETTA - RANKED 11/02 - IBNA STANDARD 2026 - Classifiche"}	2026-08-21 16:54:46.08961
759	evzb79o8	{"id": "evzb79o8", "standings": [{"name": "Luca_Bellaveglia", "rank": 1, "is_top_cut": true}, {"name": "Luca_Capoch", "rank": 2, "is_top_cut": true}, {"name": "Deadnos", "rank": 3, "is_top_cut": true}, {"name": "PerSempre", "rank": 4, "is_top_cut": true}, {"name": "Batmann91", "rank": 5, "is_top_cut": true}, {"name": "Boo37", "rank": 5, "is_top_cut": true}, {"name": "Pika__27", "rank": 5, "is_top_cut": true}, {"name": "Sagro_AFST", "rank": 5, "is_top_cut": true}, {"name": "ChrisZec", "rank": 9, "is_top_cut": false}, {"name": "UNDER100", "rank": 10, "is_top_cut": false}, {"name": "Edo", "rank": 11, "is_top_cut": false}, {"name": "CALPISREDCOMET", "rank": 12, "is_top_cut": false}, {"name": "Konau", "rank": 13, "is_top_cut": false}, {"name": "Darkmok", "rank": 14, "is_top_cut": false}, {"name": "Alicino_AFST", "rank": 15, "is_top_cut": false}, {"name": "NovaBless", "rank": 16, "is_top_cut": false}, {"name": "Fle95a", "rank": 17, "is_top_cut": false}, {"name": "Blair888", "rank": 18, "is_top_cut": false}], "start_date": "2026-02-25T22:34:00", "total_players": 18, "tournament_name": "Torneo LA CIVETTA - RANKED 25/02 - IBNA STANDARD 2026 - Classifiche"}	2026-08-21 16:54:46.601314
760	wymu299x	{"id": "wymu299x", "standings": [{"name": "Redd0", "rank": 1, "is_top_cut": true}, {"name": "Thagomizer", "rank": 2, "is_top_cut": true}, {"name": "El_Olvido", "rank": 3, "is_top_cut": true}, {"name": "Sampei_the_Blader", "rank": 4, "is_top_cut": true}, {"name": "JasonX_10", "rank": 5, "is_top_cut": true}, {"name": "Leventiel", "rank": 6, "is_top_cut": true}, {"name": "3NTØNY", "rank": 7, "is_top_cut": true}, {"name": "ELCULON", "rank": 8, "is_top_cut": true}, {"name": "SnoopDoggX", "rank": 9, "is_top_cut": true}, {"name": "Palissandro", "rank": 10, "is_top_cut": true}, {"name": "Gab_17", "rank": 11, "is_top_cut": true}, {"name": "Botta00", "rank": 12, "is_top_cut": true}, {"name": "JackC84", "rank": 13, "is_top_cut": true}, {"name": "KaghemushaSama", "rank": 14, "is_top_cut": true}, {"name": "Enrico_Pakinko", "rank": 15, "is_top_cut": true}, {"name": "RagazzoScheletro", "rank": 16, "is_top_cut": true}, {"name": "Malato_per_favore", "rank": 17, "is_top_cut": false}, {"name": "Vichingo", "rank": 18, "is_top_cut": false}, {"name": "PartisanTunic", "rank": 19, "is_top_cut": false}, {"name": "SfornaPatate", "rank": 20, "is_top_cut": false}, {"name": "Xayrevers45", "rank": 21, "is_top_cut": false}, {"name": "YukiYux", "rank": 22, "is_top_cut": false}, {"name": "Fabbo_97", "rank": 23, "is_top_cut": false}, {"name": "FrancisFordTrottola", "rank": 24, "is_top_cut": false}, {"name": "HoRubatoIlFondoCassa", "rank": 25, "is_top_cut": false}, {"name": "Laura19", "rank": 26, "is_top_cut": false}, {"name": "LoydNinja", "rank": 27, "is_top_cut": false}, {"name": "fedone", "rank": 28, "is_top_cut": false}, {"name": "Quereloperdiffamazione", "rank": 29, "is_top_cut": false}, {"name": "Bakudomo", "rank": 30, "is_top_cut": false}, {"name": "RyanT_07", "rank": 31, "is_top_cut": false}, {"name": "Zio_Fra74", "rank": 32, "is_top_cut": false}, {"name": "XTHOM", "rank": 33, "is_top_cut": false}, {"name": "_Steffo_", "rank": 34, "is_top_cut": false}, {"name": "Goburin69", "rank": 35, "is_top_cut": false}, {"name": "AleF81", "rank": 36, "is_top_cut": false}], "start_date": "2026-02-22T00:00:00", "total_players": 36, "tournament_name": "TORNEO LAZZARONI RANKED IBNA STANDARD WYVERN - 22/02/26 - Classifiche"}	2026-08-21 16:54:47.117476
761	gmhwyasy	{"id": "gmhwyasy", "standings": [{"name": "Pr1m0s", "rank": 1, "is_top_cut": true}, {"name": "Kooiji", "rank": 2, "is_top_cut": true}, {"name": "Twins_2016", "rank": 3, "is_top_cut": true}, {"name": "AmetDj", "rank": 4, "is_top_cut": true}, {"name": "Jiimmyyy", "rank": 5, "is_top_cut": true}, {"name": "RingLords", "rank": 6, "is_top_cut": true}, {"name": "Fried_Toxic_Rice", "rank": 7, "is_top_cut": true}, {"name": "Matty92bey", "rank": 8, "is_top_cut": true}, {"name": "Ispanico1986", "rank": 9, "is_top_cut": true}, {"name": "Tiresia_", "rank": 10, "is_top_cut": true}, {"name": "Superabo56", "rank": 11, "is_top_cut": true}, {"name": "Mazinga2016", "rank": 12, "is_top_cut": true}, {"name": "Farinella", "rank": 13, "is_top_cut": true}, {"name": "DrHats", "rank": 14, "is_top_cut": true}, {"name": "Samublade", "rank": 15, "is_top_cut": true}, {"name": "Kigen", "rank": 16, "is_top_cut": true}, {"name": "Nico13", "rank": 17, "is_top_cut": false}, {"name": "Laura19", "rank": 18, "is_top_cut": false}, {"name": "_Eva01", "rank": 19, "is_top_cut": false}, {"name": "Valebisso", "rank": 20, "is_top_cut": false}, {"name": "Francesco15", "rank": 21, "is_top_cut": false}, {"name": "Pobaz98", "rank": 22, "is_top_cut": false}, {"name": "Nicolino1977", "rank": 23, "is_top_cut": false}, {"name": "Vinci31", "rank": 24, "is_top_cut": false}, {"name": "KaghemushaSama", "rank": 25, "is_top_cut": false}, {"name": "Enea_Mazza", "rank": 26, "is_top_cut": false}, {"name": "Gabrimarche", "rank": 27, "is_top_cut": false}, {"name": "Seiesse", "rank": 28, "is_top_cut": false}, {"name": "GabrieleChiarenza", "rank": 29, "is_top_cut": false}, {"name": "VoxDubium", "rank": 30, "is_top_cut": false}, {"name": "cosonakking3000", "rank": 31, "is_top_cut": false}, {"name": "BladerX1", "rank": 32, "is_top_cut": false}, {"name": "LDL18", "rank": 33, "is_top_cut": false}], "start_date": "2026-02-21T00:00:00", "total_players": 33, "tournament_name": "TORNEO RISING PHOENIX RANKED 21/02/2026 IBNA STANDARD - Classifiche"}	2026-08-21 16:54:47.626954
762	1fq7fnl8	{"id": "1fq7fnl8", "standings": [{"name": "BromisS", "rank": 1, "is_top_cut": true}, {"name": "Paolomu_99", "rank": 2, "is_top_cut": true}, {"name": "Zigozago284", "rank": 3, "is_top_cut": true}, {"name": "Aokira77", "rank": 4, "is_top_cut": true}, {"name": "Bastoos", "rank": 5, "is_top_cut": true}, {"name": "idril20xx", "rank": 6, "is_top_cut": true}, {"name": "Barone83", "rank": 7, "is_top_cut": true}, {"name": "KnightK", "rank": 8, "is_top_cut": true}, {"name": "_D_Hakkai", "rank": 9, "is_top_cut": false}, {"name": "Marty20xx", "rank": 10, "is_top_cut": false}, {"name": "GerardoDelia", "rank": 11, "is_top_cut": false}, {"name": "Musshu", "rank": 12, "is_top_cut": false}, {"name": "riiching901", "rank": 13, "is_top_cut": false}, {"name": "cacci351", "rank": 14, "is_top_cut": false}, {"name": "LucaNP", "rank": 15, "is_top_cut": false}, {"name": "Zurukuma", "rank": 16, "is_top_cut": false}, {"name": "RikyFire", "rank": 17, "is_top_cut": false}, {"name": "LordTz", "rank": 18, "is_top_cut": false}, {"name": "Dark_ritow", "rank": 19, "is_top_cut": false}, {"name": "ThePitcher", "rank": 20, "is_top_cut": false}, {"name": "_Zein", "rank": 21, "is_top_cut": false}, {"name": "MaccheRonin", "rank": 22, "is_top_cut": false}, {"name": "Newteam91", "rank": 23, "is_top_cut": false}, {"name": "Maso19", "rank": 24, "is_top_cut": false}], "start_date": "2026-02-07T00:00:00", "total_players": 24, "tournament_name": "Torneo Wildfire - 07/02/26 - Standard Tappa Beyleague 13/16 - Classifiche"}	2026-08-21 16:54:48.15644
763	o8t6pvg5	{"id": "o8t6pvg5", "standings": [{"name": "Tramu_BV", "rank": 1, "is_top_cut": true}, {"name": "RascalNBC", "rank": 2, "is_top_cut": true}, {"name": "LucaNP", "rank": 3, "is_top_cut": true}, {"name": "Anatra_finale", "rank": 4, "is_top_cut": true}, {"name": "_D_Hakkai", "rank": 5, "is_top_cut": true}, {"name": "Depa19", "rank": 5, "is_top_cut": true}, {"name": "Marty20xx", "rank": 5, "is_top_cut": true}, {"name": "Newteam91", "rank": 5, "is_top_cut": true}, {"name": "Paolomu_99", "rank": 9, "is_top_cut": false}, {"name": "BladerXF", "rank": 10, "is_top_cut": false}, {"name": "Vittorino81rm", "rank": 11, "is_top_cut": false}, {"name": "idril20xx", "rank": 12, "is_top_cut": false}, {"name": "Caramella72", "rank": 13, "is_top_cut": false}, {"name": "GerardoDelia", "rank": 14, "is_top_cut": false}, {"name": "Aokira77", "rank": 15, "is_top_cut": false}, {"name": "BLADEREMA", "rank": 16, "is_top_cut": false}, {"name": "Gabriele19", "rank": 17, "is_top_cut": false}, {"name": "Maso19", "rank": 18, "is_top_cut": false}], "start_date": "2026-02-14T00:00:00", "total_players": 18, "tournament_name": "Torneo Wildfire - 14/02/26 - Standard Tappa Beyleague 14/16 - Classifiche"}	2026-08-21 16:54:48.67235
764	git4fnga	{"id": "git4fnga", "standings": [{"name": "UnamxriDotExe", "rank": 1, "is_top_cut": true}, {"name": "Barone83", "rank": 2, "is_top_cut": true}, {"name": "Tramu_BV", "rank": 3, "is_top_cut": true}, {"name": "elbisc", "rank": 4, "is_top_cut": true}, {"name": "Misosone", "rank": 5, "is_top_cut": false}, {"name": "fonty94", "rank": 6, "is_top_cut": false}, {"name": "Caramella72", "rank": 7, "is_top_cut": false}, {"name": "GerardoDelia", "rank": 8, "is_top_cut": false}, {"name": "Musshu", "rank": 9, "is_top_cut": false}, {"name": "Andrytrik", "rank": 10, "is_top_cut": false}], "start_date": "2026-02-21T00:00:00", "total_players": 10, "tournament_name": "Torneo Wildfire - 21/02/26 - Standard Tappa Beyleague 15/16 - Classifiche"}	2026-08-21 16:54:49.174619
765	mvojkbfo	{"id": "mvojkbfo", "standings": [{"name": "Federeeeco", "rank": 1, "is_top_cut": true}, {"name": "GHOST__23", "rank": 2, "is_top_cut": true}, {"name": "HarimaKenji", "rank": 3, "is_top_cut": true}, {"name": "Dark_ritow", "rank": 4, "is_top_cut": true}, {"name": "Brettbbx", "rank": 5, "is_top_cut": true}, {"name": "BromisS", "rank": 5, "is_top_cut": true}, {"name": "Jonathan2011", "rank": 5, "is_top_cut": true}, {"name": "Pico7", "rank": 5, "is_top_cut": true}, {"name": "Ubekage", "rank": 9, "is_top_cut": false}, {"name": "_Zein", "rank": 10, "is_top_cut": false}, {"name": "M4rti", "rank": 11, "is_top_cut": false}, {"name": "Piero145", "rank": 12, "is_top_cut": false}, {"name": "Khepri01", "rank": 13, "is_top_cut": false}, {"name": "VentoAran", "rank": 14, "is_top_cut": false}, {"name": "RascalNBC", "rank": 15, "is_top_cut": false}, {"name": "RoboRobo", "rank": 16, "is_top_cut": false}, {"name": "D_Hakkai", "rank": 17, "is_top_cut": false}, {"name": "Dains_Celance", "rank": 18, "is_top_cut": false}, {"name": "Shaka1985", "rank": 19, "is_top_cut": false}, {"name": "SuperSonicGjo", "rank": 20, "is_top_cut": false}, {"name": "Mad_Blade", "rank": 21, "is_top_cut": false}, {"name": "Pigi_fenix", "rank": 22, "is_top_cut": false}, {"name": "GerardoDelia", "rank": 23, "is_top_cut": false}, {"name": "hellboy_76", "rank": 24, "is_top_cut": false}, {"name": "Bastoos", "rank": 25, "is_top_cut": false}, {"name": "ShonBeyXx", "rank": 26, "is_top_cut": false}, {"name": "Massimassi", "rank": 27, "is_top_cut": false}, {"name": "RionX", "rank": 28, "is_top_cut": false}, {"name": "cacci351", "rank": 29, "is_top_cut": false}, {"name": "Flavio2015", "rank": 30, "is_top_cut": false}, {"name": "Maxdavi100", "rank": 31, "is_top_cut": false}], "start_date": "2026-02-01T00:00:00", "total_players": 31, "tournament_name": "UBX RANKED BEYLEAGUE 01/02 STANDARD - Classifiche"}	2026-08-21 16:54:49.677348
766	dvbwd9sz	{"id": "dvbwd9sz", "standings": [{"name": "ShonBeyXx", "rank": 1, "is_top_cut": true}, {"name": "PerSempre", "rank": 2, "is_top_cut": true}, {"name": "Pigi_fenix", "rank": 3, "is_top_cut": true}, {"name": "BusterDran", "rank": 4, "is_top_cut": true}, {"name": "BromisS", "rank": 5, "is_top_cut": true}, {"name": "Leon1990", "rank": 5, "is_top_cut": true}, {"name": "Mad_Blade", "rank": 5, "is_top_cut": true}, {"name": "Miani83", "rank": 5, "is_top_cut": true}, {"name": "Paolomu_99", "rank": 9, "is_top_cut": false}, {"name": "Nerkio", "rank": 10, "is_top_cut": false}, {"name": "Leoshadow", "rank": 11, "is_top_cut": false}, {"name": "Massimassi", "rank": 12, "is_top_cut": false}, {"name": "Deku90", "rank": 13, "is_top_cut": false}, {"name": "_D_Hakkai", "rank": 14, "is_top_cut": false}, {"name": "EgilTheWanderer", "rank": 15, "is_top_cut": false}, {"name": "Brettbbx", "rank": 16, "is_top_cut": false}, {"name": "_Vento", "rank": 17, "is_top_cut": false}, {"name": "Turbo73", "rank": 18, "is_top_cut": false}, {"name": "FrancoGalbazzi", "rank": 19, "is_top_cut": false}, {"name": "Ragnarovi", "rank": 20, "is_top_cut": false}, {"name": "hellboy_09", "rank": 21, "is_top_cut": false}, {"name": "RascalNBC", "rank": 22, "is_top_cut": false}, {"name": "Maxdavi100", "rank": 23, "is_top_cut": false}, {"name": "Depa19", "rank": 24, "is_top_cut": false}, {"name": "Jonathan2011", "rank": 25, "is_top_cut": false}, {"name": "Prof_Lele", "rank": 26, "is_top_cut": false}, {"name": "MaccheRonin", "rank": 27, "is_top_cut": false}, {"name": "LupoAlbano97", "rank": 28, "is_top_cut": false}, {"name": "Anatra_finale", "rank": 29, "is_top_cut": false}, {"name": "BladeryX", "rank": 30, "is_top_cut": false}, {"name": "GIULIODARK", "rank": 31, "is_top_cut": false}, {"name": "_Zein", "rank": 32, "is_top_cut": false}, {"name": "Flavietto_8", "rank": 33, "is_top_cut": false}], "start_date": "2026-02-08T00:00:00", "total_players": 33, "tournament_name": "UBX RANKED BEYLEAGUE 08/02 STANDARD - Classifiche"}	2026-08-21 16:54:50.221401
767	wyinzxiq	{"id": "wyinzxiq", "standings": [{"name": "BromisS", "rank": 1, "is_top_cut": true}, {"name": "Topodadoccia", "rank": 2, "is_top_cut": true}, {"name": "Federeeeco", "rank": 3, "is_top_cut": true}, {"name": "alessandro_iv", "rank": 4, "is_top_cut": true}, {"name": "Daniele_S", "rank": 5, "is_top_cut": true}, {"name": "Monkey_King_Tattoo", "rank": 5, "is_top_cut": true}, {"name": "Polargh", "rank": 5, "is_top_cut": true}, {"name": "Wukan", "rank": 5, "is_top_cut": true}, {"name": "FetusGrinder", "rank": 9, "is_top_cut": false}, {"name": "Jonathan2011", "rank": 10, "is_top_cut": false}, {"name": "ShonBeyXx", "rank": 11, "is_top_cut": false}, {"name": "SickShok", "rank": 12, "is_top_cut": false}, {"name": "Vittorino81rm", "rank": 13, "is_top_cut": false}, {"name": "JuliusHyodo", "rank": 14, "is_top_cut": false}, {"name": "_D_Hakkai", "rank": 15, "is_top_cut": false}, {"name": "Jack_CBR", "rank": 16, "is_top_cut": false}, {"name": "BusterDran", "rank": 17, "is_top_cut": false}, {"name": "ZioGabrio", "rank": 18, "is_top_cut": false}, {"name": "Miani83", "rank": 19, "is_top_cut": false}, {"name": "Rorasev", "rank": 20, "is_top_cut": false}, {"name": "Senza_Rod_sono_una_frode", "rank": 21, "is_top_cut": false}, {"name": "Big_TunaX", "rank": 22, "is_top_cut": false}, {"name": "Emmet77", "rank": 23, "is_top_cut": false}, {"name": "Artorias94", "rank": 24, "is_top_cut": false}, {"name": "_Vento", "rank": 25, "is_top_cut": false}, {"name": "Nerkio", "rank": 26, "is_top_cut": false}, {"name": "MatteoFolle", "rank": 27, "is_top_cut": false}, {"name": "Shaka1985", "rank": 28, "is_top_cut": false}, {"name": "Napo_bx", "rank": 29, "is_top_cut": false}, {"name": "Bumbey", "rank": 30, "is_top_cut": false}, {"name": "Julescio", "rank": 31, "is_top_cut": false}, {"name": "Mad_Blade", "rank": 32, "is_top_cut": false}, {"name": "Brettbbx", "rank": 33, "is_top_cut": false}, {"name": "BladerXF", "rank": 34, "is_top_cut": false}, {"name": "_M1RAGE_", "rank": 35, "is_top_cut": false}, {"name": "Flavio2015", "rank": 36, "is_top_cut": false}, {"name": "RionX", "rank": 37, "is_top_cut": false}, {"name": "Trottolina_Amorosa", "rank": 38, "is_top_cut": false}, {"name": "picci8", "rank": 39, "is_top_cut": false}, {"name": "LucaNP", "rank": 40, "is_top_cut": false}], "start_date": "2026-02-15T00:00:00", "total_players": 40, "tournament_name": "UBX RANKED BEYLEAGUE 15/02 STANDARD - Classifiche"}	2026-08-21 16:54:50.764453
768	zu5bm1fn	{"id": "zu5bm1fn", "standings": [{"name": "Jay_Mugiwara", "rank": 1, "is_top_cut": true}, {"name": "Ubekage", "rank": 2, "is_top_cut": true}, {"name": "_Zein", "rank": 3, "is_top_cut": true}, {"name": "Anatra_finale", "rank": 4, "is_top_cut": true}, {"name": "_D_Hakkai", "rank": 5, "is_top_cut": true}, {"name": "Bastoos", "rank": 5, "is_top_cut": true}, {"name": "Miani83", "rank": 5, "is_top_cut": true}, {"name": "Nerkio", "rank": 5, "is_top_cut": true}, {"name": "hellboy_09", "rank": 9, "is_top_cut": false}, {"name": "Federeeeco", "rank": 10, "is_top_cut": false}, {"name": "Brettbbx", "rank": 11, "is_top_cut": false}, {"name": "GHOST__23", "rank": 12, "is_top_cut": false}, {"name": "_Vento", "rank": 13, "is_top_cut": false}, {"name": "Dark_ritow", "rank": 14, "is_top_cut": false}, {"name": "Turbo73_Ruben", "rank": 15, "is_top_cut": false}, {"name": "idril20xx", "rank": 16, "is_top_cut": false}, {"name": "Marty20xx", "rank": 17, "is_top_cut": false}, {"name": "ShonBeyXx", "rank": 18, "is_top_cut": false}, {"name": "SuperSonicGjo", "rank": 19, "is_top_cut": false}, {"name": "Mad_Blade", "rank": 20, "is_top_cut": false}, {"name": "Jonathan2011", "rank": 21, "is_top_cut": false}, {"name": "PerSempre", "rank": 22, "is_top_cut": false}, {"name": "Depa19", "rank": 23, "is_top_cut": false}, {"name": "UNDER100", "rank": 24, "is_top_cut": false}, {"name": "Paolomu_99", "rank": 25, "is_top_cut": false}], "start_date": "2026-02-21T00:00:00", "total_players": 25, "tournament_name": "UBX RANKED BEYLEAGUE 21/02 STANDARD - Classifiche"}	2026-08-21 16:54:51.312274
769	yqof4j2q	{"id": "yqof4j2q", "standings": [{"name": "_D_Hakkai", "rank": 1, "is_top_cut": true}, {"name": "Bicbo", "rank": 2, "is_top_cut": true}, {"name": "Mhasik", "rank": 3, "is_top_cut": true}, {"name": "BusterDran", "rank": 4, "is_top_cut": true}, {"name": "Anatra_finale", "rank": 5, "is_top_cut": true}, {"name": "cacci351", "rank": 5, "is_top_cut": true}, {"name": "MaccheRonin", "rank": 5, "is_top_cut": true}, {"name": "Massimassi", "rank": 5, "is_top_cut": true}, {"name": "Jonathan2011", "rank": 9, "is_top_cut": false}, {"name": "Dark_ritow", "rank": 10, "is_top_cut": false}, {"name": "Tramu_BV", "rank": 11, "is_top_cut": false}, {"name": "Nerkio", "rank": 12, "is_top_cut": false}, {"name": "PerSempre", "rank": 13, "is_top_cut": false}, {"name": "Miani83", "rank": 14, "is_top_cut": false}, {"name": "Themistokles16", "rank": 15, "is_top_cut": false}, {"name": "RionX", "rank": 16, "is_top_cut": false}, {"name": "ShonBeyXx", "rank": 17, "is_top_cut": false}, {"name": "Pigi_fenix", "rank": 18, "is_top_cut": false}, {"name": "Brettbbx", "rank": 19, "is_top_cut": false}, {"name": "Jay_Mugiwara", "rank": 20, "is_top_cut": false}, {"name": "Turbo73_Ruben", "rank": 21, "is_top_cut": false}, {"name": "Riccio97", "rank": 22, "is_top_cut": false}, {"name": "Shaka1985", "rank": 23, "is_top_cut": false}, {"name": "Zigozago284", "rank": 24, "is_top_cut": false}, {"name": "Depa19", "rank": 25, "is_top_cut": false}, {"name": "Seppiozzo", "rank": 26, "is_top_cut": false}, {"name": "Aridran", "rank": 27, "is_top_cut": false}, {"name": "Drysepht", "rank": 28, "is_top_cut": false}, {"name": "Konau", "rank": 29, "is_top_cut": false}, {"name": "Maxdavi100", "rank": 30, "is_top_cut": false}, {"name": "GerardoDelia", "rank": 31, "is_top_cut": false}, {"name": "_Vento", "rank": 32, "is_top_cut": false}], "start_date": "2026-02-22T00:00:00", "total_players": 32, "tournament_name": "UBX RANKED BEYLEAGUE 22/02 STANDARD"}	2026-08-21 16:54:51.83259
770	x24um8op	{"id": "x24um8op", "standings": [{"name": "BleaderA", "rank": 1, "is_top_cut": true}, {"name": "Youngsnapp10", "rank": 2, "is_top_cut": true}, {"name": "anima_L", "rank": 3, "is_top_cut": true}, {"name": "Noktis1O", "rank": 4, "is_top_cut": true}, {"name": "Donguz", "rank": 5, "is_top_cut": true}, {"name": "PoverettoKid", "rank": 5, "is_top_cut": true}, {"name": "HarukoEbi", "rank": 7, "is_top_cut": true}, {"name": "Spadaccino", "rank": 7, "is_top_cut": true}, {"name": "MetalRaffo", "rank": 9, "is_top_cut": false}, {"name": "KapraStyle", "rank": 10, "is_top_cut": false}, {"name": "Rosy66", "rank": 11, "is_top_cut": false}, {"name": "Espionerion", "rank": 12, "is_top_cut": false}, {"name": "Eminenza_grigia", "rank": 13, "is_top_cut": false}, {"name": "LasagnaVulvosa", "rank": 14, "is_top_cut": false}, {"name": "peps10", "rank": 15, "is_top_cut": false}, {"name": "IL_PL_99", "rank": 16, "is_top_cut": false}, {"name": "Leone400", "rank": 17, "is_top_cut": false}, {"name": "SharkDav_98", "rank": 18, "is_top_cut": false}, {"name": "Andy_One", "rank": 19, "is_top_cut": false}, {"name": "Jhon", "rank": 20, "is_top_cut": false}, {"name": "Rengoku10", "rank": 21, "is_top_cut": false}, {"name": "LPhoenix1", "rank": 22, "is_top_cut": false}, {"name": "Jacksada", "rank": 23, "is_top_cut": false}], "start_date": "2026-02-07T18:52:00", "total_players": 23, "tournament_name": "WHITE DRAKE - LEAGUE TOURNAMENT 07/02 - IBNA STANDARD - Classifiche"}	2026-08-21 16:54:52.387123
771	elhvomef	{"id": "elhvomef", "standings": [{"name": "ElevateKid", "rank": 1, "is_top_cut": true}, {"name": "Redd0", "rank": 2, "is_top_cut": true}, {"name": "YoUnG_SnApP10", "rank": 3, "is_top_cut": true}, {"name": "Bakudomo", "rank": 4, "is_top_cut": true}, {"name": "Autocratico fascista", "rank": 5, "is_top_cut": true}, {"name": "Botta00", "rank": 6, "is_top_cut": true}, {"name": "3NTØNY", "rank": 7, "is_top_cut": true}, {"name": "ZzaWarudo", "rank": 7, "is_top_cut": true}, {"name": "PartisanTunic", "rank": 9, "is_top_cut": false}, {"name": "Xtiranno", "rank": 10, "is_top_cut": false}, {"name": "Robides", "rank": 11, "is_top_cut": false}, {"name": "Goblin_69", "rank": 12, "is_top_cut": false}, {"name": "Xlarax", "rank": 13, "is_top_cut": false}, {"name": "Thagomizer", "rank": 14, "is_top_cut": false}, {"name": "_Gabii_", "rank": 15, "is_top_cut": false}, {"name": "Fabbo_97", "rank": 16, "is_top_cut": false}, {"name": "Seven861", "rank": 17, "is_top_cut": false}, {"name": "TheGhost2015", "rank": 18, "is_top_cut": false}, {"name": "fedone", "rank": 19, "is_top_cut": false}, {"name": "BleaderA", "rank": 20, "is_top_cut": false}, {"name": "Rayblad25", "rank": 21, "is_top_cut": false}, {"name": "Xayrevers45", "rank": 22, "is_top_cut": false}], "start_date": "2026-03-07T00:00:00", "total_players": 22, "tournament_name": "WYVERN x AEROSPHYNX - RANKED 07/03/26 - IBNA STANDARD - Classifiche"}	2026-08-21 16:54:52.95031
772	HydraCore_Tappa1_Lega_IBNA	{"id": "HydraCore_Tappa1_Lega_IBNA", "standings": [{"name": "Ste67_Motivated", "rank": 1, "is_top_cut": true}, {"name": "3NTØNY", "rank": 2, "is_top_cut": true}, {"name": "LeonardoDiCarpi", "rank": 3, "is_top_cut": true}, {"name": "Nicx15", "rank": 4, "is_top_cut": true}, {"name": "Pesyb", "rank": 5, "is_top_cut": true}, {"name": "TheSituation14", "rank": 6, "is_top_cut": true}, {"name": "Fyxit", "rank": 7, "is_top_cut": true}, {"name": "Seven", "rank": 8, "is_top_cut": true}, {"name": "Devis_Ucarlo", "rank": 9, "is_top_cut": false}, {"name": "DystopianViper39", "rank": 10, "is_top_cut": false}, {"name": "Blaster_Chimera98", "rank": 11, "is_top_cut": false}, {"name": "Redd0", "rank": 12, "is_top_cut": false}, {"name": "Fabbo_97", "rank": 13, "is_top_cut": false}, {"name": "Botta00", "rank": 14, "is_top_cut": false}, {"name": "Blader_A15", "rank": 15, "is_top_cut": false}, {"name": "_Jinx", "rank": 16, "is_top_cut": false}, {"name": "Buster_Duck", "rank": 17, "is_top_cut": false}, {"name": "Feder000", "rank": 18, "is_top_cut": false}, {"name": "Shackur87", "rank": 19, "is_top_cut": false}, {"name": "MatteMantovani", "rank": 20, "is_top_cut": false}, {"name": "Hudi15", "rank": 21, "is_top_cut": false}, {"name": "Rayblad25", "rank": 22, "is_top_cut": false}, {"name": "_Gabii_", "rank": 23, "is_top_cut": false}, {"name": "_Sketchy_", "rank": 24, "is_top_cut": false}, {"name": "Linkin_Shark", "rank": 25, "is_top_cut": false}, {"name": "GiacomoLuzzi", "rank": 26, "is_top_cut": false}, {"name": "_DkAngelo_", "rank": 27, "is_top_cut": false}, {"name": "gorillaz3", "rank": 28, "is_top_cut": false}, {"name": "Don Lorenzo", "rank": 29, "is_top_cut": false}, {"name": "Gique", "rank": 30, "is_top_cut": false}, {"name": "ToX", "rank": 31, "is_top_cut": false}], "start_date": "2026-02-21T00:00:00", "total_players": 31, "tournament_name": "TORNEO HYDRA CORE - LEGA RANKED 21/02 - IBNA STANDARD 2026 - Classifiche"}	2026-08-21 17:22:32.879856
773	bcxlfntz	{"id": "bcxlfntz", "standings": [{"name": "CrudeliaDeMon", "rank": 1, "is_top_cut": true}, {"name": "Skizzo10", "rank": 2, "is_top_cut": true}, {"name": "_Ezecutor-iBh", "rank": 3, "is_top_cut": true}, {"name": "Walter", "rank": 4, "is_top_cut": true}, {"name": "_J_O_K_E_R_", "rank": 5, "is_top_cut": true}, {"name": "Fra86170", "rank": 5, "is_top_cut": true}, {"name": "FrancisFordTrottola", "rank": 5, "is_top_cut": true}, {"name": "Spartaco31", "rank": 5, "is_top_cut": true}, {"name": "_Marks", "rank": 9, "is_top_cut": true}, {"name": "Deledea", "rank": 9, "is_top_cut": true}, {"name": "Giammi", "rank": 9, "is_top_cut": true}, {"name": "Leventiel", "rank": 9, "is_top_cut": true}, {"name": "Oh_Nico", "rank": 9, "is_top_cut": true}, {"name": "Sunshine", "rank": 9, "is_top_cut": true}, {"name": "Tiziano_Banano", "rank": 9, "is_top_cut": true}, {"name": "Wolverine23", "rank": 9, "is_top_cut": true}, {"name": "Giann19", "rank": 17, "is_top_cut": false}, {"name": "StormPrelude", "rank": 18, "is_top_cut": false}, {"name": "Bigsimmy", "rank": 19, "is_top_cut": false}, {"name": "_Greta_96", "rank": 20, "is_top_cut": false}, {"name": "Pikachu_16", "rank": 21, "is_top_cut": false}, {"name": "ELCULON", "rank": 22, "is_top_cut": false}, {"name": "BonnyBong", "rank": 23, "is_top_cut": false}, {"name": "Palissandro", "rank": 24, "is_top_cut": false}, {"name": "TeoBerto", "rank": 25, "is_top_cut": false}, {"name": "Dedours", "rank": 26, "is_top_cut": false}, {"name": "Jaypoy", "rank": 27, "is_top_cut": false}, {"name": "Myridar", "rank": 28, "is_top_cut": false}, {"name": "Charizard_18", "rank": 29, "is_top_cut": false}, {"name": "DooMS20", "rank": 30, "is_top_cut": false}, {"name": "N2Z2", "rank": 31, "is_top_cut": false}, {"name": "Suaveeee", "rank": 32, "is_top_cut": false}, {"name": "Donkeymax", "rank": 33, "is_top_cut": false}, {"name": "TORO", "rank": 34, "is_top_cut": false}, {"name": "Dante9053", "rank": 35, "is_top_cut": false}, {"name": "Bronev", "rank": 36, "is_top_cut": false}, {"name": "Xaldin99", "rank": 37, "is_top_cut": false}, {"name": "Cico", "rank": 38, "is_top_cut": false}, {"name": "ContactBlader", "rank": 39, "is_top_cut": false}, {"name": "Giko89", "rank": 40, "is_top_cut": false}, {"name": "Laura19", "rank": 41, "is_top_cut": false}, {"name": "Renegaderene", "rank": 42, "is_top_cut": false}, {"name": "Manolo10", "rank": 43, "is_top_cut": false}, {"name": "Chriss18", "rank": 44, "is_top_cut": false}, {"name": "PrincipessaPeach", "rank": 45, "is_top_cut": false}, {"name": "Feder_X", "rank": 46, "is_top_cut": false}], "start_date": "2026-02-14T00:00:00", "total_players": 46, "tournament_name": "Alma Draco RANKED 2026 x IBNA 14/02 - Classifiche"}	2026-08-21 17:27:01.558778
774	7n5h2jxb	{"id": "7n5h2jxb", "standings": [{"name": "Salas_1", "rank": 1, "is_top_cut": true}, {"name": "SfornaPatate", "rank": 2, "is_top_cut": true}, {"name": "Thagomizer", "rank": 3, "is_top_cut": true}, {"name": "SnoopDoggX", "rank": 4, "is_top_cut": true}, {"name": "Xlarax", "rank": 5, "is_top_cut": true}, {"name": "_Greta_96", "rank": 6, "is_top_cut": true}, {"name": "_J_O_K_E_R_", "rank": 7, "is_top_cut": true}, {"name": "ChuckNorris10", "rank": 8, "is_top_cut": true}, {"name": "Robides", "rank": 9, "is_top_cut": false}, {"name": "GustavoLaFessa", "rank": 10, "is_top_cut": false}, {"name": "DarC12", "rank": 11, "is_top_cut": false}, {"name": "_Sketchy_", "rank": 12, "is_top_cut": false}, {"name": "Redd0", "rank": 13, "is_top_cut": false}, {"name": "Pesyb", "rank": 14, "is_top_cut": false}, {"name": "L_MAMA", "rank": 15, "is_top_cut": false}, {"name": "ZORO15", "rank": 16, "is_top_cut": false}, {"name": "JackC84", "rank": 17, "is_top_cut": false}, {"name": "Youngsnapp10", "rank": 18, "is_top_cut": false}, {"name": "Dante9053", "rank": 19, "is_top_cut": false}, {"name": "Midorina", "rank": 20, "is_top_cut": false}, {"name": "LL_blader_15", "rank": 21, "is_top_cut": false}, {"name": "Misellazzo", "rank": 22, "is_top_cut": false}, {"name": "xGabiix", "rank": 23, "is_top_cut": false}, {"name": "Miky77", "rank": 24, "is_top_cut": false}, {"name": "Nicx15", "rank": 25, "is_top_cut": false}, {"name": "DaggerFrederik", "rank": 26, "is_top_cut": false}, {"name": "Blader_Richi22", "rank": 27, "is_top_cut": false}, {"name": "unicornorologio", "rank": 28, "is_top_cut": false}, {"name": "Sylveon11", "rank": 29, "is_top_cut": false}, {"name": "BabboBurstale", "rank": 30, "is_top_cut": false}], "start_date": "2026-02-15T00:00:00", "total_players": 30, "tournament_name": "TORNEO RANKED IBNA STANDARD WYVERN - 15/02/26 - Classifiche"}	2026-08-21 17:27:03.147222
775	tg2x5o5c	{"id": "tg2x5o5c", "standings": [{"name": "Blaster_Hydra", "rank": 1, "is_top_cut": true}, {"name": "Redd0", "rank": 2, "is_top_cut": true}, {"name": "Sampei_the_Blader", "rank": 3, "is_top_cut": true}, {"name": "_Steffo_", "rank": 4, "is_top_cut": true}, {"name": "RagazzoScheletro", "rank": 5, "is_top_cut": true}, {"name": "Vichingo", "rank": 6, "is_top_cut": true}, {"name": "Tonix93", "rank": 7, "is_top_cut": true}, {"name": "Xtiranno", "rank": 8, "is_top_cut": true}, {"name": "Ste67_Motivated", "rank": 9, "is_top_cut": false}, {"name": "Vally34", "rank": 10, "is_top_cut": false}, {"name": "ZzaWarudo", "rank": 11, "is_top_cut": false}, {"name": "Bakudomo", "rank": 12, "is_top_cut": false}, {"name": "Robides", "rank": 13, "is_top_cut": false}, {"name": "Miky77", "rank": 14, "is_top_cut": false}, {"name": "Cosmo89xD", "rank": 15, "is_top_cut": false}, {"name": "Thagomizer", "rank": 16, "is_top_cut": false}, {"name": "L_MAMA", "rank": 17, "is_top_cut": false}, {"name": "Sneezyreal_10", "rank": 18, "is_top_cut": false}, {"name": "_Greta_96", "rank": 19, "is_top_cut": false}, {"name": "_Gabii_", "rank": 20, "is_top_cut": false}, {"name": "Zio_Fra74", "rank": 21, "is_top_cut": false}, {"name": "Dante9053", "rank": 22, "is_top_cut": false}, {"name": "ZORO15", "rank": 23, "is_top_cut": false}, {"name": "SnoopDoggX", "rank": 24, "is_top_cut": false}, {"name": "_J_O_K_E_R_", "rank": 25, "is_top_cut": false}, {"name": "Rayblad25", "rank": 26, "is_top_cut": false}, {"name": "JackC84", "rank": 27, "is_top_cut": false}, {"name": "DonLorenz0", "rank": 28, "is_top_cut": false}], "start_date": "2026-03-01T00:00:00", "total_players": 28, "tournament_name": "TORNEO WYVERN - RANKED 1/3- zero one - Classifiche"}	2026-08-21 17:27:04.726076
\.


--
-- Data for Name: challonge_players; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.challonge_players (id, nickname, avatar, updated_at) FROM stdin;
7429014	RAGAZZO_SCHELETRO	https://user-assets.challonge.com/users/images/007/429/014/hdpi/IMG_20251202_002537.png	2026-02-04 09:42:41.746103+00
Zanna85	Zanna85	\N	2026-08-21 14:54:31.710687+00
_arAle_	_arAle_	\N	2026-08-21 14:54:31.711257+00
masterpippo	masterpippo	\N	2026-08-21 14:54:31.713144+00
edomark	edomark	\N	2026-08-21 14:54:31.713768+00
POWDER_07	POWDER_07	\N	2026-08-21 14:54:31.714968+00
LeonardoDiCarpi	LeonardoDiCarpi	\N	2026-08-21 15:22:32.887186+00
Dheidhara	Dheidhara	\N	2026-08-21 14:54:31.718292+00
FranciBerto	FranciBerto	\N	2026-08-21 14:54:31.71939+00
Scarlet25	Scarlet25	\N	2026-08-21 14:54:31.720045+00
Giaruto	Giaruto	\N	2026-08-21 14:54:31.721466+00
RikuGG_	RikuGG_	\N	2026-08-21 14:54:31.722166+00
Draxler811_	Draxler811_	\N	2026-08-21 14:54:31.72272+00
TheSituation14	TheSituation14	\N	2026-08-21 15:22:32.889237+00
MetalClover	MetalClover	\N	2026-08-21 14:54:31.724964+00
Seven	Seven	\N	2026-08-21 15:22:32.890747+00
LeohLKing	LeohLKing	\N	2026-08-21 14:54:31.726083+00
Vergio101	Vergio101	\N	2026-08-21 14:54:31.727178+00
AndrewLKing	AndrewLKing	\N	2026-08-21 14:54:31.727719+00
Devis_Ucarlo	Devis_Ucarlo	\N	2026-08-21 15:22:32.891351+00
Ehisnam	Ehisnam	\N	2026-08-21 14:54:31.729178+00
India_Pale_Ale	India_Pale_Ale	\N	2026-08-21 14:54:31.730395+00
DystopianViper39	DystopianViper39	\N	2026-08-21 15:22:32.891943+00
Blader N	Blader N	\N	2026-08-21 14:54:31.732725+00
Asriel2	Asriel2	\N	2026-08-21 14:54:31.733284+00
leogiova	leogiova	\N	2026-08-21 14:54:34.23062+00
Musshu	Musshu	\N	2026-08-21 14:54:49.182705+00
Buscaduto	Buscaduto	\N	2026-08-21 14:54:32.207382+00
BLÅCKJÅCK	BLÅCKJÅCK	\N	2026-08-21 14:54:32.207923+00
Matty92bey	Matty92bey	\N	2026-08-21 14:54:47.635053+00
Chef_Rossini	Chef_Rossini	\N	2026-08-21 14:54:43.01871+00
Vexel666	Vexel666	\N	2026-08-21 14:54:37.24507+00
Jimmy1996	Jimmy1996	\N	2026-08-21 14:54:32.211716+00
SpaceGirlfriend	SpaceGirlfriend	\N	2026-08-21 14:54:43.020384+00
Cobralori	Cobralori	\N	2026-08-21 14:54:32.215746+00
Ubekage	Ubekage	\N	2026-08-21 14:54:51.316377+00
KPopBlade	KPopBlade	\N	2026-08-21 14:54:32.217394+00
Sapux	Sapux	\N	2026-08-21 14:54:32.218951+00
Ros Bey	Ros Bey	\N	2026-08-21 14:54:32.219466+00
TirannoNico	TirannoNico	\N	2026-08-21 14:54:32.220615+00
smvr8	smvr8	\N	2026-08-21 14:54:32.221827+00
Jakson	Jakson	\N	2026-08-21 14:54:32.222418+00
Shadow	Shadow	\N	2026-08-21 14:54:32.222967+00
4RTV	4RTV	\N	2026-08-21 14:54:32.763596+00
Frakki	Frakki	\N	2026-08-21 14:54:37.241859+00
Alnas	Alnas	\N	2026-08-21 14:54:32.764751+00
Dase05_	Dase05_	\N	2026-08-21 14:54:37.243955+00
SaltyKessi	SaltyKessi	\N	2026-08-21 14:54:32.766928+00
ROSBLADE	ROSBLADE	\N	2026-08-21 14:54:32.767483+00
Maestro_Miyagi	Maestro_Miyagi	\N	2026-08-21 14:54:32.768027+00
_Sketchy_	_Sketchy_	\N	2026-08-21 15:27:03.157083+00
_D_Hakkai	_D_Hakkai	\N	2026-08-21 14:54:51.834249+00
beerdcello66	beerdcello66	\N	2026-08-21 14:54:32.770971+00
Tiresia_	Tiresia_	\N	2026-08-21 14:54:47.636222+00
AuraTaccons	AuraTaccons	\N	2026-08-21 14:54:33.250317+00
Blaster_Chimera98	Blaster_Chimera98	\N	2026-08-21 15:22:32.892553+00
Mr_Fuffolone	Mr_Fuffolone	\N	2026-08-21 14:54:33.253069+00
Blader_A15	Blader_A15	\N	2026-08-21 15:22:32.894868+00
_Jinx	_Jinx	\N	2026-08-21 15:22:32.895418+00
Buster_Duck	Buster_Duck	\N	2026-08-21 15:22:32.895973+00
Crusblade	Crusblade	\N	2026-08-21 14:54:33.260032+00
Feder000	Feder000	\N	2026-08-21 15:22:32.896516+00
Gringo	Gringo	\N	2026-08-21 14:54:33.263138+00
JohnBey	JohnBey	\N	2026-08-21 14:54:33.264855+00
GengisChad	GengisChad	\N	2026-08-21 14:54:33.268612+00
Balentine_AFST	Balentine_AFST	\N	2026-08-21 14:54:33.270291+00
Twins_2016	Twins_2016	\N	2026-08-21 14:54:47.632175+00
SledgeHammer94	SledgeHammer94	\N	2026-08-21 14:54:34.232279+00
Raidenkiuby	Raidenkiuby	\N	2026-08-21 14:54:34.233349+00
Alicino_AFST	Alicino_AFST	\N	2026-08-21 14:54:46.612345+00
Xliga	Xliga	\N	2026-08-21 14:54:34.238466+00
Hyskel	Hyskel	\N	2026-08-21 14:54:34.240193+00
Idignio	Idignio	\N	2026-08-21 14:54:34.241281+00
Pevons	Pevons	\N	2026-08-21 14:54:34.244522+00
#MaiunaGioia	#MaiunaGioia	\N	2026-08-21 14:54:34.245213+00
Bicbo	Bicbo	\N	2026-08-21 14:54:51.836459+00
Bellaccia	Bellaccia	\N	2026-08-21 14:54:34.25311+00
Piramide_	Piramide_	\N	2026-08-21 14:54:37.244519+00
Andy_bbx	Andy_bbx	\N	2026-08-21 14:54:37.245655+00
ILDISTO	ILDISTO	\N	2026-08-21 14:54:37.246306+00
AuraFarming	AuraFarming	\N	2026-08-21 14:54:37.246896+00
SoraKurosaki	SoraKurosaki	\N	2026-08-21 14:54:38.787743+00
Anatra_finale	Anatra_finale	\N	2026-08-21 14:54:51.838417+00
Gabbob	Gabbob	\N	2026-08-21 14:54:38.790177+00
JuliusHyodo	JuliusHyodo	\N	2026-08-21 14:54:50.775178+00
GerroBlader	GerroBlader	\N	2026-08-21 14:54:40.850546+00
Deca96	Deca96	\N	2026-08-21 14:54:40.851088+00
Shackur87	Shackur87	\N	2026-08-21 15:22:32.897028+00
AlanLee86	AlanLee86	\N	2026-08-21 14:54:40.853824+00
Jonathan2011	Jonathan2011	\N	2026-08-21 14:54:51.840811+00
Brian303	Brian303	\N	2026-08-21 14:54:39.834255+00
MatteMantovani	MatteMantovani	\N	2026-08-21 15:22:32.897579+00
Nerkio	Nerkio	\N	2026-08-21 14:54:51.842488+00
SoLollo	SoLollo	\N	2026-08-21 14:54:38.80433+00
Hudi15	Hudi15	\N	2026-08-21 15:22:32.898124+00
Miani83	Miani83	\N	2026-08-21 14:54:51.843568+00
Mr_Tuna_Head	Mr_Tuna_Head	\N	2026-08-21 14:54:38.809429+00
Toncho04	Toncho04	\N	2026-08-21 14:54:40.337417+00
ShonBeyXx	ShonBeyXx	\N	2026-08-21 14:54:51.845192+00
RingLords	RingLords	\N	2026-08-21 14:54:47.633894+00
Federeeeco	Federeeeco	\N	2026-08-21 14:54:51.320829+00
Ludix96	Ludix96	\N	2026-08-21 14:54:39.320521+00
GiacomoLuzzi	GiacomoLuzzi	\N	2026-08-21 15:22:32.900793+00
Red	Red	\N	2026-08-21 14:54:39.321778+00
Brettbbx	Brettbbx	\N	2026-08-21 14:54:51.846364+00
idril20xx	idril20xx	\N	2026-08-21 14:54:51.32427+00
Newteam91	Newteam91	\N	2026-08-21 14:54:48.679622+00
_DkAngelo_	_DkAngelo_	\N	2026-08-21 15:22:32.901332+00
gorillaz3	gorillaz3	\N	2026-08-21 15:22:32.901883+00
Cricco	Cricco	\N	2026-08-21 14:54:40.860548+00
Superabo56	Superabo56	\N	2026-08-21 14:54:47.636907+00
ToMs0	ToMs0	\N	2026-08-21 14:54:40.862334+00
Pesyb	Pesyb	\N	2026-08-21 15:27:03.158275+00
Marty20xx	Marty20xx	\N	2026-08-21 14:54:51.324794+00
Fried_Toxic_Rice	Fried_Toxic_Rice	\N	2026-08-21 14:54:47.634476+00
Xtiranno	Xtiranno	\N	2026-08-21 15:27:04.734019+00
_M1RAGE_	_M1RAGE_	\N	2026-08-21 14:54:50.786915+00
Edo2016	Edo2016	\N	2026-08-21 14:54:40.873096+00
Mazinga2016	Mazinga2016	\N	2026-08-21 14:54:47.637599+00
DrHats	DrHats	\N	2026-08-21 14:54:47.638887+00
Nico13	Nico13	\N	2026-08-21 14:54:47.640664+00
_Eva01	_Eva01	\N	2026-08-21 14:54:47.641784+00
Pobaz98	Pobaz98	\N	2026-08-21 14:54:47.643429+00
Vinci31	Vinci31	\N	2026-08-21 14:54:47.644532+00
KaghemushaSama	KaghemushaSama	\N	2026-08-21 14:54:47.645152+00
Gabrimarche	Gabrimarche	\N	2026-08-21 14:54:47.646637+00
cosonakking3000	cosonakking3000	\N	2026-08-21 14:54:47.648842+00
BladerX1	BladerX1	\N	2026-08-21 14:54:47.64938+00
Paolomu_99	Paolomu_99	\N	2026-08-21 14:54:51.329167+00
3NTØNY	3NTØNY	\N	2026-08-21 15:22:32.886553+00
Fyxit	Fyxit	\N	2026-08-21 15:22:32.889874+00
Gique	Gique	\N	2026-08-21 15:22:32.902955+00
ToX	ToX	\N	2026-08-21 15:22:32.903503+00
_Ezecutor-iBh	_Ezecutor-iBh	\N	2026-08-21 15:27:01.564257+00
Walter	Walter	\N	2026-08-21 15:27:01.564818+00
FrancisFordTrottola	FrancisFordTrottola	\N	2026-08-21 15:27:01.56652+00
Deledea	Deledea	\N	2026-08-21 15:27:01.568264+00
Giammi	Giammi	\N	2026-08-21 15:27:01.568821+00
Sunshine	Sunshine	\N	2026-08-21 15:27:01.570547+00
Wolverine23	Wolverine23	\N	2026-08-21 15:27:01.571677+00
Giann19	Giann19	\N	2026-08-21 15:27:01.572235+00
Jaypoy	Jaypoy	\N	2026-08-21 15:27:01.578007+00
DooMS20	DooMS20	\N	2026-08-21 15:27:01.579729+00
N2Z2	N2Z2	\N	2026-08-21 15:27:01.580303+00
Suaveeee	Suaveeee	\N	2026-08-21 15:27:01.580897+00
TORO	TORO	\N	2026-08-21 15:27:01.582075+00
Bronev	Bronev	\N	2026-08-21 15:27:01.583243+00
Giko89	Giko89	\N	2026-08-21 15:27:01.585478+00
Laura19	Laura19	\N	2026-08-21 15:27:01.586114+00
Renegaderene	Renegaderene	\N	2026-08-21 15:27:01.586696+00
Manolo10	Manolo10	\N	2026-08-21 15:27:01.587254+00
Chriss18	Chriss18	\N	2026-08-21 15:27:01.587803+00
Feder_X	Feder_X	\N	2026-08-21 15:27:01.588914+00
ChuckNorris10	ChuckNorris10	\N	2026-08-21 15:27:03.154769+00
GustavoLaFessa	GustavoLaFessa	\N	2026-08-21 15:27:03.155928+00
DarC12	DarC12	\N	2026-08-21 15:27:03.156506+00
Misellazzo	Misellazzo	\N	2026-08-21 15:27:03.163002+00
xGabiix	xGabiix	\N	2026-08-21 15:27:03.163579+00
Nicx15	Nicx15	\N	2026-08-21 15:27:03.164734+00
DaggerFrederik	DaggerFrederik	\N	2026-08-21 15:27:03.165315+00
Blader_Richi22	Blader_Richi22	\N	2026-08-21 15:27:03.16589+00
Rednoe	Rednoe	\N	2026-08-21 14:54:34.228304+00
JerryUomoFagiolo	JerryUomoFagiolo	\N	2026-08-21 14:54:34.231717+00
ell_deablo	ell_deablo	\N	2026-08-21 14:54:34.232814+00
HADES93	HADES93	\N	2026-08-21 14:54:34.234417+00
Matty93	Matty93	\N	2026-08-21 14:54:34.234968+00
Simojr98	Simojr98	\N	2026-08-21 14:54:34.2355+00
Thalor	Thalor	\N	2026-08-21 14:54:34.236039+00
Cippi	Cippi	\N	2026-08-21 14:54:34.236678+00
Mr.Co	Mr.Co	\N	2026-08-21 14:54:34.237279+00
Sara_loca_99	Sara_loca_99	\N	2026-08-21 14:54:34.237877+00
Belair_	Belair_	\N	2026-08-21 14:54:34.239076+00
ManuBart	ManuBart	\N	2026-08-21 14:54:34.239626+00
gidio96	gidio96	\N	2026-08-21 14:54:34.240735+00
CAMSO	CAMSO	\N	2026-08-21 14:54:34.241838+00
Moffone	Moffone	\N	2026-08-21 14:54:34.242372+00
SeregonX	SeregonX	\N	2026-08-21 14:54:34.242906+00
Furia888	Furia888	\N	2026-08-21 14:54:34.243438+00
The_brother_91	The_brother_91	\N	2026-08-21 14:54:34.243973+00
TheGreat_Kurama	TheGreat_Kurama	\N	2026-08-21 14:54:34.245954+00
Pacis	Pacis	\N	2026-08-21 14:54:34.246567+00
Corinzio	Corinzio	\N	2026-08-21 14:54:34.247176+00
Korise	Korise	\N	2026-08-21 14:54:34.247715+00
Remio	Remio	\N	2026-08-21 14:54:34.248282+00
B14g10	B14g10	\N	2026-08-21 14:54:34.248817+00
MuLaN_X	MuLaN_X	\N	2026-08-21 14:54:34.249349+00
Filiphs24	Filiphs24	\N	2026-08-21 14:54:34.249882+00
Fumo95	Fumo95	\N	2026-08-21 14:54:34.250415+00
Sephiroth555	Sephiroth555	\N	2026-08-21 14:54:34.250956+00
Rmastu	Rmastu	\N	2026-08-21 14:54:34.252036+00
bas1	bas1	\N	2026-08-21 14:54:34.252578+00
AleCecca	AleCecca	\N	2026-08-21 14:54:34.253708+00
Tomax09	Tomax09	\N	2026-08-21 14:54:34.25492+00
Alexsp93	Alexsp93	\N	2026-08-21 14:54:34.256151+00
OffTravel	OffTravel	\N	2026-08-21 14:54:34.257275+00
polly91mat	polly91mat	\N	2026-08-21 14:54:34.257812+00
KinomiyaTakao	KinomiyaTakao	\N	2026-08-21 14:54:34.258349+00
Cosetta00	Cosetta00	\N	2026-08-21 14:54:34.258891+00
BladderN	BladderN	\N	2026-08-21 14:54:34.259428+00
Edèku	Edèku	\N	2026-08-21 14:54:34.259964+00
unicornorologio	unicornorologio	\N	2026-08-21 15:27:03.166475+00
Souten_no_ken	Souten_no_ken	\N	2026-08-21 14:54:34.749011+00
Sylveon11	Sylveon11	\N	2026-08-21 15:27:03.167057+00
SfornaPatateDolci	SfornaPatateDolci	\N	2026-08-21 14:54:34.752238+00
Snoop17	Snoop17	\N	2026-08-21 14:54:34.752762+00
BabboBurstale	BabboBurstale	\N	2026-08-21 15:27:03.167635+00
Ryckylyck	Ryckylyck	\N	2026-08-21 14:54:34.758499+00
Blaster_Hydra	Blaster_Hydra	\N	2026-08-21 15:27:04.727974+00
Tonix93	Tonix93	\N	2026-08-21 15:27:04.733396+00
Ste67_Motivated	Ste67_Motivated	\N	2026-08-21 15:27:04.734615+00
Vally34	Vally34	\N	2026-08-21 15:27:04.735211+00
Miky77	Miky77	\N	2026-08-21 15:27:04.737592+00
Cosmo89xD	Cosmo89xD	\N	2026-08-21 15:27:04.738203+00
chicosnef	chicosnef	\N	2026-08-21 14:54:34.765394+00
L_MAMA	L_MAMA	\N	2026-08-21 15:27:04.739403+00
Sneezyreal_10	Sneezyreal_10	\N	2026-08-21 15:27:04.740016+00
Lore_knight	Lore_knight	\N	2026-08-21 14:54:34.767548+00
ZORO15	ZORO15	\N	2026-08-21 15:27:04.743021+00
SnoopDoggX	SnoopDoggX	\N	2026-08-21 15:27:04.74362+00
_Snoozer	_Snoozer	\N	2026-08-21 14:54:35.243923+00
DonLorenz0	DonLorenz0	\N	2026-08-21 15:27:04.746081+00
Matzuda	Matzuda	\N	2026-08-21 14:54:37.247525+00
EOT_Negros	EOT_Negros	\N	2026-08-21 14:54:36.219471+00
Giacomo_Proiettile	Giacomo_Proiettile	\N	2026-08-21 14:54:37.248111+00
Banaleo49	Banaleo49	\N	2026-08-21 14:54:37.248667+00
Halloween5264	Halloween5264	\N	2026-08-21 14:54:37.249217+00
Sofi19	Sofi19	\N	2026-08-21 14:54:37.249745+00
IamVulgus	IamVulgus	\N	2026-08-21 14:54:37.250293+00
EarvS	EarvS	\N	2026-08-21 14:54:36.745777+00
Raula97	Raula97	\N	2026-08-21 14:54:37.250818+00
Mago_Nero	Mago_Nero	\N	2026-08-21 14:54:37.251364+00
Mergimiliano	Mergimiliano	\N	2026-08-21 14:54:37.251938+00
Fambrini	Fambrini	\N	2026-08-21 14:54:37.252499+00
Doctor_monkey	Doctor_monkey	\N	2026-08-21 14:54:37.253041+00
Eziusnanni	Eziusnanni	\N	2026-08-21 14:54:37.777539+00
Santa89	Santa89	\N	2026-08-21 14:54:40.858364+00
Sarina01	Sarina01	\N	2026-08-21 14:54:40.861723+00
Alo_thegunsl1nger	Alo_thegunsl1nger	\N	2026-08-21 14:54:40.869015+00
Enri2016	Enri2016	\N	2026-08-21 14:54:40.869551+00
duemilaventitre	duemilaventitre	\N	2026-08-21 14:54:41.913821+00
Masèō_8	Masèō_8	\N	2026-08-21 14:54:41.917729+00
Mr_baobab	Mr_baobab	\N	2026-08-21 14:54:45.08922+00
Orticoltore	Orticoltore	\N	2026-08-21 14:54:45.094802+00
EsDeeShark	EsDeeShark	\N	2026-08-21 14:54:45.102807+00
Pr1m0s	Pr1m0s	\N	2026-08-21 14:54:47.628734+00
Ispanico1986	Ispanico1986	\N	2026-08-21 14:54:47.635653+00
Ganga	Ganga	\N	2026-08-21 14:54:35.247882+00
Mara	Mara	\N	2026-08-21 14:54:35.249547+00
ll_Ezecutor-iBh	ll_Ezecutor-iBh	\N	2026-08-21 14:54:35.72272+00
Giammi08	Giammi08	\N	2026-08-21 14:54:35.730209+00
Adri_81	Adri_81	\N	2026-08-21 14:54:35.731334+00
BruteForce	BruteForce	\N	2026-08-21 14:54:35.73564+00
gioepifani	gioepifani	\N	2026-08-21 14:54:35.739099+00
Imperatore_Level22	Imperatore_Level22	\N	2026-08-21 14:54:41.905972+00
B3rserker	B3rserker	\N	2026-08-21 14:54:41.91494+00
Escariota	Escariota	\N	2026-08-21 14:54:36.21685+00
DemonSampei	DemonSampei	\N	2026-08-21 14:54:45.095958+00
SfornaPatate	SfornaPatate	\N	2026-08-21 15:27:03.151229+00
Linkin_Shark	Linkin_Shark	\N	2026-08-21 15:22:32.900257+00
♤PhilRy♤	♤PhilRy♤	\N	2026-08-21 14:54:36.221699+00
LucaZambro	LucaZambro	\N	2026-08-21 14:54:36.222231+00
ChiperZero1	ChiperZero1	\N	2026-08-21 14:54:36.225026+00
Nonnonanni	Nonnonanni	\N	2026-08-21 14:54:36.22556+00
TreZLionS	TreZLionS	\N	2026-08-21 14:54:36.226083+00
NOVA	NOVA	\N	2026-08-21 14:54:36.226612+00
Beltram	Beltram	\N	2026-08-21 14:54:36.230001+00
Papadriou	Papadriou	\N	2026-08-21 14:54:36.231088+00
MaT1806	MaT1806	\N	2026-08-21 14:54:36.232672+00
CrispyDanger	CrispyDanger	\N	2026-08-21 14:54:36.233186+00
Skǫll	Skǫll	\N	2026-08-21 14:54:36.233712+00
Condor15	Condor15	\N	2026-08-21 14:54:36.234227+00
CrudeliaDeMon	CrudeliaDeMon	\N	2026-08-21 15:27:01.561238+00
Scrotobleyder	Scrotobleyder	\N	2026-08-21 14:54:45.103468+00
GZeta	GZeta	\N	2026-08-21 14:54:36.236335+00
Mikelone	Mikelone	\N	2026-08-21 14:54:36.237599+00
Viper X	Viper X	\N	2026-08-21 14:54:36.238134+00
LL_blader_15	LL_blader_15	\N	2026-08-21 15:27:03.16239+00
Giovermir	Giovermir	\N	2026-08-21 14:54:36.239908+00
Justjack90	Justjack90	\N	2026-08-21 14:54:36.727382+00
Redd0	Redd0	\N	2026-08-21 15:27:04.730361+00
ToRoAdry	ToRoAdry	\N	2026-08-21 14:54:36.730408+00
_Greta_96	_Greta_96	\N	2026-08-21 15:27:04.740635+00
Dante9053	Dante9053	\N	2026-08-21 15:27:04.742435+00
Khaleesi07	Khaleesi07	\N	2026-08-21 14:54:36.732707+00
Skizzo10	Skizzo10	\N	2026-08-21 15:27:01.563675+00
_J_O_K_E_R_	_J_O_K_E_R_	\N	2026-08-21 15:27:04.74423+00
Anna70	Anna70	\N	2026-08-21 14:54:36.734412+00
DeadSpall	DeadSpall	\N	2026-08-21 14:54:36.735559+00
IronGabry	IronGabry	\N	2026-08-21 14:54:36.736697+00
PhilRy	PhilRy	\N	2026-08-21 14:54:36.737327+00
SyNC0	SyNC0	\N	2026-08-21 14:54:36.741842+00
Fra86170	Fra86170	\N	2026-08-21 15:27:01.56594+00
KOB_14	KOB_14	\N	2026-08-21 14:54:36.743503+00
_Kenzo	_Kenzo	\N	2026-08-21 14:54:36.74405+00
Spartaco31	Spartaco31	\N	2026-08-21 15:27:01.567154+00
Wolverine	Wolverine	\N	2026-08-21 14:54:36.749151+00
RedBandicoot	RedBandicoot	\N	2026-08-21 14:54:36.749682+00
N3k019	N3k019	\N	2026-08-21 14:54:36.75077+00
RoboBarat	RoboBarat	\N	2026-08-21 14:54:36.751315+00
Aaronjulz	Aaronjulz	\N	2026-08-21 14:54:36.75186+00
SIGLA	SIGLA	\N	2026-08-21 14:54:36.752418+00
Wm7	Wm7	\N	2026-08-21 14:54:36.752987+00
Nanibleyder	Nanibleyder	\N	2026-08-21 14:54:36.754733+00
Cannyburst	Cannyburst	\N	2026-08-21 14:54:36.755279+00
YoshiroDaiShi_26_teo	YoshiroDaiShi_26_teo	\N	2026-08-21 14:54:36.755862+00
JustPlus	JustPlus	\N	2026-08-21 14:54:37.253675+00
RyoSaeba	RyoSaeba	\N	2026-08-21 14:54:37.25432+00
CrystalClod	CrystalClod	\N	2026-08-21 14:54:37.254887+00
Firefre	Firefre	\N	2026-08-21 14:54:37.255469+00
Dipi999	Dipi999	\N	2026-08-21 14:54:37.256086+00
Cosciu	Cosciu	\N	2026-08-21 14:54:37.256644+00
Giakos98	Giakos98	\N	2026-08-21 14:54:37.257256+00
Debyx	Debyx	\N	2026-08-21 14:54:37.257844+00
Indian_Chey7	Indian_Chey7	\N	2026-08-21 14:54:37.258384+00
Brandix	Brandix	\N	2026-08-21 14:54:37.258919+00
LeleGianne	LeleGianne	\N	2026-08-21 14:54:37.25947+00
Tiamat27	Tiamat27	\N	2026-08-21 14:54:37.260044+00
_vic_	_vic_	\N	2026-08-21 14:54:37.260593+00
Jacksoncross2017	Jacksoncross2017	\N	2026-08-21 14:54:37.261117+00
Loreo_	Loreo_	\N	2026-08-21 14:54:37.261715+00
Kiokka	Kiokka	\N	2026-08-21 14:54:37.26246+00
Edoardo23	Edoardo23	\N	2026-08-21 14:54:37.263022+00
Mattia17	Mattia17	\N	2026-08-21 14:54:37.263625+00
Giovanni_Stempy	Giovanni_Stempy	\N	2026-08-21 14:54:37.264247+00
Solfa3	Solfa3	\N	2026-08-21 14:54:37.264789+00
Abbandono_97	Abbandono_97	\N	2026-08-21 14:54:37.265343+00
Lirlandese	Lirlandese	\N	2026-08-21 14:54:37.265889+00
Tanjiro67	Tanjiro67	\N	2026-08-21 14:54:37.266411+00
_Marks	_Marks	\N	2026-08-21 15:27:01.56771+00
nova	nova	\N	2026-08-21 14:54:44.579366+00
Merca94	Merca94	\N	2026-08-21 14:54:44.580604+00
_Ezecutor_iBh	_Ezecutor_iBh	\N	2026-08-21 14:54:44.583406+00
Leventiel	Leventiel	\N	2026-08-21 15:27:01.569392+00
Blade_Sabbath	Blade_Sabbath	\N	2026-08-21 14:54:44.594259+00
Enrico_Pakinko	Enrico_Pakinko	\N	2026-08-21 14:54:47.128937+00
Pikachu_16	Pikachu_16	\N	2026-08-21 15:27:01.574494+00
Oh_Nico	Oh_Nico	\N	2026-08-21 15:27:01.569973+00
Tiziano_Banano	Tiziano_Banano	\N	2026-08-21 15:27:01.57112+00
StormPrelude	StormPrelude	\N	2026-08-21 15:27:01.5728+00
Bigsimmy	Bigsimmy	\N	2026-08-21 15:27:01.57336+00
ELCULON	ELCULON	\N	2026-08-21 15:27:01.575091+00
BonnyBong	BonnyBong	\N	2026-08-21 15:27:01.575659+00
Palissandro	Palissandro	\N	2026-08-21 15:27:01.576216+00
TeoBerto	TeoBerto	\N	2026-08-21 15:27:01.57683+00
Dedours	Dedours	\N	2026-08-21 15:27:01.577434+00
Myridar	Myridar	\N	2026-08-21 15:27:01.578617+00
Charizard_18	Charizard_18	\N	2026-08-21 15:27:01.57918+00
Donkeymax	Donkeymax	\N	2026-08-21 15:27:01.5815+00
Xaldin99	Xaldin99	\N	2026-08-21 15:27:01.583801+00
Cico	Cico	\N	2026-08-21 15:27:01.584349+00
ContactBlader	ContactBlader	\N	2026-08-21 15:27:01.584901+00
PrincipessaPeach	PrincipessaPeach	\N	2026-08-21 15:27:01.588366+00
Kriperus	Kriperus	\N	2026-08-21 14:54:37.267005+00
Matteilpro15	Matteilpro15	\N	2026-08-21 14:54:37.267597+00
Danki0_0	Danki0_0	\N	2026-08-21 14:54:37.268206+00
Hanayrim	Hanayrim	\N	2026-08-21 14:54:37.26873+00
Kira45	Kira45	\N	2026-08-21 14:54:37.269279+00
FrancescoLuti	FrancescoLuti	\N	2026-08-21 14:54:37.2698+00
Eliopuccinelli	Eliopuccinelli	\N	2026-08-21 14:54:37.270424+00
Righello	Righello	\N	2026-08-21 14:54:37.27099+00
Liam2016	Liam2016	\N	2026-08-21 14:54:37.271596+00
Aldo_Abbaglio	Aldo_Abbaglio	\N	2026-08-21 14:54:37.272239+00
GS9	GS9	\N	2026-08-21 14:54:37.272811+00
Gabriele10	Gabriele10	\N	2026-08-21 14:54:37.273357+00
Danielx17	Danielx17	\N	2026-08-21 14:54:37.273878+00
YouHateBryan	YouHateBryan	\N	2026-08-21 14:54:37.274473+00
LBladerLui	LBladerLui	\N	2026-08-21 14:54:37.769103+00
Nonnechik99	Nonnechik99	\N	2026-08-21 14:54:37.772005+00
yuriymo	yuriymo	\N	2026-08-21 14:54:37.774261+00
Atarassìa - spacegames-bus	Atarassìa - spacegames-bus	\N	2026-08-21 14:54:37.775323+00
Diletta	Diletta	\N	2026-08-21 14:54:37.775867+00
SoloBuildEsotiche	SoloBuildEsotiche	\N	2026-08-21 14:54:37.776466+00
Umbeole	Umbeole	\N	2026-08-21 14:54:37.778064+00
Konjo92	Konjo92	\N	2026-08-21 14:54:37.779339+00
BlueMida	BlueMida	\N	2026-08-21 14:54:37.779922+00
The Watcher	The Watcher	\N	2026-08-21 14:54:37.780584+00
Ridnegar	Ridnegar	\N	2026-08-21 14:54:37.781185+00
D3M1GR4	D3M1GR4	\N	2026-08-21 14:54:37.781746+00
GinTony	GinTony	\N	2026-08-21 14:54:37.782286+00
Ravezim	Ravezim	\N	2026-08-21 14:54:37.783361+00
Tano_Ferblade16	Tano_Ferblade16	\N	2026-08-21 14:54:37.783879+00
Doungeons &Dragons Niihon	Doungeons &Dragons Niihon	\N	2026-08-21 14:54:38.269235+00
magteo	magteo	\N	2026-08-21 14:54:38.271607+00
GorillaZ_98	GorillaZ_98	\N	2026-08-21 14:54:38.273822+00
Minerol1	Minerol1	\N	2026-08-21 14:54:38.274875+00
Leviatano95	Leviatano95	\N	2026-08-21 14:54:38.275391+00
Slide_Off	Slide_Off	\N	2026-08-21 14:54:38.276488+00
TanoST	TanoST	\N	2026-08-21 14:54:38.277027+00
Doungeons&Dragons Niihon	Doungeons&Dragons Niihon	\N	2026-08-21 14:54:38.277553+00
Grizzly_97	Grizzly_97	\N	2026-08-21 14:54:38.278067+00
RUMI	RUMI	\N	2026-08-21 14:54:38.278728+00
Bore33	Bore33	\N	2026-08-21 14:54:38.27939+00
Antonio Rinaldi	Antonio Rinaldi	\N	2026-08-21 14:54:38.279973+00
Loris_Phoenix	Loris_Phoenix	\N	2026-08-21 14:54:38.28053+00
Fedeco98	Fedeco98	\N	2026-08-21 14:54:38.281059+00
Soar_Ale	Soar_Ale	\N	2026-08-21 14:54:38.281573+00
Skio69	Skio69	\N	2026-08-21 14:54:38.28209+00
LukeMcWall	LukeMcWall	\N	2026-08-21 14:54:38.282606+00
Malviobbld	Malviobbld	\N	2026-08-21 14:54:38.283121+00
BLAYDER X	BLAYDER X	\N	2026-08-21 14:54:38.28417+00
NathLL	NathLL	\N	2026-08-21 14:54:38.284714+00
PietroMerola	PietroMerola	\N	2026-08-21 14:54:38.286897+00
Leo140419	Leo140419	\N	2026-08-21 14:54:38.789+00
FReechain	FReechain	\N	2026-08-21 14:54:38.793016+00
Geco91	Geco91	\N	2026-08-21 14:54:38.793552+00
IRObb	IRObb	\N	2026-08-21 14:54:38.794099+00
Ho_pianto_sono_triste_datemi_BlastRosso	Ho_pianto_sono_triste_datemi_BlastRosso	\N	2026-08-21 14:54:38.798125+00
plus_exe	plus_exe	\N	2026-08-21 14:54:38.800332+00
Nomade7	Nomade7	\N	2026-08-21 14:54:38.801446+00
Podas	Podas	\N	2026-08-21 14:54:38.806081+00
Leni17	Leni17	\N	2026-08-21 14:54:38.808325+00
black0vt_TMN	black0vt_TMN	\N	2026-08-21 14:54:38.814567+00
DOMN	DOMN	\N	2026-08-21 14:54:38.81511+00
_inghetta_	_inghetta_	\N	2026-08-21 14:54:38.817323+00
Manuelo_	Manuelo_	\N	2026-08-21 14:54:38.818956+00
Mhasik	Mhasik	\N	2026-08-21 14:54:51.837201+00
Simorux	Simorux	\N	2026-08-21 14:54:41.376376+00
Bastoos	Bastoos	\N	2026-08-21 14:54:51.318557+00
FLOGGY_THE_WIZARD	FLOGGY_THE_WIZARD	\N	2026-08-21 14:54:41.379374+00
DARIONEOLLARE	DARIONEOLLARE	\N	2026-08-21 14:54:39.325835+00
LorenzoLSD	LorenzoLSD	\N	2026-08-21 14:54:39.326378+00
ataler_f2	ataler_f2	\N	2026-08-21 14:54:41.380594+00
LeoRyu	LeoRyu	\N	2026-08-21 14:54:39.329396+00
Ennardo	Ennardo	\N	2026-08-21 14:54:41.381214+00
Stupeficium	Stupeficium	\N	2026-08-21 14:54:39.331179+00
LolloNanairo	LolloNanairo	\N	2026-08-21 14:54:39.332282+00
Ryzer_og	Ryzer_og	\N	2026-08-21 14:54:41.382322+00
GHOST__23	GHOST__23	\N	2026-08-21 14:54:51.321988+00
Killva	Killva	\N	2026-08-21 14:54:39.334418+00
SickNova	SickNova	\N	2026-08-21 14:54:39.81731+00
Mi_ha_costretto_Lorenzo	Mi_ha_costretto_Lorenzo	\N	2026-08-21 14:54:39.817865+00
Gullit23	Gullit23	\N	2026-08-21 14:54:39.818931+00
Tramu_BV	Tramu_BV	\N	2026-08-21 14:54:51.841911+00
elbisc	elbisc	\N	2026-08-21 14:54:49.17983+00
VaultBoy91	VaultBoy91	\N	2026-08-21 14:54:39.820618+00
Akkaw1	Akkaw1	\N	2026-08-21 14:54:39.821781+00
PePe49	PePe49	\N	2026-08-21 14:54:39.822424+00
Hachiko_	Hachiko_	\N	2026-08-21 14:54:39.822986+00
Tijen	Tijen	\N	2026-08-21 14:54:41.383404+00
SeccoD91	SeccoD91	\N	2026-08-21 14:54:39.82416+00
BestiaGiallaX	BestiaGiallaX	\N	2026-08-21 14:54:39.826327+00
Eclissatore	Eclissatore	\N	2026-08-21 14:54:39.827401+00
Racche210	Racche210	\N	2026-08-21 14:54:39.829113+00
alessandro_iv	alessandro_iv	\N	2026-08-21 14:54:50.769403+00
Mad_Blade	Mad_Blade	\N	2026-08-21 14:54:51.326411+00
KhromeRyughu67	KhromeRyughu67	\N	2026-08-21 14:54:41.383971+00
Izba_prj	Izba_prj	\N	2026-08-21 14:54:41.387403+00
EXO358	EXO358	\N	2026-08-21 14:54:41.393056+00
Jonny_21	Jonny_21	\N	2026-08-21 14:54:41.399369+00
1V0	1V0	\N	2026-08-21 14:54:41.400476+00
AlphaXEND	AlphaXEND	\N	2026-08-21 14:54:41.909794+00
robb_430	robb_430	\N	2026-08-21 14:54:41.910332+00
louissan	louissan	\N	2026-08-21 14:54:41.912035+00
LaLacrimaDeFragtrap	LaLacrimaDeFragtrap	\N	2026-08-21 14:54:41.917178+00
Cool_man01	Cool_man01	\N	2026-08-21 14:54:41.921803+00
ChrisZec	ChrisZec	\N	2026-08-21 14:54:46.608958+00
Turbo73	Turbo73	\N	2026-08-21 14:54:50.234956+00
Caramella72	Caramella72	\N	2026-08-21 14:54:49.181608+00
riiching901	riiching901	\N	2026-08-21 14:54:48.166567+00
RascalNBC	RascalNBC	\N	2026-08-21 14:54:50.237301+00
Daniele_S	Daniele_S	\N	2026-08-21 14:54:50.769948+00
RionX	RionX	\N	2026-08-21 14:54:51.844637+00
Jay_Mugiwara	Jay_Mugiwara	\N	2026-08-21 14:54:51.846918+00
Shaka1985	Shaka1985	\N	2026-08-21 14:54:51.848654+00
Monkey_King_Tattoo	Monkey_King_Tattoo	\N	2026-08-21 14:54:50.770699+00
Depa19	Depa19	\N	2026-08-21 14:54:51.849714+00
GerardoDelia	GerardoDelia	\N	2026-08-21 14:54:51.852901+00
_Vento	_Vento	\N	2026-08-21 14:54:51.853488+00
Prof_Lele	Prof_Lele	\N	2026-08-21 14:54:50.239842+00
Vittorino81rm	Vittorino81rm	\N	2026-08-21 14:54:50.774636+00
BladerXF	BladerXF	\N	2026-08-21 14:54:50.786297+00
LucaNP	LucaNP	\N	2026-08-21 14:54:50.789891+00
ErConfy_BV	ErConfy_BV	\N	2026-08-21 14:54:39.832649+00
Taccons	Taccons	\N	2026-08-21 14:54:40.333947+00
Barone83	Barone83	\N	2026-08-21 14:54:49.178546+00
Lucifero88	Lucifero88	\N	2026-08-21 14:54:40.336802+00
_Zein	_Zein	\N	2026-08-21 14:54:51.316926+00
Domiziano	Domiziano	\N	2026-08-21 14:54:40.33925+00
Andrea_90	Andrea_90	\N	2026-08-21 14:54:40.339834+00
Donpi2	Donpi2	\N	2026-08-21 14:54:40.340391+00
22baymax	22baymax	\N	2026-08-21 14:54:40.341556+00
Kein_Tamerg	Kein_Tamerg	\N	2026-08-21 14:54:40.852167+00
Shagor	Shagor	\N	2026-08-21 14:54:40.853262+00
Ceci91	Ceci91	\N	2026-08-21 14:54:40.854996+00
Giovy	Giovy	\N	2026-08-21 14:54:40.85729+00
RòX	RòX	\N	2026-08-21 14:54:40.858891+00
MrLoba29	MrLoba29	\N	2026-08-21 14:54:40.859415+00
drramik	drramik	\N	2026-08-21 14:54:40.862964+00
Laura90	Laura90	\N	2026-08-21 14:54:40.865784+00
KKLord	KKLord	\N	2026-08-21 14:54:40.866865+00
Nastyyy27	Nastyyy27	\N	2026-08-21 14:54:40.867398+00
Francy	Francy	\N	2026-08-21 14:54:40.867949+00
ThunderMatthew	ThunderMatthew	\N	2026-08-21 14:54:40.870116+00
Trexgiulio	Trexgiulio	\N	2026-08-21 14:54:40.870726+00
keg0	keg0	\N	2026-08-21 14:54:40.871329+00
Nunze	Nunze	\N	2026-08-21 14:54:40.872546+00
Conralori	Conralori	\N	2026-08-21 14:54:40.873642+00
MGNathan	MGNathan	\N	2026-08-21 14:54:41.378715+00
Pivessio	Pivessio	\N	2026-08-21 14:54:41.379998+00
MZtore	MZtore	\N	2026-08-21 14:54:41.381777+00
DonLopez	DonLopez	\N	2026-08-21 14:54:41.382882+00
AlessioC_05	AlessioC_05	\N	2026-08-21 14:54:41.384541+00
alberto_ruffy	alberto_ruffy	\N	2026-08-21 14:54:41.385063+00
Euge7198	Euge7198	\N	2026-08-21 14:54:41.385605+00
KUROSU10	KUROSU10	\N	2026-08-21 14:54:41.386131+00
Cerys04	Cerys04	\N	2026-08-21 14:54:41.386731+00
Niihon	Niihon	\N	2026-08-21 14:54:41.388009+00
Niko2410	Niko2410	\N	2026-08-21 14:54:41.388567+00
Zaelion	Zaelion	\N	2026-08-21 14:54:41.38922+00
zero_90	zero_90	\N	2026-08-21 14:54:41.389766+00
Kapparella	Kapparella	\N	2026-08-21 14:54:41.390317+00
Ranur	Ranur	\N	2026-08-21 14:54:41.390844+00
Loris	Loris	\N	2026-08-21 14:54:41.391385+00
Dallaio	Dallaio	\N	2026-08-21 14:54:41.391933+00
Limboh	Limboh	\N	2026-08-21 14:54:41.3925+00
youngsta1017	youngsta1017	\N	2026-08-21 14:54:41.393616+00
Isabey	Isabey	\N	2026-08-21 14:54:41.394149+00
IMEØN	IMEØN	\N	2026-08-21 14:54:41.394681+00
Andrephoenix	Andrephoenix	\N	2026-08-21 14:54:41.395345+00
_Freezer_	_Freezer_	\N	2026-08-21 14:54:41.39596+00
johnnyrobomeka	johnnyrobomeka	\N	2026-08-21 14:54:41.396576+00
Hammer_Savio	Hammer_Savio	\N	2026-08-21 14:54:41.397149+00
donnola_17	donnola_17	\N	2026-08-21 14:54:41.397733+00
Cris391	Cris391	\N	2026-08-21 14:54:41.398264+00
ABBACS	ABBACS	\N	2026-08-21 14:54:41.398805+00
Avventuriero	Avventuriero	\N	2026-08-21 14:54:41.399914+00
_aletreecko_	_aletreecko_	\N	2026-08-21 14:54:41.401005+00
Bey_Sabbath	Bey_Sabbath	\N	2026-08-21 14:54:41.401549+00
Jean_05	Jean_05	\N	2026-08-21 14:54:41.402074+00
__ENGINE__	__ENGINE__	\N	2026-08-21 14:54:41.402627+00
ElbryanXV	ElbryanXV	\N	2026-08-21 14:54:41.403191+00
Ikigai06	Ikigai06	\N	2026-08-21 14:54:41.908151+00
PennaRigata	PennaRigata	\N	2026-08-21 14:54:41.908704+00
Acesword	Acesword	\N	2026-08-21 14:54:41.909248+00
BladerLui	BladerLui	\N	2026-08-21 14:54:41.911412+00
Aster94	Aster94	\N	2026-08-21 14:54:41.912647+00
GyroRad	GyroRad	\N	2026-08-21 14:54:41.913247+00
P_Rocka	P_Rocka	\N	2026-08-21 14:54:41.914397+00
ToninoX	ToninoX	\N	2026-08-21 14:54:41.915485+00
Manty72	Manty72	\N	2026-08-21 14:54:41.916054+00
Sharkina😈	Sharkina😈	\N	2026-08-21 14:54:41.916621+00
Adrixp08	Adrixp08	\N	2026-08-21 14:54:41.918275+00
Scavabuchi	Scavabuchi	\N	2026-08-21 14:54:41.918817+00
Blader126	Blader126	\N	2026-08-21 14:54:41.91936+00
Stabi23	Stabi23	\N	2026-08-21 14:54:41.920038+00
Miba88	Miba88	\N	2026-08-21 14:54:41.920627+00
mariovongola	mariovongola	\N	2026-08-21 14:54:41.921223+00
EdoLaFenice	EdoLaFenice	\N	2026-08-21 14:54:42.470196+00
Blader_F_2018	Blader_F_2018	\N	2026-08-21 14:54:42.471038+00
BeshtiOne	BeshtiOne	\N	2026-08-21 14:54:42.471924+00
Nicolas_14	Nicolas_14	\N	2026-08-21 14:54:42.472674+00
Guerins98	Guerins98	\N	2026-08-21 14:54:42.474076+00
ZyroBeastPink	ZyroBeastPink	\N	2026-08-21 14:54:42.474953+00
Raffy2016	Raffy2016	\N	2026-08-21 14:54:42.477927+00
Lorenzix	Lorenzix	\N	2026-08-21 14:54:42.478875+00
FRENCK	FRENCK	\N	2026-08-21 14:54:42.479606+00
GabYoshi	GabYoshi	\N	2026-08-21 14:54:42.480291+00
LoSportivo	LoSportivo	\N	2026-08-21 14:54:42.481068+00
Fede2016	Fede2016	\N	2026-08-21 14:54:42.483325+00
MarioShark	MarioShark	\N	2026-08-21 14:54:42.484021+00
Edoardodg	Edoardodg	\N	2026-08-21 14:54:42.485414+00
loleva	loleva	\N	2026-08-21 14:54:42.486123+00
Unhunexio	Unhunexio	\N	2026-08-21 14:54:43.011205+00
SansOnne	SansOnne	\N	2026-08-21 14:54:43.013721+00
sdwDancer	sdwDancer	\N	2026-08-21 14:54:43.014284+00
Daruma86	Daruma86	\N	2026-08-21 14:54:43.014844+00
xSam16	xSam16	\N	2026-08-21 14:54:43.015389+00
DarkMagici4n	DarkMagici4n	\N	2026-08-21 14:54:43.01597+00
Scooby_Nac	Scooby_Nac	\N	2026-08-21 14:54:43.016506+00
FranLu	FranLu	\N	2026-08-21 14:54:43.017102+00
Vincenzo68	Vincenzo68	\N	2026-08-21 14:54:43.017641+00
NordicPain	NordicPain	\N	2026-08-21 14:54:43.018176+00
Allessio1702	Allessio1702	\N	2026-08-21 14:54:43.019264+00
whiteknight_	whiteknight_	\N	2026-08-21 14:54:43.019824+00
Karletto	Karletto	\N	2026-08-21 14:54:43.021013+00
Giuseppe2018	Giuseppe2018	\N	2026-08-21 14:54:43.021606+00
ItsImogen	ItsImogen	\N	2026-08-21 14:54:43.022181+00
Mattia16	Mattia16	\N	2026-08-21 14:54:43.022726+00
TommyBX	TommyBX	\N	2026-08-21 14:54:43.023326+00
RikiAndrea	RikiAndrea	\N	2026-08-21 14:54:43.023951+00
GIOMASKpro355	GIOMASKpro355	\N	2026-08-21 14:54:43.024492+00
Luffy15	Luffy15	\N	2026-08-21 14:54:43.025031+00
Dadolow98	Dadolow98	\N	2026-08-21 14:54:43.530059+00
Kute	Kute	\N	2026-08-21 14:54:43.531722+00
eldefensor	eldefensor	\N	2026-08-21 14:54:43.53492+00
Thiass	Thiass	\N	2026-08-21 14:54:43.539502+00
Bosco027	Bosco027	\N	2026-08-21 14:54:43.542732+00
Ma_stro_nzo	Ma_stro_nzo	\N	2026-08-21 14:54:44.054998+00
Casper14	Casper14	\N	2026-08-21 14:54:44.590033+00
lil_LOTC	lil_LOTC	\N	2026-08-21 14:54:45.091758+00
xXAX96Xx	xXAX96Xx	\N	2026-08-21 14:54:45.093796+00
Jiimmyyy	Jiimmyyy	\N	2026-08-21 14:54:47.633326+00
Farinella	Farinella	\N	2026-08-21 14:54:47.638298+00
Nicolino1977	Nicolino1977	\N	2026-08-21 14:54:47.643992+00
BromisS	BromisS	\N	2026-08-21 14:54:50.766173+00
Massimassi	Massimassi	\N	2026-08-21 14:54:51.84023+00
Emmet77	Emmet77	\N	2026-08-21 14:54:50.780304+00
Dains_Celance	Dains_Celance	\N	2026-08-21 14:54:49.690763+00
Riccio97	Riccio97	\N	2026-08-21 14:54:51.848121+00
Seppiozzo	Seppiozzo	\N	2026-08-21 14:54:51.850239+00
GrazyGip	GrazyGip	\N	2026-08-21 14:54:43.54509+00
Ivoboye	Ivoboye	\N	2026-08-21 14:54:44.057311+00
Serse	Serse	\N	2026-08-21 14:54:44.058899+00
Supporto_Emotivo	Supporto_Emotivo	\N	2026-08-21 14:54:44.059468+00
ilFaraone96	ilFaraone96	\N	2026-08-21 14:54:44.06058+00
Kh0zaky	Kh0zaky	\N	2026-08-21 14:54:44.061111+00
N_O_X_	N_O_X_	\N	2026-08-21 14:54:44.062628+00
Teschio96	Teschio96	\N	2026-08-21 14:54:44.064383+00
Squalessandro	Squalessandro	\N	2026-08-21 14:54:44.064957+00
La_Jade	La_Jade	\N	2026-08-21 14:54:44.066076+00
SigIvan	SigIvan	\N	2026-08-21 14:54:44.580006+00
Gigigi_	Gigigi_	\N	2026-08-21 14:54:44.581185+00
_Aeonax_	_Aeonax_	\N	2026-08-21 14:54:44.582348+00
Gibby14	Gibby14	\N	2026-08-21 14:54:44.582887+00
Fabbo_97	Fabbo_97	\N	2026-08-21 15:22:32.89374+00
Ma_stron_zo	Ma_stron_zo	\N	2026-08-21 14:54:44.586009+00
Sikaka	Sikaka	\N	2026-08-21 14:54:44.586581+00
Deku90	Deku90	\N	2026-08-21 14:54:50.232135+00
Botta00	Botta00	\N	2026-08-21 15:22:32.894315+00
gorillaz	gorillaz	\N	2026-08-21 14:54:44.591664+00
Malevolovo	Malevolovo	\N	2026-08-21 14:54:44.592181+00
UNDER100	UNDER100	\N	2026-08-21 14:54:51.328615+00
Toaultra	Toaultra	\N	2026-08-21 14:54:44.5932+00
PerSempre	PerSempre	\N	2026-08-21 14:54:51.843026+00
FrancisRookie96	FrancisRookie96	\N	2026-08-21 14:54:44.594771+00
Vitto95	Vitto95	\N	2026-08-21 14:54:45.091215+00
Talion99	Talion99	\N	2026-08-21 14:54:45.092271+00
Davide	Davide	\N	2026-08-21 14:54:45.092778+00
Kute_	Kute_	\N	2026-08-21 14:54:45.093287+00
Citpit	Citpit	\N	2026-08-21 14:54:45.09654+00
Coppyy	Coppyy	\N	2026-08-21 14:54:45.09709+00
Bass96	Bass96	\N	2026-08-21 14:54:45.097658+00
Sarcai	Sarcai	\N	2026-08-21 14:54:45.09923+00
Yurix01	Yurix01	\N	2026-08-21 14:54:45.09977+00
Tomahhh	Tomahhh	\N	2026-08-21 14:54:45.100275+00
Benobeno	Benobeno	\N	2026-08-21 14:54:45.100783+00
Claudio94	Claudio94	\N	2026-08-21 14:54:45.101295+00
EdoPambi	EdoPambi	\N	2026-08-21 14:54:45.102303+00
Marmaxx	Marmaxx	\N	2026-08-21 14:54:45.1041+00
Alemartini	Alemartini	\N	2026-08-21 14:54:45.104749+00
Sagro	Sagro	\N	2026-08-21 14:54:45.587334+00
Ilbadrone	Ilbadrone	\N	2026-08-21 14:54:45.589006+00
Lallalalla	Lallalalla	\N	2026-08-21 14:54:45.593734+00
Konau	Konau	\N	2026-08-21 14:54:51.85185+00
Freud911	Freud911	\N	2026-08-21 14:54:46.093392+00
BigRicco	BigRicco	\N	2026-08-21 14:54:46.094478+00
PartisanTunic	PartisanTunic	\N	2026-08-21 14:54:52.95812+00
fedone	fedone	\N	2026-08-21 14:54:52.963623+00
Xayrevers45	Xayrevers45	\N	2026-08-21 14:54:52.965286+00
Lucacolt	Lucacolt	\N	2026-08-21 14:54:46.099028+00
Don Lorenzo	Don Lorenzo	\N	2026-08-21 15:22:32.902422+00
Salas_1	Salas_1	\N	2026-08-21 15:27:03.149049+00
Rosefield95	Rosefield95	\N	2026-08-21 14:54:46.100686+00
Bio__	Bio__	\N	2026-08-21 14:54:46.10122+00
TheNask	TheNask	\N	2026-08-21 14:54:46.10175+00
Dragosandro	Dragosandro	\N	2026-08-21 14:54:46.103289+00
Luca_Bellaveglia	Luca_Bellaveglia	\N	2026-08-21 14:54:46.602974+00
Luca_Capoch	Luca_Capoch	\N	2026-08-21 14:54:46.605167+00
Deadnos	Deadnos	\N	2026-08-21 14:54:46.605729+00
Batmann91	Batmann91	\N	2026-08-21 14:54:46.606876+00
Boo37	Boo37	\N	2026-08-21 14:54:46.607403+00
Pika__27	Pika__27	\N	2026-08-21 14:54:46.607919+00
Sagro_AFST	Sagro_AFST	\N	2026-08-21 14:54:46.608447+00
Edo	Edo	\N	2026-08-21 14:54:46.610003+00
CALPISREDCOMET	CALPISREDCOMET	\N	2026-08-21 14:54:46.610511+00
Midorina	Midorina	\N	2026-08-21 15:27:03.161751+00
Darkmok	Darkmok	\N	2026-08-21 14:54:46.611779+00
NovaBless	NovaBless	\N	2026-08-21 14:54:46.612941+00
Fle95a	Fle95a	\N	2026-08-21 14:54:46.613526+00
Blair888	Blair888	\N	2026-08-21 14:54:46.614098+00
El_Olvido	El_Olvido	\N	2026-08-21 14:54:47.122168+00
JasonX_10	JasonX_10	\N	2026-08-21 14:54:47.123395+00
Gab_17	Gab_17	\N	2026-08-21 14:54:47.126592+00
Malato_per_favore	Malato_per_favore	\N	2026-08-21 14:54:47.13004+00
YukiYux	YukiYux	\N	2026-08-21 14:54:47.13287+00
HoRubatoIlFondoCassa	HoRubatoIlFondoCassa	\N	2026-08-21 14:54:47.134466+00
LoydNinja	LoydNinja	\N	2026-08-21 14:54:47.135524+00
Quereloperdiffamazione	Quereloperdiffamazione	\N	2026-08-21 14:54:47.136574+00
RyanT_07	RyanT_07	\N	2026-08-21 14:54:47.137718+00
XTHOM	XTHOM	\N	2026-08-21 14:54:47.138907+00
Goburin69	Goburin69	\N	2026-08-21 14:54:47.140051+00
AleF81	AleF81	\N	2026-08-21 14:54:47.140597+00
Kooiji	Kooiji	\N	2026-08-21 14:54:47.631436+00
AmetDj	AmetDj	\N	2026-08-21 14:54:47.63275+00
Samublade	Samublade	\N	2026-08-21 14:54:47.639526+00
Kigen	Kigen	\N	2026-08-21 14:54:47.640113+00
Valebisso	Valebisso	\N	2026-08-21 14:54:47.642328+00
Francesco15	Francesco15	\N	2026-08-21 14:54:47.642864+00
Sampei_the_Blader	Sampei_the_Blader	\N	2026-08-21 15:27:04.730964+00
_Steffo_	_Steffo_	\N	2026-08-21 15:27:04.731577+00
RagazzoScheletro	RagazzoScheletro	\N	2026-08-21 15:27:04.732169+00
Vichingo	Vichingo	\N	2026-08-21 15:27:04.732784+00
Bakudomo	Bakudomo	\N	2026-08-21 15:27:04.736396+00
Thagomizer	Thagomizer	\N	2026-08-21 15:27:04.738806+00
Zio_Fra74	Zio_Fra74	\N	2026-08-21 15:27:04.741841+00
JackC84	JackC84	\N	2026-08-21 15:27:04.745469+00
Enea_Mazza	Enea_Mazza	\N	2026-08-21 14:54:47.64592+00
Seiesse	Seiesse	\N	2026-08-21 14:54:47.647204+00
GabrieleChiarenza	GabrieleChiarenza	\N	2026-08-21 14:54:47.647787+00
VoxDubium	VoxDubium	\N	2026-08-21 14:54:47.648315+00
LDL18	LDL18	\N	2026-08-21 14:54:47.6499+00
KnightK	KnightK	\N	2026-08-21 14:54:48.163925+00
Zurukuma	Zurukuma	\N	2026-08-21 14:54:48.16822+00
RikyFire	RikyFire	\N	2026-08-21 14:54:48.168735+00
LordTz	LordTz	\N	2026-08-21 14:54:48.169247+00
ThePitcher	ThePitcher	\N	2026-08-21 14:54:48.170323+00
Aokira77	Aokira77	\N	2026-08-21 14:54:48.683509+00
BLADEREMA	BLADEREMA	\N	2026-08-21 14:54:48.684066+00
Gabriele19	Gabriele19	\N	2026-08-21 14:54:48.684609+00
Maso19	Maso19	\N	2026-08-21 14:54:48.685143+00
UnamxriDotExe	UnamxriDotExe	\N	2026-08-21 14:54:49.176297+00
Misosone	Misosone	\N	2026-08-21 14:54:49.180405+00
fonty94	fonty94	\N	2026-08-21 14:54:49.181002+00
Andrytrik	Andrytrik	\N	2026-08-21 14:54:49.183245+00
HarimaKenji	HarimaKenji	\N	2026-08-21 14:54:49.681925+00
Pico7	Pico7	\N	2026-08-21 14:54:49.684719+00
M4rti	M4rti	\N	2026-08-21 14:54:49.686355+00
Piero145	Piero145	\N	2026-08-21 14:54:49.687067+00
Khepri01	Khepri01	\N	2026-08-21 14:54:49.687699+00
VentoAran	VentoAran	\N	2026-08-21 14:54:49.688299+00
RoboRobo	RoboRobo	\N	2026-08-21 14:54:49.689503+00
D_Hakkai	D_Hakkai	\N	2026-08-21 14:54:49.690111+00
hellboy_76	hellboy_76	\N	2026-08-21 14:54:49.694107+00
Xlarax	Xlarax	\N	2026-08-21 15:27:03.152996+00
Leon1990	Leon1990	\N	2026-08-21 14:54:50.227938+00
Leoshadow	Leoshadow	\N	2026-08-21 14:54:50.230932+00
EgilTheWanderer	EgilTheWanderer	\N	2026-08-21 14:54:50.233288+00
FrancoGalbazzi	FrancoGalbazzi	\N	2026-08-21 14:54:50.235529+00
Ragnarovi	Ragnarovi	\N	2026-08-21 14:54:50.236077+00
Youngsnapp10	Youngsnapp10	\N	2026-08-21 15:27:03.160595+00
LupoAlbano97	LupoAlbano97	\N	2026-08-21 14:54:50.240989+00
BladeryX	BladeryX	\N	2026-08-21 14:54:50.242082+00
GIULIODARK	GIULIODARK	\N	2026-08-21 14:54:50.242628+00
Flavietto_8	Flavietto_8	\N	2026-08-21 14:54:50.243717+00
Topodadoccia	Topodadoccia	\N	2026-08-21 14:54:50.768329+00
Polargh	Polargh	\N	2026-08-21 14:54:50.771336+00
Wukan	Wukan	\N	2026-08-21 14:54:50.771927+00
FetusGrinder	FetusGrinder	\N	2026-08-21 14:54:50.772504+00
SickShok	SickShok	\N	2026-08-21 14:54:50.7741+00
Jack_CBR	Jack_CBR	\N	2026-08-21 14:54:50.776342+00
ZzaWarudo	ZzaWarudo	\N	2026-08-21 15:27:04.735801+00
ZioGabrio	ZioGabrio	\N	2026-08-21 14:54:50.777419+00
Rorasev	Rorasev	\N	2026-08-21 14:54:50.778484+00
Senza_Rod_sono_una_frode	Senza_Rod_sono_una_frode	\N	2026-08-21 14:54:50.779121+00
Big_TunaX	Big_TunaX	\N	2026-08-21 14:54:50.779711+00
Artorias94	Artorias94	\N	2026-08-21 14:54:50.780901+00
MatteoFolle	MatteoFolle	\N	2026-08-21 14:54:50.782546+00
Napo_bx	Napo_bx	\N	2026-08-21 14:54:50.783611+00
Bumbey	Bumbey	\N	2026-08-21 14:54:50.784162+00
Julescio	Julescio	\N	2026-08-21 14:54:50.784696+00
Flavio2015	Flavio2015	\N	2026-08-21 14:54:50.787574+00
Trottolina_Amorosa	Trottolina_Amorosa	\N	2026-08-21 14:54:50.788768+00
picci8	picci8	\N	2026-08-21 14:54:50.789323+00
hellboy_09	hellboy_09	\N	2026-08-21 14:54:51.320236+00
Robides	Robides	\N	2026-08-21 15:27:04.73698+00
SuperSonicGjo	SuperSonicGjo	\N	2026-08-21 14:54:51.325865+00
BusterDran	BusterDran	\N	2026-08-21 14:54:51.837842+00
cacci351	cacci351	\N	2026-08-21 14:54:51.839046+00
MaccheRonin	MaccheRonin	\N	2026-08-21 14:54:51.839641+00
Dark_ritow	Dark_ritow	\N	2026-08-21 14:54:51.841355+00
Themistokles16	Themistokles16	\N	2026-08-21 14:54:51.8441+00
Pigi_fenix	Pigi_fenix	\N	2026-08-21 14:54:51.84579+00
Turbo73_Ruben	Turbo73_Ruben	\N	2026-08-21 14:54:51.84755+00
Zigozago284	Zigozago284	\N	2026-08-21 14:54:51.849179+00
Aridran	Aridran	\N	2026-08-21 14:54:51.850768+00
Drysepht	Drysepht	\N	2026-08-21 14:54:51.851327+00
Maxdavi100	Maxdavi100	\N	2026-08-21 14:54:51.852379+00
anima_L	anima_L	\N	2026-08-21 14:54:52.393655+00
Noktis1O	Noktis1O	\N	2026-08-21 14:54:52.394425+00
Donguz	Donguz	\N	2026-08-21 14:54:52.395494+00
PoverettoKid	PoverettoKid	\N	2026-08-21 14:54:52.396244+00
HarukoEbi	HarukoEbi	\N	2026-08-21 14:54:52.397033+00
Spadaccino	Spadaccino	\N	2026-08-21 14:54:52.397717+00
MetalRaffo	MetalRaffo	\N	2026-08-21 14:54:52.398543+00
KapraStyle	KapraStyle	\N	2026-08-21 14:54:52.399443+00
Rosy66	Rosy66	\N	2026-08-21 14:54:52.400289+00
Espionerion	Espionerion	\N	2026-08-21 14:54:52.401026+00
Eminenza_grigia	Eminenza_grigia	\N	2026-08-21 14:54:52.401809+00
LasagnaVulvosa	LasagnaVulvosa	\N	2026-08-21 14:54:52.402821+00
peps10	peps10	\N	2026-08-21 14:54:52.403826+00
IL_PL_99	IL_PL_99	\N	2026-08-21 14:54:52.404652+00
Leone400	Leone400	\N	2026-08-21 14:54:52.40535+00
SharkDav_98	SharkDav_98	\N	2026-08-21 14:54:52.406103+00
Andy_One	Andy_One	\N	2026-08-21 14:54:52.406961+00
Jhon	Jhon	\N	2026-08-21 14:54:52.408053+00
Rengoku10	Rengoku10	\N	2026-08-21 14:54:52.408769+00
LPhoenix1	LPhoenix1	\N	2026-08-21 14:54:52.409601+00
Jacksada	Jacksada	\N	2026-08-21 14:54:52.410437+00
ElevateKid	ElevateKid	\N	2026-08-21 14:54:52.95196+00
YoUnG_SnApP10	YoUnG_SnApP10	\N	2026-08-21 14:54:52.954746+00
Autocratico fascista	Autocratico fascista	\N	2026-08-21 14:54:52.955895+00
Goblin_69	Goblin_69	\N	2026-08-21 14:54:52.959776+00
Seven861	Seven861	\N	2026-08-21 14:54:52.962449+00
TheGhost2015	TheGhost2015	\N	2026-08-21 14:54:52.963065+00
BleaderA	BleaderA	\N	2026-08-21 14:54:52.964177+00
_Gabii_	_Gabii_	\N	2026-08-21 15:27:04.741253+00
Rayblad25	Rayblad25	\N	2026-08-21 15:27:04.744851+00
\.


--
-- Data for Name: challonge_reported_combos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.challonge_reported_combos (id, user_id, tournament_id, tournament_name, combo_number, blade, assist_blade, ratchet, "bit", lock_chip, rank, season, created_at) FROM stdin;
\.


--
-- Data for Name: clubs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clubs (id, name, region, logo, created_at, city) FROM stdin;
1	Wyvern Club	Emilia Romagna	\N	2026-01-12 17:33:02.331855	Reggio Emilia
2	Alma Draco	Emilia Romagna	\N	2026-01-12 17:33:02.331855	Bologna
3	Street Sharks	Emilia Romagna	\N	2026-01-12 17:33:02.331855	Ferrara
4	Chimera Typhoon	Emilia Romagna	\N	2026-01-12 17:33:02.331855	Modena
5	Club Rising Phoenix	Emilia Romagna	\N	2026-01-12 17:33:02.331855	Rimini
6	Stormbreakers	Emilia Romagna	\N	2026-01-12 17:33:02.331855	Ravenna
7	Crusaders Club Beyblade X Parma	Emilia Romagna	\N	2026-01-12 17:33:02.331855	Parma
8	Hollow Kraken	Emilia Romagna	\N	2026-01-12 17:33:02.331855	Forli
9	Wail Siren Napoli	Campania	\N	2026-01-12 17:36:43.314268	Napoli
10	Wizard Busters	Umbria	\N	2026-01-12 17:37:35.85862	Perugia
12	Wail Siren Caserta	Campania	\N	2026-01-12 17:39:19.994066	Caserta
11	Blue Dragon Beyblade Club	Umbria	\N	2026-01-12 17:38:12.922986	Perugia
13	Dran Gladius Beyblade Club - Roma Ovest	Lazio	\N	2026-01-12 17:42:43.544122	\N
14	Etrurian Bey Club	Toscana	\N	2026-01-12 19:59:56.554091	Firenze
15	MIST KNIGHTS ROVIGO	Veneto	\N	2026-01-12 20:00:49.822588	\N
16	Phoenix Pisa Bey Club	Toscana	\N	2026-01-13 15:48:13.79983	\N
17	Saint Shield Club Vigevano	Lombardia	\N	2026-01-13 15:49:11.597393	\N
18	Apuliabey - Bari	Puglia	\N	2026-01-13 15:49:51.8271	\N
\.


--
-- Data for Name: cm_match_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cm_match_results (tournament_id, player_id, combo_number, blade, assist_blade, ratchet, "bit", lock_chip, piazzamento, numero_partecipanti, data_torneo, punti_guadagnati, updated_at) FROM stdin;
7e82013b-8870-4262-265d-08de10ba2958	d6abd100-0300-49df-9d70-4a11c408157d	1	CobaltDragoon	None	5-60	Elevate	None	3	24	2025-10-22	120	2025-11-15 13:43:21.866626+00
7e82013b-8870-4262-265d-08de10ba2958	d6abd100-0300-49df-9d70-4a11c408157d	2	SharkScale	None	3-60	LowRush	None	3	24	2025-10-22	120	2025-11-15 13:43:21.866626+00
7e82013b-8870-4262-265d-08de10ba2958	d6abd100-0300-49df-9d70-4a11c408157d	3	WizardRod	None	1-60	Hexa	None	3	24	2025-10-22	120	2025-11-15 13:43:21.866626+00
7e82013b-8870-4262-265d-08de10ba2958	7b93216a-d77e-479f-8d1e-5ad2bc604f6d	1	SharkScale	None	3-60	LowRush	None	3	24	2025-10-22	120	2025-11-15 13:44:05.100708+00
7e82013b-8870-4262-265d-08de10ba2958	7b93216a-d77e-479f-8d1e-5ad2bc604f6d	2	WizardRod	None	1-60	FreeBall	None	3	24	2025-10-22	120	2025-11-15 13:44:05.100708+00
7e82013b-8870-4262-265d-08de10ba2958	7b93216a-d77e-479f-8d1e-5ad2bc604f6d	3	SilverWolf	None	9-60	UnderNeedle	None	3	24	2025-10-22	120	2025-11-15 13:44:05.100708+00
2e1f67ab-05b4-49c6-0661-08de12178f7b	fbdc994f-18e6-4ff1-897d-c25d7b50c4bb	1	Blast	Slash	9-60	Wedge	None	1	24	2025-10-24	240	2025-11-15 13:46:30.670666+00
2e1f67ab-05b4-49c6-0661-08de12178f7b	fbdc994f-18e6-4ff1-897d-c25d7b50c4bb	2	WizardRod	None	1-60	Hexa	None	1	24	2025-10-24	240	2025-11-15 13:46:30.670666+00
2e1f67ab-05b4-49c6-0661-08de12178f7b	fbdc994f-18e6-4ff1-897d-c25d7b50c4bb	3	SilverWolf	None	9-60	FreeBall	None	1	24	2025-10-24	240	2025-11-15 13:46:30.670666+00
2e1f67ab-05b4-49c6-0661-08de12178f7b	c22a9e64-da54-437c-bcd0-4f53535d3350	1	Blast	Jaggy	3-60	Rush	None	2	24	2025-10-24	168	2025-11-15 13:47:09.324503+00
2e1f67ab-05b4-49c6-0661-08de12178f7b	c22a9e64-da54-437c-bcd0-4f53535d3350	2	CobaltDragoon	None	5-60	Elevate	None	2	24	2025-10-24	168	2025-11-15 13:47:09.324503+00
2e1f67ab-05b4-49c6-0661-08de12178f7b	c22a9e64-da54-437c-bcd0-4f53535d3350	3	SharkScale	None	1-70	LowRush	None	2	24	2025-10-24	168	2025-11-15 13:47:09.324503+00
2e1f67ab-05b4-49c6-0661-08de12178f7b	8b107f55-9609-4711-b33a-f322e684a678	1	CobaltDragoon	None	5-60	Elevate	None	3	24	2025-10-24	120	2025-11-15 13:48:30.527502+00
2e1f67ab-05b4-49c6-0661-08de12178f7b	8b107f55-9609-4711-b33a-f322e684a678	2	WizardRod	None	1-60	FreeBall	None	3	24	2025-10-24	120	2025-11-15 13:48:30.527502+00
2e1f67ab-05b4-49c6-0661-08de12178f7b	8b107f55-9609-4711-b33a-f322e684a678	3	SharkScale	None	3-60	Kick	None	3	24	2025-10-24	120	2025-11-15 13:48:30.527502+00
2e1f67ab-05b4-49c6-0661-08de12178f7b	96ff4c7f-ae31-46c2-9c7a-a4dde068f206	1	PhoenixWing	None	3-60	Rush	None	3	24	2025-10-24	120	2025-11-15 13:49:09.393529+00
2e1f67ab-05b4-49c6-0661-08de12178f7b	96ff4c7f-ae31-46c2-9c7a-a4dde068f206	2	SilverWolf	None	9-70	Ball	None	3	24	2025-10-24	120	2025-11-15 13:49:09.393529+00
2e1f67ab-05b4-49c6-0661-08de12178f7b	96ff4c7f-ae31-46c2-9c7a-a4dde068f206	3	WizardRod	None	1-60	FreeBall	None	3	24	2025-10-24	120	2025-11-15 13:49:09.393529+00
1fc6d496-bf2a-4924-3822-08de21115a66	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	1	PhoenixWing	None	1-60	Rush	None	1	9	2025-11-12	90	2025-11-15 13:52:02.901252+00
1fc6d496-bf2a-4924-3822-08de21115a66	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	2	SharkScale	None	4-50	Point	None	1	9	2025-11-12	90	2025-11-15 13:52:02.901252+00
1fc6d496-bf2a-4924-3822-08de21115a66	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	3	WizardRod	None	1-70	Hexa	None	1	9	2025-11-12	90	2025-11-15 13:52:02.901252+00
1fc6d496-bf2a-4924-3822-08de21115a66	55c70b52-40d6-4c65-bf69-6798204d54a3	1	Blast	Assault	9-60	LowRush	None	2	9	2025-11-12	63	2025-11-15 13:52:45.446192+00
1fc6d496-bf2a-4924-3822-08de21115a66	55c70b52-40d6-4c65-bf69-6798204d54a3	2	PhoenixWing	None	3-60	Rush	None	2	9	2025-11-12	63	2025-11-15 13:52:45.446192+00
1fc6d496-bf2a-4924-3822-08de21115a66	55c70b52-40d6-4c65-bf69-6798204d54a3	3	WizardRod	None	1-60	Hexa	None	2	9	2025-11-12	63	2025-11-15 13:52:45.446192+00
1fc6d496-bf2a-4924-3822-08de21115a66	875ccc4e-4d96-4412-a7fc-b1460cf734a0	1	HoverWyvern	None	3-60	Kick	None	3	9	2025-11-12	45	2025-11-15 13:53:18.551637+00
1fc6d496-bf2a-4924-3822-08de21115a66	875ccc4e-4d96-4412-a7fc-b1460cf734a0	2	SharkScale	None	1-60	LowRush	None	3	9	2025-11-12	45	2025-11-15 13:53:18.551637+00
1fc6d496-bf2a-4924-3822-08de21115a66	875ccc4e-4d96-4412-a7fc-b1460cf734a0	3	PhoenixWing	None	1-70	Rush	None	3	9	2025-11-12	45	2025-11-15 13:53:18.551637+00
1fc6d496-bf2a-4924-3822-08de21115a66	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	1	DranDagger	None	4-60	Rush	None	3	9	2025-11-12	45	2025-11-15 13:53:56.61646+00
1fc6d496-bf2a-4924-3822-08de21115a66	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	2	SharkEdge	None	3-60	LowFlat	None	3	9	2025-11-12	45	2025-11-15 13:53:56.61646+00
1fc6d496-bf2a-4924-3822-08de21115a66	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	3	SamuraiSaber	None	5-60	Taper	None	3	9	2025-11-12	45	2025-11-15 13:53:56.61646+00
cf110239-4f06-484d-0554-08de14904573	c9b251bd-03ec-49ee-99ae-36959f63b1cd	1	SilverWolf	None	9-60	FreeBall	None	1	13	2025-10-29	130	2025-11-15 13:54:41.590439+00
cf110239-4f06-484d-0554-08de14904573	c9b251bd-03ec-49ee-99ae-36959f63b1cd	2	CobaltDragoon	None	4-60	Elevate	None	1	13	2025-10-29	130	2025-11-15 13:54:41.590439+00
cf110239-4f06-484d-0554-08de14904573	c9b251bd-03ec-49ee-99ae-36959f63b1cd	3	WizardRod	None	1-60	LowOrb	None	1	13	2025-10-29	130	2025-11-15 13:54:41.590439+00
cf110239-4f06-484d-0554-08de14904573	736d1acf-027c-4128-8c07-540aae993ed8	1	PhoenixWing	None	3-60	LowFlat	None	2	13	2025-10-29	91	2025-11-15 13:55:23.433349+00
cf110239-4f06-484d-0554-08de14904573	736d1acf-027c-4128-8c07-540aae993ed8	2	SilverWolf	None	9-60	FreeBall	None	2	13	2025-10-29	91	2025-11-15 13:55:23.433349+00
cf110239-4f06-484d-0554-08de14904573	736d1acf-027c-4128-8c07-540aae993ed8	3	WizardRod	None	1-60	Rush	None	2	13	2025-10-29	91	2025-11-15 13:55:23.433349+00
cf110239-4f06-484d-0554-08de14904573	bf0d2c91-4798-4294-a798-6bfe3e810ef3	1	SharkScale	None	4-60	UnderFlat	None	3	13	2025-10-29	65	2025-11-15 13:55:58.192548+00
cf110239-4f06-484d-0554-08de14904573	bf0d2c91-4798-4294-a798-6bfe3e810ef3	2	KnightMail	None	1-60	Rush	None	3	13	2025-10-29	65	2025-11-15 13:55:58.192548+00
cf110239-4f06-484d-0554-08de14904573	bf0d2c91-4798-4294-a798-6bfe3e810ef3	3	TyrannoBeat	None	6-60	Kick	None	3	13	2025-10-29	65	2025-11-15 13:55:58.192548+00
cf110239-4f06-484d-0554-08de14904573	55c70b52-40d6-4c65-bf69-6798204d54a3	1	HoverWyvern	None	3-60	Kick	None	3	13	2025-10-29	65	2025-11-15 13:56:27.426643+00
cf110239-4f06-484d-0554-08de14904573	55c70b52-40d6-4c65-bf69-6798204d54a3	2	PhoenixWing	None	1-60	Rush	None	3	13	2025-10-29	65	2025-11-15 13:56:27.426643+00
cf110239-4f06-484d-0554-08de14904573	55c70b52-40d6-4c65-bf69-6798204d54a3	3	SilverWolf	None	9-60	FreeBall	None	3	13	2025-10-29	65	2025-11-15 13:56:27.426643+00
7e82013b-8870-4262-265d-08de10ba2958	6ef8d6cd-683f-403d-bfd5-b7c3b8351ef3	1	CobaltDragoon	None	5-60	Elevate	None	2	24	2025-10-22	168	2025-11-16 16:22:36.835455+00
7e82013b-8870-4262-265d-08de10ba2958	6ef8d6cd-683f-403d-bfd5-b7c3b8351ef3	2	WizardRod	None	1-60	Hexa	None	2	24	2025-10-22	168	2025-11-16 16:22:36.835455+00
7e82013b-8870-4262-265d-08de10ba2958	6ef8d6cd-683f-403d-bfd5-b7c3b8351ef3	3	SharkScale	None	4-50	LowRush	None	2	24	2025-10-22	168	2025-11-16 16:22:36.835455+00
7e82013b-8870-4262-265d-08de10ba2958	9c78170c-0b9c-4491-88ab-baa817ff7951	1	PhoenixWing	None	1-60	Rush	None	1	24	2025-10-22	240	2025-11-16 16:22:41.817487+00
7e82013b-8870-4262-265d-08de10ba2958	9c78170c-0b9c-4491-88ab-baa817ff7951	2	WizardRod	None	3-60	Hexa	None	1	24	2025-10-22	240	2025-11-16 16:22:41.817487+00
7e82013b-8870-4262-265d-08de10ba2958	9c78170c-0b9c-4491-88ab-baa817ff7951	3	SilverWolf	None	9-60	FreeBall	None	1	24	2025-10-22	240	2025-11-16 16:22:41.817487+00
e309e8a8-e930-4f4c-389e-08de278ff875	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	1	PhoenixWing	None	1-70	Rush	None	1	12	2025-11-20	120	2025-11-21 21:55:58.996924+00
e309e8a8-e930-4f4c-389e-08de278ff875	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	2	SharkScale	None	4-50	Point	None	1	12	2025-11-20	120	2025-11-21 21:55:58.996924+00
e309e8a8-e930-4f4c-389e-08de278ff875	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	3	WizardRod	None	1-60	Hexa	None	1	12	2025-11-20	120	2025-11-21 21:55:58.996924+00
e309e8a8-e930-4f4c-389e-08de278ff875	e017fb67-e90e-4935-a633-caf9ae32f463	1	PhoenixWing	None	3-70	LowRush	None	2	12	2025-11-20	84	2025-11-21 21:56:53.068485+00
e309e8a8-e930-4f4c-389e-08de278ff875	e017fb67-e90e-4935-a633-caf9ae32f463	2	SilverWolf	None	9-60	FreeBall	None	2	12	2025-11-20	84	2025-11-21 21:56:53.068485+00
e309e8a8-e930-4f4c-389e-08de278ff875	e017fb67-e90e-4935-a633-caf9ae32f463	3	WizardRod	None	1-60	Hexa	None	2	12	2025-11-20	84	2025-11-21 21:56:53.068485+00
e309e8a8-e930-4f4c-389e-08de278ff875	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	1	DranDagger	None	4-60	Rush	None	3	12	2025-11-20	60	2025-11-21 21:58:15.172597+00
e309e8a8-e930-4f4c-389e-08de278ff875	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	2	SharkEdge	None	3-60	LowFlat	None	3	12	2025-11-20	60	2025-11-21 21:58:15.172597+00
e309e8a8-e930-4f4c-389e-08de278ff875	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	3	SamuraiSaber	None	5-60	Taper	None	3	12	2025-11-20	60	2025-11-21 21:58:15.172597+00
e309e8a8-e930-4f4c-389e-08de278ff875	bf0d2c91-4798-4294-a798-6bfe3e810ef3	1	SharkScale	None	9-60	LowRush	None	3	12	2025-11-20	60	2025-11-21 21:59:08.984116+00
e309e8a8-e930-4f4c-389e-08de278ff875	bf0d2c91-4798-4294-a798-6bfe3e810ef3	2	KnightMail	None	1-60	Rush	None	3	12	2025-11-20	60	2025-11-21 21:59:08.984116+00
e309e8a8-e930-4f4c-389e-08de278ff875	bf0d2c91-4798-4294-a798-6bfe3e810ef3	3	TyrannoBeat	None	1-70	Kick	None	3	12	2025-11-20	60	2025-11-21 21:59:08.984116+00
2e6e8eff-51e2-4051-3ca6-08de024c2a08	bf0d2c91-4798-4294-a798-6bfe3e810ef3	1	SharkScale	None	4-50	UnderFlat	None	1	12	2025-10-03	120	2025-11-23 11:00:58.833833+00
2e6e8eff-51e2-4051-3ca6-08de024c2a08	bf0d2c91-4798-4294-a798-6bfe3e810ef3	2	KnightMail	None	1-60	Rush	None	1	12	2025-10-03	120	2025-11-23 11:00:58.833833+00
2e6e8eff-51e2-4051-3ca6-08de024c2a08	bf0d2c91-4798-4294-a798-6bfe3e810ef3	3	TyrannoBeat	None	5-60	Kick	None	1	12	2025-10-03	120	2025-11-23 11:00:58.833833+00
2e6e8eff-51e2-4051-3ca6-08de024c2a08	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	1	HoverWyvern	None	9-60	Kick	None	2	12	2025-10-03	84	2025-11-23 11:01:45.68928+00
2e6e8eff-51e2-4051-3ca6-08de024c2a08	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	2	SharkScale	None	3-60	Level	None	2	12	2025-10-03	84	2025-11-23 11:01:45.68928+00
2e6e8eff-51e2-4051-3ca6-08de024c2a08	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	3	WizardRod	None	6-60	Ball	None	2	12	2025-10-03	84	2025-11-23 11:01:45.68928+00
2e6e8eff-51e2-4051-3ca6-08de024c2a08	2db4c771-059a-4ffd-99e6-2fb1826be418	1	SilverWolf	None	9-60	FreeBall	None	3	12	2025-10-03	60	2025-11-23 11:02:30.678876+00
2e6e8eff-51e2-4051-3ca6-08de024c2a08	2db4c771-059a-4ffd-99e6-2fb1826be418	2	DranBuster	None	1-60	Rush	None	3	12	2025-10-03	60	2025-11-23 11:02:30.678876+00
2e6e8eff-51e2-4051-3ca6-08de024c2a08	2db4c771-059a-4ffd-99e6-2fb1826be418	3	PhoenixWing	None	3-60	Hexa	None	3	12	2025-10-03	60	2025-11-23 11:02:30.678876+00
2e6e8eff-51e2-4051-3ca6-08de024c2a08	da54d0b7-7af4-475c-9617-e89198753a30	1	SilverWolf	None	9-60	FreeBall	None	3	12	2025-10-03	60	2025-11-23 11:03:43.18574+00
2e6e8eff-51e2-4051-3ca6-08de024c2a08	da54d0b7-7af4-475c-9617-e89198753a30	2	SamuraiSaber	None	3-60	Hexa	None	3	12	2025-10-03	60	2025-11-23 11:03:43.18574+00
2e6e8eff-51e2-4051-3ca6-08de024c2a08	da54d0b7-7af4-475c-9617-e89198753a30	3	TyrannoRoar	None	3-70	Kick	None	3	12	2025-10-03	60	2025-11-23 11:03:43.18574+00
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	875ccc4e-4d96-4412-a7fc-b1460cf734a0	1	HoverWyvern	None	9-60	Kick	None	1	8	2025-11-28	80	2025-12-07 22:18:42.065055+00
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	875ccc4e-4d96-4412-a7fc-b1460cf734a0	2	SharkScale	None	1-60	LowRush	None	1	8	2025-11-28	80	2025-12-07 22:18:42.065055+00
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	875ccc4e-4d96-4412-a7fc-b1460cf734a0	3	WizardRod	None	1-70	Hexa	None	1	8	2025-11-28	80	2025-12-07 22:18:42.065055+00
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	eefad2d2-1c4b-42cd-8496-b4260ead3128	1	SamuraiSaber	None	7-60	Hexa	None	3	8	2025-11-28	40	2025-12-07 22:20:52.530389+00
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	eefad2d2-1c4b-42cd-8496-b4260ead3128	2	SharkEdge	None	3-80	LowFlat	None	3	8	2025-11-28	40	2025-12-07 22:20:52.530389+00
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	eefad2d2-1c4b-42cd-8496-b4260ead3128	3	KnightMail	None	1-60	Point	None	3	8	2025-11-28	40	2025-12-07 22:20:52.530389+00
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	1	DranBuster	None	1-60	Rush	None	4	8	2025-11-28	0	2025-12-07 22:22:33.167623+00
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	2	SharkEdge	None	3-60	LowFlat	None	4	8	2025-11-28	0	2025-12-07 22:22:33.167623+00
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	3	WizardRod	None	5-60	Ball	None	4	8	2025-11-28	0	2025-12-07 22:22:33.167623+00
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	55c70b52-40d6-4c65-bf69-6798204d54a3	1	Blast	Heavy	9-60	LowRush	None	2	8	2025-11-28	56	2025-12-07 22:54:19.087339+00
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	55c70b52-40d6-4c65-bf69-6798204d54a3	2	PhoenixWing	None	None	Operate	None	2	8	2025-11-28	56	2025-12-07 22:54:19.087339+00
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	55c70b52-40d6-4c65-bf69-6798204d54a3	3	WizardRod	None	1-60	Rush	None	2	8	2025-11-28	56	2025-12-07 22:54:19.087339+00
34db284a-9d01-44bb-3992-08de278ff875	9284b32b-f0e1-4aa9-83a7-dc11f1c62dcc	1	SilverWolf	None	9-70	FreeBall	None	2	28	2025-11-22	196	2025-12-11 17:28:08.232027+00
34db284a-9d01-44bb-3992-08de278ff875	9284b32b-f0e1-4aa9-83a7-dc11f1c62dcc	2	WizardRod	None	9-60	Ball	None	2	28	2025-11-22	196	2025-12-11 17:28:08.232027+00
34db284a-9d01-44bb-3992-08de278ff875	9284b32b-f0e1-4aa9-83a7-dc11f1c62dcc	3	PhoenixWing	None	1-60	Rush	None	2	28	2025-11-22	196	2025-12-11 17:28:08.232027+00
34db284a-9d01-44bb-3992-08de278ff875	52af5e3d-7923-4c50-96b1-b4ffae064824	1	KnightMail	None	9-60	Rush	None	1	28	2025-11-22	280	2025-12-11 17:27:12.940805+00
34db284a-9d01-44bb-3992-08de278ff875	52af5e3d-7923-4c50-96b1-b4ffae064824	2	TyrannoBeat	None	1-60	Level	None	1	28	2025-11-22	280	2025-12-11 17:27:12.940805+00
34db284a-9d01-44bb-3992-08de278ff875	52af5e3d-7923-4c50-96b1-b4ffae064824	3	SharkScale	None	1-70	LowRush	None	1	28	2025-11-22	280	2025-12-11 17:27:12.940805+00
34db284a-9d01-44bb-3992-08de278ff875	b6bf50b2-6b37-4ad7-aef3-e95c84a9c2fe	1	CobaltDragoon	None	5-60	Elevate	None	3	28	2025-11-22	140	2025-12-11 17:28:55.063804+00
34db284a-9d01-44bb-3992-08de278ff875	b6bf50b2-6b37-4ad7-aef3-e95c84a9c2fe	2	WizardRod	None	9-60	Ball	None	3	28	2025-11-22	140	2025-12-11 17:28:55.063804+00
34db284a-9d01-44bb-3992-08de278ff875	b6bf50b2-6b37-4ad7-aef3-e95c84a9c2fe	3	SharkScale	None	1-60	LowRush	None	3	28	2025-11-22	140	2025-12-11 17:28:55.063804+00
34db284a-9d01-44bb-3992-08de278ff875	4d3f97b1-28ec-42de-bb6b-529c4f440b53	1	SilverWolf	None	3-60	Hexa	None	3	28	2025-11-22	140	2025-12-11 17:30:03.826814+00
34db284a-9d01-44bb-3992-08de278ff875	4d3f97b1-28ec-42de-bb6b-529c4f440b53	2	WizardRod	None	9-60	Ball	None	3	28	2025-11-22	140	2025-12-11 17:30:03.826814+00
34db284a-9d01-44bb-3992-08de278ff875	4d3f97b1-28ec-42de-bb6b-529c4f440b53	3	ImpactDrake	None	4-60	Kick	None	3	28	2025-11-22	140	2025-12-11 17:30:03.826814+00
a874ee55-7a54-45dd-6dc1-08de30f37986	b956f704-a5cc-42c1-a76e-728cc030ce2a	1	SharkScale	None	1-70	LowRush	None	1	30	2025-12-06	300	2025-12-18 21:48:52.787119+00
a874ee55-7a54-45dd-6dc1-08de30f37986	b956f704-a5cc-42c1-a76e-728cc030ce2a	2	Blast	Heavy	9-60	Taper	emperor	1	30	2025-12-06	300	2025-12-18 21:48:52.787119+00
a874ee55-7a54-45dd-6dc1-08de30f37986	b956f704-a5cc-42c1-a76e-728cc030ce2a	3	SilverWolf	None	9-70	FreeBall	None	1	30	2025-12-06	300	2025-12-18 21:48:52.787119+00
a874ee55-7a54-45dd-6dc1-08de30f37986	f6f47a62-9aa5-4303-8b1c-d4caefdc509e	1	ImpactDrake	None	4-60	Rush	None	2	30	2025-12-06	210	2025-12-18 21:49:34.877288+00
a874ee55-7a54-45dd-6dc1-08de30f37986	f6f47a62-9aa5-4303-8b1c-d4caefdc509e	2	WizardRod	None	1-60	Hexa	None	2	30	2025-12-06	210	2025-12-18 21:49:34.877288+00
a874ee55-7a54-45dd-6dc1-08de30f37986	f6f47a62-9aa5-4303-8b1c-d4caefdc509e	3	SharkScale	None	4-50	LowRush	None	2	30	2025-12-06	210	2025-12-18 21:49:34.877288+00
a874ee55-7a54-45dd-6dc1-08de30f37986	3432caad-f9ac-48c0-8011-22d32680a889	1	HoverWyvern	None	1-60	Kick	None	3	30	2025-12-06	150	2025-12-18 21:50:12.467337+00
a874ee55-7a54-45dd-6dc1-08de30f37986	3432caad-f9ac-48c0-8011-22d32680a889	2	WizardRod	None	9-60	Ball	None	3	30	2025-12-06	150	2025-12-18 21:50:12.467337+00
a874ee55-7a54-45dd-6dc1-08de30f37986	3432caad-f9ac-48c0-8011-22d32680a889	3	SilverWolf	None	5-60	FreeBall	None	3	30	2025-12-06	150	2025-12-18 21:50:12.467337+00
a874ee55-7a54-45dd-6dc1-08de30f37986	9515229f-3cf7-4870-9b17-42516832c2fa	1	GolemRock	None	3-60	FreeBall	None	3	30	2025-12-06	150	2025-12-18 21:50:44.667021+00
a874ee55-7a54-45dd-6dc1-08de30f37986	9515229f-3cf7-4870-9b17-42516832c2fa	2	WizardRod	None	9-60	Ball	None	3	30	2025-12-06	150	2025-12-18 21:50:44.667021+00
a874ee55-7a54-45dd-6dc1-08de30f37986	9515229f-3cf7-4870-9b17-42516832c2fa	3	KnightMail	None	1-60	Rush	None	3	30	2025-12-06	150	2025-12-18 21:50:44.667021+00
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	52af5e3d-7923-4c50-96b1-b4ffae064824	1	WizardRod	None	1-60	Hexa	None	1	24	2025-12-19	240	2025-12-20 23:23:54.33784+00
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	52af5e3d-7923-4c50-96b1-b4ffae064824	2	SharkScale	None	1-70	LowRush	None	1	24	2025-12-19	240	2025-12-20 23:23:54.33784+00
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	52af5e3d-7923-4c50-96b1-b4ffae064824	3	CobaltDragoon	None	9-60	Elevate	None	1	24	2025-12-19	240	2025-12-20 23:23:54.33784+00
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	875ccc4e-4d96-4412-a7fc-b1460cf734a0	1	Blast	Heavy	9-60	Kick	emperor	2	24	2025-12-19	168	2025-12-20 23:24:29.137675+00
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	875ccc4e-4d96-4412-a7fc-b1460cf734a0	2	SharkScale	None	1-60	LowRush	None	2	24	2025-12-19	168	2025-12-20 23:24:29.137675+00
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	875ccc4e-4d96-4412-a7fc-b1460cf734a0	3	WizardRod	None	1-70	Hexa	None	2	24	2025-12-19	168	2025-12-20 23:24:29.137675+00
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	1	SilverWolf	None	9-60	FreeBall	None	3	24	2025-12-19	120	2025-12-20 23:25:20.568539+00
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	2	SharkScale	None	3-60	LowRush	None	3	24	2025-12-19	120	2025-12-20 23:25:20.568539+00
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	3	WizardRod	None	1-60	Hexa	None	3	24	2025-12-19	120	2025-12-20 23:25:20.568539+00
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	55c70b52-40d6-4c65-bf69-6798204d54a3	1	WizardRod	None	7-60	Hexa	None	3	24	2025-12-19	120	2025-12-20 23:25:57.882646+00
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	55c70b52-40d6-4c65-bf69-6798204d54a3	2	DranSword	None	1-60	Rush	None	3	24	2025-12-19	120	2025-12-20 23:25:57.882646+00
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	55c70b52-40d6-4c65-bf69-6798204d54a3	3	SharkScale	None	3-60	LowRush	None	3	24	2025-12-19	120	2025-12-20 23:25:57.882646+00
0909d7a6-6cea-433d-ed50-08de4ae7da31	3432caad-f9ac-48c0-8011-22d32680a889	1	Blast	Heavy	9-60	Kick	emperor	1	32	2026-01-16	320	2026-01-26 13:12:47.826687+00
0909d7a6-6cea-433d-ed50-08de4ae7da31	3432caad-f9ac-48c0-8011-22d32680a889	2	SharkScale	None	3-60	Rush	None	1	32	2026-01-16	320	2026-01-26 13:12:47.826687+00
0909d7a6-6cea-433d-ed50-08de4ae7da31	3432caad-f9ac-48c0-8011-22d32680a889	3	WizardRod	None	1-60	Hexa	None	1	32	2026-01-16	320	2026-01-26 13:12:47.826687+00
0909d7a6-6cea-433d-ed50-08de4ae7da31	6433156e-ba76-4d4e-9013-4bc834b5c004	1	SilverWolf	None	9-60	FreeBall	None	2	32	2026-01-16	224	2026-01-26 13:13:32.662856+00
0909d7a6-6cea-433d-ed50-08de4ae7da31	6433156e-ba76-4d4e-9013-4bc834b5c004	2	SharkScale	None	3-60	LowRush	None	2	32	2026-01-16	224	2026-01-26 13:13:32.662856+00
0909d7a6-6cea-433d-ed50-08de4ae7da31	6433156e-ba76-4d4e-9013-4bc834b5c004	3	WizardRod	None	1-60	Hexa	None	2	32	2026-01-16	224	2026-01-26 13:13:32.662856+00
0909d7a6-6cea-433d-ed50-08de4ae7da31	fbe08cae-c480-49da-aa11-5967b6621f3b	1	Blast	Heavy	9-60	Kick	emperor	3	32	2026-01-16	160	2026-01-26 13:24:31.398018+00
0909d7a6-6cea-433d-ed50-08de4ae7da31	fbe08cae-c480-49da-aa11-5967b6621f3b	2	SharkScale	None	1-60	LowRush	None	3	32	2026-01-16	160	2026-01-26 13:24:31.398018+00
0909d7a6-6cea-433d-ed50-08de4ae7da31	fbe08cae-c480-49da-aa11-5967b6621f3b	3	WizardRod	None	1-60	Hexa	None	3	32	2026-01-16	160	2026-01-26 13:24:31.398018+00
0909d7a6-6cea-433d-ed50-08de4ae7da31	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	1	WizardRod	None	1-60	Hexa	None	4	32	2026-01-16	0	2026-01-26 13:25:51.936394+00
0909d7a6-6cea-433d-ed50-08de4ae7da31	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	2	SharkScale	None	3-60	LowRush	None	4	32	2026-01-16	0	2026-01-26 13:25:51.936394+00
0909d7a6-6cea-433d-ed50-08de4ae7da31	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	3	SilverWolf	None	9-60	FreeBall	None	4	32	2026-01-16	0	2026-01-26 13:25:51.936394+00
\.


--
-- Data for Name: cm_players; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cm_players (id, nickname, avatar, updated_at) FROM stdin;
4adf798d-cf50-48f7-821f-bca57219f4cf	il Cuggio	https://image1.challengermode.com/9c6b35fc-0555-48ce-d418-08de4d65b536_64_64	2026-01-08 18:33:44.376581+00
e1c7fad1-8a22-4c15-984c-ce0cd3edc731	Vixit	https://image1.challengermode.com/55350d89-48ea-4fd3-d53d-08de4d65b536_32_32	2026-02-02 21:12:15.81311+00
eefad2d2-1c4b-42cd-8496-b4260ead3128	Leonardoash	\N	2026-02-02 16:24:32.080357+00
003452fd-56da-46f4-8d20-95bc13d6e2a8	Fr3x	https://image1.challengermode.com/ba7d1fc2-1938-4be3-1869-08de50e57757_64_64	2026-01-14 12:11:06.733799+00
c86e41d2-23f9-4820-be62-33ed802f9897	Camistar	https://image1.challengermode.com/6a3fd4fb-a6c7-4c75-5bb9-08de0fc05e6f_32_32	2026-02-03 10:17:54.614191+00
dacf3e59-321e-433c-8625-067adee4abcf	Sif97	\N	2026-01-26 14:49:05.749734+00
466ca1a9-8f13-4c49-9cef-b974b7f5a74d	FedericoMaurini	https://image1.challengermode.com/891a8fd6-e117-4740-da54-08de4d65b536_64_64	2026-02-01 11:17:28.415768+00
fa7114c9-1f92-4249-98a0-ad598ad5c242	ErConfy	https://image1.challengermode.com/ecbba1b4-cde6-47c7-5486-08de2773033d_32_32	2026-02-02 16:24:32.089997+00
e9b01722-950a-43ea-9148-6740229ed992	Killered	\N	2026-01-16 18:29:46.247647+00
376b0451-8d02-4d38-9b87-027b6e58b8fe	Il Papà imbattibile	https://image1.challengermode.com/4382587e-1e9f-49c1-dba1-08ddfe048ed4_64_64	2026-01-28 19:32:03.250652+00
163de0bc-2d67-4b32-8cc9-0420305e00a7	Jhaykz	https://image1.challengermode.com/a75d2d96-6350-4488-d69c-08ddfe048ed4_32_32	2026-01-13 23:09:04.359954+00
ee1bca4e-d0db-4606-884d-c812dab99695	LoreDottore	\N	2026-01-13 23:09:04.359954+00
b7d89667-ace7-4a3a-900c-bc7eee1563ca	Lollo939	https://image1.challengermode.com/d74547bd-48a9-441f-faae-08de45e9d236_32_32	2026-02-02 16:24:31.115774+00
3f539cfe-8aa2-47c4-b6cd-2790b1c14321	ToninDuracell	https://image1.challengermode.com/6f597258-ee73-4727-f716-08de5762384e_32_32	2026-02-02 19:07:29.580662+00
91bea2f4-8358-4172-9e79-e07d375e688e	Michael94	\N	2026-02-02 16:24:31.675894+00
6694aaf3-b234-45a6-97ad-ea2a9e45f03f	Uran91	https://image1.challengermode.com/ba1a5e29-a9b5-4e4f-c57b-08de203ed509_32_32	2026-02-02 16:24:32.25348+00
74ddbf26-fdf6-4afb-8b63-789bf44e8bff	IoExTeR	https://image1.challengermode.com/781019a3-b71a-4f72-e761-08de5762384e_64_64	2026-01-24 12:01:29.421919+00
b12dbd71-a701-467a-993a-4d9bb09879b1	CrocchettaBagnata	https://image1.challengermode.com/d100c431-dbf9-4304-d484-08de4d65b536_32_32	2026-01-26 14:49:05.895347+00
b2501b89-28c4-40aa-8412-fcf583fee8b2	Ginos	https://image1.challengermode.com/15a1b779-c211-484c-cad6-08de203ed509_32_32	2026-02-02 16:24:31.499635+00
9284b32b-f0e1-4aa9-83a7-dc11f1c62dcc	Jeck22	https://image1.challengermode.com/54e24a03-4c55-461b-5961-08de2773033d_32_32	2026-02-02 16:24:32.169237+00
60ec4e56-7d92-47c5-8906-2cbfac49730e	Tomer85	https://image1.challengermode.com/52e2a229-2ccf-4a7b-e8f3-08de5762384e_32_32	2026-02-03 10:32:13.224302+00
f34ecc6e-3337-4f75-99d6-13520343161f	zircotico	\N	2026-01-14 13:16:51.595364+00
b956f704-a5cc-42c1-a76e-728cc030ce2a	Paskqualo	https://image1.challengermode.com/b37f1274-7187-42d5-6951-08de356d3ecd_32_32	2026-02-03 01:49:06.512566+00
2dbd53f1-e542-44fb-ad96-0e9faa071f9a	DadieDraghi	\N	2026-02-03 16:19:26.520239+00
e1fe29e2-9a1a-4711-a85a-8ef5cf942fe4	defuntoartist	https://image1.challengermode.com/2b08bafa-9514-4fdf-3c10-08de1bdf03fd_32_32	2026-02-02 16:24:32.091121+00
3028d769-8186-4387-9e36-812b26087fc4	m4tty.	https://image1.challengermode.com/089edcf0-6262-46de-1795-08de50e57757_32_32	2026-02-02 16:24:31.237889+00
b38664c0-7d96-49dd-9fc2-283f448f6af3	Unicorno_V	\N	2026-02-02 16:24:31.115774+00
c5a5d9ad-f18a-4ee2-85ab-908cf76aa72a	zHarion617	https://image1.challengermode.com/e372f799-180f-4bcd-8506-08de61764f16_64_64	2026-02-03 00:52:30.979684+00
70f9b2da-aa5f-439d-bb17-fa0d6f5e2279	xliga	https://image1.challengermode.com/2c2eb013-3646-4aa0-b02d-08ddebf5a029_32_32	2026-02-02 16:24:31.302757+00
6aa4c853-90f9-4292-8cf4-dd6a0b0b4d66	M33w	\N	2026-02-02 16:24:31.506676+00
e017fb67-e90e-4935-a633-caf9ae32f463	zef_99	\N	2026-02-03 11:32:55.60244+00
e7b1d625-a033-436b-bdaf-86e7a3dcaaa3	Blackdranzer1	\N	2026-01-26 14:49:05.888976+00
bb18fa2e-efae-4748-bff9-fee1290472be	Dypala	https://image1.challengermode.com/1258d64a-580a-46eb-57f2-08de2773033d_32_32	2026-01-16 18:29:46.247647+00
6969fb62-dd75-47c5-8070-0794dded1c0a	Unxam	https://image1.challengermode.com/6d10da91-27bc-4091-9235-08de2773033d_32_32	2026-02-02 16:24:31.792227+00
04414507-6240-4189-bd32-efee693b7858	FrankPH	https://image1.challengermode.com/948546f6-ed88-4154-6c81-08de2773033d_32_32	2026-02-03 10:32:13.224302+00
39215df5-f9d1-48a9-975d-d604f34c224a	Alessandro.IV	https://image1.challengermode.com/4497df56-e3b1-4d5a-587b-08de3ae4a372_32_32	2026-02-02 16:24:32.005112+00
8d5bfb98-1479-46fc-8ed4-227464e3ed3c	Alexsp93	\N	2026-02-02 16:24:31.302757+00
25e28290-023a-4159-b324-f57385693656	Anto301	\N	2026-01-15 22:12:25.12067+00
47cb8622-405a-4f9d-a666-fa0bea96fd76	Viceversa90	https://image1.challengermode.com/710ce272-32a8-4eac-b78b-08de19ecd147_64_64	2026-01-16 16:25:40.594184+00
6f4143ef-cbca-48a9-bc9c-d95336cbd098	testguy	\N	2026-01-21 23:05:45.397423+00
c50d4fc0-52e2-4ec9-a344-dc2277c3d139	Marty06	https://image1.challengermode.com/4b52ffa0-2317-4c33-f526-08de45e9d236_32_32	2026-02-03 10:17:51.535232+00
85822a86-057b-4b02-aaa8-736365bedeb5	Pat30	\N	2026-02-02 16:24:31.115774+00
f7158e1d-4e03-4ad1-b85f-b61d5829f48b	gamestimemarsciano	https://image1.challengermode.com/25a4cf5b-9cf4-4e94-1c14-08de50e57757_32_32	2026-02-03 11:32:55.60244+00
f760b545-d7e1-4ba6-b97d-b8439e630f0e	Khozaky	https://image1.challengermode.com/7c1821cb-7744-48c5-9717-08de2773033d_32_32	2026-02-02 16:24:31.414466+00
a35b2153-bd49-4c88-99d1-3969b7b990e8	Antonio Iker Mazzilli	\N	2026-02-02 16:24:31.115774+00
3b1ee979-99df-488d-99d9-be9f13e4bb62	Captain-Nex	\N	2026-02-02 16:24:31.86273+00
967c7cf7-2954-43c1-975b-ee7afb895e55	Noalone	\N	2026-02-02 16:24:31.411826+00
063aa453-48e6-49c2-8bfc-bdb2d9d08a08	testguy2	\N	2026-01-21 23:05:45.397423+00
6a41e08f-d8fe-4cf3-90d7-34cce7e904f8	testguy12	\N	2026-01-26 14:49:05.749734+00
228adb48-fc3b-41ee-a5c0-c523b3491aa7	CrazyTeddy	https://image1.challengermode.com/e83a9563-2253-4d80-1a0c-08de50e57757_32_32	2026-02-02 16:24:31.86273+00
0ff76fd8-e01e-4a4b-ba48-7cf11f927393	NoMorePhil	https://image1.challengermode.com/62c568ed-54f2-4d94-6e9b-08de2773033d_32_32	2026-02-02 16:24:32.091121+00
4f1da5cb-1a60-4cf4-a4a8-a0a1cd868871	Elvetius	https://image1.challengermode.com/261e57f9-d608-461e-fad1-08de45e9d236_32_32	2026-02-02 16:24:31.792227+00
29273bea-7c52-4fe6-b97d-8e95d225173f	testguy21	\N	2026-01-26 14:49:05.749734+00
27eb726a-7853-4dfd-b060-c37a747f06ca	testguy123	\N	2026-01-26 14:49:05.749734+00
f6f47a62-9aa5-4303-8b1c-d4caefdc509e	Nick111R96	https://image1.challengermode.com/b1660654-fe9d-4a46-5877-08de2773033d_32_32	2026-02-03 01:49:06.512566+00
7a1e5423-e07c-4fa3-9068-951366372d80	testguy3	\N	2026-01-21 23:05:45.397423+00
96ff4c7f-ae31-46c2-9c7a-a4dde068f206	Yulang_	https://image1.challengermode.com/174383ef-eb93-4d2c-f4c7-08de5762384e_32_32	2026-02-03 10:17:51.535232+00
902c6636-6aa0-4def-8b0d-edfb23ed5722	Fonzy_87	https://image1.challengermode.com/749cc9eb-4b99-42e7-9daf-08de1490395d_32_32	2026-02-02 16:24:32.086639+00
c9b251bd-03ec-49ee-99ae-36959f63b1cd	Griennel	https://image1.challengermode.com/4ead031e-682d-4f9d-60af-08de2773033d_32_32	2026-01-18 18:41:14.84868+00
39e31565-a904-4803-a9c4-569f712b0eb2	Kaselli	\N	2026-01-16 18:29:46.247647+00
d37fce58-92f1-4d7b-904e-f659d6b2a1d3	Miky_	\N	2026-02-02 16:24:30.880023+00
f68611ef-8c26-40e3-8195-d13e0758516c	Mat94	\N	2026-02-02 16:24:30.880023+00
9515229f-3cf7-4870-9b17-42516832c2fa	Leon__	https://image1.challengermode.com/90fe0cc8-019d-4f57-db01-08de4d65b536_32_32	2026-02-03 01:49:06.512566+00
1f856dc5-3735-43be-a88f-fc558f8b7fcd	JMD23	https://image1.challengermode.com/5f1bf857-a70a-484b-b3f0-08de066b6e6b_32_32	2026-02-02 16:24:32.089997+00
6ad34546-2f27-499b-b79b-b97a814eb065	*-Grimmjow*-	\N	2026-02-02 16:24:31.489533+00
736d1acf-027c-4128-8c07-540aae993ed8	ZEF99	https://image1.challengermode.com/a1476d60-49e8-47f8-9d64-08de1490395d_32_32	2026-01-18 18:41:14.84868+00
504aca91-30d4-45af-9d8e-bca117c398ae	cicchio51	\N	2026-02-02 16:24:31.86273+00
84679bcf-0397-45ed-a191-a10507339451	DoctorMlem	\N	2026-01-09 21:05:58.504875+00
3432caad-f9ac-48c0-8011-22d32680a889	Bob_23	https://image1.challengermode.com/b0a11183-0857-4adc-1e5b-08de50e57757_32_32	2026-02-04 08:11:28.104475+00
72938c5e-d4d5-4682-9fe1-516aa45f51ad	Il_mitico_ulisse	https://image1.challengermode.com/afdb4439-9099-44b1-3cdb-08de1bdf03fd_32_32	2026-02-03 10:17:54.614191+00
27123ef8-6f21-4afa-9f05-63da58012118	Guxisar	https://image1.challengermode.com/1606db52-b7ae-474c-ae75-08de066b6e6b_32_32	2026-02-02 21:12:25.987509+00
52af5e3d-7923-4c50-96b1-b4ffae064824	yori99	https://image1.challengermode.com/debfb05a-2a34-469c-dce8-08ddfe048ed4_32_32	2026-02-04 08:12:50.304606+00
8b107f55-9609-4711-b33a-f322e684a678	Pone_1	https://image1.challengermode.com/8243e41e-67e5-439c-6665-08de0fc05e6f_32_32	2026-01-22 21:05:04.672703+00
0282926c-d97d-4d0d-aa69-da337d0d2158	_Sh4rk_	https://image1.challengermode.com/ddc06639-7f1a-4b91-d917-08ddfe048ed4_32_32	2026-02-02 16:24:31.237889+00
6433156e-ba76-4d4e-9013-4bc834b5c004	PAJA94	https://image1.challengermode.com/cb9ae056-cdcf-43cb-68b1-08de2773033d_32_32	2026-02-04 08:11:28.104475+00
2d1207d1-b591-4196-8e95-b883989f288d	neko_hana00	https://image1.challengermode.com/c2be1552-2844-4113-5883-08de2773033d_32_32	2026-02-02 16:24:32.283297+00
46d58fed-6183-456c-b0fc-e0c1e7072854	Kriperus	https://image1.challengermode.com/a8aee0d5-0796-43de-8bad-08de2773033d_64_64	2026-01-30 16:31:33.06435+00
fbdc994f-18e6-4ff1-897d-c25d7b50c4bb	Blayder p	\N	2026-01-26 14:49:05.888976+00
31c84919-2494-4f1c-be09-033504a671b1	wasssup1	https://image1.challengermode.com/7cd09741-02ee-40e2-3c6b-08de1bdf03fd_32_32	2026-02-02 21:12:25.987509+00
afdd6f43-b951-44a3-870c-d9d07e8144d2	#MaiunaGioia	https://image1.challengermode.com/ba9018cf-8004-4049-1243-08de50e57757_32_32	2026-02-02 16:24:31.302757+00
4e7bbcdd-a32c-4806-96c9-1019be3ac72d	Jek55	\N	2026-02-02 16:24:31.314919+00
2bbd2c66-684d-4146-945a-cd1c92b8c323	Marshxq120	https://image1.challengermode.com/0888cc2b-8708-4d92-f481-08de5762384e_32_32	2026-02-03 10:32:13.224302+00
9422e372-5376-446f-aefb-31387ab0ad41	Foxone	https://image1.challengermode.com/1fa13f9a-3c9b-4322-d204-08de203ed509_32_32	2026-02-03 10:32:13.224302+00
f69f36d0-b58c-49a0-bcc8-3aa842813bd0	Succo Di Frutta	\N	2026-02-02 16:24:31.314919+00
bc721971-5d53-4ac0-9f92-2acb52717b51	distruttore	https://image1.challengermode.com/7d7d06c0-2916-437b-6439-08de0fc05e6f_32_32	2026-02-02 16:24:31.68796+00
d7a3523e-41ca-4e91-87e9-9513dc2ec290	Anto_pika	https://image1.challengermode.com/e77973ea-a258-45ff-5962-08de3ae4a372_32_32	2026-02-02 16:24:32.18621+00
90fe51b8-b025-43c5-b477-7a960ead95b4	The_Luke	https://image1.challengermode.com/ac26279d-e02d-4de0-dc4f-08de4d65b536_32_32	2026-02-02 16:24:30.880023+00
fbe08cae-c480-49da-aa11-5967b6621f3b	Post91	https://image1.challengermode.com/3bbbb855-a94c-48b8-663a-08de55f47bfc_32_32	2026-02-04 08:11:28.104475+00
8db2a1c1-72a0-44a5-b8e0-27c236a9afb9	v2hel	https://image1.challengermode.com/f960a8d2-82c7-4ac5-185a-08de50e57757_32_32	2026-02-02 16:24:32.337098+00
d7398b0e-3bc2-4aef-aef9-f88009c4576e	JackNG	https://image1.challengermode.com/e2b5aa96-9f48-42c1-5ae5-08de356d3ecd_32_32	2026-02-02 16:24:31.86273+00
6708c485-be3b-4e7a-9126-046755fe77ad	Vincent97	https://image1.challengermode.com/955c1aed-614a-4b68-ae84-08de066b6e6b_32_32	2026-02-02 16:24:31.498323+00
d6abd100-0300-49df-9d70-4a11c408157d	antmemoli92	\N	2026-02-02 19:53:24.542537+00
5577bb9e-d9a6-4796-a4ba-07227e09c67d	Krist0	https://image1.challengermode.com/ad3d88cd-d092-493e-d918-08ddfe048ed4_32_32	2026-02-02 16:24:31.237889+00
171985d0-867f-4e76-a9ea-ed44b96160bd	Xcidio	https://image1.challengermode.com/9cd13caa-224f-49fc-914e-08de24e07668_32_32	2026-02-02 16:24:31.314919+00
20ff388d-22e3-4acb-a709-ff8c823c4593	Brian3003	https://image1.challengermode.com/98a235d0-216b-45af-c59e-08de203ed509_32_32	2026-02-02 16:24:32.25348+00
fc00a907-2bb3-4ff7-8431-d395b9fcf2e1	Sonic il supersonico	\N	2026-02-02 16:24:31.314919+00
8eddd258-8cb5-404d-b811-2c9d4ea66f3b	TeoFil795	https://image1.challengermode.com/48852b38-db89-4241-61ff-08de2773033d_32_32	2026-02-02 16:24:31.335065+00
60c3e4a9-53ee-478a-b6b3-492e2ecb87ef	Vexcel	https://image1.challengermode.com/fd267cee-62c7-41c5-6a85-08de356d3ecd_32_32	2026-02-02 19:56:52.593271+00
e2e4f6c6-b777-4b96-81bc-29c1012556e8	Crimson:)	https://image1.challengermode.com/43013388-16ab-4617-d754-08de4d65b536_32_32	2026-02-02 16:24:31.335065+00
8a328f79-528e-4071-a5cf-9f26c1d30756	Kutami	https://image1.challengermode.com/5d7d1537-0001-4546-9895-08dd03ea6a3a_32_32	2026-02-02 16:24:32.283297+00
ee291233-fe2c-45bf-adb6-3b4204fd209a	Fedarka	\N	2026-02-02 16:24:30.880023+00
74437637-9b6a-4495-9a42-4ba0abeadcc5	Hitara	https://image1.challengermode.com/a4aee5f4-1627-4d09-59c1-08de3ae4a372_32_32	2026-02-02 16:24:31.68796+00
6a064bfc-b8dc-4994-884d-e548697b659a	Zoffone	\N	2026-02-02 19:56:52.593271+00
ca70e8e5-7bc2-4f69-b120-005725e265d5	Cuscino	\N	2026-02-02 16:24:32.283297+00
1c665022-1ad5-4f14-ab15-481759b249bc	EneaRomano	https://image1.challengermode.com/76189b54-879e-4fe4-11d1-08de50e57757_32_32	2026-02-02 19:56:52.593271+00
b27eae0c-c7b4-49a4-b7fb-f84cb80d704e	Barbonesoterico	\N	2026-02-02 19:56:52.593271+00
12ba1dcc-c40b-42e8-9f9c-db7c3767741d	ROXY28	https://image1.challengermode.com/fb61d53a-5e51-4066-670a-08de0fc05e6f_32_32	2026-02-02 16:24:32.006534+00
cc697e12-8a68-4b05-b8dd-c11d7847bde8	imgiacolo	https://image1.challengermode.com/e22601f2-c117-435c-444a-08de1bdf03fd_32_32	2026-02-01 18:19:25.686376+00
be9f0491-8cef-4802-839f-37ab49329e34	BoBnica	https://image1.challengermode.com/a1b5f669-c522-4d5b-d58f-08de4d65b536_32_32	2026-02-01 18:19:25.686376+00
01eecb73-3dc0-46c3-a2be-c0cd0fefbf9c	Bellockamp	https://image1.challengermode.com/0de6d961-8352-4ffb-8e64-08de2773033d_32_32	2026-02-02 16:40:11.234655+00
c8d4838f-ee6f-451d-a16b-21b532cde98b	Nonnechik99	https://image1.challengermode.com/d96e1b8a-edf5-4ef2-8354-08de61764f16_32_32	2026-02-02 19:07:29.580662+00
50179e51-4645-48d0-9960-f65bed7ba3eb	Misterious reaper	https://image1.challengermode.com/b4504c71-5b1c-4f69-f34a-08de5762384e_32_32	2026-02-02 21:12:25.987509+00
1abd0de5-67bd-4a50-bacf-c3f20902b6fd	Ryupi	https://image1.challengermode.com/c4bf1345-c203-4cec-f52b-08de45e9d236_32_32	2026-02-02 16:24:31.677084+00
139b8dc5-f6f9-4f23-b14d-3ad34c63b82c	Burner3401	https://image1.challengermode.com/072d1ebc-b797-4cec-9161-08de2773033d_32_32	2026-02-03 10:17:51.535232+00
30e374f9-af50-42fc-ad13-1053d6cc6a9d	ubekage	https://image1.challengermode.com/de96f497-2f5a-4064-7935-08de2773033d_32_32	2026-02-02 16:24:32.089997+00
527ffa94-2073-4a74-a006-89092ff9a9b7	xReko	https://image1.challengermode.com/eeeb9610-6467-40a9-99c1-08de1490395d_32_32	2026-02-02 16:24:31.677084+00
374dd633-8222-41eb-a76a-c155ce0d5e72	120% Disparter	https://image1.challengermode.com/cd42eedc-2dd0-4d03-d59d-08de4d65b536_32_32	2026-02-02 16:24:32.091121+00
b6bf50b2-6b37-4ad7-aef3-e95c84a9c2fe	ThE_HiTmAn88	https://image1.challengermode.com/e78be1de-50ec-40e4-5ad2-08de2773033d_32_32	2026-02-02 16:24:32.169237+00
4de3d716-1958-461c-a01b-da9f4e36e4c8	ZioTonio	\N	2026-02-02 16:24:31.026988+00
7bd9d3d8-2ba7-4c87-9e41-287072ad5396	lucifero.93	\N	2025-11-30 14:43:13.526204+00
f20386ab-bbea-46d8-bb29-23da65bdae10	BlacklightX	https://image1.challengermode.com/00f1e216-1d63-4cf9-d92a-08ddfe048ed4_32_32	2026-02-02 16:24:31.026988+00
4d3f97b1-28ec-42de-bb6b-529c4f440b53	MattoSquash	https://image1.challengermode.com/f457c8e4-1123-4426-61fe-08de2773033d_32_32	2026-02-02 16:24:32.169237+00
fc705f84-15eb-488b-af47-459a19305c2b	sasa-man	https://image1.challengermode.com/ad335fe6-acfc-42cb-5ae7-08de0fc05e6f_32_32	2026-02-03 10:17:54.614191+00
2c6aeef1-6313-46ed-baa7-6aec833a6864	emmanuelevito	https://image1.challengermode.com/232d49ab-e5d4-4275-5d95-08de2773033d_32_32	2026-02-02 16:24:32.18621+00
5d26c6c9-366c-494a-ae95-bb9fd52a0612	RagazzoScheletro	https://image1.challengermode.com/29f50146-490a-4bd0-6516-08de2773033d_64_64	2026-02-03 13:16:33.448353+00
fdf43f3f-96c0-4604-98ef-ac9a8798ee0e	Ludix96	\N	2026-02-02 16:24:32.25348+00
b665b54a-d04f-47bf-86af-39d3801ece39	Gammaa_	https://image1.challengermode.com/ae9a26f2-3a3a-4ebe-d91e-08ddfe048ed4_32_32	2026-02-02 16:24:31.237889+00
3cf335c0-fc87-49b6-89bb-1879c79527bb	BobLaggiustatutto	https://image1.challengermode.com/6ffc4499-b73e-437d-5c0d-08de3ae4a372_32_32	2026-02-02 16:24:31.861882+00
33f9162f-6715-4dea-9e76-b8d35f03cc5e	Monkey King Tattoo	https://image1.challengermode.com/e85b6e27-35b8-4f5f-aace-08ddf99e48ba_32_32	2026-02-02 16:24:32.25348+00
1f3fbbcd-0e70-4aad-ba5a-fbe0c12cb0b9	India_Pale_Ale	https://image1.challengermode.com/842f03ed-372b-4def-40c0-08de4b65d9f9_32_32	2026-02-02 16:24:31.302757+00
875ccc4e-4d96-4412-a7fc-b1460cf734a0	-Marshall-	https://image1.challengermode.com/56f75d6f-c6b9-40dc-99bc-08de1490395d_32_32	2026-02-04 08:12:50.304606+00
12cebd5b-356d-4bd9-a4d4-f88ad18cf59f	Lemm_77	https://image1.challengermode.com/4f78068f-710d-4946-0701-08de40693808_32_32	2026-02-02 16:24:31.335065+00
79ae80d4-9e52-465a-a3b5-67a4427e0679	yuriymo	https://image1.challengermode.com/7cfb76df-2740-4166-ae70-08de066b6e6b_32_32	2026-02-02 16:24:32.337098+00
55c70b52-40d6-4c65-bf69-6798204d54a3	AnDrEai	\N	2026-02-04 08:12:50.304606+00
3fcf773a-ed59-40db-a826-b489b096f676	Paky21	\N	2026-02-02 16:24:31.498323+00
f3b0b3e1-bf97-4273-97fb-978125a96a85	Eclissatore	https://image1.challengermode.com/75bae282-50ae-4a3a-9a40-08de26b9471c_32_32	2026-02-02 16:24:31.868276+00
13a5e203-ca99-45d9-83ba-ddd2ec836ece	Emmet77	https://image1.challengermode.com/8f9c35e9-342a-4c00-9748-08de2773033d_32_32	2026-02-02 16:24:31.868276+00
2a8d2919-8cc3-4783-aa11-2b4fe713288d	Riky Ricotta	https://image1.challengermode.com/1dd369c8-48d0-4ea4-b593-08de04dc1a75_32_32	2026-01-12 12:20:57.184925+00
982acdeb-c07d-42c9-9a8d-c3cf734117a4	Pod81	\N	2026-01-12 12:20:57.184925+00
71571aab-0983-4474-a134-2165c31b1b56	ExtremeGabry	\N	2026-01-12 12:20:57.184925+00
18fa714e-c0a7-4a37-b2f7-463088f4e41a	MikyBuster	\N	2026-01-12 12:20:57.184925+00
ca698742-8ee0-41d8-9328-d65599b5bfdf	Nollax_Yukiko	https://image1.challengermode.com/0deb90d0-c37b-4320-5901-08de0fc05e6f_32_32	2026-02-02 16:24:31.675894+00
c22a9e64-da54-437c-bcd0-4f53535d3350	Solixi120	https://image1.challengermode.com/a5c576c2-5817-445f-ae7a-08de066b6e6b_32_32	2026-02-02 16:24:32.268555+00
72a0bb2a-1667-4611-9bac-645c42baa7b3	Verbix	https://image1.challengermode.com/941e204f-e578-4b45-6ad3-08de356d3ecd_64_64	2026-01-20 10:03:47.309862+00
35d33303-af71-4657-85a2-46df5fb76960	Glace98	\N	2026-01-16 18:29:46.247647+00
6ef8d6cd-683f-403d-bfd5-b7c3b8351ef3	ofraton	https://image1.challengermode.com/842758b4-9278-47f5-aec2-08de066b6e6b_32_32	2026-02-02 19:53:24.542537+00
7b93216a-d77e-479f-8d1e-5ad2bc604f6d	Laerte1	\N	2026-02-02 19:53:24.542537+00
9c78170c-0b9c-4491-88ab-baa817ff7951	Bernyfur	https://image1.challengermode.com/85f4f66a-cec2-4546-68de-08de0fc05e6f_32_32	2026-02-03 10:17:54.614191+00
92c51076-5b04-4ba1-babd-29aa77c92052	Lapsus_	https://image1.challengermode.com/b31b2b60-d7b3-44c6-b53a-08de066b6e6b_32_32	2026-01-13 23:09:04.359954+00
bc3016a0-94b7-4e19-9383-efd13a25ce54	m4nishtv	\N	2026-02-01 23:44:34.059076+00
3412facf-e387-4278-b1b3-cc8586de07f7	WOLFUX07	https://image1.challengermode.com/2b72f004-7750-49d7-ae74-08de066b6e6b_32_32	2026-01-16 06:16:51.702837+00
fb8b02fa-2b31-43f8-ba29-171c3bad3457	michele3829	\N	2026-01-08 08:37:57.273414+00
8b9e5a38-6710-40ea-978e-d118af034b7e	_Steffo_	\N	2026-01-08 08:37:57.273414+00
0b2c3620-662e-4b39-8ddf-5af62517a9e4	JFSawyer	\N	2026-01-08 08:37:57.273414+00
fbb39197-1cc6-4241-b112-b9d80d1efde1	ofuentes98	\N	2026-01-16 06:16:51.702837+00
b22bd7ca-2ca5-4dfc-9661-cbe62db2fcf9	ic.draken	\N	2026-01-27 16:36:10.352768+00
b1243654-c15c-4681-897b-add368d5a04b	Ayaya04	https://image1.challengermode.com/1f890c18-063c-419f-b039-08ddebf5a029_32_32	2026-01-11 12:28:23.96184+00
14f847bd-58de-4a9e-8b04-7e11076da936	Dains Celance	https://image1.challengermode.com/3b973654-63ca-4817-afe1-08ddebf5a029_32_32	2026-01-11 12:28:23.96184+00
97eae769-ee59-4720-b3e8-faa983207f06	HunterKilller	https://image1.challengermode.com/575fda8e-7125-4a2e-5207-08dd03ea46ad_32_32	2026-01-09 08:38:30.289067+00
aef12da7-93fe-4730-8793-48cfa398297d	Vance_Refrigeration	https://image1.challengermode.com/9464a6cc-cb65-4a00-a4f7-08dd8f85ef08_32_32	2026-01-09 08:38:30.289067+00
994bacee-a319-4e01-9e28-5e349abc0cdc	AnriHanekawa	https://image1.challengermode.com/33418fab-2540-490e-5294-08dd03ea46ad_32_32	2026-01-09 08:38:30.289067+00
795af579-7b39-4880-8462-f286bcea65e3	Vysor90	https://image1.challengermode.com/0c51d993-764d-463f-99f1-08dd03ea6a3a_32_32	2026-01-09 08:38:30.289067+00
c05be628-0b2b-4225-a4cc-5df3aaf332da	RayDark27	https://image1.challengermode.com/bf866e36-a79f-4619-ae77-08de066b6e6b_32_32	2026-02-02 16:24:31.107058+00
17a057f6-ebe7-42d1-9216-26be70268ce2	Oby92	\N	2026-01-27 23:29:53.001917+00
537eaf9d-f86d-48eb-aa68-55d83404310f	Fazbal	\N	2026-02-02 02:06:18.644932+00
083b39ca-6ad1-464a-8e4c-ca01142f25c8	paolomu_99	\N	2026-02-02 16:24:31.793766+00
caf51fc9-0007-434d-94d3-dc589b68bd64	Nerkio	https://image1.challengermode.com/3300e275-18e4-425d-b24b-08de066b6e6b_32_32	2026-02-02 16:24:32.089997+00
d963841c-bdb8-47a4-a500-1ca61c451b3d	giusando3097	\N	2026-02-02 11:12:48.374193+00
b6e71cec-29f1-493f-ba4a-5fe5aa6082d0	nath_ll	https://image1.challengermode.com/c2acce5b-f2d0-45c1-9967-08dd03ea6a3a_32_32	2026-01-10 09:08:50.472955+00
0baf11bc-4efa-4439-be58-4298d6776e07	Kai87	\N	2026-01-10 09:08:50.472955+00
d66fafc4-9edc-44fb-bbf6-4c3ec8396a24	Xirab	\N	2026-01-10 09:08:50.472955+00
1e31a2d2-c773-4b5c-9ec4-37076502817b	Ranur	\N	2026-01-10 09:08:50.472955+00
bbd8a1de-a369-48d5-a153-4863de675530	RobertoSerra	\N	2026-02-02 21:12:15.81311+00
53face5a-1fa9-4d2c-8f75-70e430adbecb	YuriFas	https://image1.challengermode.com/7f842bdf-025d-4594-3bf4-08de1bdf03fd_32_32	2026-02-02 21:12:15.81311+00
bf0d2c91-4798-4294-a798-6bfe3e810ef3	CrazyFoll	https://image1.challengermode.com/3cfa44cf-cb3b-4347-b215-08ddf99e48ba_32_32	2026-02-03 11:32:55.60244+00
2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	TEVO_	https://image1.challengermode.com/c724591f-de16-4bf1-b356-08de04dc1a75_32_32	2026-02-04 08:12:50.304606+00
2db4c771-059a-4ffd-99e6-2fb1826be418	itsfloinn	https://image1.challengermode.com/4fd9865f-f65a-46b4-68bc-08de356d3ecd_32_32	2026-01-28 19:50:43.33854+00
da54d0b7-7af4-475c-9617-e89198753a30	WizardBusters	https://image1.challengermode.com/378bbf29-d8b9-4d86-f90e-08de45e9d236_32_32	2026-01-28 19:50:43.33854+00
\.


--
-- Data for Name: combo_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.combo_stats (blade, assist_blade, ratchet, "bit", lock_chip, primi_posti, secondi_posti, terzi_posti, punteggio_totale, data_creazione, season, quarti_posti) FROM stdin;
SharkScale	None	3-60	Rush	None	0	0	0	0	2026-01-26 13:11:27.172898+00	Off Season 2025	0
KnightMail	None	6-60	Level	None	0	0	0	0	2026-01-14 13:25:19.053603+00	Off Season 2025	0
PhoenixWing	None	1-60	Rush	None	2	1	1	591	2026-01-14 13:25:19.053603+00	Off Season 2025	0
PhoenixWing	None	1-70	Rush	None	1	0	1	165	2026-01-14 13:25:19.053603+00	Off Season 2025	0
PhoenixWing	None	3-60	Hexa	None	0	0	1	60	2026-01-14 13:25:19.053603+00	Off Season 2025	0
AeroPegasus	None	1-60	Kick	None	0	0	0	0	2026-01-14 13:25:19.053603+00	Off Season 2025	0
Blast	Assault	9-60	LowRush	None	0	1	0	63	2026-01-14 13:25:19.053603+00	Off Season 2025	0
Blast	Heavy	9-60	LowRush	None	0	1	0	56	2026-01-14 13:25:19.053603+00	Off Season 2025	0
Blast	Heavy	9-60	Taper	emperor	1	0	0	300	2026-01-14 13:25:19.053603+00	Off Season 2025	0
PhoenixWing	None	3-60	Level	None	0	0	0	0	2026-01-14 13:25:19.053603+00	Off Season 2025	0
Blast	Jaggy	3-60	Rush	None	0	1	0	168	2026-01-14 13:25:19.053603+00	Off Season 2025	0
PhoenixWing	None	3-60	LowFlat	None	0	1	0	91	2026-01-14 13:25:19.053603+00	Off Season 2025	0
PhoenixWing	None	3-60	Rush	None	0	1	1	183	2026-01-14 13:25:19.053603+00	Off Season 2025	0
Blast	Slash	6-60	Wedge	None	0	0	0	0	2026-01-14 13:25:19.053603+00	Off Season 2025	0
CobaltDragoon	None	1-60	Elevate	None	0	0	0	0	2026-01-14 13:25:19.053603+00	Off Season 2025	0
CobaltDragoon	None	4-60	Elevate	None	1	0	0	130	2026-01-14 13:25:19.053603+00	Off Season 2025	0
CobaltDragoon	None	5-60	Elevate	None	0	2	3	716	2026-01-14 13:25:19.053603+00	Off Season 2025	0
CobaltDragoon	None	9-60	Elevate	None	1	0	0	240	2026-01-14 13:25:19.053603+00	Off Season 2025	0
DranBuster	None	1-60	Rush	None	0	0	1	60	2026-01-14 13:25:19.053603+00	Off Season 2025	0
DranSword	None	1-60	Rush	None	0	0	1	120	2026-01-14 13:25:19.053603+00	Off Season 2025	0
HoverWyvern	None	1-60	Kick	None	0	0	1	150	2026-01-14 13:25:19.053603+00	Off Season 2025	0
HoverWyvern	None	3-60	Kick	None	0	0	2	110	2026-01-14 13:25:19.053603+00	Off Season 2025	0
HoverWyvern	None	9-60	Rush	None	0	0	0	0	2026-01-14 13:25:19.053603+00	Off Season 2025	0
KnightMail	None	1-60	Point	None	0	0	1	40	2026-01-14 13:25:19.053603+00	Off Season 2025	0
PhoenixWing	None	3-70	LowRush	None	0	1	0	84	2026-01-14 13:25:19.053603+00	Off Season 2025	0
PhoenixWing	None	7-60	Rush	None	0	0	0	0	2026-01-14 13:25:19.053603+00	Off Season 2025	0
PhoenixWing	None	None	Operate	None	0	1	0	56	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SamuraiSaber	None	7-60	Hexa	None	0	0	1	40	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkEdge	None	3-80	LowFlat	None	0	0	1	40	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkScale	None	1-60	LowRush	None	1	1	2	433	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkScale	None	1-70	LowRush	None	3	1	0	988	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkScale	None	3-60	Kick	None	0	0	1	120	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SilverWolf	None	9-60	FreeBall	None	3	2	4	1090	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SilverWolf	None	9-60	UnderNeedle	None	0	0	1	120	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SilverWolf	None	9-70	Ball	None	0	0	1	120	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SilverWolf	None	9-70	FreeBall	None	1	1	0	496	2026-01-14 13:25:19.053603+00	Off Season 2025	0
TyrannoBeat	None	1-60	Level	None	1	0	0	280	2026-01-14 13:25:19.053603+00	Off Season 2025	0
TyrannoBeat	None	1-70	Kick	None	0	0	1	60	2026-01-14 13:25:19.053603+00	Off Season 2025	0
TyrannoBeat	None	1-70	Zap	None	0	0	0	0	2026-01-14 13:25:19.053603+00	Off Season 2025	0
TyrannoBeat	None	5-60	Kick	None	1	0	0	120	2026-01-14 13:25:19.053603+00	Off Season 2025	0
TyrannoBeat	None	6-60	Kick	None	0	0	1	65	2026-01-14 13:25:19.053603+00	Off Season 2025	0
TyrannoRoar	None	3-70	Kick	None	0	0	1	60	2026-01-14 13:25:19.053603+00	Off Season 2025	0
WizardRod	None	1-60	FreeBall	None	0	0	3	360	2026-01-14 13:25:19.053603+00	Off Season 2025	0
WizardRod	None	1-60	Hexa	None	3	4	2	1365	2026-01-14 13:25:19.053603+00	Off Season 2025	0
WizardRod	None	1-60	LowOrb	None	1	0	0	130	2026-01-14 13:25:19.053603+00	Off Season 2025	0
WizardRod	None	1-60	Rush	None	0	2	0	147	2026-01-14 13:25:19.053603+00	Off Season 2025	0
Blast	Heavy	9-60	Kick	emperor	0	1	0	168	2026-01-14 13:25:19.053603+00	Off Season 2025	0
Blast	Slash	9-60	Wedge	None	1	0	0	240	2026-01-14 13:25:19.053603+00	Off Season 2025	0
DranDagger	None	4-60	Rush	None	0	0	2	105	2026-01-14 13:25:19.053603+00	Off Season 2025	0
GolemRock	None	3-60	FreeBall	None	0	0	1	150	2026-01-14 13:25:19.053603+00	Off Season 2025	0
HoverWyvern	None	9-60	Kick	None	1	1	0	164	2026-01-14 13:25:19.053603+00	Off Season 2025	0
ImpactDrake	None	4-60	Kick	None	0	0	1	140	2026-01-14 13:25:19.053603+00	Off Season 2025	0
ImpactDrake	None	4-60	Rush	None	0	1	0	210	2026-01-14 13:25:19.053603+00	Off Season 2025	0
KnightMail	None	1-60	Rush	None	1	0	3	395	2026-01-14 13:25:19.053603+00	Off Season 2025	0
KnightMail	None	9-60	Rush	None	1	0	0	280	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SamuraiSaber	None	3-60	Hexa	None	0	0	1	60	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SamuraiSaber	None	5-60	Taper	None	0	0	2	105	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkEdge	None	3-60	LowFlat	None	0	0	2	105	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkScale	None	3-60	Level	None	0	1	0	84	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkScale	None	3-60	LowRush	None	0	0	4	480	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkScale	None	4-50	LowRush	None	0	2	0	378	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkScale	None	4-50	Point	None	2	0	0	210	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkScale	None	4-50	UnderFlat	None	1	0	0	120	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkScale	None	4-50	UnderNeedle	None	0	0	0	0	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkScale	None	4-60	UnderFlat	None	0	0	1	65	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SharkScale	None	9-60	LowRush	None	0	0	1	60	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SilverWolf	None	3-60	Hexa	None	0	0	1	140	2026-01-14 13:25:19.053603+00	Off Season 2025	0
SilverWolf	None	5-60	FreeBall	None	0	0	1	150	2026-01-14 13:25:19.053603+00	Off Season 2025	0
WizardRod	None	1-70	Hexa	None	2	1	0	338	2026-01-14 13:25:19.053603+00	Off Season 2025	0
WizardRod	None	3-60	Hexa	None	1	0	0	240	2026-01-14 13:25:19.053603+00	Off Season 2025	0
WizardRod	None	5-60	Ball	None	0	0	0	0	2026-01-14 13:25:19.053603+00	Off Season 2025	0
WizardRod	None	6-60	Ball	None	0	1	0	84	2026-01-14 13:25:19.053603+00	Off Season 2025	0
WizardRod	None	7-60	Hexa	None	0	0	1	120	2026-01-14 13:25:19.053603+00	Off Season 2025	0
WizardRod	None	9-60	Ball	None	0	1	4	776	2026-01-14 13:25:19.053603+00	Off Season 2025	0
\.


--
-- Data for Name: component_alias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.component_alias (alias_norm, alias, slug, kind) FROM stdin;
aeropegasus	AeroPegasus	aero-pegasus	exact
arc	Arc	arc	exact
bearscratch	BearScratch	bear-scratch	exact
blackshell	BlackShell	black-shell	exact
blast	Blast	blast	exact
bolt	Bolt	bolt	exact
brave	Brave	brave	exact
brush	Brush	brush	exact
clockmirage	ClockMirage	clock-mirage	exact
cobaltdragoon	CobaltDragoon	cobalt-dragoon	exact
cobaltdrake	CobaltDrake	cobalt-drake	exact
crimsongaruda	CrimsonGaruda	crimson-garuda	exact
croccrunch	CrocCrunch	croc-crunch	exact
dark	Dark	dark	exact
darthvader	DarthVader	darth-vader	exact
dracielshield	DracielShield	draciel-shield	exact
dragoonstorm	DragoonStorm	dragoon-storm	exact
dranbuster	DranBuster	dran-buster	exact
drandagger	DranDagger	dran-dagger	exact
dransword	DranSword	dran-sword	exact
dranzerspiral	DranzerSpiral	dranzer-spiral	exact
drigerslash	DrigerSlash	driger-slash	exact
eclipse	Eclipse	eclipse	exact
flame	Flame	flame	exact
generalgrievous	GeneralGrievous	general-grievous	exact
ghostcircle	GhostCircle	ghost-circle	exact
gillshark	GillShark	gill-shark	exact
golemrock	GolemRock	golem-rock	exact
hellschain	HellsChain	hells-chain	exact
hellshammer	HellsHammer	hells-hammer	exact
hellsscythe	HellsScythe	hells-scythe	exact
hornet	Hornet	hornet	exact
hoverwyvern	HoverWyvern	hover-wyvern	exact
impactdrake	ImpactDrake	impact-drake	exact
knightlance	KnightLance	knight-lance	exact
knightmail	KnightMail	knight-mail	exact
knightshield	KnightShield	knight-shield-blade	exact
knightshieldblade	knight-shield-blade	knight-shield-blade	slug
kraken	Kraken	kraken	exact
leonclaw	LeonClaw	leon-claw	exact
leoncrest	LeonCrest	leon-crest	exact
lightningldrago	LightningL-Drago	lightningl-drago	exact
mammothtusk	MammothTusk	mammoth-tusk	exact
might	Might	might	exact
moffgideon	MoffGideon	moff-gideon	exact
mosasaurus	Mosasaurus	mosasaurus	exact
optimusprimal	OptimusPrimal	optimus-primal	exact
optimusprime	OptimusPrime	optimus-prime	exact
phoenixfeather	PhoenixFeather	phoenix-feather	exact
phoenixrudder	PhoenixRudder	phoenix-rudder	exact
phoenixwing	PhoenixWing	phoenix-wing	exact
pteraswing	PteraSwing	ptera-swing	exact
reaper	Reaper	reaper	exact
rhinohorn	RhinoHorn	rhino-horn	exact
rockleone	RockLeone	rock-leone	exact
samuraicalibur	SamuraiCalibur	samurai-calibur	exact
samuraisaber	SamuraiSaber	samurai-saber	exact
samuraisteel	SamuraiSteel	samurai-steel	exact
scorpiospear	ScorpioSpear	scorpio-spear	exact
sharkedge	SharkEdge	shark-edge	exact
sharkscale	SharkScale	shark-scale	exact
shelterdrake	ShelterDrake	shelter-drake	exact
shinobiknife	ShinobiKnife	shinobi-knife	exact
shinobishadow	ShinobiShadow	shinobi-shadow	exact
silverwolf	SilverWolf	silver-wolf	exact
sphinxcowl	SphinxCowl	sphinx-cowl	exact
spiderman	Spider-Man	spider-man	exact
spinosaurus	Spinosaurus	spinosaurus	exact
stormpegasus	StormPegasus	storm-pegasus	exact
tacklegoat	TackleGoat	tackle-goat	exact
thanos	Thanos	thanos	exact
tricerapress	TriceraPress	tricera-press	exact
tyrannobeat	TyrannoBeat	tyranno-beat	exact
tyrannoroar	TyrannoRoar	tyranno-roar	exact
unicornsting	UnicornSting	unicorn-sting	exact
venom	Venom	venom	exact
victoryvalkyrie	VictoryValkyrie	victory-valkyrie	exact
vipertail	ViperTail	viper-tail	exact
weisstiger	WeissTiger	weiss-tiger	exact
whalewave	WhaleWave	whale-wave	exact
wizardarrow	WizardArrow	wizard-arrow	exact
wizardrod	WizardRod	wizard-rod	exact
wyverngale	WyvernGale	wyvern-gale	exact
xenoxcalibur	XenoXcalibur	xeno-xcalibur	exact
yellkong	YellKong	yell-kong	exact
assault	Assault	assault	exact
bumper	Bumper	bumper	exact
charge	Charge	charge	exact
dual	Dual	dual	exact
heavy	Heavy	heavy	exact
jaggy	Jaggy	jaggy	exact
massive	Massive	massive	exact
round	Round	round	exact
slash	Slash	slash	exact
turn	Turn	turn	exact
wheel	Wheel	wheel	exact
060	0-60	0-60	exact
070	0-70	0-70	exact
080	0-80	0-80	exact
160	1-60	1-60	exact
170	1-70	1-70	exact
180	1-80	1-80	exact
260	2-60	2-60	exact
270	2-70	2-70	exact
360	3-60	3-60	exact
370	3-70	3-70	exact
380	3-80	3-80	exact
450	4-50	4-50	exact
455	4-55	4-55	exact
460	4-60	4-60	exact
470	4-70	4-70	exact
480	4-80	4-80	exact
560	5-60	5-60	exact
570	5-70	5-70	exact
580	5-80	5-80	exact
660	6-60	6-60	exact
670	6-70	6-70	exact
680	6-80	6-80	exact
760	7-60	7-60	exact
770	7-70	7-70	exact
780	7-80	7-80	exact
960	9-60	9-60	exact
965	9-65	9-65	exact
970	9-70	9-70	exact
980	9-80	9-80	exact
m85	M-85	m-85	exact
accel	Accel	accel	exact
ball	Ball	ball	exact
boundspike	BoundSpike	bound-spike	exact
cyclone	Cyclone	cyclone	exact
diskball	DiskBall	disk-ball	exact
dot	Dot	dot	exact
elevate	Elevate	elevate	exact
flat	Flat	flat	exact
freeball	FreeBall	free-ball	exact
gearball	GearBall	gear-ball	exact
gearflat	GearFlat	gear-flat	exact
gearneedle	GearNeedle	gear-needle	exact
gearpoint	GearPoint	gear-point	exact
gearrush	GearRush	gear-rush	exact
glide	Glide	glide	exact
hexa	Hexa	hexa	exact
highneedle	HighNeedle	high-needle	exact
hightaper	HighTaper	high-taper	exact
kick	Kick	kick	exact
level	Level	level	exact
lowflat	LowFlat	low-flat	exact
loworb	LowOrb	low-orb	exact
lowrush	LowRush	low-rush	exact
merge	Merge	merge	exact
metalneedle	MetalNeedle	metal-needle	exact
needle	Needle	needle	exact
operate	Operate	operate	exact
orb	Orb	orb	exact
point	Point	point	exact
quake	Quake	quake	exact
rubberaccel	RubberAccel	rubber-accel	exact
rush	Rush	rush	exact
spike	Spike	spike	exact
taper	Taper	taper	exact
transpoint	TransPoint	trans-point	exact
turbo	Turbo	turbo	exact
underflat	UnderFlat	under-flat	exact
underneedle	UnderNeedle	under-needle	exact
unite	Unite	unite	exact
vortex	Vortex	vortex	exact
wedge	Wedge	wedge	exact
zap	Zap	zap	exact
emperor	emperor	emperor	exact
valkyrie	valkyrie	valkyrie	exact
e	E	elevate	abbrev
fb	FB	free-ball	abbrev
h	H	hexa	abbrev
k	K	kick	abbrev
lr	LR	low-rush	abbrev
r	R	rush	abbrev
phoenixsoaryoungtoys	PhoenixSoar (Youngtoys)	phoenix-wing	localized
soarphoenix	Soar Phoenix	phoenix-wing	localized
scaleshark	Scale Shark	shark-scale	localized
sterlingwolf	Sterling Wolf	silver-wolf	localized
wandwizard	Wand Wizard	wizard-rod	localized
a	A	accel	abbrev
bs	BS	bound-spike	abbrev
c	C	cyclone	abbrev
d	D	dot	abbrev
gr	GR	gear-rush	abbrev
g	G	glide	abbrev
l	L	level	abbrev
lf	LF	low-flat	abbrev
m	M	merge	abbrev
o	O	orb	abbrev
p	P	point	abbrev
q	Q	quake	abbrev
ra	RA	rubber-accel	abbrev
s	S	spike	abbrev
uf	UF	under-flat	abbrev
un	UN	under-needle	abbrev
u	U	unite	abbrev
v	V	vortex	abbrev
w	W	wedge	abbrev
z	Z	zap	abbrev
obsidianshell	Obsidian Shell	black-shell	localized
mirageclock	Mirage Clock	clock-mirage	localized
scarletgaruda	Scarlet Garuda	crimson-garuda	localized
busterdran	Buster Dran	dran-buster	localized
daggerdran	Dagger Dran	dran-dagger	localized
sworddran	Sword Dran	dran-sword	localized
circleghost	Circle Ghost	ghost-circle	localized
sharktorsotakaratomydevelopmentname	SharkTorso (Takara Tomy Development Name)	gill-shark	localized
rockgolem	Rock Golem	golem-rock	localized
chainincendio	Chain Incendio	hells-chain	localized
scytheincendio	Scythe Incendio	hells-scythe	localized
wyvernhover	WyvernHover	hover-wyvern	localized
mailknight	Mail Knight	knight-mail	localized
helmknight	Helm Knight	knight-shield-blade	localized
crestleon	Crest Leon	leon-crest	localized
featherphoenix	Feather Phoenix	phoenix-feather	localized
rudderphoenix	Rudder Phoenix	phoenix-rudder	localized
pterastroketakaratomydevelopmentname	PteraStroke (Takara Tomy Development Name)	ptera-swing	localized
calibursamurai	Calibur Samurai	samurai-calibur	localized
sabersamurai	Saber Samurai	samurai-saber	localized
spearscorpio	Spear Scorpio	scorpio-spear	localized
keelshark	Keel Shark	shark-edge	localized
cowlsphinx	Cowl Sphinx	sphinx-cowl	localized
goattackle	GoatTackle	tackle-goat	localized
bracetriceratops	Brace Triceratops	tricera-press	localized
stingunicorn	Sting Unicorn	unicorn-sting	localized
pearltiger	Pearl Tiger	weiss-tiger	localized
tidewhale	Tide Whale	whale-wave	localized
bxorg07takaratomydevelopmentcode	BX-ORG07 (Takara Tomy Development Code)	yell-kong	localized
valkerion	Valkerion	valkyrie	localized
b	B	ball	abbrev
db	DB	disk-ball	abbrev
f	F	flat	abbrev
gb	GB	gear-ball	abbrev
gf	GF	gear-flat	abbrev
gn	GN	gear-needle	abbrev
gp	GP	gear-point	abbrev
hn	HN	high-needle	abbrev
ht	HT	high-taper	abbrev
lo	LO	low-orb	abbrev
mn	MN	metal-needle	abbrev
n	N	needle	abbrev
t	T	taper	abbrev
tp	TP	trans-point	abbrev
courage	Courage	brave	localized
crococrunch	CrocoCrunch	croc-crunch	localized
g2747	G2747	flame	localized
bx00	BX-00	general-grievous	localized
clawleon	Claw Leon	leon-claw	localized
g3028	G3028	might	localized
ridgetriceratops	Ridge Triceratops	mosasaurus	localized
mosasaurusjurassicworldver	Mosasaurus (Jurassic World Ver.)	mosasaurus	localized
hornrhino	Horn Rhino	rhino-horn	localized
beattyranno	Beat Tyranno	tyranno-beat	localized
tailviper	Tail Viper	viper-tail	localized
arrowwizard	Arrow Wizard	wizard-arrow	localized
galewyvern	Gale Wyvern	wyvern-gale	localized
op	Op	operate	abbrev
tr	Tr	turbo	abbrev
quetzalcoatlus	Quetzalcoatlus	ptera-swing	localized
trex	T.Rex	tyranno-beat	localized
\.


--
-- Data for Name: component_registry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.component_registry (slug, canonical_name, slot, system, attributes, created_at, updated_at) FROM stdin;
assault	Assault	assist_blade	CX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 25, "defense": 10, "stamina": 5}, "weight_g": 5.0, "wiki_page": "Assist Blade - Assault", "release_jp": "July 19th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/assault-assist-blade/", "product_code": "CX-07 (Takara Tomy) / G2350 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
yell-kong	YellKong	blade	BX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 13, "defense": 37, "stamina": 50}, "weight_g": 31.1, "wiki_page": "Blade - Yell Kong", "x_standard": true, "product_code": "G0198 (Hasbro) / BX-ORG07 (Takara Tomy Development Code)"}	2026-08-21 19:14:14.356763+00	2026-08-24 10:55:34.522721+00
bumper	Bumper	assist_blade	CX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 10, "defense": 20, "stamina": 10}, "weight_g": 5.3, "wiki_page": "Assist Blade - Bumper", "release_jp": "March 29th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/bumper-assist-blade/", "product_code": "CX-03 (Takara Tomy) / G1680 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
bolt	Bolt	blade	\N	{}	2026-08-21 19:14:14.356763+00	2026-08-21 19:14:14.356763+00
flat	Flat	bit	BX	{"type": "Attack", "stats": {"attack": 40, "defense": 15, "stamina": 10}, "weight_g": 2.2, "wiki_page": "Bit - Flat", "release_jp": "June 10th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/flat-bit/", "product_code": "BX-01 (Takara Tomy) / F9580 (Hasbro)", "stats_official": {"dash": "35", "attack": "40", "defense": "15", "stamina": "10", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
gear-ball	GearBall	bit	BX	{"type": "Stamina", "stats": {"attack": 10, "defense": 15, "stamina": 45}, "weight_g": 2.0, "wiki_page": "Bit - Gear Ball", "release_jp": "December 27th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/gear-ball-bit/", "product_code": "BX-24 (Takara Tomy) / G0198 (Hasbro)", "stats_official": {"dash": "30", "attack": "10", "defense": "15", "stamina": "45", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
gear-flat	GearFlat	bit	BX	{"type": "Attack", "stats": {"attack": 50, "defense": 5, "stamina": 5}, "weight_g": 2.3, "wiki_page": "Bit - Gear Flat", "release_jp": "December 10th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/gear-flat-bit/", "product_code": "BX-23 (Takara Tomy) / F9324 (Hasbro)", "stats_official": {"dash": "40", "attack": "50", "defense": "5", "stamina": "5", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
general-grievous	GeneralGrievous	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 22, "defense": 50, "stamina": 28}, "weight_g": 31.0, "wiki_page": "Blade - General Grievous", "x_standard": true, "product_code": "G1694 (Hasbro) / BX-00 (Takara Tomy)"}	2026-08-21 19:14:14.356763+00	2026-08-24 10:55:34.522721+00
gear-needle	GearNeedle	bit	BX	{"type": "Defense", "stats": {"attack": 20, "defense": 40, "stamina": 10}, "weight_g": 2.0, "wiki_page": "Bit - Gear Needle", "release_jp": "February 22nd, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/gear-needle-bit/", "product_code": "BX-27 (Takara Tomy) / G1530 (Hasbro)", "stats_official": {"dash": "30", "attack": "20", "defense": "40", "stamina": "10", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
glide	Glide	bit	UX	{"type": "Stamina", "stats": {"attack": 20, "defense": 10, "stamina": 55}, "weight_g": 2.5, "wiki_page": "Bit - Glide", "release_jp": "August 10th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/glide-bit/", "product_code": "UX-07 (Takara Tomy) / G3393 (Hasbro)", "stats_official": {"dash": "15", "attack": "20", "defense": "10", "stamina": "55", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
hexa	Hexa	bit	UX	{"type": "Balance", "stats": {"attack": 30, "defense": 35, "stamina": 20}, "weight_g": 2.6, "wiki_page": "Bit - Hexa", "release_jp": "March 30th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/hexa-bit/", "product_code": "UX-02 (Takara Tomy) / G1752 (Hasbro)", "stats_official": {"dash": "15", "attack": "30", "defense": "35", "stamina": "20", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
high-needle	HighNeedle	bit	BX	{"type": "Defense", "stats": {"attack": 15, "defense": 55, "stamina": 20}, "weight_g": 2.2, "wiki_page": "Bit - High Needle", "release_jp": "August 10th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/high-needle-bit/", "product_code": "BX-13 (Takara Tomy) / G0190 (Hasbro)", "stats_official": {"dash": "10", "attack": "15", "defense": "55", "stamina": "20", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
might	Might	blade	CX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 25, "defense": 25, "stamina": 25}, "weight_g": 33.1, "wiki_page": "Main Blade - Might", "release_jp": "November 1st, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/might-main-blade/", "product_code": "CX-11 (Takara Tomy) / G3028 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-24 10:55:34.522721+00
hornet	Hornet	blade	\N	{}	2026-08-21 19:14:14.356763+00	2026-08-21 19:14:14.356763+00
kraken	Kraken	blade	\N	{}	2026-08-21 19:14:14.356763+00	2026-08-21 19:14:14.356763+00
lightningl-drago	LightningL-Drago	blade	\N	{}	2026-08-21 19:14:14.356763+00	2026-08-21 19:14:14.356763+00
storm-pegasus	StormPegasus	blade	\N	{}	2026-08-21 19:14:14.356763+00	2026-08-21 19:14:14.356763+00
heavy	Heavy	assist_blade	CX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 17, "defense": 17, "stamina": 11}, "weight_g": 7.8, "wiki_page": "Assist Blade - Heavy", "release_jp": "November 1st, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/heavy-assist-blade/", "product_code": "CX-11 (Takara Tomy) / G3028 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
jaggy	Jaggy	assist_blade	CX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 20, "defense": 15, "stamina": 5}, "weight_g": 4.9, "wiki_page": "Assist Blade - Jaggy", "release_jp": "May 17th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/jaggy-assist-blade/", "product_code": "CX-06 (Takara Tomy) / G1681 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
accel	Accel	bit	UX	{"type": "Attack", "stats": {"attack": 40, "defense": 10, "stamina": 10}, "weight_g": 2.6, "wiki_page": "Bit - Accel", "release_jp": "March 30th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/accel-bit/", "product_code": "UX-01 (Takara Tomy) / G1536 (Hasbro)", "stats_official": {"dash": "40", "attack": "40", "defense": "10", "stamina": "10", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
ball	Ball	bit	BX	{"type": "Stamina", "stats": {"attack": 15, "defense": 25, "stamina": 50}, "weight_g": 2.1, "wiki_page": "Bit - Ball", "release_jp": "July 15th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/ball-bit/", "product_code": "BX-03 (Takara Tomy) / F9582 (Hasbro)", "stats_official": {"dash": "10", "attack": "15", "defense": "25", "stamina": "50", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
bound-spike	BoundSpike	bit	UX	{"type": "Defense", "stats": {"attack": 5, "defense": 60, "stamina": 30}, "weight_g": 2.0, "wiki_page": "Bit - Bound Spike", "release_jp": "November 2nd, 2024", "x_standard": true, "product_code": "UX-10 (Takara Tomy) / G3195 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
cyclone	Cyclone	bit	BX	{"type": "Attack", "stats": {"attack": 40, "defense": 5, "stamina": 10}, "weight_g": 2.1, "wiki_page": "Bit - Cyclone", "release_jp": "July 13th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/cyclone-bit/", "product_code": "BX-34 (Takara Tomy) / G1491 (Hasbro)", "stats_official": {"dash": "45", "attack": "40", "defense": "5", "stamina": "10", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
disk-ball	DiskBall	bit	UX	{"type": "Stamina", "stats": {"attack": 15, "defense": 20, "stamina": 55}, "weight_g": 3.2, "wiki_page": "Bit - Disk Ball", "release_jp": "March 30th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/disk-ball-bit/", "product_code": "UX-03 (Takara Tomy) / G1537 (Hasbro)", "stats_official": {"dash": "10", "attack": "15", "defense": "20", "stamina": "55", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
dot	Dot	bit	BX	{"type": "Defense", "weight_g": 2.0, "wiki_page": "Bit - Dot", "release_jp": "July 13th, 2024", "x_standard": false, "beybladewiki": "https://beyblade.wiki/dot-bit/", "product_code": "BX-35 (Takara Tomy) / G1533 (Hasbro)", "stats_official": {"dash": "10", "attack": "10", "defense": "55", "stamina": "25", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
slash	Slash	assist_blade	CX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 20, "defense": 10, "stamina": 10}, "weight_g": 4.7, "wiki_page": "Assist Blade - Slash", "release_jp": "March 29th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/slash-assist-blade/", "product_code": "CX-01 (Takara Tomy) / G1677 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
elevate	Elevate	bit	BX	{"type": "Balance", "stats": {"attack": 30, "defense": 15, "stamina": 20}, "weight_g": 3.2, "wiki_page": "Bit - Elevate", "release_jp": "September 14th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/elevate-bit/", "product_code": "BX-36 (Takara Tomy) / G1669 (Hasbro)", "stats_official": {"dash": "35", "attack": "30", "defense": "15", "stamina": "20", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
free-ball	FreeBall	bit	UX	{"type": "Stamina", "stats": {"attack": 10, "defense": 25, "stamina": 60}, "weight_g": 1.9, "wiki_page": "Bit - Free Ball", "release_jp": "October 12th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/free-ball-bit/", "product_code": "UX-08 (Takara Tomy) / G1674 (Hasbro)", "stats_official": {"dash": "5", "attack": "10", "defense": "25", "stamina": "60", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
gear-point	GearPoint	bit	BX	{"type": "Balance", "stats": {"attack": 30, "defense": 25, "stamina": 15}, "weight_g": 2.3, "wiki_page": "Bit - Gear Point", "release_jp": "January 27th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/gear-point-bit/", "product_code": "BX-26 (Takara Tomy) / G0283 (Hasbro)", "stats_official": {"dash": "30", "attack": "30", "defense": "25", "stamina": "15", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
gear-rush	GearRush	bit	CX	{"type": "Attack", "stats": {"attack": 45, "defense": 10, "stamina": 10}, "weight_g": 2.1, "wiki_page": "Bit - Gear Rush", "release_jp": "May 17th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/gear-rush-bit/", "product_code": "CX-06 (Takara Tomy) / G1681 (Hasbro)", "stats_official": {"dash": "35", "attack": "45", "defense": "10", "stamina": "10", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
rubber-accel	RubberAccel	bit	UX	{"type": "Attack", "weight_g": 3.1, "wiki_page": "Bit - Rubber Accel", "release_jp": "November 2nd, 2024", "x_standard": false, "product_code": "UX-10 (Takara Tomy) / G1844 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
charge	Charge	assist_blade	CX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 15, "defense": 20, "stamina": 5}, "weight_g": 5.0, "wiki_page": "Assist Blade - Charge", "release_jp": "April 26th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/charge-assist-blade/", "product_code": "CX-05 (Takara Tomy) / G2746 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
dual	Dual	assist_blade	CX	{"spin": "Right-Spin", "type": "Balance", "weight_g": 5.9, "wiki_page": "Assist Blade - Dual", "release_jp": "September 27th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/dual-assist-blade/", "product_code": "CX-09"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
massive	Massive	assist_blade	CX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 15, "defense": 15, "stamina": 10}, "weight_g": 5.3, "wiki_page": "Assist Blade - Massive", "release_jp": "July 19th, 2025", "x_standard": true, "product_code": "CX-08"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
round	Round	assist_blade	CX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 10, "defense": 10, "stamina": 20}, "weight_g": 4.7, "wiki_page": "Assist Blade - Round", "release_jp": "March 29th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/round-assist-blade/", "product_code": "CX-02 (Takara Tomy) / G1679 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
turn	Turn	assist_blade	CX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 10, "defense": 10, "stamina": 20}, "weight_g": 5.8, "wiki_page": "Assist Blade - Turn", "release_jp": "April 26th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/turn-assist-blade/", "product_code": "CX-05 (Takara Tomy) / G1678 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
wheel	Wheel	assist_blade	CX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 5, "defense": 15, "stamina": 20}, "weight_g": 7.2, "wiki_page": "Assist Blade - Wheel", "release_jp": "July 19th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/wheel-assist-blade/", "product_code": "CX-08 (Takara Tomy) / G2747 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
high-taper	HighTaper	bit	BX	{"type": "Balance", "stats": {"attack": 30, "defense": 25, "stamina": 20}, "weight_g": 2.2, "wiki_page": "Bit - High Taper", "release_jp": "November 2nd, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/high-taper-bit/", "product_code": "BX-21 (Takara Tomy) / G0196 (Hasbro)", "stats_official": {"dash": "25", "attack": "30", "defense": "25", "stamina": "20", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
kick	Kick	bit	CX	{"type": "Balance", "stats": {"attack": 35, "defense": 25, "stamina": 15}, "weight_g": 2.2, "wiki_page": "Bit - Kick", "release_jp": "April 26th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/kick-bit/", "product_code": "CX-05 (Takara Tomy) / G1678 (Hasbro)", "stats_official": {"dash": "25", "attack": "35", "defense": "25", "stamina": "15", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
5-80	5-80	ratchet	BX	{"stats": {"attack": 12, "defense": 8, "stamina": 10}, "weight_g": 7.3, "wiki_page": "Ratchet - 5-80", "release_jp": "October 7th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/5-80-ratchet/", "product_code": "BX-16 (Takara Tomy) / G0197 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
dran-sword	DranSword	blade	BX	{"spin": "Right-Spin", "type": "Attack", "weight_g": 34.6, "wiki_page": "Blade - DranSword", "release_jp": "June 10th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/dran-sword-blade/", "product_code": "BX-01 (Takara Tomy) / F9580 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
level	Level	bit	UX	{"type": "Attack", "stats": {"attack": 40, "defense": 5, "stamina": 15}, "weight_g": 2.7, "wiki_page": "Bit - Level", "release_jp": "November 2nd, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/level-bit/", "product_code": "UX-09 (Takara Tomy) / G1862 (Hasbro)", "stats_official": {"dash": "40", "attack": "40", "defense": "5", "stamina": "15", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
low-flat	LowFlat	bit	BX	{"type": "Attack", "stats": {"attack": 45, "defense": 5, "stamina": 10}, "weight_g": 2.1, "wiki_page": "Bit - Low Flat", "release_jp": "September 9th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/low-flat-bit/", "product_code": "BX-14 (Takara Tomy) / G0194 (Hasbro)", "stats_official": {"dash": "40", "attack": "45", "defense": "5", "stamina": "10", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
low-orb	LowOrb	bit	CX	{"type": "Stamina", "stats": {"attack": 5, "defense": 25, "stamina": 55}, "weight_g": 1.9, "wiki_page": "Bit - Low Orb", "release_jp": "March 29th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/low-orb-bit/", "product_code": "CX-02 (Takara Tomy) / G1679 (Hasbro)", "stats_official": {"dash": "15", "attack": "5", "defense": "25", "stamina": "55", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
low-rush	LowRush	bit	UX	{"type": "Attack", "stats": {"attack": 45, "defense": 5, "stamina": 15}, "weight_g": 1.9, "wiki_page": "Bit - Low Rush", "release_jp": "December 28th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/low-rush-bit/", "product_code": "UX-11 (Takara Tomy) / G0842 (Hasbro)", "stats_official": {"dash": "35", "attack": "45", "defense": "5", "stamina": "15", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
merge	Merge	bit	BX	{"type": "Balance", "stats": {"attack": 50, "defense": 20, "stamina": 10}, "weight_g": 3.4, "wiki_page": "Bit - Merge", "release_jp": "August 9th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/merge-bit/", "product_code": "BX-45 (Takara Tomy) / G2754 (Hasbro)", "stats_official": {"dash": "10", "attack": "50", "defense": "20", "stamina": "10", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
metal-needle	MetalNeedle	bit	UX	{"type": "Defense", "stats": {"attack": 8, "defense": 57, "stamina": 30}, "weight_g": 2.8, "wiki_page": "Bit - Metal Needle", "release_jp": "May 18th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/metal-needle-bit/", "product_code": "UX-05 (Takara Tomy) / G1539 (Hasbro)", "stats_official": {"dash": "5", "attack": "8", "defense": "57", "stamina": "30", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
needle	Needle	bit	BX	{"type": "Defense", "stats": {"attack": 10, "defense": 50, "stamina": 30}, "weight_g": 2.0, "wiki_page": "Bit - Needle", "release_jp": "July 15th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/needle-bit/", "product_code": "BX-04 (Takara Tomy) / F9581 (Hasbro)", "stats_official": {"dash": "10", "attack": "10", "defense": "50", "stamina": "30", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
operate	Operate	bit	\N	{"beybladewiki": "https://beyblade.wiki/operate-bit/", "stats_official": {"dash": "10/35", "attack": "20/50", "defense": "50/35", "stamina": "50/10", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
bear-scratch	BearScratch	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 25, "defense": 45, "stamina": 30}, "weight_g": 29.6, "wiki_page": "Blade - Savage Bear", "release_jp": "October 12th, 2024", "x_standard": true, "product_code": "G0286 (Hasbro) / BX-37 (Takara Tomy) / BX-ORG04 (Takara Tomy Development Code)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
orb	Orb	bit	BX	{"type": "Stamina", "stats": {"attack": 10, "defense": 30, "stamina": 50}, "weight_g": 2.0, "wiki_page": "Bit - Orb", "release_jp": "October 7th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/orb-bit/", "product_code": "BX-16 (Takara Tomy) / G0197 (Hasbro)", "stats_official": {"dash": "10", "attack": "10", "defense": "30", "stamina": "50", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
point	Point	bit	BX	{"type": "Balance", "stats": {"attack": 25, "defense": 25, "stamina": 25}, "weight_g": 2.2, "wiki_page": "Bit - Point", "release_jp": "October 7th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/point-bit/", "product_code": "BX-15 (Takara Tomy) / G0353 (Hasbro)", "stats_official": {"dash": "25", "attack": "25", "defense": "25", "stamina": "25", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
quake	Quake	bit	BX	{"type": "Attack", "stats": {"attack": 55, "defense": 15, "stamina": 5}, "weight_g": 2.2, "wiki_page": "Bit - Quake", "release_jp": "April 27th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/quake-bit/", "product_code": "BX-31 (Takara Tomy) / G1542 (Hasbro)", "stats_official": {"dash": "25", "attack": "55", "defense": "15", "stamina": "5", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
rush	Rush	bit	BX	{"type": "Attack", "stats": {"attack": 40, "defense": 10, "stamina": 20}, "weight_g": 2.1, "wiki_page": "Bit - Rush", "release_jp": "November 2nd, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/rush-bit/", "product_code": "BX-20 (Takara Tomy) / F9588 (Hasbro)", "stats_official": {"dash": "30", "attack": "40", "defense": "10", "stamina": "20", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
spike	Spike	bit	BX	{"type": "Defense", "weight_g": 2.0, "wiki_page": "Bit - Spike", "release_jp": "November 2nd, 2023", "x_standard": false, "beybladewiki": "https://beyblade.wiki/spike-bit/", "product_code": "BX-19 (Takara Tomy) / G0192 (Hasbro)", "stats_official": {"dash": "10", "attack": "10", "defense": "45", "stamina": "35", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
taper	Taper	bit	BX	{"type": "Balance", "stats": {"attack": 35, "defense": 20, "stamina": 20}, "weight_g": 2.2, "wiki_page": "Bit - Taper", "release_jp": "June 10th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/taper-bit/", "product_code": "BX-02 (Takara Tomy) / F9583 (Hasbro)", "stats_official": {"dash": "25", "attack": "35", "defense": "20", "stamina": "20", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
trans-point	TransPoint	bit	BX	{"type": "Balance", "stats": {"attack": 35, "defense": 25, "stamina": 25}, "weight_g": 2.2, "wiki_page": "Bit - Trans Point", "release_jp": "November 2nd, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/trans-point-bit/", "product_code": "BX-38 (Takara Tomy) / G1673 (Hasbro)", "stats_official": {"dash": "15", "attack": "35", "defense": "25", "stamina": "25", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
turbo	Turbo	bit	\N	{"beybladewiki": "https://beyblade.wiki/turbo-bit/", "stats_official": {"dash": "10/45", "attack": "30/55", "defense": "30/20", "stamina": "60/10", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
under-flat	UnderFlat	bit	UX	{"type": "Attack", "stats": {"attack": 55, "defense": 5, "stamina": 5}, "weight_g": 2.0, "wiki_page": "Bit - Under Flat", "release_jp": "August 9th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/under-flat-bit/", "product_code": "UX-15 (Takara Tomy) / G2731 (Hasbro)", "stats_official": {"dash": "35", "attack": "55", "defense": "5", "stamina": "5", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
under-needle	UnderNeedle	bit	UX	{"type": "Defense", "stats": {"attack": 10, "defense": 60, "stamina": 20}, "weight_g": 1.9, "wiki_page": "Bit - Under Needle", "release_jp": "January 25th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/under-needle-bit/", "product_code": "UX-13 (Takara Tomy) / G1646 (Hasbro)", "stats_official": {"dash": "10", "attack": "10", "defense": "60", "stamina": "20", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
darth-vader	DarthVader	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 28, "defense": 60, "stamina": 12}, "weight_g": 30.7, "wiki_page": "Blade - Darth Vader", "release_jp": "April 26th, 2025", "x_standard": true, "product_code": "G0290 (Hasbro) / BX-00 (Takara Tomy)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
draciel-shield	DracielShield	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 30, "defense": 50, "stamina": 20}, "weight_g": 28.0, "wiki_page": "Blade - DracielShield", "release_jp": "December 28th, 2024", "x_standard": true, "product_code": "BX-00 (Takara Tomy) / G2218 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
dragoon-storm	DragoonStorm	blade	BX	{"spin": "Left-Spin", "type": "Attack", "stats": {"attack": 55, "defense": 30, "stamina": 15}, "weight_g": 25.1, "wiki_page": "Blade - DragoonStorm", "release_jp": "March 21st, 2025", "x_standard": true, "product_code": "BX-00 (Takara Tomy) / G1844 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
unite	Unite	bit	BX	{"type": "Balance", "stats": {"attack": 25, "defense": 25, "stamina": 30}, "weight_g": 2.1, "wiki_page": "Bit - Unite", "release_jp": "June 15th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/unite-bit/", "product_code": "BX-33 (Takara Tomy) / G1686 (Hasbro)", "stats_official": {"dash": "20", "attack": "25", "defense": "25", "stamina": "30", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
wizard-arrow	WizardArrow	blade	BX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 15, "defense": 30, "stamina": 55}, "weight_g": 31.8, "wiki_page": "Blade - WizardArrow", "release_jp": "July 15th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/wizard-arrow-blade/", "product_code": "BX-03 (Takara Tomy) / F9582 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
driger-slash	DrigerSlash	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 40, "defense": 35, "stamina": 25}, "weight_g": 28.6, "wiki_page": "Blade - DrigerSlash", "release_jp": "April 27th, 2024", "x_standard": true, "product_code": "BX-00 (Takara Tomy) / G1843 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
vortex	Vortex	bit	CX	{"type": "Attack", "stats": {"attack": 45, "defense": 10, "stamina": 5}, "weight_g": 2.2, "wiki_page": "Bit - Vortex", "release_jp": "March 29th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/vortex-bit/", "product_code": "CX-01 (Takara Tomy) / G1677 (Hasbro)", "stats_official": {"dash": "40", "attack": "45", "defense": "10", "stamina": "5", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
gill-shark	GillShark	blade	BX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 20, "defense": 25, "stamina": 55}, "weight_g": 29.6, "wiki_page": "Blade - Gill Shark", "release_jp": "November 2025", "x_standard": true, "product_code": "G1686 (Hasbro) / CX-11 (Takara Tomy)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
wedge	Wedge	bit	CX	{"type": "Defense", "stats": {"attack": 5, "defense": 55, "stamina": 30}, "weight_g": 1.8, "wiki_page": "Bit - Wedge", "release_jp": "March 29th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/wedge-bit/", "product_code": "CX-03 (Takara Tomy) / G1680 (Hasbro)", "stats_official": {"dash": "10", "attack": "5", "defense": "55", "stamina": "30", "burst_resistance": "30"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
zap	Zap	bit	UX	{"type": "Balance", "stats": {"attack": 30, "defense": 20, "stamina": 15}, "weight_g": 2.5, "wiki_page": "Bit - Zap", "release_jp": "April 26th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/zap-bit/", "product_code": "UX-14 (Takara Tomy) / G2758 (Hasbro)", "stats_official": {"dash": "35", "attack": "30", "defense": "20", "stamina": "15", "burst_resistance": "80"}}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
aero-pegasus	AeroPegasus	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 60, "defense": 25, "stamina": 30}, "weight_g": 38.2, "wiki_page": "Blade - AeroPegasus", "release_jp": "July 30th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/aero-pegasus-blade/", "product_code": "UX-00"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
arc	Arc	blade	CX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 10, "defense": 10, "stamina": 40}, "weight_g": 29.2, "wiki_page": "Main Blade - Arc", "release_jp": "March 29th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/arc-main-blade/", "product_code": "CX-02 (Takara Tomy) / G1679 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
hover-wyvern	HoverWyvern	blade	UX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 13, "defense": 60, "stamina": 27}, "weight_g": 35.1, "wiki_page": "Blade - Hover Wyvern", "release_jp": "October 24th, 2025", "x_standard": true, "product_code": "UX-00 (Takara Tomy) / G0842 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
black-shell	BlackShell	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 10, "defense": 65, "stamina": 25}, "weight_g": 32.4, "wiki_page": "Blade - BlackShell", "release_jp": "July 13th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/black-shell-blade/", "product_code": "BX-35 (Takara Tomy) / G1533 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
blast	Blast	blade	CX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 50, "defense": 10, "stamina": 15}, "weight_g": 32.8, "wiki_page": "Main Blade - Blast", "release_jp": "July 19th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/blast-main-blade/", "product_code": "CX-07 (Takara Tomy) / G2350 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
brave	Brave	blade	CX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 40, "defense": 10, "stamina": 10}, "weight_g": 31.2, "wiki_page": "Main Blade - Brave", "release_jp": "March 29th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/brave-main-blade/", "product_code": "CX-01 (Takara Tomy) / G1677 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
brush	Brush	blade	CX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 40, "defense": 15, "stamina": 5}, "weight_g": 30.3, "wiki_page": "Main Blade - Brush", "release_jp": "May 17th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/brush-main-blade/", "product_code": "CX-06 (Takara Tomy) / G1681 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
clock-mirage	ClockMirage	blade	UX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 10, "defense": 10, "stamina": 80}, "weight_g": 37.7, "wiki_page": "Blade - ClockMirage", "release_jp": "October 11th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/clock-mirage-blade/", "product_code": "UX-16 (Takara Tomy) / G2737 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
cobalt-dragoon	CobaltDragoon	blade	BX	{"spin": "Left-Spin", "type": "Attack", "stats": {"attack": 60, "defense": 15, "stamina": 25}, "weight_g": 37.8, "wiki_page": "Blade - CobaltDragoon", "release_jp": "July 13th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/cobalt-dragoon-blade/", "product_code": "BX-34 (Takara Tomy) / G1491 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
cobalt-drake	CobaltDrake	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 65, "defense": 30, "stamina": 20}, "weight_g": 38.0, "wiki_page": "Blade - CobaltDrake", "release_jp": "September 14th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/cobalt-drake-blade/", "product_code": "BX-00 (Takara Tomy) / G2736 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
moff-gideon	MoffGideon	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 32, "defense": 35, "stamina": 33}, "weight_g": 30.5, "wiki_page": "Blade - Moff Gideon", "release_jp": "April 26th, 2025", "x_standard": true, "product_code": "F9589 (Hasbro) / BX-00 (Takara Tomy)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
mosasaurus	Mosasaurus	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 32, "defense": 55, "stamina": 13}, "weight_g": 29.9, "wiki_page": "Blade - TriceraSpiky", "release_jp": "July 19th, 2025", "x_standard": true, "product_code": "G1898 (Hasbro) / BX-00 (Takara Tomy)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
optimus-primal	OptimusPrimal	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 60, "defense": 27, "stamina": 13}, "weight_g": 35.0, "wiki_page": "Blade - Optimus Primal", "release_jp": "May 17th, 2025", "x_standard": true, "product_code": "G0352 (Hasbro) / BX-00 (Takara Tomy)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
optimus-prime	OptimusPrime	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 22, "defense": 55, "stamina": 23}, "weight_g": 31.7, "wiki_page": "Blade - Optimus Prime", "release_jp": "May 17th, 2025", "x_standard": true, "product_code": "G0353 (Hasbro) / BX-00 (Takara Tomy)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
crimson-garuda	CrimsonGaruda	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 45, "defense": 25, "stamina": 30}, "weight_g": 35.0, "wiki_page": "Blade - CrimsonGaruda", "release_jp": "November 2nd, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/crimson-garuda-blade/", "product_code": "BX-38 (Takara Tomy) / G1673 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
ptera-swing	PteraSwing	blade	BX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 27, "defense": 23, "stamina": 50}, "weight_g": 34.3, "wiki_page": "Blade - Talon Ptera", "release_jp": "November 2nd, 2024", "x_standard": true, "product_code": "G0195 (Hasbro) / UX-10 (Takara Tomy) / BX-ORG02 (Takara Tomy Development Code)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
croc-crunch	CrocCrunch	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 60, "defense": 22, "stamina": 18}, "weight_g": 34.0, "wiki_page": "Blade - Bite Croc", "release_jp": "February 5th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/croc-crunch-blade/", "product_code": "G0199 (Hasbro) / BX-00 (Takara Tomy) / BX-ORG06 (Takara Tomy Development Code)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
dark	Dark	blade	CX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 10, "defense": 40, "stamina": 10}, "weight_g": 30.3, "wiki_page": "Main Blade - Dark", "release_jp": "March 29th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/dark-main-blade/", "product_code": "CX-03 (Takara Tomy) / G1680 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
rock-leone	RockLeone	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 30, "defense": 55, "stamina": 15}, "weight_g": 29.8, "wiki_page": "Blade - Rock Leone", "release_jp": "July 19th, 2025", "x_standard": true, "product_code": "BX-00"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
dran-buster	DranBuster	blade	UX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 70, "defense": 20, "stamina": 10}, "weight_g": 36.5, "wiki_page": "Blade - DranBuster", "release_jp": "March 30th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/dran-buster-blade/", "product_code": "UX-01 (Takara Tomy) / G1536 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
dran-dagger	DranDagger	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 50, "defense": 25, "stamina": 25}, "weight_g": 34.8, "wiki_page": "Blade - DranDagger", "release_jp": "November 2nd, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/dran-dagger-blade/", "product_code": "BX-20"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
dranzer-spiral	DranzerSpiral	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 35, "defense": 30, "stamina": 35}, "weight_g": 27.7, "wiki_page": "Blade - DranzerSpiral", "release_jp": "July 15th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/dranzer-spiral-blade/", "product_code": "BX-00 (Takara Tomy) / F9584 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
ghost-circle	GhostCircle	blade	UX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 5, "defense": 40, "stamina": 55}, "weight_g": 26.7, "wiki_page": "Blade - GhostCircle", "release_jp": "December 28th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/ghost-circle-blade/", "product_code": "UX-12 (Takara Tomy) / G1687 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
shelter-drake	ShelterDrake	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 25, "defense": 40, "stamina": 35}, "weight_g": 32.6, "wiki_page": "Blade - ShelterDrake", "release_jp": "February 15th, 2025", "x_standard": true, "product_code": "BX-39 (Takara Tomy) / G1675 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
shinobi-knife	ShinobiKnife	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 23, "defense": 50, "stamina": 27}, "weight_g": 30.9, "wiki_page": "Blade - Knife Shinobi", "release_jp": "November 14th, 2024", "x_standard": true, "product_code": "G0190 (Hasbro) / BX-00 (Takara Tomy) / BX-ORG05 (Takara Tomy Development Code)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
golem-rock	GolemRock	blade	UX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 30, "defense": 60, "stamina": 10}, "weight_g": 34.0, "wiki_page": "Blade - GolemRock", "release_jp": "January 25th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/golem-rock-blade/", "product_code": "UX-13 (Takara Tomy) / G1646 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
spinosaurus	Spinosaurus	blade	\N	{}	2026-08-21 19:14:14.356763+00	2026-08-24 10:44:57.797487+00
sphinx-cowl	SphinxCowl	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 35, "defense": 55, "stamina": 10}, "weight_g": 32.7, "wiki_page": "Blade - SphinxCowl", "release_jp": "February 22nd, 2024", "x_standard": true, "product_code": "BX-27 (Takara Tomy) / G1530 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
spider-man	Spider-Man	blade	BX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 33, "defense": 17, "stamina": 50}, "weight_g": 33.0, "wiki_page": "Blade - Spider-Man", "release_jp": "April 26th, 2025", "x_standard": true, "product_code": "G0288 (Hasbro) / BX-00 (Takara Tomy)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
tackle-goat	TackleGoat	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 13, "defense": 65, "stamina": 22}, "weight_g": 31.5, "wiki_page": "Blade - Tackle Goat", "release_jp": "October 11th, 2025", "x_standard": true, "product_code": "G1688 / BX-46 (Takara Tomy) / BX-ORG15 (Takara Tomy Development Code)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
eclipse	Eclipse	blade	CX	{"spin": "Right-Spin", "type": "Balance", "weight_g": 32.3, "wiki_page": "Main Blade - Eclipse", "release_jp": "September 27th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/eclipse-main-blade/", "product_code": "CX-09"}	2026-08-21 19:14:14.356763+00	2026-08-24 10:55:34.522721+00
flame	Flame	blade	CX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 5, "defense": 15, "stamina": 40}, "weight_g": 28.5, "wiki_page": "Main Blade - Flame", "release_jp": "July 19th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/flame-main-blade/", "product_code": "CX-08 (Takara Tomy) / G2747 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-24 10:55:34.522721+00
thanos	Thanos	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 22, "defense": 60, "stamina": 18}, "weight_g": 29.5, "wiki_page": "Blade - Thanos", "release_jp": "April 26th, 2025", "x_standard": true, "product_code": "G0287 (Hasbro) / BX-00 (Takara Tomy)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
hells-chain	HellsChain	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 35, "defense": 40, "stamina": 25}, "weight_g": 33.2, "wiki_page": "Blade - HellsChain", "release_jp": "November 2nd, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/hells-chain-blade/", "product_code": "BX-21 (Takara Tomy) / G0196 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
hells-hammer	HellsHammer	blade	UX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 50, "defense": 25, "stamina": 25}, "weight_g": 33.0, "wiki_page": "Blade - HellsHammer", "release_jp": "March 30th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/hells-hammer-blade/", "product_code": "UX-02 (Takara Tomy) / G1752 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
hells-scythe	HellsScythe	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 30, "defense": 35, "stamina": 35}, "weight_g": 32.7, "wiki_page": "Blade - HellsScythe", "release_jp": "June 10th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/hells-scythe-blade/", "product_code": "BX-02 (Takara Tomy) / F9583 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
impact-drake	ImpactDrake	blade	UX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 75, "defense": 25, "stamina": 10}, "weight_g": 39.0, "wiki_page": "Blade - ImpactDrake", "release_jp": "December 28th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/impact-drake-blade/", "product_code": "UX-11 (Takara Tomy) / G0842 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
venom	Venom	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 55, "defense": 22, "stamina": 23}, "weight_g": 34.3, "wiki_page": "Blade - Venom", "release_jp": "April 26th, 2025", "x_standard": true, "product_code": "G0288 (Hasbro) / BX-00 (Takara Tomy)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
victory-valkyrie	VictoryValkyrie	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 55, "defense": 20, "stamina": 25}, "weight_g": 33.2, "wiki_page": "Blade - VictoryValkyrie", "release_jp": "March 21st, 2025", "x_standard": true, "product_code": "BX-00 (Takara Tomy) / G1844 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
knight-lance	KnightLance	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 25, "defense": 60, "stamina": 15}, "weight_g": 32.9, "wiki_page": "Blade - KnightLance", "release_jp": "August 10th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/knight-lance-blade/", "product_code": "BX-13 (Takara Tomy) / G0184 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
knight-mail	KnightMail	blade	UX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 10, "defense": 65, "stamina": 35}, "weight_g": 36.7, "wiki_page": "Blade - KnightMail", "release_jp": "November 2nd, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/knight-mail-blade/", "product_code": "UX-10 (Takara Tomy) / G3195 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
knight-shield-blade	KnightShield	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 20, "defense": 55, "stamina": 25}, "weight_g": 32.4, "wiki_page": "Blade - KnightShield", "release_jp": "July 15th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/knight-shield-blade/", "product_code": "BX-04 (Takara Tomy) / F9581 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
leon-claw	LeonClaw	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 40, "defense": 40, "stamina": 20}, "weight_g": 31.4, "wiki_page": "Blade - LeonClaw", "release_jp": "October 7th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/leon-claw-blade/", "product_code": "BX-15 (Takara Tomy) / G0193 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
leon-crest	LeonCrest	blade	UX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 15, "defense": 70, "stamina": 15}, "weight_g": 35.0, "wiki_page": "Blade - LeonCrest", "release_jp": "August 10th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/leon-crest-blade/", "product_code": "UX-06 (Takara Tomy) / G1685 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
mammoth-tusk	MammothTusk	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 33, "defense": 35, "stamina": 32}, "weight_g": 32.3, "wiki_page": "Blade - Tusk Mammoth", "release_jp": "December 27th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/mammoth-tusk-blade/", "product_code": "F9588 (Hasbro) / BX-00 (Takara Tomy) / BX-ORG08 (Takara Tomy Development Code)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
xeno-xcalibur	XenoXcalibur	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 65, "defense": 25, "stamina": 10}, "weight_g": 31.0, "wiki_page": "Blade - XenoXcalibur", "release_jp": "March 29th, 2025", "x_standard": true, "product_code": "BX-00"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
phoenix-feather	PhoenixFeather	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 50, "defense": 20, "stamina": 30}, "weight_g": 33.3, "wiki_page": "Blade - PhoenixFeather", "release_jp": "December 15th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/phoenix-feather-blade/", "product_code": "BX-00 (Takara Tomy) / G2740 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
phoenix-rudder	PhoenixRudder	blade	UX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 10, "defense": 35, "stamina": 55}, "weight_g": 34.5, "wiki_page": "Blade - PhoenixRudder", "release_jp": "August 10th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/phoenix-rudder-blade/", "product_code": "UX-07 (Takara Tomy) / G3393 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
phoenix-wing	PhoenixWing	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 60, "defense": 25, "stamina": 15}, "weight_g": 38.0, "wiki_page": "Blade - PhoenixWing", "release_jp": "December 10th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/phoenix-wing-blade/", "product_code": "BX-23 (Takara Tomy) / F9324 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
reaper	Reaper	blade	CX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 25, "defense": 10, "stamina": 25}, "weight_g": 29.0, "wiki_page": "Main Blade - Reaper", "release_jp": "April 26th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/reaper-main-blade/", "product_code": "CX-05 (Takara Tomy) / G1678 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
rhino-horn	RhinoHorn	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 20, "defense": 50, "stamina": 30}, "weight_g": 32.7, "wiki_page": "Blade - RhinoHorn", "release_jp": "November 2nd, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/rhino-horn-blade/", "product_code": "BX-19 (Takara Tomy) / G0192 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
samurai-calibur	SamuraiCalibur	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 40, "defense": 30, "stamina": 30}, "weight_g": 36.0, "wiki_page": "Blade - SamuraiCalibur", "release_jp": "August 9th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/samurai-calibur-blade/", "product_code": "BX-45 (Takara Tomy) / G2754 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
samurai-saber	SamuraiSaber	blade	UX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 65, "defense": 20, "stamina": 25}, "weight_g": 36.5, "wiki_page": "Blade - SamuraiSaber", "release_jp": "November 2nd, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/samurai-saber-blade/", "product_code": "UX-09 (Takara Tomy) / G1862 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
samurai-steel	SamuraiSteel	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 40, "defense": 37, "stamina": 23}, "weight_g": 31.2, "wiki_page": "Blade - Steel Samurai", "release_jp": "May 15th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/samurai-steel-blade/", "product_code": "G0188 (Hasbro) / BX-ORG01 (Takara Tomy Development Code)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
scorpio-spear	ScorpioSpear	blade	UX	{"spin": "Right-Spin", "type": "Balance", "weight_g": 39.6, "wiki_page": "Blade - ScorpioSpear", "release_jp": "April 26th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/scorpio-spear-blade/", "product_code": "UX-14 (Takara Tomy) / G2758 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
shark-edge	SharkEdge	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 60, "defense": 25, "stamina": 15}, "weight_g": 34.5, "wiki_page": "Blade - SharkEdge", "release_jp": "September 9th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/shark-edge-blade/", "product_code": "BX-14 (Takara Tomy) / G0194 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
shark-scale	SharkScale	blade	UX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 70, "defense": 15, "stamina": 15}, "weight_g": 37.6, "wiki_page": "Blade - SharkScale", "release_jp": "August 9th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/shark-scale-blade/", "product_code": "UX-15 (Takara Tomy) / G2731 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
shinobi-shadow	ShinobiShadow	blade	UX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 10, "defense": 70, "stamina": 20}, "weight_g": 28.2, "wiki_page": "Blade - ShinobiShadow", "release_jp": "May 18th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/shinobi-shadow-blade/", "product_code": "UX-05 (Takara Tomy) / G1539 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
silver-wolf	SilverWolf	blade	UX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 15, "defense": 30, "stamina": 65}, "weight_g": 36.8, "wiki_page": "Blade - SilverWolf", "release_jp": "October 12th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/silver-wolf-blade/", "product_code": "UX-08 (Takara Tomy) / G1674 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
tricera-press	TriceraPress	blade	BX	{"spin": "Right-Spin", "type": "Defense", "stats": {"attack": 20, "defense": 65, "stamina": 15}, "weight_g": 36.5, "wiki_page": "Blade - TriceraPress", "release_jp": "June 28th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/tricera-press-blade/", "product_code": "BX-44 (Takara Tomy) / G2763 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
tyranno-beat	TyrannoBeat	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 65, "defense": 30, "stamina": 5}, "weight_g": 37.0, "wiki_page": "Blade - TyrannoBeat", "release_jp": "April 27th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/tyranno-beat-blade/", "product_code": "BX-31 (Takara Tomy) / G1542 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
tyranno-roar	TyrannoRoar	blade	BX	{"spin": "Right-Spin", "type": "Attack", "stats": {"attack": 60, "defense": 28, "stamina": 12}, "weight_g": 36.0, "wiki_page": "Blade - Roar Tyranno", "release_jp": "July 19th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/tyranno-roar-blade/", "product_code": "G0284 (Hasbro) / BX-ORG03 (Takara Tomy)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
unicorn-sting	UnicornSting	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 35, "defense": 35, "stamina": 30}, "weight_g": 33.4, "wiki_page": "Blade - UnicornSting", "release_jp": "January 27th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/unicorn-sting-blade/", "product_code": "BX-26 (Takara Tomy) / G0283 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
viper-tail	ViperTail	blade	BX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 30, "defense": 20, "stamina": 50}, "weight_g": 34.7, "wiki_page": "Blade - ViperTail", "release_jp": "October 7th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/viper-tail-blade/", "product_code": "BX-16 (Takara Tomy) / G0197 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
7-60	7-60	ratchet	UX	{"stats": {"attack": 8, "defense": 14, "stamina": 8}, "weight_g": 7.1, "wiki_page": "Ratchet - 7-60", "release_jp": "August 10th, 2024", "x_standard": true, "product_code": "UX-06 (Takara Tomy) / G1685 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
7-70	7-70	ratchet	UX	{"stats": {"attack": 8, "defense": 12, "stamina": 10}, "weight_g": 7.3, "wiki_page": "Ratchet - 7-70", "release_jp": "November 2nd, 2024", "x_standard": true, "product_code": "UX-10 (Takara Tomy) / G3195 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
7-80	7-80	ratchet	BX	{"stats": {"attack": 7, "defense": 14, "stamina": 9}, "weight_g": 7.8, "wiki_page": "Ratchet - 7-80", "release_jp": "February 15th, 2025", "x_standard": true, "product_code": "BX-39 (Takara Tomy) / G1675 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 21:49:50.148823+00
weiss-tiger	WeissTiger	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 45, "defense": 30, "stamina": 25}, "weight_g": 34.6, "wiki_page": "Blade - WeissTiger", "release_jp": "June 15th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/weiss-tiger-blade/", "product_code": "BX-33 (Takara Tomy) / G1686 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
whale-wave	WhaleWave	blade	BX	{"spin": "Right-Spin", "type": "Balance", "stats": {"attack": 45, "defense": 35, "stamina": 20}, "weight_g": 38.2, "wiki_page": "Blade - WhaleWave", "release_jp": "September 14th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/whale-wave-blade/", "product_code": "BX-36 (Takara Tomy) / G1669 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
3-70	3-70	ratchet	UX	{"stats": {"attack": 15, "defense": 8, "stamina": 7}, "weight_g": 6.4, "wiki_page": "Ratchet - 3-70", "release_jp": "March 30th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/3-70-ratchet/", "product_code": "UX-02 (Takara Tomy) / G1752 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
wizard-rod	WizardRod	blade	UX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 15, "defense": 25, "stamina": 60}, "weight_g": 35.3, "wiki_page": "Blade - WizardRod", "release_jp": "March 30th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/wizard-rod-blade/", "product_code": "UX-03 (Takara Tomy) / G1537 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
wyvern-gale	WyvernGale	blade	BX	{"spin": "Right-Spin", "type": "Stamina", "stats": {"attack": 10, "defense": 40, "stamina": 50}, "weight_g": 31.9, "wiki_page": "Blade - WyvernGale", "release_jp": "December 27th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/wyvern-gale-blade/", "product_code": "BX-24 (Takara Tomy) / G0282 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
emperor	emperor	lock_chip	CX	{"spin": "Right-Spin", "weight_g": 4.7, "wiki_page": "Lock Chip - Emperor", "release_jp": "November 1st, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/emperor-lock-chip/", "product_code": "CX-11 (Takara Tomy) / G3028 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
valkyrie	valkyrie	lock_chip	CX	{"spin": "Right-Spin", "weight_g": 5.6, "wiki_page": "Lock Chip - Valkyrie", "release_jp": "July 17th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/valkyrie-lock-chip/", "product_code": "CX-00"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
0-60	0-60	ratchet	CX	{"stats": {"defense": 14, "stamina": 13}, "weight_g": 6.8, "wiki_page": "Ratchet - 0-60", "release_jp": "November 1st, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/0-60-ratchet/", "product_code": "CX-10"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
0-70	0-70	ratchet	UX	{"stats": {"attack": 3, "defense": 13, "stamina": 14}, "weight_g": 7.0, "wiki_page": "Ratchet - 0-70", "release_jp": "April 26th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/0-70-ratchet/", "product_code": "UX-14 (Takara Tomy) / G2758 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
0-80	0-80	ratchet	UX	{"stats": {"attack": 3, "defense": 12, "stamina": 15}, "weight_g": 7.6, "wiki_page": "Ratchet - 0-80", "release_jp": "December 28th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/0-80-ratchet/", "product_code": "UX-12 (Takara Tomy) / G1687 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
1-60	1-60	ratchet	UX	{"stats": {"attack": 17, "defense": 9, "stamina": 4}, "weight_g": 6.0, "wiki_page": "Ratchet - 1-60", "release_jp": "March 30th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/1-60-ratchet/", "product_code": "UX-01 (Takara Tomy) / G1536 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
1-70	1-70	ratchet	BX	{"stats": {"defense": 6, "stamina": 7}, "weight_g": 6.1, "wiki_page": "Ratchet - 1-70", "release_jp": "August 9th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/1-70-ratchet/", "product_code": "UX-15"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
1-80	1-80	ratchet	UX	{"weight_g": 6.7, "wiki_page": "Ratchet - 1-80", "release_jp": "May 18th, 2024", "x_standard": false, "beybladewiki": "https://beyblade.wiki/1-80-ratchet/", "product_code": "UX-05 (Takara Tomy) / G1539 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
2-60	2-60	ratchet	BX	{"weight_g": 6.2, "wiki_page": "Ratchet - 2-60", "release_jp": "July 13th, 2024", "x_standard": false, "beybladewiki": "https://beyblade.wiki/2-60-ratchet/", "product_code": "BX-34 (Takara Tomy) / G1491 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
2-70	2-70	ratchet	UX	{"stats": {"attack": 10, "defense": 12, "stamina": 8}, "weight_g": 6.3, "wiki_page": "Ratchet - 2-70", "release_jp": "November 2nd, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/2-70-ratchet/", "product_code": "UX-09 (Takara Tomy) / G1862 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
3-60	3-60	ratchet	BX	{"stats": {"attack": 15, "defense": 9, "stamina": 6}, "weight_g": 6.4, "wiki_page": "Ratchet - 3-60", "release_jp": "June 10th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/3-60-ratchet/", "product_code": "BX-01 (Takara Tomy) / F9580 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
3-80	3-80	ratchet	BX	{"stats": {"attack": 15, "defense": 7, "stamina": 8}, "weight_g": 7.1, "wiki_page": "Ratchet - 3-80", "release_jp": "July 15th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/3-80-ratchet/", "product_code": "BX-04 (Takara Tomy) / F9581 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
4-50	4-50	ratchet	UX	{"stats": {"attack": 12, "defense": 13, "stamina": 5}, "weight_g": 5.9, "wiki_page": "Ratchet - 4-50", "release_jp": "August 9th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/4-50-ratchet/", "product_code": "UX-15 (Takara Tomy) / G2731 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
4-55	4-55	ratchet	CX	{"stats": {"attack": 7, "defense": 11, "stamina": 12}, "weight_g": 4.8, "wiki_page": "Ratchet - 4-55", "release_jp": "March 29th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/4-55-ratchet/", "product_code": "CX-02 (Takara Tomy) / G1679 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
4-60	4-60	ratchet	BX	{"stats": {"attack": 11, "defense": 13, "stamina": 6}, "weight_g": 6.3, "wiki_page": "Ratchet - 4-60", "release_jp": "June 10th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/4-60-ratchet/", "product_code": "BX-02 (Takara Tomy) / F9583 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
4-70	4-70	ratchet	BX	{"stats": {"attack": 11, "defense": 12, "stamina": 7}, "weight_g": 6.4, "wiki_page": "Ratchet - 4-70", "release_jp": "April 27th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/4-70-ratchet/", "product_code": "BX-31 (Takara Tomy) / G1542 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
4-80	4-80	ratchet	BX	{"stats": {"attack": 11, "defense": 11, "stamina": 8}, "weight_g": 7.0, "wiki_page": "Ratchet - 4-80", "release_jp": "July 15th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/4-80-ratchet/", "product_code": "BX-03 (Takara Tomy) / F9582 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
5-60	5-60	ratchet	BX	{"stats": {"attack": 12, "defense": 9, "stamina": 9}, "weight_g": 6.6, "wiki_page": "Ratchet - 5-60", "release_jp": "October 7th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/5-60-ratchet/", "product_code": "BX-15 (Takara Tomy) / G0196 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
5-70	5-70	ratchet	UX	{"stats": {"attack": 12, "defense": 8, "stamina": 10}, "weight_g": 6.7, "wiki_page": "Ratchet - 5-70", "release_jp": "March 30th, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/5-70-ratchet/", "product_code": "UX-03 (Takara Tomy) / G1537 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
6-60	6-60	ratchet	CX	{"stats": {"attack": 14, "defense": 8, "stamina": 8}, "weight_g": 6.1, "wiki_page": "Ratchet - 6-60", "release_jp": "March 29th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/6-60-ratchet/", "product_code": "CX-01 (Takara Tomy) / G1677 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
6-70	6-70	ratchet	BX	{"stats": {"attack": 14, "defense": 7, "stamina": 9}, "weight_g": 6.3, "wiki_page": "Ratchet - 6-70", "release_jp": "August 9th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/6-70-ratchet/", "product_code": "BX-45 (Takara Tomy) / G2754 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
6-80	6-80	ratchet	CX	{"stats": {"attack": 14, "defense": 6, "stamina": 10}, "weight_g": 6.9, "wiki_page": "Ratchet - 6-80", "release_jp": "March 29th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/6-80-ratchet/", "product_code": "CX-03 (Takara Tomy) / G1680 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
9-60	9-60	ratchet	BX	{"stats": {"attack": 13, "defense": 10, "stamina": 7}, "weight_g": 6.2, "wiki_page": "Ratchet - 9-60", "release_jp": "December 10th, 2023", "x_standard": true, "beybladewiki": "https://beyblade.wiki/9-60-ratchet/", "product_code": "BX-23 (Takara Tomy) / F9324 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
9-65	9-65	ratchet	UX	{"stats": {"attack": 13, "defense": 10, "stamina": 7}, "weight_g": 4.5, "wiki_page": "Ratchet - 9-65", "release_jp": "October 11th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/9-65-ratchet/", "product_code": "UX-16 (Takara Tomy) / G3195 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
9-70	9-70	ratchet	UX	{"weight_g": 6.3, "wiki_page": "Ratchet - 9-70", "release_jp": "August 10th, 2024", "x_standard": false, "beybladewiki": "https://beyblade.wiki/9-70-ratchet/", "product_code": "UX-07 (Takara Tomy) / G1681 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
9-80	9-80	ratchet	BX	{"stats": {"attack": 13, "defense": 10, "stamina": 7}, "weight_g": 6.9, "wiki_page": "Ratchet - 9-80", "release_jp": "February 22nd, 2024", "x_standard": true, "beybladewiki": "https://beyblade.wiki/9-80-ratchet/", "product_code": "BX-27 (Takara Tomy) / G1530 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
m-85	M-85	ratchet	BX	{"stats": {"attack": 8, "defense": 19, "stamina": 13}, "weight_g": 10.6, "wiki_page": "Ratchet - M-85", "release_jp": "June 28th, 2025", "x_standard": true, "beybladewiki": "https://beyblade.wiki/m-85-ratchet/", "product_code": "BX-44 (Takara Tomy) / G3028 (Hasbro)"}	2026-08-21 19:14:14.356763+00	2026-08-21 22:09:42.436676+00
\.


--
-- Data for Name: external_player_combos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.external_player_combos (tournament_id, player_id, combo_number, blade, assist_blade, ratchet, "bit", lock_chip, updated_at, placement, total_participants, tournament_date, season, platform) FROM stdin;
0909d7a6-6cea-433d-ed50-08de4ae7da31	fbe08cae-c480-49da-aa11-5967b6621f3b	1	Blast	Heavy	9-60	Kick	emperor	2026-01-26 13:24:31.358115+00	3	32	2026-01-16	Off Season 2025	challengermode
0909d7a6-6cea-433d-ed50-08de4ae7da31	fbe08cae-c480-49da-aa11-5967b6621f3b	2	SharkScale	None	1-60	LowRush	None	2026-01-26 13:24:31.358115+00	3	32	2026-01-16	Off Season 2025	challengermode
0909d7a6-6cea-433d-ed50-08de4ae7da31	fbe08cae-c480-49da-aa11-5967b6621f3b	3	WizardRod	None	1-60	Hexa	None	2026-01-26 13:24:31.358115+00	3	32	2026-01-16	Off Season 2025	challengermode
7e82013b-8870-4262-265d-08de10ba2958	d6abd100-0300-49df-9d70-4a11c408157d	1	CobaltDragoon	None	5-60	Elevate	None	2025-11-15 13:43:21.741579+00	3	24	2025-10-22	Off Season 2025	challengermode
7e82013b-8870-4262-265d-08de10ba2958	d6abd100-0300-49df-9d70-4a11c408157d	2	SharkScale	None	3-60	LowRush	None	2025-11-15 13:43:21.741579+00	3	24	2025-10-22	Off Season 2025	challengermode
7e82013b-8870-4262-265d-08de10ba2958	d6abd100-0300-49df-9d70-4a11c408157d	3	WizardRod	None	1-60	Hexa	None	2025-11-15 13:43:21.741579+00	3	24	2025-10-22	Off Season 2025	challengermode
7e82013b-8870-4262-265d-08de10ba2958	7b93216a-d77e-479f-8d1e-5ad2bc604f6d	1	SharkScale	None	3-60	LowRush	None	2025-11-15 13:44:04.96215+00	3	24	2025-10-22	Off Season 2025	challengermode
7e82013b-8870-4262-265d-08de10ba2958	7b93216a-d77e-479f-8d1e-5ad2bc604f6d	2	WizardRod	None	1-60	FreeBall	None	2025-11-15 13:44:04.96215+00	3	24	2025-10-22	Off Season 2025	challengermode
0909d7a6-6cea-433d-ed50-08de4ae7da31	3432caad-f9ac-48c0-8011-22d32680a889	1	Blast	Heavy	9-60	Kick	emperor	2026-01-26 13:12:47.812212+00	1	32	2026-01-16	Off Season 2025	challengermode
0909d7a6-6cea-433d-ed50-08de4ae7da31	3432caad-f9ac-48c0-8011-22d32680a889	2	SharkScale	None	3-60	Rush	None	2026-01-26 13:12:47.812212+00	1	32	2026-01-16	Off Season 2025	challengermode
0909d7a6-6cea-433d-ed50-08de4ae7da31	3432caad-f9ac-48c0-8011-22d32680a889	3	WizardRod	None	1-60	Hexa	None	2026-01-26 13:12:47.812212+00	1	32	2026-01-16	Off Season 2025	challengermode
0909d7a6-6cea-433d-ed50-08de4ae7da31	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	1	WizardRod	None	1-60	Hexa	None	2026-01-26 13:25:51.920389+00	4	32	2026-01-16	Off Season 2025	challengermode
0909d7a6-6cea-433d-ed50-08de4ae7da31	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	2	SharkScale	None	3-60	LowRush	None	2026-01-26 13:25:51.920389+00	4	32	2026-01-16	Off Season 2025	challengermode
0909d7a6-6cea-433d-ed50-08de4ae7da31	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	3	SilverWolf	None	9-60	FreeBall	None	2026-01-26 13:25:51.920389+00	4	32	2026-01-16	Off Season 2025	challengermode
0909d7a6-6cea-433d-ed50-08de4ae7da31	6433156e-ba76-4d4e-9013-4bc834b5c004	1	SilverWolf	None	9-60	FreeBall	None	2026-01-26 13:13:32.647249+00	2	32	2026-01-16	Off Season 2025	challengermode
0909d7a6-6cea-433d-ed50-08de4ae7da31	6433156e-ba76-4d4e-9013-4bc834b5c004	2	SharkScale	None	3-60	LowRush	None	2026-01-26 13:13:32.647249+00	2	32	2026-01-16	Off Season 2025	challengermode
0909d7a6-6cea-433d-ed50-08de4ae7da31	6433156e-ba76-4d4e-9013-4bc834b5c004	3	WizardRod	None	1-60	Hexa	None	2026-01-26 13:13:32.647249+00	2	32	2026-01-16	Off Season 2025	challengermode
7e82013b-8870-4262-265d-08de10ba2958	7b93216a-d77e-479f-8d1e-5ad2bc604f6d	3	SilverWolf	None	9-60	UnderNeedle	None	2025-11-15 13:44:04.96215+00	3	24	2025-10-22	Off Season 2025	challengermode
2e1f67ab-05b4-49c6-0661-08de12178f7b	fbdc994f-18e6-4ff1-897d-c25d7b50c4bb	1	Blast	Slash	9-60	Wedge	None	2025-11-15 13:46:30.55969+00	1	24	2025-10-24	Off Season 2025	challengermode
2e1f67ab-05b4-49c6-0661-08de12178f7b	fbdc994f-18e6-4ff1-897d-c25d7b50c4bb	2	WizardRod	None	1-60	Hexa	None	2025-11-15 13:46:30.55969+00	1	24	2025-10-24	Off Season 2025	challengermode
2e1f67ab-05b4-49c6-0661-08de12178f7b	fbdc994f-18e6-4ff1-897d-c25d7b50c4bb	3	SilverWolf	None	9-60	FreeBall	None	2025-11-15 13:46:30.55969+00	1	24	2025-10-24	Off Season 2025	challengermode
2e1f67ab-05b4-49c6-0661-08de12178f7b	c22a9e64-da54-437c-bcd0-4f53535d3350	1	Blast	Jaggy	3-60	Rush	None	2025-11-15 13:47:09.196222+00	2	24	2025-10-24	Off Season 2025	challengermode
2e1f67ab-05b4-49c6-0661-08de12178f7b	c22a9e64-da54-437c-bcd0-4f53535d3350	2	CobaltDragoon	None	5-60	Elevate	None	2025-11-15 13:47:09.196222+00	2	24	2025-10-24	Off Season 2025	challengermode
2e1f67ab-05b4-49c6-0661-08de12178f7b	c22a9e64-da54-437c-bcd0-4f53535d3350	3	SharkScale	None	1-70	LowRush	None	2025-11-15 13:47:09.196222+00	2	24	2025-10-24	Off Season 2025	challengermode
2e1f67ab-05b4-49c6-0661-08de12178f7b	8b107f55-9609-4711-b33a-f322e684a678	1	CobaltDragoon	None	5-60	Elevate	None	2025-11-15 13:48:30.3416+00	3	24	2025-10-24	Off Season 2025	challengermode
2e1f67ab-05b4-49c6-0661-08de12178f7b	8b107f55-9609-4711-b33a-f322e684a678	2	WizardRod	None	1-60	FreeBall	None	2025-11-15 13:48:30.3416+00	3	24	2025-10-24	Off Season 2025	challengermode
2e1f67ab-05b4-49c6-0661-08de12178f7b	8b107f55-9609-4711-b33a-f322e684a678	3	SharkScale	None	3-60	Kick	None	2025-11-15 13:48:30.3416+00	3	24	2025-10-24	Off Season 2025	challengermode
2e1f67ab-05b4-49c6-0661-08de12178f7b	96ff4c7f-ae31-46c2-9c7a-a4dde068f206	1	PhoenixWing	None	3-60	Rush	None	2025-11-15 13:49:09.227469+00	3	24	2025-10-24	Off Season 2025	challengermode
2e1f67ab-05b4-49c6-0661-08de12178f7b	96ff4c7f-ae31-46c2-9c7a-a4dde068f206	2	SilverWolf	None	9-70	Ball	None	2025-11-15 13:49:09.227469+00	3	24	2025-10-24	Off Season 2025	challengermode
2e1f67ab-05b4-49c6-0661-08de12178f7b	96ff4c7f-ae31-46c2-9c7a-a4dde068f206	3	WizardRod	None	1-60	FreeBall	None	2025-11-15 13:49:09.227469+00	3	24	2025-10-24	Off Season 2025	challengermode
1fc6d496-bf2a-4924-3822-08de21115a66	55c70b52-40d6-4c65-bf69-6798204d54a3	1	Blast	Assault	9-60	LowRush	None	2025-11-15 13:52:45.26679+00	2	9	2025-11-12	Off Season 2025	challengermode
1fc6d496-bf2a-4924-3822-08de21115a66	55c70b52-40d6-4c65-bf69-6798204d54a3	2	PhoenixWing	None	3-60	Rush	None	2025-11-15 13:52:45.26679+00	2	9	2025-11-12	Off Season 2025	challengermode
1fc6d496-bf2a-4924-3822-08de21115a66	55c70b52-40d6-4c65-bf69-6798204d54a3	3	WizardRod	None	1-60	Hexa	None	2025-11-15 13:52:45.26679+00	2	9	2025-11-12	Off Season 2025	challengermode
1fc6d496-bf2a-4924-3822-08de21115a66	875ccc4e-4d96-4412-a7fc-b1460cf734a0	1	HoverWyvern	None	3-60	Kick	None	2025-11-15 13:53:18.370849+00	3	9	2025-11-12	Off Season 2025	challengermode
1fc6d496-bf2a-4924-3822-08de21115a66	875ccc4e-4d96-4412-a7fc-b1460cf734a0	2	SharkScale	None	1-60	LowRush	None	2025-11-15 13:53:18.370849+00	3	9	2025-11-12	Off Season 2025	challengermode
1fc6d496-bf2a-4924-3822-08de21115a66	875ccc4e-4d96-4412-a7fc-b1460cf734a0	3	PhoenixWing	None	1-70	Rush	None	2025-11-15 13:53:18.370849+00	3	9	2025-11-12	Off Season 2025	challengermode
1fc6d496-bf2a-4924-3822-08de21115a66	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	1	DranDagger	None	4-60	Rush	None	2025-11-15 13:53:56.480859+00	3	9	2025-11-12	Off Season 2025	challengermode
1fc6d496-bf2a-4924-3822-08de21115a66	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	2	SharkEdge	None	3-60	LowFlat	None	2025-11-15 13:53:56.480859+00	3	9	2025-11-12	Off Season 2025	challengermode
1fc6d496-bf2a-4924-3822-08de21115a66	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	3	SamuraiSaber	None	5-60	Taper	None	2025-11-15 13:53:56.480859+00	3	9	2025-11-12	Off Season 2025	challengermode
cf110239-4f06-484d-0554-08de14904573	c9b251bd-03ec-49ee-99ae-36959f63b1cd	1	SilverWolf	None	9-60	FreeBall	None	2025-11-15 13:54:41.482019+00	1	13	2025-10-29	Off Season 2025	challengermode
cf110239-4f06-484d-0554-08de14904573	c9b251bd-03ec-49ee-99ae-36959f63b1cd	2	CobaltDragoon	None	4-60	Elevate	None	2025-11-15 13:54:41.482019+00	1	13	2025-10-29	Off Season 2025	challengermode
cf110239-4f06-484d-0554-08de14904573	c9b251bd-03ec-49ee-99ae-36959f63b1cd	3	WizardRod	None	1-60	LowOrb	None	2025-11-15 13:54:41.482019+00	1	13	2025-10-29	Off Season 2025	challengermode
cf110239-4f06-484d-0554-08de14904573	736d1acf-027c-4128-8c07-540aae993ed8	1	PhoenixWing	None	3-60	LowFlat	None	2025-11-15 13:55:23.3014+00	2	13	2025-10-29	Off Season 2025	challengermode
cf110239-4f06-484d-0554-08de14904573	736d1acf-027c-4128-8c07-540aae993ed8	2	SilverWolf	None	9-60	FreeBall	None	2025-11-15 13:55:23.3014+00	2	13	2025-10-29	Off Season 2025	challengermode
cf110239-4f06-484d-0554-08de14904573	736d1acf-027c-4128-8c07-540aae993ed8	3	WizardRod	None	1-60	Rush	None	2025-11-15 13:55:23.3014+00	2	13	2025-10-29	Off Season 2025	challengermode
cf110239-4f06-484d-0554-08de14904573	bf0d2c91-4798-4294-a798-6bfe3e810ef3	1	SharkScale	None	4-60	UnderFlat	None	2025-11-15 13:55:58.089381+00	3	13	2025-10-29	Off Season 2025	challengermode
cf110239-4f06-484d-0554-08de14904573	bf0d2c91-4798-4294-a798-6bfe3e810ef3	2	KnightMail	None	1-60	Rush	None	2025-11-15 13:55:58.089381+00	3	13	2025-10-29	Off Season 2025	challengermode
cf110239-4f06-484d-0554-08de14904573	bf0d2c91-4798-4294-a798-6bfe3e810ef3	3	TyrannoBeat	None	6-60	Kick	None	2025-11-15 13:55:58.089381+00	3	13	2025-10-29	Off Season 2025	challengermode
cf110239-4f06-484d-0554-08de14904573	55c70b52-40d6-4c65-bf69-6798204d54a3	1	HoverWyvern	None	3-60	Kick	None	2025-11-15 13:56:27.321057+00	3	13	2025-10-29	Off Season 2025	challengermode
cf110239-4f06-484d-0554-08de14904573	55c70b52-40d6-4c65-bf69-6798204d54a3	2	PhoenixWing	None	1-60	Rush	None	2025-11-15 13:56:27.321057+00	3	13	2025-10-29	Off Season 2025	challengermode
cf110239-4f06-484d-0554-08de14904573	55c70b52-40d6-4c65-bf69-6798204d54a3	3	SilverWolf	None	9-60	FreeBall	None	2025-11-15 13:56:27.321057+00	3	13	2025-10-29	Off Season 2025	challengermode
7e82013b-8870-4262-265d-08de10ba2958	6ef8d6cd-683f-403d-bfd5-b7c3b8351ef3	1	CobaltDragoon	None	5-60	Elevate	None	2025-11-16 16:22:36.822302+00	2	24	2025-10-22	Off Season 2025	challengermode
7e82013b-8870-4262-265d-08de10ba2958	6ef8d6cd-683f-403d-bfd5-b7c3b8351ef3	2	WizardRod	None	1-60	Hexa	None	2025-11-16 16:22:36.822302+00	2	24	2025-10-22	Off Season 2025	challengermode
7e82013b-8870-4262-265d-08de10ba2958	6ef8d6cd-683f-403d-bfd5-b7c3b8351ef3	3	SharkScale	None	4-50	LowRush	None	2025-11-16 16:22:36.822302+00	2	24	2025-10-22	Off Season 2025	challengermode
7e82013b-8870-4262-265d-08de10ba2958	9c78170c-0b9c-4491-88ab-baa817ff7951	1	PhoenixWing	None	1-60	Rush	None	2025-11-16 16:22:41.810447+00	1	24	2025-10-22	Off Season 2025	challengermode
7e82013b-8870-4262-265d-08de10ba2958	9c78170c-0b9c-4491-88ab-baa817ff7951	2	WizardRod	None	3-60	Hexa	None	2025-11-16 16:22:41.810447+00	1	24	2025-10-22	Off Season 2025	challengermode
7e82013b-8870-4262-265d-08de10ba2958	9c78170c-0b9c-4491-88ab-baa817ff7951	3	SilverWolf	None	9-60	FreeBall	None	2025-11-16 16:22:41.810447+00	1	24	2025-10-22	Off Season 2025	challengermode
e309e8a8-e930-4f4c-389e-08de278ff875	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	1	PhoenixWing	None	1-70	Rush	None	2025-11-21 21:55:58.977334+00	1	12	2025-11-20	Off Season 2025	challengermode
e309e8a8-e930-4f4c-389e-08de278ff875	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	2	SharkScale	None	4-50	Point	None	2025-11-21 21:55:58.977334+00	1	12	2025-11-20	Off Season 2025	challengermode
e309e8a8-e930-4f4c-389e-08de278ff875	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	3	WizardRod	None	1-60	Hexa	None	2025-11-21 21:55:58.977334+00	1	12	2025-11-20	Off Season 2025	challengermode
e309e8a8-e930-4f4c-389e-08de278ff875	e017fb67-e90e-4935-a633-caf9ae32f463	1	PhoenixWing	None	3-70	LowRush	None	2025-11-21 21:56:53.056372+00	2	12	2025-11-20	Off Season 2025	challengermode
e309e8a8-e930-4f4c-389e-08de278ff875	e017fb67-e90e-4935-a633-caf9ae32f463	2	SilverWolf	None	9-60	FreeBall	None	2025-11-21 21:56:53.056372+00	2	12	2025-11-20	Off Season 2025	challengermode
e309e8a8-e930-4f4c-389e-08de278ff875	e017fb67-e90e-4935-a633-caf9ae32f463	3	WizardRod	None	1-60	Hexa	None	2025-11-21 21:56:53.056372+00	2	12	2025-11-20	Off Season 2025	challengermode
e309e8a8-e930-4f4c-389e-08de278ff875	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	1	DranDagger	None	4-60	Rush	None	2025-11-21 21:58:15.156325+00	3	12	2025-11-20	Off Season 2025	challengermode
e309e8a8-e930-4f4c-389e-08de278ff875	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	2	SharkEdge	None	3-60	LowFlat	None	2025-11-21 21:58:15.156325+00	3	12	2025-11-20	Off Season 2025	challengermode
e309e8a8-e930-4f4c-389e-08de278ff875	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	3	SamuraiSaber	None	5-60	Taper	None	2025-11-21 21:58:15.156325+00	3	12	2025-11-20	Off Season 2025	challengermode
e309e8a8-e930-4f4c-389e-08de278ff875	bf0d2c91-4798-4294-a798-6bfe3e810ef3	1	SharkScale	None	9-60	LowRush	None	2025-11-21 21:59:08.972955+00	3	12	2025-11-20	Off Season 2025	challengermode
e309e8a8-e930-4f4c-389e-08de278ff875	bf0d2c91-4798-4294-a798-6bfe3e810ef3	2	KnightMail	None	1-60	Rush	None	2025-11-21 21:59:08.972955+00	3	12	2025-11-20	Off Season 2025	challengermode
e309e8a8-e930-4f4c-389e-08de278ff875	bf0d2c91-4798-4294-a798-6bfe3e810ef3	3	TyrannoBeat	None	1-70	Kick	None	2025-11-21 21:59:08.972955+00	3	12	2025-11-20	Off Season 2025	challengermode
2e6e8eff-51e2-4051-3ca6-08de024c2a08	bf0d2c91-4798-4294-a798-6bfe3e810ef3	1	SharkScale	None	4-50	UnderFlat	None	2025-11-23 11:00:58.815186+00	1	12	2025-10-03	Off Season 2025	challengermode
2e6e8eff-51e2-4051-3ca6-08de024c2a08	bf0d2c91-4798-4294-a798-6bfe3e810ef3	2	KnightMail	None	1-60	Rush	None	2025-11-23 11:00:58.815186+00	1	12	2025-10-03	Off Season 2025	challengermode
2e6e8eff-51e2-4051-3ca6-08de024c2a08	bf0d2c91-4798-4294-a798-6bfe3e810ef3	3	TyrannoBeat	None	5-60	Kick	None	2025-11-23 11:00:58.815186+00	1	12	2025-10-03	Off Season 2025	challengermode
2e6e8eff-51e2-4051-3ca6-08de024c2a08	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	1	HoverWyvern	None	9-60	Kick	None	2025-11-23 11:01:45.67299+00	2	12	2025-10-03	Off Season 2025	challengermode
2e6e8eff-51e2-4051-3ca6-08de024c2a08	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	2	SharkScale	None	3-60	Level	None	2025-11-23 11:01:45.67299+00	2	12	2025-10-03	Off Season 2025	challengermode
2e6e8eff-51e2-4051-3ca6-08de024c2a08	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	3	WizardRod	None	6-60	Ball	None	2025-11-23 11:01:45.67299+00	2	12	2025-10-03	Off Season 2025	challengermode
2e6e8eff-51e2-4051-3ca6-08de024c2a08	2db4c771-059a-4ffd-99e6-2fb1826be418	1	SilverWolf	None	9-60	FreeBall	None	2025-11-23 11:02:30.667415+00	3	12	2025-10-03	Off Season 2025	challengermode
2e6e8eff-51e2-4051-3ca6-08de024c2a08	2db4c771-059a-4ffd-99e6-2fb1826be418	2	DranBuster	None	1-60	Rush	None	2025-11-23 11:02:30.667415+00	3	12	2025-10-03	Off Season 2025	challengermode
2e6e8eff-51e2-4051-3ca6-08de024c2a08	2db4c771-059a-4ffd-99e6-2fb1826be418	3	PhoenixWing	None	3-60	Hexa	None	2025-11-23 11:02:30.667415+00	3	12	2025-10-03	Off Season 2025	challengermode
2e6e8eff-51e2-4051-3ca6-08de024c2a08	da54d0b7-7af4-475c-9617-e89198753a30	1	SilverWolf	None	9-60	FreeBall	None	2025-11-23 11:03:43.168637+00	3	12	2025-10-03	Off Season 2025	challengermode
2e6e8eff-51e2-4051-3ca6-08de024c2a08	da54d0b7-7af4-475c-9617-e89198753a30	2	SamuraiSaber	None	3-60	Hexa	None	2025-11-23 11:03:43.168637+00	3	12	2025-10-03	Off Season 2025	challengermode
2e6e8eff-51e2-4051-3ca6-08de024c2a08	da54d0b7-7af4-475c-9617-e89198753a30	3	TyrannoRoar	None	3-70	Kick	None	2025-11-23 11:03:43.168637+00	3	12	2025-10-03	Off Season 2025	challengermode
1fc6d496-bf2a-4924-3822-08de21115a66	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	1	PhoenixWing	None	1-60	Rush	None	2025-11-27 20:01:16.794891+00	1	9	2025-11-12	Off Season 2025	challengermode
1fc6d496-bf2a-4924-3822-08de21115a66	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	2	SharkScale	None	4-50	Point	None	2025-11-27 20:01:16.794891+00	1	9	2025-11-12	Off Season 2025	challengermode
1fc6d496-bf2a-4924-3822-08de21115a66	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	3	WizardRod	None	1-70	Hexa	None	2025-11-27 20:01:16.794891+00	1	9	2025-11-12	Off Season 2025	challengermode
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	875ccc4e-4d96-4412-a7fc-b1460cf734a0	1	HoverWyvern	None	9-60	Kick	None	2025-12-07 22:18:42.049105+00	1	8	2025-11-28	Off Season 2025	challengermode
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	875ccc4e-4d96-4412-a7fc-b1460cf734a0	2	SharkScale	None	1-60	LowRush	None	2025-12-07 22:18:42.049105+00	1	8	2025-11-28	Off Season 2025	challengermode
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	875ccc4e-4d96-4412-a7fc-b1460cf734a0	3	WizardRod	None	1-70	Hexa	None	2025-12-07 22:18:42.049105+00	1	8	2025-11-28	Off Season 2025	challengermode
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	eefad2d2-1c4b-42cd-8496-b4260ead3128	1	SamuraiSaber	None	7-60	Hexa	None	2025-12-07 22:20:52.515281+00	3	8	2025-11-28	Off Season 2025	challengermode
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	eefad2d2-1c4b-42cd-8496-b4260ead3128	2	SharkEdge	None	3-80	LowFlat	None	2025-12-07 22:20:52.515281+00	3	8	2025-11-28	Off Season 2025	challengermode
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	eefad2d2-1c4b-42cd-8496-b4260ead3128	3	KnightMail	None	1-60	Point	None	2025-12-07 22:20:52.515281+00	3	8	2025-11-28	Off Season 2025	challengermode
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	1	DranBuster	None	1-60	Rush	None	2025-12-07 22:22:33.155515+00	4	8	2025-11-28	Off Season 2025	challengermode
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	2	SharkEdge	None	3-60	LowFlat	None	2025-12-07 22:22:33.155515+00	4	8	2025-11-28	Off Season 2025	challengermode
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	f7158e1d-4e03-4ad1-b85f-b61d5829f48b	3	WizardRod	None	5-60	Ball	None	2025-12-07 22:22:33.155515+00	4	8	2025-11-28	Off Season 2025	challengermode
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	55c70b52-40d6-4c65-bf69-6798204d54a3	1	Blast	Heavy	9-60	LowRush	None	2025-12-07 22:54:18.971288+00	2	8	2025-11-28	Off Season 2025	challengermode
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	55c70b52-40d6-4c65-bf69-6798204d54a3	2	PhoenixWing	None	None	Operate	None	2025-12-07 22:54:18.971288+00	2	8	2025-11-28	Off Season 2025	challengermode
9f30d2d1-c4ac-4e0b-3b11-08de278ff875	55c70b52-40d6-4c65-bf69-6798204d54a3	3	WizardRod	None	1-60	Rush	None	2025-12-07 22:54:18.971288+00	2	8	2025-11-28	Off Season 2025	challengermode
34db284a-9d01-44bb-3992-08de278ff875	52af5e3d-7923-4c50-96b1-b4ffae064824	1	KnightMail	None	9-60	Rush	None	2025-12-11 17:27:12.928526+00	1	28	2025-11-22	Off Season 2025	challengermode
34db284a-9d01-44bb-3992-08de278ff875	52af5e3d-7923-4c50-96b1-b4ffae064824	2	TyrannoBeat	None	1-60	Level	None	2025-12-11 17:27:12.928526+00	1	28	2025-11-22	Off Season 2025	challengermode
34db284a-9d01-44bb-3992-08de278ff875	52af5e3d-7923-4c50-96b1-b4ffae064824	3	SharkScale	None	1-70	LowRush	None	2025-12-11 17:27:12.928526+00	1	28	2025-11-22	Off Season 2025	challengermode
34db284a-9d01-44bb-3992-08de278ff875	9284b32b-f0e1-4aa9-83a7-dc11f1c62dcc	1	SilverWolf	None	9-70	FreeBall	None	2025-12-11 17:28:08.214494+00	2	28	2025-11-22	Off Season 2025	challengermode
34db284a-9d01-44bb-3992-08de278ff875	9284b32b-f0e1-4aa9-83a7-dc11f1c62dcc	2	WizardRod	None	9-60	Ball	None	2025-12-11 17:28:08.214494+00	2	28	2025-11-22	Off Season 2025	challengermode
34db284a-9d01-44bb-3992-08de278ff875	9284b32b-f0e1-4aa9-83a7-dc11f1c62dcc	3	PhoenixWing	None	1-60	Rush	None	2025-12-11 17:28:08.214494+00	2	28	2025-11-22	Off Season 2025	challengermode
34db284a-9d01-44bb-3992-08de278ff875	b6bf50b2-6b37-4ad7-aef3-e95c84a9c2fe	1	CobaltDragoon	None	5-60	Elevate	None	2025-12-11 17:28:55.051891+00	3	28	2025-11-22	Off Season 2025	challengermode
34db284a-9d01-44bb-3992-08de278ff875	b6bf50b2-6b37-4ad7-aef3-e95c84a9c2fe	2	WizardRod	None	9-60	Ball	None	2025-12-11 17:28:55.051891+00	3	28	2025-11-22	Off Season 2025	challengermode
34db284a-9d01-44bb-3992-08de278ff875	b6bf50b2-6b37-4ad7-aef3-e95c84a9c2fe	3	SharkScale	None	1-60	LowRush	None	2025-12-11 17:28:55.051891+00	3	28	2025-11-22	Off Season 2025	challengermode
34db284a-9d01-44bb-3992-08de278ff875	4d3f97b1-28ec-42de-bb6b-529c4f440b53	1	SilverWolf	None	3-60	Hexa	None	2025-12-11 17:30:03.811512+00	3	28	2025-11-22	Off Season 2025	challengermode
34db284a-9d01-44bb-3992-08de278ff875	4d3f97b1-28ec-42de-bb6b-529c4f440b53	2	WizardRod	None	9-60	Ball	None	2025-12-11 17:30:03.811512+00	3	28	2025-11-22	Off Season 2025	challengermode
34db284a-9d01-44bb-3992-08de278ff875	4d3f97b1-28ec-42de-bb6b-529c4f440b53	3	ImpactDrake	None	4-60	Kick	None	2025-12-11 17:30:03.811512+00	3	28	2025-11-22	Off Season 2025	challengermode
a874ee55-7a54-45dd-6dc1-08de30f37986	b956f704-a5cc-42c1-a76e-728cc030ce2a	1	SharkScale	None	1-70	LowRush	None	2025-12-18 21:48:52.776076+00	1	30	2025-12-06	Off Season 2025	challengermode
a874ee55-7a54-45dd-6dc1-08de30f37986	b956f704-a5cc-42c1-a76e-728cc030ce2a	2	Blast	Heavy	9-60	Taper	emperor	2025-12-18 21:48:52.776076+00	1	30	2025-12-06	Off Season 2025	challengermode
a874ee55-7a54-45dd-6dc1-08de30f37986	b956f704-a5cc-42c1-a76e-728cc030ce2a	3	SilverWolf	None	9-70	FreeBall	None	2025-12-18 21:48:52.776076+00	1	30	2025-12-06	Off Season 2025	challengermode
a874ee55-7a54-45dd-6dc1-08de30f37986	f6f47a62-9aa5-4303-8b1c-d4caefdc509e	1	ImpactDrake	None	4-60	Rush	None	2025-12-18 21:49:34.866512+00	2	30	2025-12-06	Off Season 2025	challengermode
a874ee55-7a54-45dd-6dc1-08de30f37986	f6f47a62-9aa5-4303-8b1c-d4caefdc509e	2	WizardRod	None	1-60	Hexa	None	2025-12-18 21:49:34.866512+00	2	30	2025-12-06	Off Season 2025	challengermode
a874ee55-7a54-45dd-6dc1-08de30f37986	f6f47a62-9aa5-4303-8b1c-d4caefdc509e	3	SharkScale	None	4-50	LowRush	None	2025-12-18 21:49:34.866512+00	2	30	2025-12-06	Off Season 2025	challengermode
a874ee55-7a54-45dd-6dc1-08de30f37986	3432caad-f9ac-48c0-8011-22d32680a889	1	HoverWyvern	None	1-60	Kick	None	2025-12-18 21:50:12.457495+00	3	30	2025-12-06	Off Season 2025	challengermode
a874ee55-7a54-45dd-6dc1-08de30f37986	3432caad-f9ac-48c0-8011-22d32680a889	2	WizardRod	None	9-60	Ball	None	2025-12-18 21:50:12.457495+00	3	30	2025-12-06	Off Season 2025	challengermode
a874ee55-7a54-45dd-6dc1-08de30f37986	3432caad-f9ac-48c0-8011-22d32680a889	3	SilverWolf	None	5-60	FreeBall	None	2025-12-18 21:50:12.457495+00	3	30	2025-12-06	Off Season 2025	challengermode
a874ee55-7a54-45dd-6dc1-08de30f37986	9515229f-3cf7-4870-9b17-42516832c2fa	1	GolemRock	None	3-60	FreeBall	None	2025-12-18 21:50:44.658457+00	3	30	2025-12-06	Off Season 2025	challengermode
a874ee55-7a54-45dd-6dc1-08de30f37986	9515229f-3cf7-4870-9b17-42516832c2fa	2	WizardRod	None	9-60	Ball	None	2025-12-18 21:50:44.658457+00	3	30	2025-12-06	Off Season 2025	challengermode
a874ee55-7a54-45dd-6dc1-08de30f37986	9515229f-3cf7-4870-9b17-42516832c2fa	3	KnightMail	None	1-60	Rush	None	2025-12-18 21:50:44.658457+00	3	30	2025-12-06	Off Season 2025	challengermode
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	52af5e3d-7923-4c50-96b1-b4ffae064824	1	WizardRod	None	1-60	Hexa	None	2025-12-20 23:23:54.326195+00	1	24	2025-12-19	Off Season 2025	challengermode
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	52af5e3d-7923-4c50-96b1-b4ffae064824	2	SharkScale	None	1-70	LowRush	None	2025-12-20 23:23:54.326195+00	1	24	2025-12-19	Off Season 2025	challengermode
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	52af5e3d-7923-4c50-96b1-b4ffae064824	3	CobaltDragoon	None	9-60	Elevate	None	2025-12-20 23:23:54.326195+00	1	24	2025-12-19	Off Season 2025	challengermode
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	875ccc4e-4d96-4412-a7fc-b1460cf734a0	1	Blast	Heavy	9-60	Kick	emperor	2025-12-20 23:24:29.12171+00	2	24	2025-12-19	Off Season 2025	challengermode
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	875ccc4e-4d96-4412-a7fc-b1460cf734a0	2	SharkScale	None	1-60	LowRush	None	2025-12-20 23:24:29.12171+00	2	24	2025-12-19	Off Season 2025	challengermode
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	875ccc4e-4d96-4412-a7fc-b1460cf734a0	3	WizardRod	None	1-70	Hexa	None	2025-12-20 23:24:29.12171+00	2	24	2025-12-19	Off Season 2025	challengermode
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	1	SilverWolf	None	9-60	FreeBall	None	2025-12-20 23:25:20.561321+00	3	24	2025-12-19	Off Season 2025	challengermode
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	2	SharkScale	None	3-60	LowRush	None	2025-12-20 23:25:20.561321+00	3	24	2025-12-19	Off Season 2025	challengermode
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	3	WizardRod	None	1-60	Hexa	None	2025-12-20 23:25:20.561321+00	3	24	2025-12-19	Off Season 2025	challengermode
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	55c70b52-40d6-4c65-bf69-6798204d54a3	1	WizardRod	None	7-60	Hexa	None	2025-12-20 23:25:57.871752+00	3	24	2025-12-19	Off Season 2025	challengermode
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	55c70b52-40d6-4c65-bf69-6798204d54a3	2	DranSword	None	1-60	Rush	None	2025-12-20 23:25:57.871752+00	3	24	2025-12-19	Off Season 2025	challengermode
95ddef78-f74b-4ae6-7a0e-08de356b8cf5	55c70b52-40d6-4c65-bf69-6798204d54a3	3	SharkScale	None	3-60	LowRush	None	2025-12-20 23:25:57.871752+00	3	24	2025-12-19	Off Season 2025	challengermode
\.


--
-- Data for Name: kb_document; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kb_document (id, source_path, doc_type, slug, lang, frontmatter, content_hash, doc_version, git_sha, created_at, superseded_at) FROM stdin;
1150	knowledge/assist-blades/heavy.md	component	heavy	it	{"id": "assist_blade.heavy", "lang": "it", "slot": "assist_blade", "slug": "heavy", "type": "component", "status": "draft", "system": "CX", "aliases": ["Heavy"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Heavy"], "reference": "https://beyblade.wiki/heavy-assist-blade/", "doc_version": 1, "canonical_name": "Heavy"}	eb8071a2fc90b856648ae1b3bd67c3d54d9833216c020cad5dc59498c077ec60	5	7f84633	2026-08-22 13:52:58.967619+00	\N
649	knowledge/assist-blades/assault.md	component	assault	it	{"id": "assist_blade.assault", "lang": "it", "slot": "assist_blade", "slug": "assault", "type": "component", "status": "draft", "system": "CX", "aliases": ["Assault"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Assault"], "reference": "https://beyblade.wiki/assault-assist-blade/", "doc_version": 1, "canonical_name": "Assault"}	8e32ded98372a9f4396d3dd8b5ab78873705f1f7dc04d7fa3abbade5874af2d1	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
983	knowledge/assist-blades/assault.md	component	assault	it	{"id": "assist_blade.assault", "lang": "it", "slot": "assist_blade", "slug": "assault", "type": "component", "status": "draft", "system": "CX", "aliases": ["Assault"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Assault"], "reference": "https://beyblade.wiki/assault-assist-blade/", "doc_version": 1, "canonical_name": "Assault"}	bf426d1c6cb95500af22da277a2edd1408d58e826839c9c7cc933cc3fd1cb710	4	7f84633	2026-08-22 13:35:57.076988+00	\N
1151	knowledge/assist-blades/wheel.md	component	wheel	it	{"id": "assist_blade.wheel", "lang": "it", "slot": "assist_blade", "slug": "wheel", "type": "component", "status": "draft", "system": "CX", "aliases": ["Wheel"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Wheel"], "reference": "https://beyblade.wiki/wheel-assist-blade/", "doc_version": 1, "canonical_name": "Wheel"}	78819b5714c964274bf49c786ecb36c25f6f699e32aa702fa46b16fced94a3cd	5	7f84633	2026-08-22 13:52:58.967619+00	\N
650	knowledge/assist-blades/bumper.md	component	bumper	it	{"id": "assist_blade.bumper", "lang": "it", "slot": "assist_blade", "slug": "bumper", "type": "component", "status": "draft", "system": "CX", "aliases": ["Bumper"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Bumper"], "reference": "https://beyblade.wiki/bumper-assist-blade/", "doc_version": 1, "canonical_name": "Bumper"}	eee28799165fccc64202e92527d167cd61dbb6a68aa45a333a849ca3a2bfcd08	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
984	knowledge/assist-blades/bumper.md	component	bumper	it	{"id": "assist_blade.bumper", "lang": "it", "slot": "assist_blade", "slug": "bumper", "type": "component", "status": "draft", "system": "CX", "aliases": ["Bumper"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Bumper"], "reference": "https://beyblade.wiki/bumper-assist-blade/", "doc_version": 1, "canonical_name": "Bumper"}	eee28799165fccc64202e92527d167cd61dbb6a68aa45a333a849ca3a2bfcd08	4	7f84633	2026-08-22 13:35:57.076988+00	\N
1152	knowledge/bits/ball.md	component	ball	it	{"id": "bit.ball", "lang": "it", "slot": "bit", "slug": "ball", "type": "component", "status": "draft", "system": "BX", "aliases": ["Ball"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Ball"], "reference": "https://beyblade.wiki/ball-bit/", "doc_version": 1, "canonical_name": "Ball"}	a025a304ac45722b0b0001a76390c506fbafa8bf886c31dff5f629bcce975d39	5	7f84633	2026-08-22 13:52:58.967619+00	\N
1153	knowledge/bits/elevate.md	component	elevate	it	{"id": "bit.elevate", "lang": "it", "slot": "bit", "slug": "elevate", "type": "component", "status": "draft", "system": "BX", "aliases": ["E", "Elevate"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Elevate"], "reference": "https://beyblade.wiki/elevate-bit/", "doc_version": 1, "canonical_name": "Elevate"}	24e7102443f425550aa195b0e0f77db7cb2554158df1962a06ddcdf0e7ffd5c9	5	7f84633	2026-08-22 13:52:58.967619+00	\N
1002	knowledge/bits/free-ball.md	component	free-ball	it	{"id": "bit.free-ball", "lang": "it", "slot": "bit", "slug": "free-ball", "type": "component", "status": "draft", "system": "UX", "aliases": ["FB", "FreeBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Free_Ball"], "reference": "https://beyblade.wiki/free-ball-bit/", "doc_version": 1, "canonical_name": "FreeBall"}	34203ada6c3930ac13b8bb9957e0dcdca6ac1bd3c27834fc8779ce17261436ec	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
176	knowledge/assist-blades/heavy.md	component	heavy	it	{"id": "assist_blade.heavy", "lang": "it", "slot": "assist_blade", "slug": "heavy", "type": "component", "status": "draft", "system": "CX", "aliases": ["Heavy"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Heavy"], "reference": "https://beyblade.wiki/heavy-assist-blade/", "doc_version": 1, "canonical_name": "Heavy"}	b4661a868ba0a89f5c1fbda7557b0d78d53756b62a9892bc08b7381a9e66d45a	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1154	knowledge/bits/free-ball.md	component	free-ball	it	{"id": "bit.free-ball", "lang": "it", "slot": "bit", "slug": "free-ball", "type": "component", "status": "draft", "system": "UX", "aliases": ["FB", "FreeBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Free_Ball"], "reference": "https://beyblade.wiki/free-ball-bit/", "doc_version": 1, "canonical_name": "FreeBall"}	b426d0116abf12a112e890f3a5e8e4ba35fab7d4ddb66fc1489406585c147c63	5	7f84633	2026-08-22 13:52:58.967619+00	\N
177	knowledge/assist-blades/jaggy.md	component	jaggy	it	{"id": "assist_blade.jaggy", "lang": "it", "slot": "assist_blade", "slug": "jaggy", "type": "component", "status": "draft", "system": "CX", "aliases": ["Jaggy"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Jaggy"], "reference": "https://beyblade.wiki/jaggy-assist-blade/", "doc_version": 1, "canonical_name": "Jaggy"}	4aee2d09051f2708f2f8c9ab67950c335a46d8a8558ef9865f012712aac6d308	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1009	knowledge/bits/hexa.md	component	hexa	it	{"id": "bit.hexa", "lang": "it", "slot": "bit", "slug": "hexa", "type": "component", "status": "draft", "system": "UX", "aliases": ["H", "Hexa"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Hexa"], "reference": "https://beyblade.wiki/hexa-bit/", "doc_version": 1, "canonical_name": "Hexa"}	5ad4a92680b0620766447b52ce022099595fc750aa3b0ad0cc2ecd6a6523b736	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
178	knowledge/assist-blades/round.md	component	round	it	{"id": "assist_blade.round", "lang": "it", "slot": "assist_blade", "slug": "round", "type": "component", "status": "draft", "system": "CX", "aliases": ["Round"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Round"], "reference": "https://beyblade.wiki/round-assist-blade/", "doc_version": 1, "canonical_name": "Round"}	38c49859c140a323d63e15c320be39ae56b0377a03131e5886fd007ca6bcac64	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
34	knowledge/assist-blades/massive.md	component	massive	it	{"id": "assist_blade.massive", "lang": "it", "slot": "assist_blade", "slug": "massive", "type": "component", "status": "draft", "system": "CX", "aliases": ["Massive"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Massive"], "doc_version": 1, "canonical_name": "Massive"}	598d9860350ce992932716c3ca39872042308f68984d98668b58108ce1fdd3a2	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
1155	knowledge/bits/hexa.md	component	hexa	it	{"id": "bit.hexa", "lang": "it", "slot": "bit", "slug": "hexa", "type": "component", "status": "draft", "system": "UX", "aliases": ["H", "Hexa"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Hexa"], "reference": "https://beyblade.wiki/hexa-bit/", "doc_version": 1, "canonical_name": "Hexa"}	6acf8da8712204be6e357d0948ae308a73871ea151a3f940f990218a0c6eb642	5	7f84633	2026-08-22 13:52:58.967619+00	\N
179	knowledge/assist-blades/slash.md	component	slash	it	{"id": "assist_blade.slash", "lang": "it", "slot": "assist_blade", "slug": "slash", "type": "component", "status": "draft", "system": "CX", "aliases": ["Slash"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Slash"], "reference": "https://beyblade.wiki/slash-assist-blade/", "doc_version": 1, "canonical_name": "Slash"}	c604ffc8356662a9ca609098145d52e65f6b632b5b49a90ad256988bdf83763c	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1012	knowledge/bits/kick.md	component	kick	it	{"id": "bit.kick", "lang": "it", "slot": "bit", "slug": "kick", "type": "component", "status": "draft", "system": "CX", "aliases": ["K", "Kick"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Kick"], "reference": "https://beyblade.wiki/kick-bit/", "doc_version": 1, "canonical_name": "Kick"}	9d0c009517bfd0ec1f69af05334040ce2aca24d4d41524e2ab2e2994ac43b3f5	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
180	knowledge/assist-blades/turn.md	component	turn	it	{"id": "assist_blade.turn", "lang": "it", "slot": "assist_blade", "slug": "turn", "type": "component", "status": "draft", "system": "CX", "aliases": ["Turn"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Turn"], "reference": "https://beyblade.wiki/turn-assist-blade/", "doc_version": 1, "canonical_name": "Turn"}	5c5a87e8dfed88726b3a825e42080d1630d87624e9091fc9a8c9af928d399f66	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1156	knowledge/bits/kick.md	component	kick	it	{"id": "bit.kick", "lang": "it", "slot": "bit", "slug": "kick", "type": "component", "status": "draft", "system": "CX", "aliases": ["K", "Kick"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Kick"], "reference": "https://beyblade.wiki/kick-bit/", "doc_version": 1, "canonical_name": "Kick"}	6b02bce8592bebd2cedd728415f5ff1ec8b239a46add6ed6ccd2515d1faac1be	5	7f84633	2026-08-22 13:52:58.967619+00	\N
181	knowledge/assist-blades/wheel.md	component	wheel	it	{"id": "assist_blade.wheel", "lang": "it", "slot": "assist_blade", "slug": "wheel", "type": "component", "status": "draft", "system": "CX", "aliases": ["Wheel"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Wheel"], "reference": "https://beyblade.wiki/wheel-assist-blade/", "doc_version": 1, "canonical_name": "Wheel"}	764db8712b640300f3974ac09244ad40ae234d989ff762bb29f753a76632aed7	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1013	knowledge/bits/level.md	component	level	it	{"id": "bit.level", "lang": "it", "slot": "bit", "slug": "level", "type": "component", "status": "draft", "system": "UX", "aliases": ["Level"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Level"], "reference": "https://beyblade.wiki/level-bit/", "doc_version": 1, "canonical_name": "Level"}	cef3f8434ab2328a25a03bd76481a12f4254a59ec90d4b08b6078551e6f89eb4	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
182	knowledge/bits/accel.md	component	accel	it	{"id": "bit.accel", "lang": "it", "slot": "bit", "slug": "accel", "type": "component", "status": "draft", "system": "UX", "aliases": ["Accel"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Accel"], "reference": "https://beyblade.wiki/accel-bit/", "doc_version": 1, "canonical_name": "Accel"}	1a465bd6a42db54b906daf24e8367b66680839854405409ac12c7d2aa277df17	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1157	knowledge/bits/level.md	component	level	it	{"id": "bit.level", "lang": "it", "slot": "bit", "slug": "level", "type": "component", "status": "draft", "system": "UX", "aliases": ["Level"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Level"], "reference": "https://beyblade.wiki/level-bit/", "doc_version": 1, "canonical_name": "Level"}	167093cb4dcb144a67232f18956bd9c14abf8ec97ceec015c2691943da8e5810	5	7f84633	2026-08-22 13:52:58.967619+00	\N
183	knowledge/bits/ball.md	component	ball	it	{"id": "bit.ball", "lang": "it", "slot": "bit", "slug": "ball", "type": "component", "status": "draft", "system": "BX", "aliases": ["Ball"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Ball"], "reference": "https://beyblade.wiki/ball-bit/", "doc_version": 1, "canonical_name": "Ball"}	b702b54d8538f0b8e8a1fc2d49051b8bfa2ce4a9020e2153529fc9033775d6c5	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1014	knowledge/bits/low-flat.md	component	low-flat	it	{"id": "bit.low-flat", "lang": "it", "slot": "bit", "slug": "low-flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["LowFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Flat"], "reference": "https://beyblade.wiki/low-flat-bit/", "doc_version": 1, "canonical_name": "LowFlat"}	1f7f73d93bcc87e3be495e6df06f60c89180e4ce389e53e90f21dfd5b84c1f41	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
1158	knowledge/bits/low-flat.md	component	low-flat	it	{"id": "bit.low-flat", "lang": "it", "slot": "bit", "slug": "low-flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["LowFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Flat"], "reference": "https://beyblade.wiki/low-flat-bit/", "doc_version": 1, "canonical_name": "LowFlat"}	af6fcc506e248cdb4d3bf7d7bd0a42c872672517f611e22f92ef1ff8680cee5c	5	7f84633	2026-08-22 13:52:58.967619+00	\N
651	knowledge/assist-blades/charge.md	component	charge	it	{"id": "assist_blade.charge", "lang": "it", "slot": "assist_blade", "slug": "charge", "type": "component", "status": "draft", "system": "CX", "aliases": ["Charge"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Charge"], "reference": "https://beyblade.wiki/charge-assist-blade/", "doc_version": 1, "canonical_name": "Charge"}	67ddadf4f976266f5ec9f6a554de229c907167f23305d42e2308e26fffa0b74d	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
184	knowledge/bits/cyclone.md	component	cyclone	it	{"id": "bit.cyclone", "lang": "it", "slot": "bit", "slug": "cyclone", "type": "component", "status": "draft", "system": "BX", "aliases": ["Cyclone"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Cyclone"], "reference": "https://beyblade.wiki/cyclone-bit/", "doc_version": 1, "canonical_name": "Cyclone"}	f1680c236ee42c9ac990caf99c35b1e8f1e4be7b583a61f464e1d37405e5f9ea	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
39	knowledge/bits/bound-spike.md	component	bound-spike	it	{"id": "bit.bound-spike", "lang": "it", "slot": "bit", "slug": "bound-spike", "type": "component", "status": "draft", "system": "UX", "aliases": ["BoundSpike"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Bound_Spike"], "doc_version": 1, "canonical_name": "BoundSpike"}	3a61291af87c915aed903b92125b467371de6714d46dae139b78d986bcf5a265	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
1015	knowledge/bits/low-orb.md	component	low-orb	it	{"id": "bit.low-orb", "lang": "it", "slot": "bit", "slug": "low-orb", "type": "component", "status": "draft", "system": "CX", "aliases": ["LowOrb"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Orb"], "reference": "https://beyblade.wiki/low-orb-bit/", "doc_version": 1, "canonical_name": "LowOrb"}	010ddab95d0f05d1a85ec04ae5665d7dfb9d3a9ba968e3b065bf6d9013434224	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
985	knowledge/assist-blades/charge.md	component	charge	it	{"id": "assist_blade.charge", "lang": "it", "slot": "assist_blade", "slug": "charge", "type": "component", "status": "draft", "system": "CX", "aliases": ["Charge"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Charge"], "reference": "https://beyblade.wiki/charge-assist-blade/", "doc_version": 1, "canonical_name": "Charge"}	67ddadf4f976266f5ec9f6a554de229c907167f23305d42e2308e26fffa0b74d	4	7f84633	2026-08-22 13:35:57.076988+00	\N
185	knowledge/bits/disk-ball.md	component	disk-ball	it	{"id": "bit.disk-ball", "lang": "it", "slot": "bit", "slug": "disk-ball", "type": "component", "status": "draft", "system": "UX", "aliases": ["DiskBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Disk_Ball"], "reference": "https://beyblade.wiki/disk-ball-bit/", "doc_version": 1, "canonical_name": "DiskBall"}	a3c5932e0f12f65b75b5259744575f360e92b5bfb1a80226beb988a13125216d	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1159	knowledge/bits/low-orb.md	component	low-orb	it	{"id": "bit.low-orb", "lang": "it", "slot": "bit", "slug": "low-orb", "type": "component", "status": "draft", "system": "CX", "aliases": ["LowOrb"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Orb"], "reference": "https://beyblade.wiki/low-orb-bit/", "doc_version": 1, "canonical_name": "LowOrb"}	e0f14e4b603b5349a4034d2736ccc5095bfd5f468533537b1513b271f9a4e6cc	5	7f84633	2026-08-22 13:52:58.967619+00	\N
186	knowledge/bits/dot.md	component	dot	it	{"id": "bit.dot", "lang": "it", "slot": "bit", "slug": "dot", "type": "component", "status": "draft", "system": "BX", "aliases": ["Dot"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Dot"], "reference": "https://beyblade.wiki/dot-bit/", "doc_version": 1, "canonical_name": "Dot"}	655ce9e8ea4b2b04f60d9e904b7f31f272c4468e42eae6e983919781b28c128b	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1016	knowledge/bits/low-rush.md	component	low-rush	it	{"id": "bit.low-rush", "lang": "it", "slot": "bit", "slug": "low-rush", "type": "component", "status": "draft", "system": "UX", "aliases": ["LowRush", "LR"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Rush"], "reference": "https://beyblade.wiki/low-rush-bit/", "doc_version": 1, "canonical_name": "LowRush"}	23fddf4504ea3d0dd7983e1359abce37097efcd3e6c43f8dde7934db3414add1	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
187	knowledge/bits/elevate.md	component	elevate	it	{"id": "bit.elevate", "lang": "it", "slot": "bit", "slug": "elevate", "type": "component", "status": "draft", "system": "BX", "aliases": ["E", "Elevate"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Elevate"], "reference": "https://beyblade.wiki/elevate-bit/", "doc_version": 1, "canonical_name": "Elevate"}	69a1ad83f84d06ab4528ed1182e2b38f5a1165ddc15f81c4521ecd0ed0e0d851	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1160	knowledge/bits/low-rush.md	component	low-rush	it	{"id": "bit.low-rush", "lang": "it", "slot": "bit", "slug": "low-rush", "type": "component", "status": "draft", "system": "UX", "aliases": ["LowRush", "LR"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Rush"], "reference": "https://beyblade.wiki/low-rush-bit/", "doc_version": 1, "canonical_name": "LowRush"}	d2c361c4f56d53054cf1c03ff4805b61d8db36684f5edeaa121bb71aec7af83c	5	7f84633	2026-08-22 13:52:58.967619+00	\N
188	knowledge/bits/flat.md	component	flat	it	{"id": "bit.flat", "lang": "it", "slot": "bit", "slug": "flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["Flat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Flat"], "reference": "https://beyblade.wiki/flat-bit/", "doc_version": 1, "canonical_name": "Flat"}	d2e499e24591d59673a301ebcc8f9f2c8b2b9fc271d7223e3dff044b118e01ea	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1021	knowledge/bits/orb.md	component	orb	it	{"id": "bit.orb", "lang": "it", "slot": "bit", "slug": "orb", "type": "component", "status": "draft", "system": "BX", "aliases": ["Orb"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Orb"], "reference": "https://beyblade.wiki/orb-bit/", "doc_version": 1, "canonical_name": "Orb"}	0f4901f0334e1094aa1f7b0856b7e74c705aad7106df0880b6afd740fb915f74	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
189	knowledge/bits/free-ball.md	component	free-ball	it	{"id": "bit.free-ball", "lang": "it", "slot": "bit", "slug": "free-ball", "type": "component", "status": "draft", "system": "UX", "aliases": ["FB", "FreeBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Free_Ball"], "reference": "https://beyblade.wiki/free-ball-bit/", "doc_version": 1, "canonical_name": "FreeBall"}	34203ada6c3930ac13b8bb9957e0dcdca6ac1bd3c27834fc8779ce17261436ec	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1161	knowledge/bits/orb.md	component	orb	it	{"id": "bit.orb", "lang": "it", "slot": "bit", "slug": "orb", "type": "component", "status": "draft", "system": "BX", "aliases": ["Orb"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Orb"], "reference": "https://beyblade.wiki/orb-bit/", "doc_version": 1, "canonical_name": "Orb"}	7d3a58c7d96b3de2a0be571cb6f4b5f39e66c2a7f10a4c0d155566a51bcc3886	5	7f84633	2026-08-22 13:52:58.967619+00	\N
652	knowledge/assist-blades/dual.md	component	dual	it	{"id": "assist_blade.dual", "lang": "it", "slot": "assist_blade", "slug": "dual", "type": "component", "status": "draft", "system": "CX", "aliases": ["Dual"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Dual"], "reference": "https://beyblade.wiki/dual-assist-blade/", "doc_version": 1, "canonical_name": "Dual"}	6b95ad2d8d8f60e47f7d69df65f82b6a427b52cd81ec565bb09c3eec56d6c171	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
190	knowledge/bits/gear-ball.md	component	gear-ball	it	{"id": "bit.gear-ball", "lang": "it", "slot": "bit", "slug": "gear-ball", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Ball"], "reference": "https://beyblade.wiki/gear-ball-bit/", "doc_version": 1, "canonical_name": "GearBall"}	4fbacd6a048829648b928a51dc1f9bde27e3949900f4af9b632df584aa3671c3	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
987	knowledge/assist-blades/heavy.md	component	heavy	it	{"id": "assist_blade.heavy", "lang": "it", "slot": "assist_blade", "slug": "heavy", "type": "component", "status": "draft", "system": "CX", "aliases": ["Heavy"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Heavy"], "reference": "https://beyblade.wiki/heavy-assist-blade/", "doc_version": 1, "canonical_name": "Heavy"}	b4661a868ba0a89f5c1fbda7557b0d78d53756b62a9892bc08b7381a9e66d45a	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
191	knowledge/bits/gear-flat.md	component	gear-flat	it	{"id": "bit.gear-flat", "lang": "it", "slot": "bit", "slug": "gear-flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Flat"], "reference": "https://beyblade.wiki/gear-flat-bit/", "doc_version": 1, "canonical_name": "GearFlat"}	977b98b8b282ddbb61fc82077c97a8e1587d3f9812289f01f357a35e5508780a	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1022	knowledge/bits/point.md	component	point	it	{"id": "bit.point", "lang": "it", "slot": "bit", "slug": "point", "type": "component", "status": "draft", "system": "BX", "aliases": ["Point"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Point"], "reference": "https://beyblade.wiki/point-bit/", "doc_version": 1, "canonical_name": "Point"}	4eefd82f885ea8d2991d2368280629e709e7b0cc33851cb52d37e1761361d374	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
192	knowledge/bits/gear-needle.md	component	gear-needle	it	{"id": "bit.gear-needle", "lang": "it", "slot": "bit", "slug": "gear-needle", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Needle"], "reference": "https://beyblade.wiki/gear-needle-bit/", "doc_version": 1, "canonical_name": "GearNeedle"}	ec7f2371dfa756bd67f2ed7f9dd6a6c5acbdf548d168486149d26db7ab08a84c	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1162	knowledge/bits/point.md	component	point	it	{"id": "bit.point", "lang": "it", "slot": "bit", "slug": "point", "type": "component", "status": "draft", "system": "BX", "aliases": ["Point"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Point"], "reference": "https://beyblade.wiki/point-bit/", "doc_version": 1, "canonical_name": "Point"}	f2fcfeb31f55c38b9aae9ee94f656960cc3c01c9afd5beb9bb1fcc055470e31a	5	7f84633	2026-08-22 13:52:58.967619+00	\N
986	knowledge/assist-blades/dual.md	component	dual	it	{"id": "assist_blade.dual", "lang": "it", "slot": "assist_blade", "slug": "dual", "type": "component", "status": "draft", "system": "CX", "aliases": ["Dual"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Dual"], "reference": "https://beyblade.wiki/dual-assist-blade/", "doc_version": 1, "canonical_name": "Dual"}	6b95ad2d8d8f60e47f7d69df65f82b6a427b52cd81ec565bb09c3eec56d6c171	4	7f84633	2026-08-22 13:35:57.076988+00	\N
193	knowledge/bits/gear-point.md	component	gear-point	it	{"id": "bit.gear-point", "lang": "it", "slot": "bit", "slug": "gear-point", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearPoint"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Point"], "reference": "https://beyblade.wiki/gear-point-bit/", "doc_version": 1, "canonical_name": "GearPoint"}	a6da4b346a1e5776b16f6223dc6156c563c23226204d1c69ec82bf03d9455ce2	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1024	knowledge/bits/rubber-accel.md	component	rubber-accel	it	{"id": "bit.rubber-accel", "lang": "it", "slot": "bit", "slug": "rubber-accel", "type": "component", "status": "draft", "system": "UX", "aliases": ["RubberAccel"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Rubber_Accel"], "doc_version": 1, "canonical_name": "RubberAccel"}	9b026f24d15e71e330f092e7b6ae26e59b6d1dde43f786474fc79e3c9367f191	3	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
194	knowledge/bits/gear-rush.md	component	gear-rush	it	{"id": "bit.gear-rush", "lang": "it", "slot": "bit", "slug": "gear-rush", "type": "component", "status": "draft", "system": "CX", "aliases": ["GearRush"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Rush"], "reference": "https://beyblade.wiki/gear-rush-bit/", "doc_version": 1, "canonical_name": "GearRush"}	7fb2e67a3e212b4bbe9e269dfe4573889a7add982179bb351810ba7f42885933	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1163	knowledge/bits/rubber-accel.md	component	rubber-accel	it	{"id": "bit.rubber-accel", "lang": "it", "slot": "bit", "slug": "rubber-accel", "type": "component", "status": "draft", "system": "UX", "aliases": ["RubberAccel"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Rubber_Accel"], "doc_version": 1, "canonical_name": "RubberAccel"}	16d526364c73e6a01638bb3e49f91e81f0880163a125959b19cbe87b511e3534	4	7f84633	2026-08-22 13:52:58.967619+00	\N
653	knowledge/assist-blades/heavy.md	component	heavy	it	{"id": "assist_blade.heavy", "lang": "it", "slot": "assist_blade", "slug": "heavy", "type": "component", "status": "draft", "system": "CX", "aliases": ["Heavy"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Heavy"], "reference": "https://beyblade.wiki/heavy-assist-blade/", "doc_version": 1, "canonical_name": "Heavy"}	b4661a868ba0a89f5c1fbda7557b0d78d53756b62a9892bc08b7381a9e66d45a	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
195	knowledge/bits/glide.md	component	glide	it	{"id": "bit.glide", "lang": "it", "slot": "bit", "slug": "glide", "type": "component", "status": "draft", "system": "UX", "aliases": ["Glide"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Glide"], "reference": "https://beyblade.wiki/glide-bit/", "doc_version": 1, "canonical_name": "Glide"}	72bf03568ef6d107f2768896418fd929119b7c61995bf65d069664e478bc5415	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1025	knowledge/bits/rush.md	component	rush	it	{"id": "bit.rush", "lang": "it", "slot": "bit", "slug": "rush", "type": "component", "status": "draft", "system": "BX", "aliases": ["R", "Rush"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Rush"], "reference": "https://beyblade.wiki/rush-bit/", "doc_version": 1, "canonical_name": "Rush"}	08ba84e548cf1671c8c3fecc9e358c9d0a18af1940ad30a6cde6201182ec0b8d	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
196	knowledge/bits/hexa.md	component	hexa	it	{"id": "bit.hexa", "lang": "it", "slot": "bit", "slug": "hexa", "type": "component", "status": "draft", "system": "UX", "aliases": ["H", "Hexa"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Hexa"], "reference": "https://beyblade.wiki/hexa-bit/", "doc_version": 1, "canonical_name": "Hexa"}	5ad4a92680b0620766447b52ce022099595fc750aa3b0ad0cc2ecd6a6523b736	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1164	knowledge/bits/rush.md	component	rush	it	{"id": "bit.rush", "lang": "it", "slot": "bit", "slug": "rush", "type": "component", "status": "draft", "system": "BX", "aliases": ["R", "Rush"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Rush"], "reference": "https://beyblade.wiki/rush-bit/", "doc_version": 1, "canonical_name": "Rush"}	b0f68e0f052db2367c6234de1a5c863566750331cbc2a55d947134579055d078	5	7f84633	2026-08-22 13:52:58.967619+00	\N
197	knowledge/bits/high-needle.md	component	high-needle	it	{"id": "bit.high-needle", "lang": "it", "slot": "bit", "slug": "high-needle", "type": "component", "status": "draft", "system": "BX", "aliases": ["HighNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_High_Needle"], "reference": "https://beyblade.wiki/high-needle-bit/", "doc_version": 1, "canonical_name": "HighNeedle"}	4bf2a6b42938e76dadbd3952238539275c52584d1f204cae2466bb4e948f537a	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1165	knowledge/bits/taper.md	component	taper	it	{"id": "bit.taper", "lang": "it", "slot": "bit", "slug": "taper", "type": "component", "status": "draft", "system": "BX", "aliases": ["Taper"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Taper"], "reference": "https://beyblade.wiki/taper-bit/", "doc_version": 1, "canonical_name": "Taper"}	0290c59e66a1490e2bccb9436a7847b77259d9cc431216ed584dd7f5b31750ef	5	7f84633	2026-08-22 13:52:58.967619+00	\N
198	knowledge/bits/high-taper.md	component	high-taper	it	{"id": "bit.high-taper", "lang": "it", "slot": "bit", "slug": "high-taper", "type": "component", "status": "draft", "system": "BX", "aliases": ["HighTaper"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_High_Taper"], "reference": "https://beyblade.wiki/high-taper-bit/", "doc_version": 1, "canonical_name": "HighTaper"}	f93a738a063efef1b2abdaa2928d3d28c44904736d41bab319850aef0078d29c	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
654	knowledge/assist-blades/jaggy.md	component	jaggy	it	{"id": "assist_blade.jaggy", "lang": "it", "slot": "assist_blade", "slug": "jaggy", "type": "component", "status": "draft", "system": "CX", "aliases": ["Jaggy"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Jaggy"], "reference": "https://beyblade.wiki/jaggy-assist-blade/", "doc_version": 1, "canonical_name": "Jaggy"}	4aee2d09051f2708f2f8c9ab67950c335a46d8a8558ef9865f012712aac6d308	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1031	knowledge/bits/under-needle.md	component	under-needle	it	{"id": "bit.under-needle", "lang": "it", "slot": "bit", "slug": "under-needle", "type": "component", "status": "draft", "system": "UX", "aliases": ["UnderNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Under_Needle"], "reference": "https://beyblade.wiki/under-needle-bit/", "doc_version": 1, "canonical_name": "UnderNeedle"}	726ae593124520868324f9d6eb0d96533ec99a68fb373ee535c24111bb819e83	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
199	knowledge/bits/kick.md	component	kick	it	{"id": "bit.kick", "lang": "it", "slot": "bit", "slug": "kick", "type": "component", "status": "draft", "system": "CX", "aliases": ["K", "Kick"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Kick"], "reference": "https://beyblade.wiki/kick-bit/", "doc_version": 1, "canonical_name": "Kick"}	9d0c009517bfd0ec1f69af05334040ce2aca24d4d41524e2ab2e2994ac43b3f5	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1166	knowledge/bits/under-needle.md	component	under-needle	it	{"id": "bit.under-needle", "lang": "it", "slot": "bit", "slug": "under-needle", "type": "component", "status": "draft", "system": "UX", "aliases": ["UnderNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Under_Needle"], "reference": "https://beyblade.wiki/under-needle-bit/", "doc_version": 1, "canonical_name": "UnderNeedle"}	ee80917f1c300abae989fcc2810a6c51fc9fb49e580fb8ed42c2c7cdbff6a386	5	7f84633	2026-08-22 13:52:58.967619+00	\N
200	knowledge/bits/level.md	component	level	it	{"id": "bit.level", "lang": "it", "slot": "bit", "slug": "level", "type": "component", "status": "draft", "system": "UX", "aliases": ["Level"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Level"], "reference": "https://beyblade.wiki/level-bit/", "doc_version": 1, "canonical_name": "Level"}	cef3f8434ab2328a25a03bd76481a12f4254a59ec90d4b08b6078551e6f89eb4	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1032	knowledge/bits/unite.md	component	unite	it	{"id": "bit.unite", "lang": "it", "slot": "bit", "slug": "unite", "type": "component", "status": "draft", "system": "BX", "aliases": ["Unite"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Unite"], "reference": "https://beyblade.wiki/unite-bit/", "doc_version": 1, "canonical_name": "Unite"}	491ba7cd7581c048e4d36658421d577fe3051e1150f20a3d29656bbf47249079	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
201	knowledge/bits/low-flat.md	component	low-flat	it	{"id": "bit.low-flat", "lang": "it", "slot": "bit", "slug": "low-flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["LowFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Flat"], "reference": "https://beyblade.wiki/low-flat-bit/", "doc_version": 1, "canonical_name": "LowFlat"}	1f7f73d93bcc87e3be495e6df06f60c89180e4ce389e53e90f21dfd5b84c1f41	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1167	knowledge/bits/unite.md	component	unite	it	{"id": "bit.unite", "lang": "it", "slot": "bit", "slug": "unite", "type": "component", "status": "draft", "system": "BX", "aliases": ["Unite"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Unite"], "reference": "https://beyblade.wiki/unite-bit/", "doc_version": 1, "canonical_name": "Unite"}	b864eb2e1adcf6a61ec6bc53f85d0c20a73071a27f555e0e4d3507940a0c6e82	5	7f84633	2026-08-22 13:52:58.967619+00	\N
988	knowledge/assist-blades/jaggy.md	component	jaggy	it	{"id": "assist_blade.jaggy", "lang": "it", "slot": "assist_blade", "slug": "jaggy", "type": "component", "status": "draft", "system": "CX", "aliases": ["Jaggy"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Jaggy"], "reference": "https://beyblade.wiki/jaggy-assist-blade/", "doc_version": 1, "canonical_name": "Jaggy"}	4aee2d09051f2708f2f8c9ab67950c335a46d8a8558ef9865f012712aac6d308	4	7f84633	2026-08-22 13:35:57.076988+00	\N
655	knowledge/assist-blades/massive.md	component	massive	it	{"id": "assist_blade.massive", "lang": "it", "slot": "assist_blade", "slug": "massive", "type": "component", "status": "draft", "system": "CX", "aliases": ["Massive"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Massive"], "doc_version": 1, "canonical_name": "Massive"}	598d9860350ce992932716c3ca39872042308f68984d98668b58108ce1fdd3a2	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
202	knowledge/bits/low-orb.md	component	low-orb	it	{"id": "bit.low-orb", "lang": "it", "slot": "bit", "slug": "low-orb", "type": "component", "status": "draft", "system": "CX", "aliases": ["LowOrb"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Orb"], "reference": "https://beyblade.wiki/low-orb-bit/", "doc_version": 1, "canonical_name": "LowOrb"}	010ddab95d0f05d1a85ec04ae5665d7dfb9d3a9ba968e3b065bf6d9013434224	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1034	knowledge/bits/wedge.md	component	wedge	it	{"id": "bit.wedge", "lang": "it", "slot": "bit", "slug": "wedge", "type": "component", "status": "draft", "system": "CX", "aliases": ["Wedge"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Wedge"], "reference": "https://beyblade.wiki/wedge-bit/", "doc_version": 1, "canonical_name": "Wedge"}	3cbb24d30a560860a0486176253e61ae079c634d780c615e752846b4ef7de3d2	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
203	knowledge/bits/low-rush.md	component	low-rush	it	{"id": "bit.low-rush", "lang": "it", "slot": "bit", "slug": "low-rush", "type": "component", "status": "draft", "system": "UX", "aliases": ["LowRush", "LR"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Rush"], "reference": "https://beyblade.wiki/low-rush-bit/", "doc_version": 1, "canonical_name": "LowRush"}	23fddf4504ea3d0dd7983e1359abce37097efcd3e6c43f8dde7934db3414add1	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1168	knowledge/bits/wedge.md	component	wedge	it	{"id": "bit.wedge", "lang": "it", "slot": "bit", "slug": "wedge", "type": "component", "status": "draft", "system": "CX", "aliases": ["Wedge"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Wedge"], "reference": "https://beyblade.wiki/wedge-bit/", "doc_version": 1, "canonical_name": "Wedge"}	49cf6980956c5852fd01ca9a21697b50820c691f290d7d5be2bb5c1f98c77823	5	7f84633	2026-08-22 13:52:58.967619+00	\N
204	knowledge/bits/merge.md	component	merge	it	{"id": "bit.merge", "lang": "it", "slot": "bit", "slug": "merge", "type": "component", "status": "draft", "system": "BX", "aliases": ["Merge"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Merge"], "reference": "https://beyblade.wiki/merge-bit/", "doc_version": 1, "canonical_name": "Merge"}	f97d88c1e34bdf7fc31295093fb7822f8134a8e7c73651737e41b3f675ad6621	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
989	knowledge/assist-blades/massive.md	component	massive	it	{"id": "assist_blade.massive", "lang": "it", "slot": "assist_blade", "slug": "massive", "type": "component", "status": "draft", "system": "CX", "aliases": ["Massive"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Massive"], "doc_version": 1, "canonical_name": "Massive"}	598d9860350ce992932716c3ca39872042308f68984d98668b58108ce1fdd3a2	3	7f84633	2026-08-22 13:35:57.076988+00	\N
656	knowledge/assist-blades/round.md	component	round	it	{"id": "assist_blade.round", "lang": "it", "slot": "assist_blade", "slug": "round", "type": "component", "status": "draft", "system": "CX", "aliases": ["Round"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Round"], "reference": "https://beyblade.wiki/round-assist-blade/", "doc_version": 1, "canonical_name": "Round"}	38c49859c140a323d63e15c320be39ae56b0377a03131e5886fd007ca6bcac64	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
990	knowledge/assist-blades/round.md	component	round	it	{"id": "assist_blade.round", "lang": "it", "slot": "assist_blade", "slug": "round", "type": "component", "status": "draft", "system": "CX", "aliases": ["Round"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Round"], "reference": "https://beyblade.wiki/round-assist-blade/", "doc_version": 1, "canonical_name": "Round"}	38c49859c140a323d63e15c320be39ae56b0377a03131e5886fd007ca6bcac64	4	7f84633	2026-08-22 13:35:57.076988+00	\N
657	knowledge/assist-blades/slash.md	component	slash	it	{"id": "assist_blade.slash", "lang": "it", "slot": "assist_blade", "slug": "slash", "type": "component", "status": "draft", "system": "CX", "aliases": ["Slash"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Slash"], "reference": "https://beyblade.wiki/slash-assist-blade/", "doc_version": 1, "canonical_name": "Slash"}	c604ffc8356662a9ca609098145d52e65f6b632b5b49a90ad256988bdf83763c	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
991	knowledge/assist-blades/slash.md	component	slash	it	{"id": "assist_blade.slash", "lang": "it", "slot": "assist_blade", "slug": "slash", "type": "component", "status": "draft", "system": "CX", "aliases": ["Slash"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Slash"], "reference": "https://beyblade.wiki/slash-assist-blade/", "doc_version": 1, "canonical_name": "Slash"}	c604ffc8356662a9ca609098145d52e65f6b632b5b49a90ad256988bdf83763c	4	7f84633	2026-08-22 13:35:57.076988+00	\N
1036	knowledge/blades/aero-pegasus.md	component	aero-pegasus	it	{"id": "blade.aero-pegasus", "lang": "it", "slot": "blade", "slug": "aero-pegasus", "type": "component", "status": "draft", "system": "BX", "aliases": ["AeroPegasus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_AeroPegasus"], "reference": "https://beyblade.wiki/aero-pegasus-blade/", "doc_version": 1, "canonical_name": "AeroPegasus"}	e5c585aded350bd05e55db679f4cc4cdfa60d70c762a0ec886bace90734bac37	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
205	knowledge/bits/metal-needle.md	component	metal-needle	it	{"id": "bit.metal-needle", "lang": "it", "slot": "bit", "slug": "metal-needle", "type": "component", "status": "draft", "system": "UX", "aliases": ["MetalNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Metal_Needle"], "reference": "https://beyblade.wiki/metal-needle-bit/", "doc_version": 1, "canonical_name": "MetalNeedle"}	ebe4dcc3e09ec158a6ac0bd646c0ee8e4abec30dc0f6cfb82c3d179e51fb0ce0	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1169	knowledge/blades/aero-pegasus.md	component	aero-pegasus	it	{"id": "blade.aero-pegasus", "lang": "it", "slot": "blade", "slug": "aero-pegasus", "type": "component", "status": "draft", "system": "BX", "aliases": ["AeroPegasus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_AeroPegasus"], "reference": "https://beyblade.wiki/aero-pegasus-blade/", "doc_version": 1, "canonical_name": "AeroPegasus"}	0245e37fec1243edd4a3ca5d0844df7d382311b15ebd80d58becbfb7091dc880	5	7f84633	2026-08-22 13:52:58.967619+00	\N
206	knowledge/bits/needle.md	component	needle	it	{"id": "bit.needle", "lang": "it", "slot": "bit", "slug": "needle", "type": "component", "status": "draft", "system": "BX", "aliases": ["Needle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Needle"], "reference": "https://beyblade.wiki/needle-bit/", "doc_version": 1, "canonical_name": "Needle"}	199fbaa45a8c30880753e3257dc55b9f04dc59cac6460d8a02f9622fb9119ddf	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1040	knowledge/blades/blast.md	component	blast	it	{"id": "blade.blast", "lang": "it", "slot": "blade", "slug": "blast", "type": "component", "status": "draft", "system": "CX", "aliases": ["Blast"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Blast"], "reference": "https://beyblade.wiki/blast-main-blade/", "doc_version": 1, "canonical_name": "Blast"}	a32d3c07822f795bfaeecf201e01b24b3450f70348dc305e6d4f1e576ab4f3c7	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
658	knowledge/assist-blades/turn.md	component	turn	it	{"id": "assist_blade.turn", "lang": "it", "slot": "assist_blade", "slug": "turn", "type": "component", "status": "draft", "system": "CX", "aliases": ["Turn"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Turn"], "reference": "https://beyblade.wiki/turn-assist-blade/", "doc_version": 1, "canonical_name": "Turn"}	5c5a87e8dfed88726b3a825e42080d1630d87624e9091fc9a8c9af928d399f66	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
992	knowledge/assist-blades/turn.md	component	turn	it	{"id": "assist_blade.turn", "lang": "it", "slot": "assist_blade", "slug": "turn", "type": "component", "status": "draft", "system": "CX", "aliases": ["Turn"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Turn"], "reference": "https://beyblade.wiki/turn-assist-blade/", "doc_version": 1, "canonical_name": "Turn"}	5c5a87e8dfed88726b3a825e42080d1630d87624e9091fc9a8c9af928d399f66	4	7f84633	2026-08-22 13:35:57.076988+00	\N
207	knowledge/bits/operate.md	component	operate	it	{"id": "bit.operate", "lang": "it", "slot": "bit", "slug": "operate", "type": "component", "status": "draft", "system": null, "aliases": ["Operate"], "sources": [], "reference": "https://beyblade.wiki/operate-bit/", "doc_version": 1, "canonical_name": "Operate"}	e7d38605459f9435179a1a8781e18e186d5d16b024d13882bfb0504cf662e71c	1	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1170	knowledge/blades/blast.md	component	blast	it	{"id": "blade.blast", "lang": "it", "slot": "blade", "slug": "blast", "type": "component", "status": "draft", "system": "CX", "aliases": ["Blast"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Blast"], "reference": "https://beyblade.wiki/blast-main-blade/", "doc_version": 1, "canonical_name": "Blast"}	cbc004adb909d0ded084adbfca4131fd7a82c330cd70b86e4362934c6932a96a	5	7f84633	2026-08-22 13:52:58.967619+00	\N
208	knowledge/bits/orb.md	component	orb	it	{"id": "bit.orb", "lang": "it", "slot": "bit", "slug": "orb", "type": "component", "status": "draft", "system": "BX", "aliases": ["Orb"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Orb"], "reference": "https://beyblade.wiki/orb-bit/", "doc_version": 1, "canonical_name": "Orb"}	0f4901f0334e1094aa1f7b0856b7e74c705aad7106df0880b6afd740fb915f74	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1043	knowledge/blades/clock-mirage.md	component	clock-mirage	it	{"id": "blade.clock-mirage", "lang": "it", "slot": "blade", "slug": "clock-mirage", "type": "component", "status": "draft", "system": "UX", "aliases": ["ClockMirage"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ClockMirage"], "reference": "https://beyblade.wiki/clock-mirage-blade/", "doc_version": 1, "canonical_name": "ClockMirage"}	a2a913e6bfb3f4a10c44a6186983506dc1c2334bf41adb4dc23e0a16072b9dfd	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
209	knowledge/bits/point.md	component	point	it	{"id": "bit.point", "lang": "it", "slot": "bit", "slug": "point", "type": "component", "status": "draft", "system": "BX", "aliases": ["Point"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Point"], "reference": "https://beyblade.wiki/point-bit/", "doc_version": 1, "canonical_name": "Point"}	4eefd82f885ea8d2991d2368280629e709e7b0cc33851cb52d37e1761361d374	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1171	knowledge/blades/clock-mirage.md	component	clock-mirage	it	{"id": "blade.clock-mirage", "lang": "it", "slot": "blade", "slug": "clock-mirage", "type": "component", "status": "draft", "system": "UX", "aliases": ["ClockMirage"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ClockMirage"], "reference": "https://beyblade.wiki/clock-mirage-blade/", "doc_version": 1, "canonical_name": "ClockMirage"}	399968aa9612094a16b05f7050401b76b35d4ec30bd667852fd254d7c4a9b3b1	5	7f84633	2026-08-22 13:52:58.967619+00	\N
210	knowledge/bits/quake.md	component	quake	it	{"id": "bit.quake", "lang": "it", "slot": "bit", "slug": "quake", "type": "component", "status": "draft", "system": "BX", "aliases": ["Quake"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Quake"], "reference": "https://beyblade.wiki/quake-bit/", "doc_version": 1, "canonical_name": "Quake"}	cb9bdced8e54bbf3e08dc74763f3db613bf6af884b8fccf983b83d965158bbd0	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1044	knowledge/blades/cobalt-dragoon.md	component	cobalt-dragoon	it	{"id": "blade.cobalt-dragoon", "lang": "it", "slot": "blade", "slug": "cobalt-dragoon", "type": "component", "status": "draft", "system": "BX", "aliases": ["CobaltDragoon"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CobaltDragoon"], "reference": "https://beyblade.wiki/cobalt-dragoon-blade/", "doc_version": 1, "canonical_name": "CobaltDragoon"}	7af1dab0c09725dd23bec5e86244a4e725fae1568a15733249af850129c3cd4c	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
50	knowledge/bits/rubber-accel.md	component	rubber-accel	it	{"id": "bit.rubber-accel", "lang": "it", "slot": "bit", "slug": "rubber-accel", "type": "component", "status": "draft", "system": "UX", "aliases": ["RubberAccel"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Rubber_Accel"], "doc_version": 1, "canonical_name": "RubberAccel"}	9b026f24d15e71e330f092e7b6ae26e59b6d1dde43f786474fc79e3c9367f191	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
1172	knowledge/blades/cobalt-dragoon.md	component	cobalt-dragoon	it	{"id": "blade.cobalt-dragoon", "lang": "it", "slot": "blade", "slug": "cobalt-dragoon", "type": "component", "status": "draft", "system": "BX", "aliases": ["CobaltDragoon"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CobaltDragoon"], "reference": "https://beyblade.wiki/cobalt-dragoon-blade/", "doc_version": 1, "canonical_name": "CobaltDragoon"}	1c37db8a82c650a498cc01b077d00e6eb38bc8dc668c4e8b14b4b5ce721d3a59	5	7f84633	2026-08-22 13:52:58.967619+00	\N
211	knowledge/bits/rush.md	component	rush	it	{"id": "bit.rush", "lang": "it", "slot": "bit", "slug": "rush", "type": "component", "status": "draft", "system": "BX", "aliases": ["R", "Rush"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Rush"], "reference": "https://beyblade.wiki/rush-bit/", "doc_version": 1, "canonical_name": "Rush"}	08ba84e548cf1671c8c3fecc9e358c9d0a18af1940ad30a6cde6201182ec0b8d	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1052	knowledge/blades/dran-buster.md	component	dran-buster	it	{"id": "blade.dran-buster", "lang": "it", "slot": "blade", "slug": "dran-buster", "type": "component", "status": "draft", "system": "UX", "aliases": ["DranBuster"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranBuster"], "reference": "https://beyblade.wiki/dran-buster-blade/", "doc_version": 1, "canonical_name": "DranBuster"}	ae1b3240a1de6b4d0cc46f76ef56f6658515c9c931f5025aea9f6b27221ab127	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
212	knowledge/bits/spike.md	component	spike	it	{"id": "bit.spike", "lang": "it", "slot": "bit", "slug": "spike", "type": "component", "status": "draft", "system": "BX", "aliases": ["Spike"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Spike"], "reference": "https://beyblade.wiki/spike-bit/", "doc_version": 1, "canonical_name": "Spike"}	e8ea8d5d5e72ff0f75a289406c5ae147841a89b47dc161b4a6745bfb6563378c	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
213	knowledge/bits/taper.md	component	taper	it	{"id": "bit.taper", "lang": "it", "slot": "bit", "slug": "taper", "type": "component", "status": "draft", "system": "BX", "aliases": ["Taper"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Taper"], "reference": "https://beyblade.wiki/taper-bit/", "doc_version": 1, "canonical_name": "Taper"}	f537497de79b42fb03792adfbd08d6f2e87986c6a8320e23cce83c4cd2ad101d	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
659	knowledge/assist-blades/wheel.md	component	wheel	it	{"id": "assist_blade.wheel", "lang": "it", "slot": "assist_blade", "slug": "wheel", "type": "component", "status": "draft", "system": "CX", "aliases": ["Wheel"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Wheel"], "reference": "https://beyblade.wiki/wheel-assist-blade/", "doc_version": 1, "canonical_name": "Wheel"}	764db8712b640300f3974ac09244ad40ae234d989ff762bb29f753a76632aed7	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
993	knowledge/assist-blades/wheel.md	component	wheel	it	{"id": "assist_blade.wheel", "lang": "it", "slot": "assist_blade", "slug": "wheel", "type": "component", "status": "draft", "system": "CX", "aliases": ["Wheel"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Wheel"], "reference": "https://beyblade.wiki/wheel-assist-blade/", "doc_version": 1, "canonical_name": "Wheel"}	764db8712b640300f3974ac09244ad40ae234d989ff762bb29f753a76632aed7	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
1173	knowledge/blades/dran-buster.md	component	dran-buster	it	{"id": "blade.dran-buster", "lang": "it", "slot": "blade", "slug": "dran-buster", "type": "component", "status": "draft", "system": "UX", "aliases": ["DranBuster"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranBuster"], "reference": "https://beyblade.wiki/dran-buster-blade/", "doc_version": 1, "canonical_name": "DranBuster"}	b0955e776afcedfd68cda91e39cd193580e299a9e2d96809e54581f702736489	5	7f84633	2026-08-22 13:52:58.967619+00	\N
214	knowledge/bits/trans-point.md	component	trans-point	it	{"id": "bit.trans-point", "lang": "it", "slot": "bit", "slug": "trans-point", "type": "component", "status": "draft", "system": "BX", "aliases": ["TransPoint"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Trans_Point"], "reference": "https://beyblade.wiki/trans-point-bit/", "doc_version": 1, "canonical_name": "TransPoint"}	b3675ac46ad98ed189dbcb54815ef9d7040dc8515338e2682dcc0bdc7cebada3	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1062	knowledge/blades/golem-rock.md	component	golem-rock	it	{"id": "blade.golem-rock", "lang": "it", "slot": "blade", "slug": "golem-rock", "type": "component", "status": "draft", "system": "UX", "aliases": ["GolemRock"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_GolemRock"], "reference": "https://beyblade.wiki/golem-rock-blade/", "doc_version": 1, "canonical_name": "GolemRock"}	3834108ae47f1c7b45a1971b129adc0d3a5c86727e49a77252732e87c2570e96	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
215	knowledge/bits/turbo.md	component	turbo	it	{"id": "bit.turbo", "lang": "it", "slot": "bit", "slug": "turbo", "type": "component", "status": "draft", "system": null, "aliases": ["Turbo"], "sources": [], "reference": "https://beyblade.wiki/turbo-bit/", "doc_version": 1, "canonical_name": "Turbo"}	adb1d006ee92479e3cdbe5717d455cead867555f5fd09b3c2cca748778141266	1	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1174	knowledge/blades/golem-rock.md	component	golem-rock	it	{"id": "blade.golem-rock", "lang": "it", "slot": "blade", "slug": "golem-rock", "type": "component", "status": "draft", "system": "UX", "aliases": ["GolemRock"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_GolemRock"], "reference": "https://beyblade.wiki/golem-rock-blade/", "doc_version": 1, "canonical_name": "GolemRock"}	06c57adac4f1db21f52f07b3599128fdeed58a2d4a86a70a20d846306ade4e88	5	7f84633	2026-08-22 13:52:58.967619+00	\N
216	knowledge/bits/under-flat.md	component	under-flat	it	{"id": "bit.under-flat", "lang": "it", "slot": "bit", "slug": "under-flat", "type": "component", "status": "draft", "system": "UX", "aliases": ["UnderFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Under_Flat"], "reference": "https://beyblade.wiki/under-flat-bit/", "doc_version": 1, "canonical_name": "UnderFlat"}	2d9128f2f36bdf8d6aa9264ec485119ea5524d397747a8b2ea84d4d92b2f9504	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1064	knowledge/blades/hells-hammer.md	component	hells-hammer	it	{"id": "blade.hells-hammer", "lang": "it", "slot": "blade", "slug": "hells-hammer", "type": "component", "status": "draft", "system": "UX", "aliases": ["HellsHammer"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsHammer"], "reference": "https://beyblade.wiki/hells-hammer-blade/", "doc_version": 1, "canonical_name": "HellsHammer"}	1814d04eac70523e14b49357c884bf6bad87f9e5331607caa306d55998c22ad3	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
217	knowledge/bits/under-needle.md	component	under-needle	it	{"id": "bit.under-needle", "lang": "it", "slot": "bit", "slug": "under-needle", "type": "component", "status": "draft", "system": "UX", "aliases": ["UnderNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Under_Needle"], "reference": "https://beyblade.wiki/under-needle-bit/", "doc_version": 1, "canonical_name": "UnderNeedle"}	726ae593124520868324f9d6eb0d96533ec99a68fb373ee535c24111bb819e83	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1175	knowledge/blades/hells-hammer.md	component	hells-hammer	it	{"id": "blade.hells-hammer", "lang": "it", "slot": "blade", "slug": "hells-hammer", "type": "component", "status": "draft", "system": "UX", "aliases": ["HellsHammer"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsHammer"], "reference": "https://beyblade.wiki/hells-hammer-blade/", "doc_version": 1, "canonical_name": "HellsHammer"}	9772fcee93938ba09e3e5e20e1923022ecead1edf4185eeecd6f1d6908acece6	5	7f84633	2026-08-22 13:52:58.967619+00	\N
218	knowledge/bits/unite.md	component	unite	it	{"id": "bit.unite", "lang": "it", "slot": "bit", "slug": "unite", "type": "component", "status": "draft", "system": "BX", "aliases": ["Unite"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Unite"], "reference": "https://beyblade.wiki/unite-bit/", "doc_version": 1, "canonical_name": "Unite"}	491ba7cd7581c048e4d36658421d577fe3051e1150f20a3d29656bbf47249079	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
219	knowledge/bits/vortex.md	component	vortex	it	{"id": "bit.vortex", "lang": "it", "slot": "bit", "slug": "vortex", "type": "component", "status": "draft", "system": "CX", "aliases": ["Vortex"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Vortex"], "reference": "https://beyblade.wiki/vortex-bit/", "doc_version": 1, "canonical_name": "Vortex"}	ea5190b76c2edd00fca326c7fbf78fd6d264d351b6205be4fcb4ccd032974e17	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
117	knowledge/ratchets/7-60.md	component	7-60	it	{"id": "ratchet.7-60", "lang": "it", "slot": "ratchet", "slug": "7-60", "type": "component", "status": "draft", "system": "UX", "aliases": ["7-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_7-60"], "doc_version": 1, "canonical_name": "7-60"}	e14b3b90e26def93ab57f8bc6acedfcccceeab8ddb36dd81b56bdbd29cbf8e7a	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
1176	knowledge/blades/hover-wyvern.md	component	hover-wyvern	it	{"id": "blade.hover-wyvern", "lang": "it", "slot": "blade", "slug": "hover-wyvern", "type": "component", "status": "draft", "system": "UX", "aliases": ["HoverWyvern"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Hover_Wyvern"], "doc_version": 1, "canonical_name": "HoverWyvern"}	e96dc77dc6815f2e81943d92367c05f9f04cc4d984ffd50adaab899971357af4	4	7f84633	2026-08-22 13:52:58.967619+00	\N
220	knowledge/bits/wedge.md	component	wedge	it	{"id": "bit.wedge", "lang": "it", "slot": "bit", "slug": "wedge", "type": "component", "status": "draft", "system": "CX", "aliases": ["Wedge"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Wedge"], "reference": "https://beyblade.wiki/wedge-bit/", "doc_version": 1, "canonical_name": "Wedge"}	3cbb24d30a560860a0486176253e61ae079c634d780c615e752846b4ef7de3d2	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1067	knowledge/blades/impact-drake.md	component	impact-drake	it	{"id": "blade.impact-drake", "lang": "it", "slot": "blade", "slug": "impact-drake", "type": "component", "status": "draft", "system": "UX", "aliases": ["ImpactDrake"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ImpactDrake"], "reference": "https://beyblade.wiki/impact-drake-blade/", "doc_version": 1, "canonical_name": "ImpactDrake"}	455683720bb2e4a83d562b5125c212242bf859f2c409b04c821116f7e1dfec57	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
221	knowledge/bits/zap.md	component	zap	it	{"id": "bit.zap", "lang": "it", "slot": "bit", "slug": "zap", "type": "component", "status": "draft", "system": "UX", "aliases": ["Zap"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Zap"], "reference": "https://beyblade.wiki/zap-bit/", "doc_version": 1, "canonical_name": "Zap"}	6d7344acbbd9d69a096e7c0959c0d3540d0bdc56cf9678cbe0bcae5e631924d0	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1177	knowledge/blades/impact-drake.md	component	impact-drake	it	{"id": "blade.impact-drake", "lang": "it", "slot": "blade", "slug": "impact-drake", "type": "component", "status": "draft", "system": "UX", "aliases": ["ImpactDrake"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ImpactDrake"], "reference": "https://beyblade.wiki/impact-drake-blade/", "doc_version": 1, "canonical_name": "ImpactDrake"}	4edcde7ca6476ce62d199f2906475de25b71b85a3b1d85d9b83c339f07b1d377	5	7f84633	2026-08-22 13:52:58.967619+00	\N
222	knowledge/blades/aero-pegasus.md	component	aero-pegasus	it	{"id": "blade.aero-pegasus", "lang": "it", "slot": "blade", "slug": "aero-pegasus", "type": "component", "status": "draft", "system": "BX", "aliases": ["AeroPegasus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_AeroPegasus"], "reference": "https://beyblade.wiki/aero-pegasus-blade/", "doc_version": 1, "canonical_name": "AeroPegasus"}	e5c585aded350bd05e55db679f4cc4cdfa60d70c762a0ec886bace90734bac37	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1070	knowledge/blades/knight-shield-blade.md	component	knight-shield-blade	it	{"id": "blade.knight-shield-blade", "lang": "it", "slot": "blade", "slug": "knight-shield-blade", "type": "component", "status": "draft", "system": "BX", "aliases": ["KnightShield", "knight-shield-blade"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightShield"], "reference": "https://beyblade.wiki/knight-shield-blade/", "doc_version": 1, "canonical_name": "KnightShield"}	c7ad8a1fe8258bcfadb51eb6f07fdf508e1db874121abd411dfbb0b28464daa5	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
223	knowledge/blades/arc.md	component	arc	it	{"id": "blade.arc", "lang": "it", "slot": "blade", "slug": "arc", "type": "component", "status": "draft", "system": "CX", "aliases": ["Arc"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Arc"], "reference": "https://beyblade.wiki/arc-main-blade/", "doc_version": 1, "canonical_name": "Arc"}	c6c72faedc4950b32c5dd9d04733011a06ededef34cb6a0aef3a996fd553fbd1	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1178	knowledge/blades/knight-shield-blade.md	component	knight-shield-blade	it	{"id": "blade.knight-shield-blade", "lang": "it", "slot": "blade", "slug": "knight-shield-blade", "type": "component", "status": "draft", "system": "BX", "aliases": ["KnightShield", "knight-shield-blade"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightShield"], "reference": "https://beyblade.wiki/knight-shield-blade/", "doc_version": 1, "canonical_name": "KnightShield"}	a9f3379cbf889fab87a8dfc70b234ea5f87ba279ccc5ac4a06034eb642673ca1	5	7f84633	2026-08-22 13:52:58.967619+00	\N
59	knowledge/blades/bear-scratch.md	component	bear-scratch	it	{"id": "blade.bear-scratch", "lang": "it", "slot": "blade", "slug": "bear-scratch", "type": "component", "status": "draft", "system": "BX", "aliases": ["BearScratch"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Savage_Bear"], "doc_version": 1, "canonical_name": "BearScratch"}	6664c185fcc408c5fddc6729423e0f16a8c3198b4d35292b427959b9ef67cf72	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
660	knowledge/bits/accel.md	component	accel	it	{"id": "bit.accel", "lang": "it", "slot": "bit", "slug": "accel", "type": "component", "status": "draft", "system": "UX", "aliases": ["Accel"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Accel"], "reference": "https://beyblade.wiki/accel-bit/", "doc_version": 1, "canonical_name": "Accel"}	1a465bd6a42db54b906daf24e8367b66680839854405409ac12c7d2aa277df17	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
994	knowledge/bits/accel.md	component	accel	it	{"id": "bit.accel", "lang": "it", "slot": "bit", "slug": "accel", "type": "component", "status": "draft", "system": "UX", "aliases": ["Accel"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Accel"], "reference": "https://beyblade.wiki/accel-bit/", "doc_version": 1, "canonical_name": "Accel"}	1a465bd6a42db54b906daf24e8367b66680839854405409ac12c7d2aa277df17	4	7f84633	2026-08-22 13:35:57.076988+00	\N
661	knowledge/bits/ball.md	component	ball	it	{"id": "bit.ball", "lang": "it", "slot": "bit", "slug": "ball", "type": "component", "status": "draft", "system": "BX", "aliases": ["Ball"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Ball"], "reference": "https://beyblade.wiki/ball-bit/", "doc_version": 1, "canonical_name": "Ball"}	b702b54d8538f0b8e8a1fc2d49051b8bfa2ce4a9020e2153529fc9033775d6c5	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
224	knowledge/blades/black-shell.md	component	black-shell	it	{"id": "blade.black-shell", "lang": "it", "slot": "blade", "slug": "black-shell", "type": "component", "status": "draft", "system": "BX", "aliases": ["BlackShell"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_BlackShell"], "reference": "https://beyblade.wiki/black-shell-blade/", "doc_version": 1, "canonical_name": "BlackShell"}	0890d5b32b56f141aef5d1b36a03d99350b3c700b4f7ca21e46cac770c6dcb67	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
995	knowledge/bits/ball.md	component	ball	it	{"id": "bit.ball", "lang": "it", "slot": "bit", "slug": "ball", "type": "component", "status": "draft", "system": "BX", "aliases": ["Ball"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Ball"], "reference": "https://beyblade.wiki/ball-bit/", "doc_version": 1, "canonical_name": "Ball"}	b702b54d8538f0b8e8a1fc2d49051b8bfa2ce4a9020e2153529fc9033775d6c5	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
225	knowledge/blades/blast.md	component	blast	it	{"id": "blade.blast", "lang": "it", "slot": "blade", "slug": "blast", "type": "component", "status": "draft", "system": "CX", "aliases": ["Blast"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Blast"], "reference": "https://beyblade.wiki/blast-main-blade/", "doc_version": 1, "canonical_name": "Blast"}	a32d3c07822f795bfaeecf201e01b24b3450f70348dc305e6d4f1e576ab4f3c7	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1081	knowledge/blades/phoenix-wing.md	component	phoenix-wing	it	{"id": "blade.phoenix-wing", "lang": "it", "slot": "blade", "slug": "phoenix-wing", "type": "component", "status": "draft", "system": "BX", "aliases": ["PhoenixSoar (Youngtoys)", "PhoenixWing", "Soar Phoenix"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixWing"], "reference": "https://beyblade.wiki/phoenix-wing-blade/", "doc_version": 1, "canonical_name": "PhoenixWing"}	e9df8e6ddc00c4d562d853a638c6169f988525e1eb374516efef4bd4d4610244	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
662	knowledge/bits/bound-spike.md	component	bound-spike	it	{"id": "bit.bound-spike", "lang": "it", "slot": "bit", "slug": "bound-spike", "type": "component", "status": "draft", "system": "UX", "aliases": ["BoundSpike"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Bound_Spike"], "doc_version": 1, "canonical_name": "BoundSpike"}	3a61291af87c915aed903b92125b467371de6714d46dae139b78d986bcf5a265	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
996	knowledge/bits/bound-spike.md	component	bound-spike	it	{"id": "bit.bound-spike", "lang": "it", "slot": "bit", "slug": "bound-spike", "type": "component", "status": "draft", "system": "UX", "aliases": ["BoundSpike"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Bound_Spike"], "doc_version": 1, "canonical_name": "BoundSpike"}	3a61291af87c915aed903b92125b467371de6714d46dae139b78d986bcf5a265	3	7f84633	2026-08-22 13:35:57.076988+00	\N
663	knowledge/bits/cyclone.md	component	cyclone	it	{"id": "bit.cyclone", "lang": "it", "slot": "bit", "slug": "cyclone", "type": "component", "status": "draft", "system": "BX", "aliases": ["Cyclone"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Cyclone"], "reference": "https://beyblade.wiki/cyclone-bit/", "doc_version": 1, "canonical_name": "Cyclone"}	f1680c236ee42c9ac990caf99c35b1e8f1e4be7b583a61f464e1d37405e5f9ea	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
226	knowledge/blades/brave.md	component	brave	it	{"id": "blade.brave", "lang": "it", "slot": "blade", "slug": "brave", "type": "component", "status": "draft", "system": "CX", "aliases": ["Brave"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Brave"], "reference": "https://beyblade.wiki/brave-main-blade/", "doc_version": 1, "canonical_name": "Brave"}	e6bffbc10c73a1b2fdaedaa55ce6b181f9a121a90834b22ebec62eb4119e684f	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1179	knowledge/blades/phoenix-wing.md	component	phoenix-wing	it	{"id": "blade.phoenix-wing", "lang": "it", "slot": "blade", "slug": "phoenix-wing", "type": "component", "status": "draft", "system": "BX", "aliases": ["PhoenixSoar (Youngtoys)", "PhoenixWing", "Soar Phoenix"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixWing"], "reference": "https://beyblade.wiki/phoenix-wing-blade/", "doc_version": 1, "canonical_name": "PhoenixWing"}	b0164a93d6c13a26fda81e2b75388391872b9d013f8bc211b9ec71938964e358	5	7f84633	2026-08-22 13:52:58.967619+00	\N
227	knowledge/blades/brush.md	component	brush	it	{"id": "blade.brush", "lang": "it", "slot": "blade", "slug": "brush", "type": "component", "status": "draft", "system": "CX", "aliases": ["Brush"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Brush"], "reference": "https://beyblade.wiki/brush-main-blade/", "doc_version": 1, "canonical_name": "Brush"}	6b392f9af65da6b5f629fbb0938487e8ca3a0b573d2d7b5124dd55ba1634092f	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
997	knowledge/bits/cyclone.md	component	cyclone	it	{"id": "bit.cyclone", "lang": "it", "slot": "bit", "slug": "cyclone", "type": "component", "status": "draft", "system": "BX", "aliases": ["Cyclone"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Cyclone"], "reference": "https://beyblade.wiki/cyclone-bit/", "doc_version": 1, "canonical_name": "Cyclone"}	f1680c236ee42c9ac990caf99c35b1e8f1e4be7b583a61f464e1d37405e5f9ea	4	7f84633	2026-08-22 13:35:57.076988+00	\N
664	knowledge/bits/disk-ball.md	component	disk-ball	it	{"id": "bit.disk-ball", "lang": "it", "slot": "bit", "slug": "disk-ball", "type": "component", "status": "draft", "system": "UX", "aliases": ["DiskBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Disk_Ball"], "reference": "https://beyblade.wiki/disk-ball-bit/", "doc_version": 1, "canonical_name": "DiskBall"}	a3c5932e0f12f65b75b5259744575f360e92b5bfb1a80226beb988a13125216d	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
998	knowledge/bits/disk-ball.md	component	disk-ball	it	{"id": "bit.disk-ball", "lang": "it", "slot": "bit", "slug": "disk-ball", "type": "component", "status": "draft", "system": "UX", "aliases": ["DiskBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Disk_Ball"], "reference": "https://beyblade.wiki/disk-ball-bit/", "doc_version": 1, "canonical_name": "DiskBall"}	a3c5932e0f12f65b75b5259744575f360e92b5bfb1a80226beb988a13125216d	4	7f84633	2026-08-22 13:35:57.076988+00	\N
665	knowledge/bits/dot.md	component	dot	it	{"id": "bit.dot", "lang": "it", "slot": "bit", "slug": "dot", "type": "component", "status": "draft", "system": "BX", "aliases": ["Dot"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Dot"], "reference": "https://beyblade.wiki/dot-bit/", "doc_version": 1, "canonical_name": "Dot"}	655ce9e8ea4b2b04f60d9e904b7f31f272c4468e42eae6e983919781b28c128b	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
999	knowledge/bits/dot.md	component	dot	it	{"id": "bit.dot", "lang": "it", "slot": "bit", "slug": "dot", "type": "component", "status": "draft", "system": "BX", "aliases": ["Dot"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Dot"], "reference": "https://beyblade.wiki/dot-bit/", "doc_version": 1, "canonical_name": "Dot"}	655ce9e8ea4b2b04f60d9e904b7f31f272c4468e42eae6e983919781b28c128b	4	7f84633	2026-08-22 13:35:57.076988+00	\N
172	knowledge/assist-blades/assault.md	component	assault	it	{"id": "assist_blade.assault", "lang": "it", "slot": "assist_blade", "slug": "assault", "type": "component", "status": "draft", "system": "CX", "aliases": ["Assault"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Assault"], "reference": "https://beyblade.wiki/assault-assist-blade/", "doc_version": 1, "canonical_name": "Assault"}	8e32ded98372a9f4396d3dd8b5ab78873705f1f7dc04d7fa3abbade5874af2d1	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
173	knowledge/assist-blades/bumper.md	component	bumper	it	{"id": "assist_blade.bumper", "lang": "it", "slot": "assist_blade", "slug": "bumper", "type": "component", "status": "draft", "system": "CX", "aliases": ["Bumper"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Bumper"], "reference": "https://beyblade.wiki/bumper-assist-blade/", "doc_version": 1, "canonical_name": "Bumper"}	eee28799165fccc64202e92527d167cd61dbb6a68aa45a333a849ca3a2bfcd08	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
174	knowledge/assist-blades/charge.md	component	charge	it	{"id": "assist_blade.charge", "lang": "it", "slot": "assist_blade", "slug": "charge", "type": "component", "status": "draft", "system": "CX", "aliases": ["Charge"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Charge"], "reference": "https://beyblade.wiki/charge-assist-blade/", "doc_version": 1, "canonical_name": "Charge"}	67ddadf4f976266f5ec9f6a554de229c907167f23305d42e2308e26fffa0b74d	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
175	knowledge/assist-blades/dual.md	component	dual	it	{"id": "assist_blade.dual", "lang": "it", "slot": "assist_blade", "slug": "dual", "type": "component", "status": "draft", "system": "CX", "aliases": ["Dual"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Dual"], "reference": "https://beyblade.wiki/dual-assist-blade/", "doc_version": 1, "canonical_name": "Dual"}	6b95ad2d8d8f60e47f7d69df65f82b6a427b52cd81ec565bb09c3eec56d6c171	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1000	knowledge/bits/elevate.md	component	elevate	it	{"id": "bit.elevate", "lang": "it", "slot": "bit", "slug": "elevate", "type": "component", "status": "draft", "system": "BX", "aliases": ["E", "Elevate"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Elevate"], "reference": "https://beyblade.wiki/elevate-bit/", "doc_version": 1, "canonical_name": "Elevate"}	69a1ad83f84d06ab4528ed1182e2b38f5a1165ddc15f81c4521ecd0ed0e0d851	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
666	knowledge/bits/elevate.md	component	elevate	it	{"id": "bit.elevate", "lang": "it", "slot": "bit", "slug": "elevate", "type": "component", "status": "draft", "system": "BX", "aliases": ["E", "Elevate"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Elevate"], "reference": "https://beyblade.wiki/elevate-bit/", "doc_version": 1, "canonical_name": "Elevate"}	69a1ad83f84d06ab4528ed1182e2b38f5a1165ddc15f81c4521ecd0ed0e0d851	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
30	knowledge/assist-blades/assault.md	component	assault	it	{"id": "assist_blade.assault", "lang": "it", "slot": "assist_blade", "slug": "assault", "type": "component", "status": "draft", "system": "CX", "aliases": ["Assault"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Assault"], "doc_version": 1, "canonical_name": "Assault"}	9c5e85875b3d9eb716acf4b661c09dfe800ac4a0886bdd69053b5fc2689023dd	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
31	knowledge/assist-blades/bumper.md	component	bumper	it	{"id": "assist_blade.bumper", "lang": "it", "slot": "assist_blade", "slug": "bumper", "type": "component", "status": "draft", "system": "CX", "aliases": ["Bumper"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Bumper"], "doc_version": 1, "canonical_name": "Bumper"}	a7e04ed042cfe34ae0528a74f058b79f791e24a6a629541b728100cfe35d1915	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
667	knowledge/bits/flat.md	component	flat	it	{"id": "bit.flat", "lang": "it", "slot": "bit", "slug": "flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["Flat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Flat"], "reference": "https://beyblade.wiki/flat-bit/", "doc_version": 1, "canonical_name": "Flat"}	d2e499e24591d59673a301ebcc8f9f2c8b2b9fc271d7223e3dff044b118e01ea	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
32	knowledge/assist-blades/charge.md	component	charge	it	{"id": "assist_blade.charge", "lang": "it", "slot": "assist_blade", "slug": "charge", "type": "component", "status": "draft", "system": "CX", "aliases": ["Charge"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Charge"], "doc_version": 1, "canonical_name": "Charge"}	5d33c345ab024e658c82ff0c8c2e81458f4bdb439585dd124acf2f92bad3c4c0	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1001	knowledge/bits/flat.md	component	flat	it	{"id": "bit.flat", "lang": "it", "slot": "bit", "slug": "flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["Flat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Flat"], "reference": "https://beyblade.wiki/flat-bit/", "doc_version": 1, "canonical_name": "Flat"}	d2e499e24591d59673a301ebcc8f9f2c8b2b9fc271d7223e3dff044b118e01ea	4	7f84633	2026-08-22 13:35:57.076988+00	\N
33	knowledge/assist-blades/dual.md	component	dual	it	{"id": "assist_blade.dual", "lang": "it", "slot": "assist_blade", "slug": "dual", "type": "component", "status": "draft", "system": "CX", "aliases": ["Dual"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Dual"], "doc_version": 1, "canonical_name": "Dual"}	064e39e897965807b22766bdb1053531040e16d73e32bf684ea729ea7d180c83	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
8	knowledge/assist-blades/heavy.md	component	heavy	it	{"id": "assist_blade.heavy", "lang": "it", "slot": "assist_blade", "slug": "heavy", "type": "component", "status": "draft", "system": "CX", "aliases": ["Heavy"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Heavy"], "doc_version": 1, "canonical_name": "Heavy"}	0598a6047b59174f9533db5f041a7d081fde91b8d4ba8a39e19310ccd7bf789b	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
40	knowledge/bits/cyclone.md	component	cyclone	it	{"id": "bit.cyclone", "lang": "it", "slot": "bit", "slug": "cyclone", "type": "component", "status": "draft", "system": "BX", "aliases": ["Cyclone"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Cyclone"], "doc_version": 1, "canonical_name": "Cyclone"}	571f3130367b86c2d4779e5c081b5563b3f228559c46c6f2d2072ba99e1da1e1	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
668	knowledge/bits/free-ball.md	component	free-ball	it	{"id": "bit.free-ball", "lang": "it", "slot": "bit", "slug": "free-ball", "type": "component", "status": "draft", "system": "UX", "aliases": ["FB", "FreeBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Free_Ball"], "reference": "https://beyblade.wiki/free-ball-bit/", "doc_version": 1, "canonical_name": "FreeBall"}	34203ada6c3930ac13b8bb9957e0dcdca6ac1bd3c27834fc8779ce17261436ec	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
9	knowledge/assist-blades/jaggy.md	component	jaggy	it	{"id": "assist_blade.jaggy", "lang": "it", "slot": "assist_blade", "slug": "jaggy", "type": "component", "status": "draft", "system": "CX", "aliases": ["Jaggy"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Jaggy"], "doc_version": 1, "canonical_name": "Jaggy"}	39dda656e1453125baf80b39d0e6990181e2bc42a2161f422a3fb765d7cec067	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
35	knowledge/assist-blades/round.md	component	round	it	{"id": "assist_blade.round", "lang": "it", "slot": "assist_blade", "slug": "round", "type": "component", "status": "draft", "system": "CX", "aliases": ["Round"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Round"], "doc_version": 1, "canonical_name": "Round"}	705cdec4ad66ba2fc5915661a640b9ea59760b1ed016dd090b7a28a1d5a05049	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
669	knowledge/bits/gear-ball.md	component	gear-ball	it	{"id": "bit.gear-ball", "lang": "it", "slot": "bit", "slug": "gear-ball", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Ball"], "reference": "https://beyblade.wiki/gear-ball-bit/", "doc_version": 1, "canonical_name": "GearBall"}	4fbacd6a048829648b928a51dc1f9bde27e3949900f4af9b632df584aa3671c3	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
10	knowledge/assist-blades/slash.md	component	slash	it	{"id": "assist_blade.slash", "lang": "it", "slot": "assist_blade", "slug": "slash", "type": "component", "status": "draft", "system": "CX", "aliases": ["Slash"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Slash"], "doc_version": 1, "canonical_name": "Slash"}	72df07343c6e7774273b2395b1f8e17dcdd2da4a7c6369fb4e3fe65d22c663bc	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
1003	knowledge/bits/gear-ball.md	component	gear-ball	it	{"id": "bit.gear-ball", "lang": "it", "slot": "bit", "slug": "gear-ball", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Ball"], "reference": "https://beyblade.wiki/gear-ball-bit/", "doc_version": 1, "canonical_name": "GearBall"}	4fbacd6a048829648b928a51dc1f9bde27e3949900f4af9b632df584aa3671c3	4	7f84633	2026-08-22 13:35:57.076988+00	\N
36	knowledge/assist-blades/turn.md	component	turn	it	{"id": "assist_blade.turn", "lang": "it", "slot": "assist_blade", "slug": "turn", "type": "component", "status": "draft", "system": "CX", "aliases": ["Turn"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Turn"], "doc_version": 1, "canonical_name": "Turn"}	386b185713e89993fe5643ba05c23aebdbdc47e0018dce94d31f6d07bf444e15	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
670	knowledge/bits/gear-flat.md	component	gear-flat	it	{"id": "bit.gear-flat", "lang": "it", "slot": "bit", "slug": "gear-flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Flat"], "reference": "https://beyblade.wiki/gear-flat-bit/", "doc_version": 1, "canonical_name": "GearFlat"}	977b98b8b282ddbb61fc82077c97a8e1587d3f9812289f01f357a35e5508780a	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
37	knowledge/assist-blades/wheel.md	component	wheel	it	{"id": "assist_blade.wheel", "lang": "it", "slot": "assist_blade", "slug": "wheel", "type": "component", "status": "draft", "system": "CX", "aliases": ["Wheel"], "sources": ["https://beyblade.fandom.com/wiki/Assist_Blade_-_Wheel"], "doc_version": 1, "canonical_name": "Wheel"}	95c5d11a630cf52473086bd507ae6da354e20c6574845b1326e0796df48a1dcb	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1004	knowledge/bits/gear-flat.md	component	gear-flat	it	{"id": "bit.gear-flat", "lang": "it", "slot": "bit", "slug": "gear-flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Flat"], "reference": "https://beyblade.wiki/gear-flat-bit/", "doc_version": 1, "canonical_name": "GearFlat"}	977b98b8b282ddbb61fc82077c97a8e1587d3f9812289f01f357a35e5508780a	4	7f84633	2026-08-22 13:35:57.076988+00	\N
38	knowledge/bits/accel.md	component	accel	it	{"id": "bit.accel", "lang": "it", "slot": "bit", "slug": "accel", "type": "component", "status": "draft", "system": "UX", "aliases": ["Accel"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Accel"], "doc_version": 1, "canonical_name": "Accel"}	13cbd8e09bb3b6c0b8e3e659944e2ba258b06b3d8698df2b95f412133a6c0b96	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
671	knowledge/bits/gear-needle.md	component	gear-needle	it	{"id": "bit.gear-needle", "lang": "it", "slot": "bit", "slug": "gear-needle", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Needle"], "reference": "https://beyblade.wiki/gear-needle-bit/", "doc_version": 1, "canonical_name": "GearNeedle"}	ec7f2371dfa756bd67f2ed7f9dd6a6c5acbdf548d168486149d26db7ab08a84c	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
124	knowledge/bits/ball.md	component	ball	it	{"id": "bit.ball", "lang": "it", "slot": "bit", "slug": "ball", "type": "component", "status": "draft", "system": "BX", "aliases": ["Ball"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Ball"], "doc_version": 1, "canonical_name": "Ball"}	db4c0931984ce5455ca7efadda726698aac8c274ffb1a612f4e8da3821a25bf8	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
1005	knowledge/bits/gear-needle.md	component	gear-needle	it	{"id": "bit.gear-needle", "lang": "it", "slot": "bit", "slug": "gear-needle", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Needle"], "reference": "https://beyblade.wiki/gear-needle-bit/", "doc_version": 1, "canonical_name": "GearNeedle"}	ec7f2371dfa756bd67f2ed7f9dd6a6c5acbdf548d168486149d26db7ab08a84c	4	7f84633	2026-08-22 13:35:57.076988+00	\N
672	knowledge/bits/gear-point.md	component	gear-point	it	{"id": "bit.gear-point", "lang": "it", "slot": "bit", "slug": "gear-point", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearPoint"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Point"], "reference": "https://beyblade.wiki/gear-point-bit/", "doc_version": 1, "canonical_name": "GearPoint"}	a6da4b346a1e5776b16f6223dc6156c563c23226204d1c69ec82bf03d9455ce2	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
125	knowledge/bits/disk-ball.md	component	disk-ball	it	{"id": "bit.disk-ball", "lang": "it", "slot": "bit", "slug": "disk-ball", "type": "component", "status": "draft", "system": "UX", "aliases": ["DiskBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Disk_Ball"], "doc_version": 1, "canonical_name": "DiskBall"}	9192ab37a833652a2870e84c5f109c97d4764ec0db8e9b036802dca5740b1ade	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
1006	knowledge/bits/gear-point.md	component	gear-point	it	{"id": "bit.gear-point", "lang": "it", "slot": "bit", "slug": "gear-point", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearPoint"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Point"], "reference": "https://beyblade.wiki/gear-point-bit/", "doc_version": 1, "canonical_name": "GearPoint"}	a6da4b346a1e5776b16f6223dc6156c563c23226204d1c69ec82bf03d9455ce2	4	7f84633	2026-08-22 13:35:57.076988+00	\N
41	knowledge/bits/dot.md	component	dot	it	{"id": "bit.dot", "lang": "it", "slot": "bit", "slug": "dot", "type": "component", "status": "draft", "system": "BX", "aliases": ["Dot"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Dot"], "doc_version": 1, "canonical_name": "Dot"}	fcc3b78be7e6710837319a103d8dddd2100e619312559263c494707c70e8ddaf	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
673	knowledge/bits/gear-rush.md	component	gear-rush	it	{"id": "bit.gear-rush", "lang": "it", "slot": "bit", "slug": "gear-rush", "type": "component", "status": "draft", "system": "CX", "aliases": ["GearRush"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Rush"], "reference": "https://beyblade.wiki/gear-rush-bit/", "doc_version": 1, "canonical_name": "GearRush"}	7fb2e67a3e212b4bbe9e269dfe4573889a7add982179bb351810ba7f42885933	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
11	knowledge/bits/elevate.md	component	elevate	it	{"id": "bit.elevate", "lang": "it", "slot": "bit", "slug": "elevate", "type": "component", "status": "draft", "system": "BX", "aliases": ["E", "Elevate"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Elevate"], "doc_version": 1, "canonical_name": "Elevate"}	f869aa718199123c5f6422a3e8834b05e7867a8242661c8eb3e76ea2cf2d2775	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
1007	knowledge/bits/gear-rush.md	component	gear-rush	it	{"id": "bit.gear-rush", "lang": "it", "slot": "bit", "slug": "gear-rush", "type": "component", "status": "draft", "system": "CX", "aliases": ["GearRush"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Rush"], "reference": "https://beyblade.wiki/gear-rush-bit/", "doc_version": 1, "canonical_name": "GearRush"}	7fb2e67a3e212b4bbe9e269dfe4573889a7add982179bb351810ba7f42885933	4	7f84633	2026-08-22 13:35:57.076988+00	\N
126	knowledge/bits/flat.md	component	flat	it	{"id": "bit.flat", "lang": "it", "slot": "bit", "slug": "flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["Flat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Flat"], "doc_version": 1, "canonical_name": "Flat"}	55108e862c4bbaaadb34eb4a961d369fc230ad378c5368b2feb333d87d6c32b2	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
674	knowledge/bits/glide.md	component	glide	it	{"id": "bit.glide", "lang": "it", "slot": "bit", "slug": "glide", "type": "component", "status": "draft", "system": "UX", "aliases": ["Glide"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Glide"], "reference": "https://beyblade.wiki/glide-bit/", "doc_version": 1, "canonical_name": "Glide"}	72bf03568ef6d107f2768896418fd929119b7c61995bf65d069664e478bc5415	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
12	knowledge/bits/free-ball.md	component	free-ball	it	{"id": "bit.free-ball", "lang": "it", "slot": "bit", "slug": "free-ball", "type": "component", "status": "draft", "system": "UX", "aliases": ["FB", "FreeBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Free_Ball"], "doc_version": 1, "canonical_name": "FreeBall"}	6dbe262a4a58819ebe9ae9d121b410c4700564b1fad6cd819a490ae200a49552	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
1008	knowledge/bits/glide.md	component	glide	it	{"id": "bit.glide", "lang": "it", "slot": "bit", "slug": "glide", "type": "component", "status": "draft", "system": "UX", "aliases": ["Glide"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Glide"], "reference": "https://beyblade.wiki/glide-bit/", "doc_version": 1, "canonical_name": "Glide"}	72bf03568ef6d107f2768896418fd929119b7c61995bf65d069664e478bc5415	4	7f84633	2026-08-22 13:35:57.076988+00	\N
127	knowledge/bits/gear-ball.md	component	gear-ball	it	{"id": "bit.gear-ball", "lang": "it", "slot": "bit", "slug": "gear-ball", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearBall"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Ball"], "doc_version": 1, "canonical_name": "GearBall"}	7c102566b6ca598c4691bea94b1cdb9f2491ad641db50ef118277576b070a951	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
675	knowledge/bits/hexa.md	component	hexa	it	{"id": "bit.hexa", "lang": "it", "slot": "bit", "slug": "hexa", "type": "component", "status": "draft", "system": "UX", "aliases": ["H", "Hexa"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Hexa"], "reference": "https://beyblade.wiki/hexa-bit/", "doc_version": 1, "canonical_name": "Hexa"}	5ad4a92680b0620766447b52ce022099595fc750aa3b0ad0cc2ecd6a6523b736	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
128	knowledge/bits/gear-flat.md	component	gear-flat	it	{"id": "bit.gear-flat", "lang": "it", "slot": "bit", "slug": "gear-flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Flat"], "doc_version": 1, "canonical_name": "GearFlat"}	73c2818bd10c7699d73279a0d7b2cfe4a4c0089e6607fe9312033e947abc90b4	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
129	knowledge/bits/gear-needle.md	component	gear-needle	it	{"id": "bit.gear-needle", "lang": "it", "slot": "bit", "slug": "gear-needle", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Needle"], "doc_version": 1, "canonical_name": "GearNeedle"}	54b77ad7f2c4542801f14b63a92977c3b268dae6d5b867fe1ae8549c9de80cac	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
676	knowledge/bits/high-needle.md	component	high-needle	it	{"id": "bit.high-needle", "lang": "it", "slot": "bit", "slug": "high-needle", "type": "component", "status": "draft", "system": "BX", "aliases": ["HighNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_High_Needle"], "reference": "https://beyblade.wiki/high-needle-bit/", "doc_version": 1, "canonical_name": "HighNeedle"}	4bf2a6b42938e76dadbd3952238539275c52584d1f204cae2466bb4e948f537a	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
130	knowledge/bits/gear-point.md	component	gear-point	it	{"id": "bit.gear-point", "lang": "it", "slot": "bit", "slug": "gear-point", "type": "component", "status": "draft", "system": "BX", "aliases": ["GearPoint"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Point"], "doc_version": 1, "canonical_name": "GearPoint"}	0c1db9db509027bce1c479d8e0174d5b025c77c87cebb708ba91a04b6580355e	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
1010	knowledge/bits/high-needle.md	component	high-needle	it	{"id": "bit.high-needle", "lang": "it", "slot": "bit", "slug": "high-needle", "type": "component", "status": "draft", "system": "BX", "aliases": ["HighNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_High_Needle"], "reference": "https://beyblade.wiki/high-needle-bit/", "doc_version": 1, "canonical_name": "HighNeedle"}	4bf2a6b42938e76dadbd3952238539275c52584d1f204cae2466bb4e948f537a	4	7f84633	2026-08-22 13:35:57.076988+00	\N
42	knowledge/bits/gear-rush.md	component	gear-rush	it	{"id": "bit.gear-rush", "lang": "it", "slot": "bit", "slug": "gear-rush", "type": "component", "status": "draft", "system": "CX", "aliases": ["GearRush"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Gear_Rush"], "doc_version": 1, "canonical_name": "GearRush"}	fb584b00c243e953e6638accb36d55a45c46e9b7120490507d65285cd1b73845	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
677	knowledge/bits/high-taper.md	component	high-taper	it	{"id": "bit.high-taper", "lang": "it", "slot": "bit", "slug": "high-taper", "type": "component", "status": "draft", "system": "BX", "aliases": ["HighTaper"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_High_Taper"], "reference": "https://beyblade.wiki/high-taper-bit/", "doc_version": 1, "canonical_name": "HighTaper"}	f93a738a063efef1b2abdaa2928d3d28c44904736d41bab319850aef0078d29c	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
43	knowledge/bits/glide.md	component	glide	it	{"id": "bit.glide", "lang": "it", "slot": "bit", "slug": "glide", "type": "component", "status": "draft", "system": "UX", "aliases": ["Glide"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Glide"], "doc_version": 1, "canonical_name": "Glide"}	5b1d4d8e149c90861a29af0073d40024a172079996f632bed2360648d64ea610	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1011	knowledge/bits/high-taper.md	component	high-taper	it	{"id": "bit.high-taper", "lang": "it", "slot": "bit", "slug": "high-taper", "type": "component", "status": "draft", "system": "BX", "aliases": ["HighTaper"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_High_Taper"], "reference": "https://beyblade.wiki/high-taper-bit/", "doc_version": 1, "canonical_name": "HighTaper"}	f93a738a063efef1b2abdaa2928d3d28c44904736d41bab319850aef0078d29c	4	7f84633	2026-08-22 13:35:57.076988+00	\N
13	knowledge/bits/hexa.md	component	hexa	it	{"id": "bit.hexa", "lang": "it", "slot": "bit", "slug": "hexa", "type": "component", "status": "draft", "system": "UX", "aliases": ["H", "Hexa"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Hexa"], "doc_version": 1, "canonical_name": "Hexa"}	f97b6701dcc3b7308941c805aed4bf4a56613015f48326ee5b99e4ca34703c05	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
678	knowledge/bits/kick.md	component	kick	it	{"id": "bit.kick", "lang": "it", "slot": "bit", "slug": "kick", "type": "component", "status": "draft", "system": "CX", "aliases": ["K", "Kick"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Kick"], "reference": "https://beyblade.wiki/kick-bit/", "doc_version": 1, "canonical_name": "Kick"}	9d0c009517bfd0ec1f69af05334040ce2aca24d4d41524e2ab2e2994ac43b3f5	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
131	knowledge/bits/high-needle.md	component	high-needle	it	{"id": "bit.high-needle", "lang": "it", "slot": "bit", "slug": "high-needle", "type": "component", "status": "draft", "system": "BX", "aliases": ["HighNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_High_Needle"], "doc_version": 1, "canonical_name": "HighNeedle"}	d1b38a89803e78ef9483af7686ec0e57f9a6e62f39f638247cdb130b0da05b6e	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
132	knowledge/bits/high-taper.md	component	high-taper	it	{"id": "bit.high-taper", "lang": "it", "slot": "bit", "slug": "high-taper", "type": "component", "status": "draft", "system": "BX", "aliases": ["HighTaper"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_High_Taper"], "doc_version": 1, "canonical_name": "HighTaper"}	d0c3354607e74a8ab4b659d9a05e1ac7240a2c0034ba4b474e71dbdf5faed273	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
679	knowledge/bits/level.md	component	level	it	{"id": "bit.level", "lang": "it", "slot": "bit", "slug": "level", "type": "component", "status": "draft", "system": "UX", "aliases": ["Level"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Level"], "reference": "https://beyblade.wiki/level-bit/", "doc_version": 1, "canonical_name": "Level"}	cef3f8434ab2328a25a03bd76481a12f4254a59ec90d4b08b6078551e6f89eb4	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
14	knowledge/bits/kick.md	component	kick	it	{"id": "bit.kick", "lang": "it", "slot": "bit", "slug": "kick", "type": "component", "status": "draft", "system": "CX", "aliases": ["K", "Kick"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Kick"], "doc_version": 1, "canonical_name": "Kick"}	682971cce334db8fda4ded1e1c2aeca94fd229312de7ca1a03c274bec326a43d	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
44	knowledge/bits/level.md	component	level	it	{"id": "bit.level", "lang": "it", "slot": "bit", "slug": "level", "type": "component", "status": "draft", "system": "UX", "aliases": ["Level"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Level"], "doc_version": 1, "canonical_name": "Level"}	e22ca648044885f7c9b395d433829780a3b5f7e74cdeb0cb8a6dfcbd4d795f5a	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
680	knowledge/bits/low-flat.md	component	low-flat	it	{"id": "bit.low-flat", "lang": "it", "slot": "bit", "slug": "low-flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["LowFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Flat"], "reference": "https://beyblade.wiki/low-flat-bit/", "doc_version": 1, "canonical_name": "LowFlat"}	1f7f73d93bcc87e3be495e6df06f60c89180e4ce389e53e90f21dfd5b84c1f41	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
45	knowledge/bits/low-flat.md	component	low-flat	it	{"id": "bit.low-flat", "lang": "it", "slot": "bit", "slug": "low-flat", "type": "component", "status": "draft", "system": "BX", "aliases": ["LowFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Flat"], "doc_version": 1, "canonical_name": "LowFlat"}	324684f8e82af5513cb4c9fe6bcdc17c60bb0a766ae746bf2696b81c37592ab0	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
133	knowledge/bits/low-orb.md	component	low-orb	it	{"id": "bit.low-orb", "lang": "it", "slot": "bit", "slug": "low-orb", "type": "component", "status": "draft", "system": "CX", "aliases": ["LowOrb"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Orb"], "doc_version": 1, "canonical_name": "LowOrb"}	61ea3a9ba11be12c4388a4802b387c8d4913b5bed31913b7275e15a571f18ab8	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
681	knowledge/bits/low-orb.md	component	low-orb	it	{"id": "bit.low-orb", "lang": "it", "slot": "bit", "slug": "low-orb", "type": "component", "status": "draft", "system": "CX", "aliases": ["LowOrb"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Orb"], "reference": "https://beyblade.wiki/low-orb-bit/", "doc_version": 1, "canonical_name": "LowOrb"}	010ddab95d0f05d1a85ec04ae5665d7dfb9d3a9ba968e3b065bf6d9013434224	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
15	knowledge/bits/low-rush.md	component	low-rush	it	{"id": "bit.low-rush", "lang": "it", "slot": "bit", "slug": "low-rush", "type": "component", "status": "draft", "system": "UX", "aliases": ["LowRush", "LR"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Rush"], "doc_version": 1, "canonical_name": "LowRush"}	a0adf1f032212082274a420bb9846e07a1d6fad1f50a3355386c204ff084a8f4	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
46	knowledge/bits/merge.md	component	merge	it	{"id": "bit.merge", "lang": "it", "slot": "bit", "slug": "merge", "type": "component", "status": "draft", "system": "BX", "aliases": ["Merge"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Merge"], "doc_version": 1, "canonical_name": "Merge"}	93d3d4ca46ae91d928e4a53eee25dce2a3c82fb033af9970271fb84c9443ce63	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
682	knowledge/bits/low-rush.md	component	low-rush	it	{"id": "bit.low-rush", "lang": "it", "slot": "bit", "slug": "low-rush", "type": "component", "status": "draft", "system": "UX", "aliases": ["LowRush", "LR"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Low_Rush"], "reference": "https://beyblade.wiki/low-rush-bit/", "doc_version": 1, "canonical_name": "LowRush"}	23fddf4504ea3d0dd7983e1359abce37097efcd3e6c43f8dde7934db3414add1	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
134	knowledge/bits/metal-needle.md	component	metal-needle	it	{"id": "bit.metal-needle", "lang": "it", "slot": "bit", "slug": "metal-needle", "type": "component", "status": "draft", "system": "UX", "aliases": ["MetalNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Metal_Needle"], "doc_version": 1, "canonical_name": "MetalNeedle"}	2293f3711cc60f25c982934b561552e7b48f6f8f929041506696759eb51fe7a3	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
135	knowledge/bits/needle.md	component	needle	it	{"id": "bit.needle", "lang": "it", "slot": "bit", "slug": "needle", "type": "component", "status": "draft", "system": "BX", "aliases": ["Needle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Needle"], "doc_version": 1, "canonical_name": "Needle"}	22727e10afcbf2d208b0e4677a4babf6a5915afb08807dd18c68f17739ad5f91	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
683	knowledge/bits/merge.md	component	merge	it	{"id": "bit.merge", "lang": "it", "slot": "bit", "slug": "merge", "type": "component", "status": "draft", "system": "BX", "aliases": ["Merge"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Merge"], "reference": "https://beyblade.wiki/merge-bit/", "doc_version": 1, "canonical_name": "Merge"}	f97d88c1e34bdf7fc31295093fb7822f8134a8e7c73651737e41b3f675ad6621	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1017	knowledge/bits/merge.md	component	merge	it	{"id": "bit.merge", "lang": "it", "slot": "bit", "slug": "merge", "type": "component", "status": "draft", "system": "BX", "aliases": ["Merge"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Merge"], "reference": "https://beyblade.wiki/merge-bit/", "doc_version": 1, "canonical_name": "Merge"}	f97d88c1e34bdf7fc31295093fb7822f8134a8e7c73651737e41b3f675ad6621	4	7f84633	2026-08-22 13:35:57.076988+00	\N
47	knowledge/bits/orb.md	component	orb	it	{"id": "bit.orb", "lang": "it", "slot": "bit", "slug": "orb", "type": "component", "status": "draft", "system": "BX", "aliases": ["Orb"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Orb"], "doc_version": 1, "canonical_name": "Orb"}	385a3f8624a32b6fe619b1681c09d93ccade3b8e7db1186ba9a0a011c497fef7	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
684	knowledge/bits/metal-needle.md	component	metal-needle	it	{"id": "bit.metal-needle", "lang": "it", "slot": "bit", "slug": "metal-needle", "type": "component", "status": "draft", "system": "UX", "aliases": ["MetalNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Metal_Needle"], "reference": "https://beyblade.wiki/metal-needle-bit/", "doc_version": 1, "canonical_name": "MetalNeedle"}	ebe4dcc3e09ec158a6ac0bd646c0ee8e4abec30dc0f6cfb82c3d179e51fb0ce0	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
48	knowledge/bits/point.md	component	point	it	{"id": "bit.point", "lang": "it", "slot": "bit", "slug": "point", "type": "component", "status": "draft", "system": "BX", "aliases": ["Point"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Point"], "doc_version": 1, "canonical_name": "Point"}	4afb85bcad6f5bd2efae4e0064b99be78a0cadbc2e204cded9d02a7b47bc5d8c	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1018	knowledge/bits/metal-needle.md	component	metal-needle	it	{"id": "bit.metal-needle", "lang": "it", "slot": "bit", "slug": "metal-needle", "type": "component", "status": "draft", "system": "UX", "aliases": ["MetalNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Metal_Needle"], "reference": "https://beyblade.wiki/metal-needle-bit/", "doc_version": 1, "canonical_name": "MetalNeedle"}	ebe4dcc3e09ec158a6ac0bd646c0ee8e4abec30dc0f6cfb82c3d179e51fb0ce0	4	7f84633	2026-08-22 13:35:57.076988+00	\N
49	knowledge/bits/quake.md	component	quake	it	{"id": "bit.quake", "lang": "it", "slot": "bit", "slug": "quake", "type": "component", "status": "draft", "system": "BX", "aliases": ["Quake"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Quake"], "doc_version": 1, "canonical_name": "Quake"}	20009e31612d716e8d85300fe2e93690ba4a1b2a096b5a7d7379a03a8b7336b0	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
685	knowledge/bits/needle.md	component	needle	it	{"id": "bit.needle", "lang": "it", "slot": "bit", "slug": "needle", "type": "component", "status": "draft", "system": "BX", "aliases": ["Needle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Needle"], "reference": "https://beyblade.wiki/needle-bit/", "doc_version": 1, "canonical_name": "Needle"}	199fbaa45a8c30880753e3257dc55b9f04dc59cac6460d8a02f9622fb9119ddf	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
16	knowledge/bits/rush.md	component	rush	it	{"id": "bit.rush", "lang": "it", "slot": "bit", "slug": "rush", "type": "component", "status": "draft", "system": "BX", "aliases": ["R", "Rush"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Rush"], "doc_version": 1, "canonical_name": "Rush"}	702d9b53a6177b74b723a8dd3f990d2ce7ceced205e7bad1cd1de8504e387f9b	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
1019	knowledge/bits/needle.md	component	needle	it	{"id": "bit.needle", "lang": "it", "slot": "bit", "slug": "needle", "type": "component", "status": "draft", "system": "BX", "aliases": ["Needle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Needle"], "reference": "https://beyblade.wiki/needle-bit/", "doc_version": 1, "canonical_name": "Needle"}	199fbaa45a8c30880753e3257dc55b9f04dc59cac6460d8a02f9622fb9119ddf	4	7f84633	2026-08-22 13:35:57.076988+00	\N
51	knowledge/bits/spike.md	component	spike	it	{"id": "bit.spike", "lang": "it", "slot": "bit", "slug": "spike", "type": "component", "status": "draft", "system": "BX", "aliases": ["Spike"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Spike"], "doc_version": 1, "canonical_name": "Spike"}	bed3eee8b1a5c51b95dc254c2881931c56b2df8c745ce6118a34dedb3ffdedda	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
686	knowledge/bits/operate.md	component	operate	it	{"id": "bit.operate", "lang": "it", "slot": "bit", "slug": "operate", "type": "component", "status": "draft", "system": null, "aliases": ["Operate"], "sources": [], "reference": "https://beyblade.wiki/operate-bit/", "doc_version": 1, "canonical_name": "Operate"}	e7d38605459f9435179a1a8781e18e186d5d16b024d13882bfb0504cf662e71c	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
136	knowledge/bits/taper.md	component	taper	it	{"id": "bit.taper", "lang": "it", "slot": "bit", "slug": "taper", "type": "component", "status": "draft", "system": "BX", "aliases": ["Taper"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Taper"], "doc_version": 1, "canonical_name": "Taper"}	f457a9e540ccec1264bb46e783dbf71f73528bc0caabb33e22b13932e7b3b107	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
1020	knowledge/bits/operate.md	component	operate	it	{"id": "bit.operate", "lang": "it", "slot": "bit", "slug": "operate", "type": "component", "status": "draft", "system": null, "aliases": ["Operate"], "sources": [], "reference": "https://beyblade.wiki/operate-bit/", "doc_version": 1, "canonical_name": "Operate"}	e7d38605459f9435179a1a8781e18e186d5d16b024d13882bfb0504cf662e71c	3	7f84633	2026-08-22 13:35:57.076988+00	\N
137	knowledge/bits/trans-point.md	component	trans-point	it	{"id": "bit.trans-point", "lang": "it", "slot": "bit", "slug": "trans-point", "type": "component", "status": "draft", "system": "BX", "aliases": ["TransPoint"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Trans_Point"], "doc_version": 1, "canonical_name": "TransPoint"}	431c8a5113ccccd4f3a5bc7db38503ae5faf25bfcb98a4d7ce4f3d7496f1bc51	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
687	knowledge/bits/orb.md	component	orb	it	{"id": "bit.orb", "lang": "it", "slot": "bit", "slug": "orb", "type": "component", "status": "draft", "system": "BX", "aliases": ["Orb"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Orb"], "reference": "https://beyblade.wiki/orb-bit/", "doc_version": 1, "canonical_name": "Orb"}	0f4901f0334e1094aa1f7b0856b7e74c705aad7106df0880b6afd740fb915f74	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
52	knowledge/bits/under-flat.md	component	under-flat	it	{"id": "bit.under-flat", "lang": "it", "slot": "bit", "slug": "under-flat", "type": "component", "status": "draft", "system": "UX", "aliases": ["UnderFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Under_Flat"], "doc_version": 1, "canonical_name": "UnderFlat"}	8b4edd8a80e5fb3012de5b1c4e0acd31a4d64ef4da47db396cd0e7392c7a1680	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
688	knowledge/bits/point.md	component	point	it	{"id": "bit.point", "lang": "it", "slot": "bit", "slug": "point", "type": "component", "status": "draft", "system": "BX", "aliases": ["Point"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Point"], "reference": "https://beyblade.wiki/point-bit/", "doc_version": 1, "canonical_name": "Point"}	4eefd82f885ea8d2991d2368280629e709e7b0cc33851cb52d37e1761361d374	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
53	knowledge/bits/under-needle.md	component	under-needle	it	{"id": "bit.under-needle", "lang": "it", "slot": "bit", "slug": "under-needle", "type": "component", "status": "draft", "system": "UX", "aliases": ["UnderNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Under_Needle"], "doc_version": 1, "canonical_name": "UnderNeedle"}	9ec12952b9dc7af21e342cd91ed5618db373d806ce9d83ba0a2cdcd4975601b1	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
54	knowledge/bits/unite.md	component	unite	it	{"id": "bit.unite", "lang": "it", "slot": "bit", "slug": "unite", "type": "component", "status": "draft", "system": "BX", "aliases": ["Unite"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Unite"], "doc_version": 1, "canonical_name": "Unite"}	4b84ba5487700756c954a00a23a6b5bf9b4ceae16a7dbad0d1f3f5f0763de556	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
689	knowledge/bits/quake.md	component	quake	it	{"id": "bit.quake", "lang": "it", "slot": "bit", "slug": "quake", "type": "component", "status": "draft", "system": "BX", "aliases": ["Quake"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Quake"], "reference": "https://beyblade.wiki/quake-bit/", "doc_version": 1, "canonical_name": "Quake"}	cb9bdced8e54bbf3e08dc74763f3db613bf6af884b8fccf983b83d965158bbd0	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
55	knowledge/bits/vortex.md	component	vortex	it	{"id": "bit.vortex", "lang": "it", "slot": "bit", "slug": "vortex", "type": "component", "status": "draft", "system": "CX", "aliases": ["Vortex"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Vortex"], "doc_version": 1, "canonical_name": "Vortex"}	270185818bef6e2a5019f4137e0cd9600746141ab3ca572d59c2ecf9c9b5dd09	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1023	knowledge/bits/quake.md	component	quake	it	{"id": "bit.quake", "lang": "it", "slot": "bit", "slug": "quake", "type": "component", "status": "draft", "system": "BX", "aliases": ["Quake"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Quake"], "reference": "https://beyblade.wiki/quake-bit/", "doc_version": 1, "canonical_name": "Quake"}	cb9bdced8e54bbf3e08dc74763f3db613bf6af884b8fccf983b83d965158bbd0	4	7f84633	2026-08-22 13:35:57.076988+00	\N
56	knowledge/bits/wedge.md	component	wedge	it	{"id": "bit.wedge", "lang": "it", "slot": "bit", "slug": "wedge", "type": "component", "status": "draft", "system": "CX", "aliases": ["Wedge"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Wedge"], "doc_version": 1, "canonical_name": "Wedge"}	7751becdc8c52ce344fc14515b4a8b35b4d53f08d5312d218225b917a01b0ac1	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
690	knowledge/bits/rubber-accel.md	component	rubber-accel	it	{"id": "bit.rubber-accel", "lang": "it", "slot": "bit", "slug": "rubber-accel", "type": "component", "status": "draft", "system": "UX", "aliases": ["RubberAccel"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Rubber_Accel"], "doc_version": 1, "canonical_name": "RubberAccel"}	9b026f24d15e71e330f092e7b6ae26e59b6d1dde43f786474fc79e3c9367f191	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
57	knowledge/bits/zap.md	component	zap	it	{"id": "bit.zap", "lang": "it", "slot": "bit", "slug": "zap", "type": "component", "status": "draft", "system": "UX", "aliases": ["Zap"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Zap"], "doc_version": 1, "canonical_name": "Zap"}	32c9ceb7a9884ce72dd490a82ade138628644c486597a6a1c0ab40c2697e7ac6	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
58	knowledge/blades/aero-pegasus.md	component	aero-pegasus	it	{"id": "blade.aero-pegasus", "lang": "it", "slot": "blade", "slug": "aero-pegasus", "type": "component", "status": "draft", "system": "BX", "aliases": ["AeroPegasus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_AeroPegasus"], "doc_version": 1, "canonical_name": "AeroPegasus"}	f0f32fb5b58b0e533481af76dbf91b03c1e36de430f563dfd3fc44cbb8b49686	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
691	knowledge/bits/rush.md	component	rush	it	{"id": "bit.rush", "lang": "it", "slot": "bit", "slug": "rush", "type": "component", "status": "draft", "system": "BX", "aliases": ["R", "Rush"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Rush"], "reference": "https://beyblade.wiki/rush-bit/", "doc_version": 1, "canonical_name": "Rush"}	08ba84e548cf1671c8c3fecc9e358c9d0a18af1940ad30a6cde6201182ec0b8d	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
138	knowledge/blades/arc.md	component	arc	it	{"id": "blade.arc", "lang": "it", "slot": "blade", "slug": "arc", "type": "component", "status": "draft", "system": "CX", "aliases": ["Arc"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Arc"], "doc_version": 1, "canonical_name": "Arc"}	691326ba617232fad788689cbdad5ecafa34803f835ae2a64715fd6c00b716c1	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
60	knowledge/blades/black-shell.md	component	black-shell	it	{"id": "blade.black-shell", "lang": "it", "slot": "blade", "slug": "black-shell", "type": "component", "status": "draft", "system": "BX", "aliases": ["BlackShell"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_BlackShell"], "doc_version": 1, "canonical_name": "BlackShell"}	03cc55f900e1b960dfe60b6c4602ee47b5fc2479bdb9561a5295f9b0904c78a8	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
692	knowledge/bits/spike.md	component	spike	it	{"id": "bit.spike", "lang": "it", "slot": "bit", "slug": "spike", "type": "component", "status": "draft", "system": "BX", "aliases": ["Spike"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Spike"], "reference": "https://beyblade.wiki/spike-bit/", "doc_version": 1, "canonical_name": "Spike"}	e8ea8d5d5e72ff0f75a289406c5ae147841a89b47dc161b4a6745bfb6563378c	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
139	knowledge/blades/blast.md	component	blast	it	{"id": "blade.blast", "lang": "it", "slot": "blade", "slug": "blast", "type": "component", "status": "draft", "system": "CX", "aliases": ["Blast"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Blast"], "doc_version": 1, "canonical_name": "Blast"}	4479a32299bc24dd01bb56aca06329a9ff3de3b9af12a5e4e11afbb536dad499	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
1026	knowledge/bits/spike.md	component	spike	it	{"id": "bit.spike", "lang": "it", "slot": "bit", "slug": "spike", "type": "component", "status": "draft", "system": "BX", "aliases": ["Spike"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Spike"], "reference": "https://beyblade.wiki/spike-bit/", "doc_version": 1, "canonical_name": "Spike"}	e8ea8d5d5e72ff0f75a289406c5ae147841a89b47dc161b4a6745bfb6563378c	4	7f84633	2026-08-22 13:35:57.076988+00	\N
140	knowledge/blades/brave.md	component	brave	it	{"id": "blade.brave", "lang": "it", "slot": "blade", "slug": "brave", "type": "component", "status": "draft", "system": "CX", "aliases": ["Brave"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Brave"], "doc_version": 1, "canonical_name": "Brave"}	559cc7593e329c82df6aeb217287e6be5863f1340f17996c38af014e33258693	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
693	knowledge/bits/taper.md	component	taper	it	{"id": "bit.taper", "lang": "it", "slot": "bit", "slug": "taper", "type": "component", "status": "draft", "system": "BX", "aliases": ["Taper"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Taper"], "reference": "https://beyblade.wiki/taper-bit/", "doc_version": 1, "canonical_name": "Taper"}	f537497de79b42fb03792adfbd08d6f2e87986c6a8320e23cce83c4cd2ad101d	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
141	knowledge/blades/brush.md	component	brush	it	{"id": "blade.brush", "lang": "it", "slot": "blade", "slug": "brush", "type": "component", "status": "draft", "system": "CX", "aliases": ["Brush"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Brush"], "doc_version": 1, "canonical_name": "Brush"}	126ce371c8981a146e5ff1c1c3ab04aebb1f9a7af212dbc2f88c9172d27e0252	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
61	knowledge/blades/clock-mirage.md	component	clock-mirage	it	{"id": "blade.clock-mirage", "lang": "it", "slot": "blade", "slug": "clock-mirage", "type": "component", "status": "draft", "system": "UX", "aliases": ["ClockMirage"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ClockMirage"], "doc_version": 1, "canonical_name": "ClockMirage"}	28c0c77e1906f5df91e76e91be7fecabee0149eb9c459036edbbd06af4043ed4	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
694	knowledge/bits/trans-point.md	component	trans-point	it	{"id": "bit.trans-point", "lang": "it", "slot": "bit", "slug": "trans-point", "type": "component", "status": "draft", "system": "BX", "aliases": ["TransPoint"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Trans_Point"], "reference": "https://beyblade.wiki/trans-point-bit/", "doc_version": 1, "canonical_name": "TransPoint"}	b3675ac46ad98ed189dbcb54815ef9d7040dc8515338e2682dcc0bdc7cebada3	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
17	knowledge/blades/cobalt-dragoon.md	component	cobalt-dragoon	it	{"id": "blade.cobalt-dragoon", "lang": "it", "slot": "blade", "slug": "cobalt-dragoon", "type": "component", "status": "draft", "system": "BX", "aliases": ["CobaltDragoon"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CobaltDragoon"], "doc_version": 1, "canonical_name": "CobaltDragoon"}	35669aedf3d3c631d4f70f4fbc4b230d8a380515e189b3b3754eb91ac8ea2d7c	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
1028	knowledge/bits/trans-point.md	component	trans-point	it	{"id": "bit.trans-point", "lang": "it", "slot": "bit", "slug": "trans-point", "type": "component", "status": "draft", "system": "BX", "aliases": ["TransPoint"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Trans_Point"], "reference": "https://beyblade.wiki/trans-point-bit/", "doc_version": 1, "canonical_name": "TransPoint"}	b3675ac46ad98ed189dbcb54815ef9d7040dc8515338e2682dcc0bdc7cebada3	4	7f84633	2026-08-22 13:35:57.076988+00	\N
62	knowledge/blades/cobalt-drake.md	component	cobalt-drake	it	{"id": "blade.cobalt-drake", "lang": "it", "slot": "blade", "slug": "cobalt-drake", "type": "component", "status": "draft", "system": "BX", "aliases": ["CobaltDrake"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CobaltDrake"], "doc_version": 1, "canonical_name": "CobaltDrake"}	484ef3b2c42c1a8868e8a61ae9b3d60e7463efe810d0e7e1f862904fa0229b76	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
695	knowledge/bits/turbo.md	component	turbo	it	{"id": "bit.turbo", "lang": "it", "slot": "bit", "slug": "turbo", "type": "component", "status": "draft", "system": null, "aliases": ["Turbo"], "sources": [], "reference": "https://beyblade.wiki/turbo-bit/", "doc_version": 1, "canonical_name": "Turbo"}	adb1d006ee92479e3cdbe5717d455cead867555f5fd09b3c2cca748778141266	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
63	knowledge/blades/crimson-garuda.md	component	crimson-garuda	it	{"id": "blade.crimson-garuda", "lang": "it", "slot": "blade", "slug": "crimson-garuda", "type": "component", "status": "draft", "system": "BX", "aliases": ["CrimsonGaruda"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CrimsonGaruda"], "doc_version": 1, "canonical_name": "CrimsonGaruda"}	26ebcc00ebaf24257a1ef97743399894352e7e0a5eb3b749edb96624ec3c0977	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1029	knowledge/bits/turbo.md	component	turbo	it	{"id": "bit.turbo", "lang": "it", "slot": "bit", "slug": "turbo", "type": "component", "status": "draft", "system": null, "aliases": ["Turbo"], "sources": [], "reference": "https://beyblade.wiki/turbo-bit/", "doc_version": 1, "canonical_name": "Turbo"}	adb1d006ee92479e3cdbe5717d455cead867555f5fd09b3c2cca748778141266	3	7f84633	2026-08-22 13:35:57.076988+00	\N
142	knowledge/blades/croc-crunch.md	component	croc-crunch	it	{"id": "blade.croc-crunch", "lang": "it", "slot": "blade", "slug": "croc-crunch", "type": "component", "status": "draft", "system": "BX", "aliases": ["CrocCrunch"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Bite_Croc"], "doc_version": 1, "canonical_name": "CrocCrunch"}	5fff473cc51fad248760d9f53db79fc306ffb236761d9badeaca40cec68a3b6a	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
696	knowledge/bits/under-flat.md	component	under-flat	it	{"id": "bit.under-flat", "lang": "it", "slot": "bit", "slug": "under-flat", "type": "component", "status": "draft", "system": "UX", "aliases": ["UnderFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Under_Flat"], "reference": "https://beyblade.wiki/under-flat-bit/", "doc_version": 1, "canonical_name": "UnderFlat"}	2d9128f2f36bdf8d6aa9264ec485119ea5524d397747a8b2ea84d4d92b2f9504	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1027	knowledge/bits/taper.md	component	taper	it	{"id": "bit.taper", "lang": "it", "slot": "bit", "slug": "taper", "type": "component", "status": "draft", "system": "BX", "aliases": ["Taper"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Taper"], "reference": "https://beyblade.wiki/taper-bit/", "doc_version": 1, "canonical_name": "Taper"}	f537497de79b42fb03792adfbd08d6f2e87986c6a8320e23cce83c4cd2ad101d	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
143	knowledge/blades/dark.md	component	dark	it	{"id": "blade.dark", "lang": "it", "slot": "blade", "slug": "dark", "type": "component", "status": "draft", "system": "CX", "aliases": ["Dark"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Dark"], "doc_version": 1, "canonical_name": "Dark"}	92159256d29136ccafa24c5d55dccbd90d2d431feec24f1171efdc690817ba90	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
1030	knowledge/bits/under-flat.md	component	under-flat	it	{"id": "bit.under-flat", "lang": "it", "slot": "bit", "slug": "under-flat", "type": "component", "status": "draft", "system": "UX", "aliases": ["UnderFlat"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Under_Flat"], "reference": "https://beyblade.wiki/under-flat-bit/", "doc_version": 1, "canonical_name": "UnderFlat"}	2d9128f2f36bdf8d6aa9264ec485119ea5524d397747a8b2ea84d4d92b2f9504	4	7f84633	2026-08-22 13:35:57.076988+00	\N
65	knowledge/blades/dran-buster.md	component	dran-buster	it	{"id": "blade.dran-buster", "lang": "it", "slot": "blade", "slug": "dran-buster", "type": "component", "status": "draft", "system": "UX", "aliases": ["DranBuster"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranBuster"], "doc_version": 1, "canonical_name": "DranBuster"}	4d843ebe2081b31936997569158a285760e870d47ad02edd3631a88aba554721	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
697	knowledge/bits/under-needle.md	component	under-needle	it	{"id": "bit.under-needle", "lang": "it", "slot": "bit", "slug": "under-needle", "type": "component", "status": "draft", "system": "UX", "aliases": ["UnderNeedle"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Under_Needle"], "reference": "https://beyblade.wiki/under-needle-bit/", "doc_version": 1, "canonical_name": "UnderNeedle"}	726ae593124520868324f9d6eb0d96533ec99a68fb373ee535c24111bb819e83	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
66	knowledge/blades/dran-dagger.md	component	dran-dagger	it	{"id": "blade.dran-dagger", "lang": "it", "slot": "blade", "slug": "dran-dagger", "type": "component", "status": "draft", "system": "BX", "aliases": ["DranDagger"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranDagger"], "doc_version": 1, "canonical_name": "DranDagger"}	c7fac0d10a8bb97759dcea168e115d37170e1d7d321f80bc47add06b707b3052	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
67	knowledge/blades/dran-sword.md	component	dran-sword	it	{"id": "blade.dran-sword", "lang": "it", "slot": "blade", "slug": "dran-sword", "type": "component", "status": "draft", "system": "BX", "aliases": ["DranSword"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranSword"], "doc_version": 1, "canonical_name": "DranSword"}	f7ae0b3b1ea698a20644c83d0084b2332046ea66d9ec91e9481d375c00268a22	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
698	knowledge/bits/unite.md	component	unite	it	{"id": "bit.unite", "lang": "it", "slot": "bit", "slug": "unite", "type": "component", "status": "draft", "system": "BX", "aliases": ["Unite"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Unite"], "reference": "https://beyblade.wiki/unite-bit/", "doc_version": 1, "canonical_name": "Unite"}	491ba7cd7581c048e4d36658421d577fe3051e1150f20a3d29656bbf47249079	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
146	knowledge/blades/dranzer-spiral.md	component	dranzer-spiral	it	{"id": "blade.dranzer-spiral", "lang": "it", "slot": "blade", "slug": "dranzer-spiral", "type": "component", "status": "draft", "system": "BX", "aliases": ["DranzerSpiral"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranzerSpiral"], "doc_version": 1, "canonical_name": "DranzerSpiral"}	9d4ffd26357c043f5bec3e726cec1d6545f9fa63cdbdaa5f06e94148321dbf3b	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
148	knowledge/blades/eclipse.md	component	eclipse	it	{"id": "blade.eclipse", "lang": "it", "slot": "blade", "slug": "eclipse", "type": "component", "status": "draft", "system": "CX", "aliases": ["Eclipse"], "sources": [], "doc_version": 1, "canonical_name": "Eclipse"}	73aac992fda85354c2daaf1600773a1fb4908f003643eebc1031f2f2b9c7e4dd	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
699	knowledge/bits/vortex.md	component	vortex	it	{"id": "bit.vortex", "lang": "it", "slot": "bit", "slug": "vortex", "type": "component", "status": "draft", "system": "CX", "aliases": ["Vortex"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Vortex"], "reference": "https://beyblade.wiki/vortex-bit/", "doc_version": 1, "canonical_name": "Vortex"}	ea5190b76c2edd00fca326c7fbf78fd6d264d351b6205be4fcb4ccd032974e17	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
149	knowledge/blades/flame.md	component	flame	it	{"id": "blade.flame", "lang": "it", "slot": "blade", "slug": "flame", "type": "component", "status": "draft", "system": "CX", "aliases": ["Flame"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Flame"], "doc_version": 1, "canonical_name": "Flame"}	55902c14aca6dd141849f087f3a777844ba82cfc8b63166ef480c90a031db606	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
1033	knowledge/bits/vortex.md	component	vortex	it	{"id": "bit.vortex", "lang": "it", "slot": "bit", "slug": "vortex", "type": "component", "status": "draft", "system": "CX", "aliases": ["Vortex"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Vortex"], "reference": "https://beyblade.wiki/vortex-bit/", "doc_version": 1, "canonical_name": "Vortex"}	ea5190b76c2edd00fca326c7fbf78fd6d264d351b6205be4fcb4ccd032974e17	4	7f84633	2026-08-22 13:35:57.076988+00	\N
68	knowledge/blades/ghost-circle.md	component	ghost-circle	it	{"id": "blade.ghost-circle", "lang": "it", "slot": "blade", "slug": "ghost-circle", "type": "component", "status": "draft", "system": "UX", "aliases": ["GhostCircle"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_GhostCircle"], "doc_version": 1, "canonical_name": "GhostCircle"}	d72435e727332e601536ed8c357aefcce7044c7309cddfe46ce1fe7d93559def	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
700	knowledge/bits/wedge.md	component	wedge	it	{"id": "bit.wedge", "lang": "it", "slot": "bit", "slug": "wedge", "type": "component", "status": "draft", "system": "CX", "aliases": ["Wedge"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Wedge"], "reference": "https://beyblade.wiki/wedge-bit/", "doc_version": 1, "canonical_name": "Wedge"}	3cbb24d30a560860a0486176253e61ae079c634d780c615e752846b4ef7de3d2	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
70	knowledge/blades/golem-rock.md	component	golem-rock	it	{"id": "blade.golem-rock", "lang": "it", "slot": "blade", "slug": "golem-rock", "type": "component", "status": "draft", "system": "UX", "aliases": ["GolemRock"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_GolemRock"], "doc_version": 1, "canonical_name": "GolemRock"}	ce833d21628498232e7f01b44574cbb0742e97c51d1443c8dd43027f8adbf884	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
701	knowledge/bits/zap.md	component	zap	it	{"id": "bit.zap", "lang": "it", "slot": "bit", "slug": "zap", "type": "component", "status": "draft", "system": "UX", "aliases": ["Zap"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Zap"], "reference": "https://beyblade.wiki/zap-bit/", "doc_version": 1, "canonical_name": "Zap"}	6d7344acbbd9d69a096e7c0959c0d3540d0bdc56cf9678cbe0bcae5e631924d0	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
71	knowledge/blades/hells-chain.md	component	hells-chain	it	{"id": "blade.hells-chain", "lang": "it", "slot": "blade", "slug": "hells-chain", "type": "component", "status": "draft", "system": "BX", "aliases": ["HellsChain"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsChain"], "doc_version": 1, "canonical_name": "HellsChain"}	a26a6a214e5443a46f3b4f5076cc615d1769fdeed65f061b38d53d2f262ba23a	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1035	knowledge/bits/zap.md	component	zap	it	{"id": "bit.zap", "lang": "it", "slot": "bit", "slug": "zap", "type": "component", "status": "draft", "system": "UX", "aliases": ["Zap"], "sources": ["https://beyblade.fandom.com/wiki/Bit_-_Zap"], "reference": "https://beyblade.wiki/zap-bit/", "doc_version": 1, "canonical_name": "Zap"}	6d7344acbbd9d69a096e7c0959c0d3540d0bdc56cf9678cbe0bcae5e631924d0	4	7f84633	2026-08-22 13:35:57.076988+00	\N
72	knowledge/blades/hells-hammer.md	component	hells-hammer	it	{"id": "blade.hells-hammer", "lang": "it", "slot": "blade", "slug": "hells-hammer", "type": "component", "status": "draft", "system": "UX", "aliases": ["HellsHammer"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsHammer"], "doc_version": 1, "canonical_name": "HellsHammer"}	12cc2fae99721e00c5e15d548c739d3b7c8d7db1077031647445024865787aa5	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
702	knowledge/blades/aero-pegasus.md	component	aero-pegasus	it	{"id": "blade.aero-pegasus", "lang": "it", "slot": "blade", "slug": "aero-pegasus", "type": "component", "status": "draft", "system": "BX", "aliases": ["AeroPegasus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_AeroPegasus"], "reference": "https://beyblade.wiki/aero-pegasus-blade/", "doc_version": 1, "canonical_name": "AeroPegasus"}	e5c585aded350bd05e55db679f4cc4cdfa60d70c762a0ec886bace90734bac37	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
73	knowledge/blades/hells-scythe.md	component	hells-scythe	it	{"id": "blade.hells-scythe", "lang": "it", "slot": "blade", "slug": "hells-scythe", "type": "component", "status": "draft", "system": "BX", "aliases": ["HellsScythe"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsScythe"], "doc_version": 1, "canonical_name": "HellsScythe"}	b370309e5c905e995e3642ac2a43be6e1a1e2f30d11fdb44b15475facb1b1fb9	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
75	knowledge/blades/impact-drake.md	component	impact-drake	it	{"id": "blade.impact-drake", "lang": "it", "slot": "blade", "slug": "impact-drake", "type": "component", "status": "draft", "system": "UX", "aliases": ["ImpactDrake"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ImpactDrake"], "doc_version": 1, "canonical_name": "ImpactDrake"}	9ab292fb8ca3c1981c02b418fe1fb840f490d7f6cc7dae83f86e9959f917ce96	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
703	knowledge/blades/arc.md	component	arc	it	{"id": "blade.arc", "lang": "it", "slot": "blade", "slug": "arc", "type": "component", "status": "draft", "system": "CX", "aliases": ["Arc"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Arc"], "reference": "https://beyblade.wiki/arc-main-blade/", "doc_version": 1, "canonical_name": "Arc"}	c6c72faedc4950b32c5dd9d04733011a06ededef34cb6a0aef3a996fd553fbd1	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
151	knowledge/blades/knight-lance.md	component	knight-lance	it	{"id": "blade.knight-lance", "lang": "it", "slot": "blade", "slug": "knight-lance", "type": "component", "status": "draft", "system": "BX", "aliases": ["KnightLance"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightLance"], "doc_version": 1, "canonical_name": "KnightLance"}	28e2aff7aa6b74947dffc6b9f309396ad12107904bc63a16f6e2da9c0f26988a	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
1037	knowledge/blades/arc.md	component	arc	it	{"id": "blade.arc", "lang": "it", "slot": "blade", "slug": "arc", "type": "component", "status": "draft", "system": "CX", "aliases": ["Arc"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Arc"], "reference": "https://beyblade.wiki/arc-main-blade/", "doc_version": 1, "canonical_name": "Arc"}	c6c72faedc4950b32c5dd9d04733011a06ededef34cb6a0aef3a996fd553fbd1	4	7f84633	2026-08-22 13:35:57.076988+00	\N
76	knowledge/blades/knight-mail.md	component	knight-mail	it	{"id": "blade.knight-mail", "lang": "it", "slot": "blade", "slug": "knight-mail", "type": "component", "status": "draft", "system": "UX", "aliases": ["KnightMail"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightMail"], "doc_version": 1, "canonical_name": "KnightMail"}	1530ce57d0939f5d0994d6e259de45031d1742da83dff91cfbb228199107ee06	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
704	knowledge/blades/bear-scratch.md	component	bear-scratch	it	{"id": "blade.bear-scratch", "lang": "it", "slot": "blade", "slug": "bear-scratch", "type": "component", "status": "draft", "system": "BX", "aliases": ["BearScratch"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Savage_Bear"], "doc_version": 1, "canonical_name": "BearScratch"}	6664c185fcc408c5fddc6729423e0f16a8c3198b4d35292b427959b9ef67cf72	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
77	knowledge/blades/knight-shield-blade.md	component	knight-shield-blade	it	{"id": "blade.knight-shield-blade", "lang": "it", "slot": "blade", "slug": "knight-shield-blade", "type": "component", "status": "draft", "system": "BX", "aliases": ["KnightShield", "knight-shield-blade"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightShield"], "doc_version": 1, "canonical_name": "KnightShield"}	ba638edb2c70634e01f07adfabb09ff02cd2cd5b45fbc7502ac947aa2a2c19d9	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1038	knowledge/blades/bear-scratch.md	component	bear-scratch	it	{"id": "blade.bear-scratch", "lang": "it", "slot": "blade", "slug": "bear-scratch", "type": "component", "status": "draft", "system": "BX", "aliases": ["BearScratch"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Savage_Bear"], "doc_version": 1, "canonical_name": "BearScratch"}	6664c185fcc408c5fddc6729423e0f16a8c3198b4d35292b427959b9ef67cf72	3	7f84633	2026-08-22 13:35:57.076988+00	\N
152	knowledge/blades/leon-claw.md	component	leon-claw	it	{"id": "blade.leon-claw", "lang": "it", "slot": "blade", "slug": "leon-claw", "type": "component", "status": "draft", "system": "BX", "aliases": ["LeonClaw"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_LeonClaw"], "doc_version": 1, "canonical_name": "LeonClaw"}	bb847502c64f2a0f8e67399924e4d8949edc512e1dda4469ba10a38ce3589093	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
705	knowledge/blades/black-shell.md	component	black-shell	it	{"id": "blade.black-shell", "lang": "it", "slot": "blade", "slug": "black-shell", "type": "component", "status": "draft", "system": "BX", "aliases": ["BlackShell"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_BlackShell"], "reference": "https://beyblade.wiki/black-shell-blade/", "doc_version": 1, "canonical_name": "BlackShell"}	0890d5b32b56f141aef5d1b36a03d99350b3c700b4f7ca21e46cac770c6dcb67	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
78	knowledge/blades/leon-crest.md	component	leon-crest	it	{"id": "blade.leon-crest", "lang": "it", "slot": "blade", "slug": "leon-crest", "type": "component", "status": "draft", "system": "UX", "aliases": ["LeonCrest"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_LeonCrest"], "doc_version": 1, "canonical_name": "LeonCrest"}	4cb57f39c20410c11db19799d645e78aa1a28614e5f7ea80e539e9b49380e601	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1039	knowledge/blades/black-shell.md	component	black-shell	it	{"id": "blade.black-shell", "lang": "it", "slot": "blade", "slug": "black-shell", "type": "component", "status": "draft", "system": "BX", "aliases": ["BlackShell"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_BlackShell"], "reference": "https://beyblade.wiki/black-shell-blade/", "doc_version": 1, "canonical_name": "BlackShell"}	0890d5b32b56f141aef5d1b36a03d99350b3c700b4f7ca21e46cac770c6dcb67	4	7f84633	2026-08-22 13:35:57.076988+00	\N
79	knowledge/blades/mammoth-tusk.md	component	mammoth-tusk	it	{"id": "blade.mammoth-tusk", "lang": "it", "slot": "blade", "slug": "mammoth-tusk", "type": "component", "status": "draft", "system": "BX", "aliases": ["MammothTusk"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Tusk_Mammoth"], "doc_version": 1, "canonical_name": "MammothTusk"}	b0d3baad4e87fe7030682cd191ef23cf346a44dacc8a2132842251c864dfa70f	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
706	knowledge/blades/blast.md	component	blast	it	{"id": "blade.blast", "lang": "it", "slot": "blade", "slug": "blast", "type": "component", "status": "draft", "system": "CX", "aliases": ["Blast"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Blast"], "reference": "https://beyblade.wiki/blast-main-blade/", "doc_version": 1, "canonical_name": "Blast"}	a32d3c07822f795bfaeecf201e01b24b3450f70348dc305e6d4f1e576ab4f3c7	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
153	knowledge/blades/might.md	component	might	it	{"id": "blade.might", "lang": "it", "slot": "blade", "slug": "might", "type": "component", "status": "draft", "system": "CX", "aliases": ["Might"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Might"], "doc_version": 1, "canonical_name": "Might"}	fc884264ffb2ef0db23162b7a6736eefd832d90bd4932cf76b921af0504662f1	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
80	knowledge/blades/phoenix-feather.md	component	phoenix-feather	it	{"id": "blade.phoenix-feather", "lang": "it", "slot": "blade", "slug": "phoenix-feather", "type": "component", "status": "draft", "system": "BX", "aliases": ["PhoenixFeather"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixFeather"], "doc_version": 1, "canonical_name": "PhoenixFeather"}	bee54e8d4ec70c01c8b78751119bf2bd48535a293eb3f9f8f398fea8e35187b7	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
707	knowledge/blades/brave.md	component	brave	it	{"id": "blade.brave", "lang": "it", "slot": "blade", "slug": "brave", "type": "component", "status": "draft", "system": "CX", "aliases": ["Brave"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Brave"], "reference": "https://beyblade.wiki/brave-main-blade/", "doc_version": 1, "canonical_name": "Brave"}	e6bffbc10c73a1b2fdaedaa55ce6b181f9a121a90834b22ebec62eb4119e684f	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
81	knowledge/blades/phoenix-rudder.md	component	phoenix-rudder	it	{"id": "blade.phoenix-rudder", "lang": "it", "slot": "blade", "slug": "phoenix-rudder", "type": "component", "status": "draft", "system": "UX", "aliases": ["PhoenixRudder"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixRudder"], "doc_version": 1, "canonical_name": "PhoenixRudder"}	d7e35c6622dc491b8ab0a269939003f3386386b211ffc080398a2fa63bda2937	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1041	knowledge/blades/brave.md	component	brave	it	{"id": "blade.brave", "lang": "it", "slot": "blade", "slug": "brave", "type": "component", "status": "draft", "system": "CX", "aliases": ["Brave"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Brave"], "reference": "https://beyblade.wiki/brave-main-blade/", "doc_version": 1, "canonical_name": "Brave"}	e6bffbc10c73a1b2fdaedaa55ce6b181f9a121a90834b22ebec62eb4119e684f	4	7f84633	2026-08-22 13:35:57.076988+00	\N
88	knowledge/blades/shark-edge.md	component	shark-edge	it	{"id": "blade.shark-edge", "lang": "it", "slot": "blade", "slug": "shark-edge", "type": "component", "status": "draft", "system": "BX", "aliases": ["SharkEdge"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SharkEdge"], "doc_version": 1, "canonical_name": "SharkEdge"}	11b928dc98bd9ed85499c540e2a657bb59825fa13cdb0880ebae1447f968f15c	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
20	knowledge/blades/phoenix-wing.md	component	phoenix-wing	it	{"id": "blade.phoenix-wing", "lang": "it", "slot": "blade", "slug": "phoenix-wing", "type": "component", "status": "draft", "system": "BX", "aliases": ["PhoenixSoar (Youngtoys)", "PhoenixWing", "Soar Phoenix"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixWing"], "doc_version": 1, "canonical_name": "PhoenixWing"}	9d79363295369d02ac196dab72ceba2853ca5e809b067b5cf6ef3b1ecc710146	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
708	knowledge/blades/brush.md	component	brush	it	{"id": "blade.brush", "lang": "it", "slot": "blade", "slug": "brush", "type": "component", "status": "draft", "system": "CX", "aliases": ["Brush"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Brush"], "reference": "https://beyblade.wiki/brush-main-blade/", "doc_version": 1, "canonical_name": "Brush"}	6b392f9af65da6b5f629fbb0938487e8ca3a0b573d2d7b5124dd55ba1634092f	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
157	knowledge/blades/reaper.md	component	reaper	it	{"id": "blade.reaper", "lang": "it", "slot": "blade", "slug": "reaper", "type": "component", "status": "draft", "system": "CX", "aliases": ["Reaper"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Reaper"], "doc_version": 1, "canonical_name": "Reaper"}	1621a10013f8ce209309f694773b5b82f5de5cc4ffcd7d6e307135c8607bc7ad	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
1042	knowledge/blades/brush.md	component	brush	it	{"id": "blade.brush", "lang": "it", "slot": "blade", "slug": "brush", "type": "component", "status": "draft", "system": "CX", "aliases": ["Brush"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Brush"], "reference": "https://beyblade.wiki/brush-main-blade/", "doc_version": 1, "canonical_name": "Brush"}	6b392f9af65da6b5f629fbb0938487e8ca3a0b573d2d7b5124dd55ba1634092f	4	7f84633	2026-08-22 13:35:57.076988+00	\N
158	knowledge/blades/rhino-horn.md	component	rhino-horn	it	{"id": "blade.rhino-horn", "lang": "it", "slot": "blade", "slug": "rhino-horn", "type": "component", "status": "draft", "system": "BX", "aliases": ["RhinoHorn"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_RhinoHorn"], "doc_version": 1, "canonical_name": "RhinoHorn"}	fc3103945164baf1fc773ddf02516753f6abf0ff8574320d1527fe45c39e591e	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
84	knowledge/blades/samurai-calibur.md	component	samurai-calibur	it	{"id": "blade.samurai-calibur", "lang": "it", "slot": "blade", "slug": "samurai-calibur", "type": "component", "status": "draft", "system": "BX", "aliases": ["SamuraiCalibur"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SamuraiCalibur"], "doc_version": 1, "canonical_name": "SamuraiCalibur"}	6e9605d795dee4894d3e9781508fee475460468e2dc4bc4c118703b0f6fa2c6b	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
85	knowledge/blades/samurai-saber.md	component	samurai-saber	it	{"id": "blade.samurai-saber", "lang": "it", "slot": "blade", "slug": "samurai-saber", "type": "component", "status": "draft", "system": "UX", "aliases": ["SamuraiSaber"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SamuraiSaber"], "doc_version": 1, "canonical_name": "SamuraiSaber"}	d64256c033553701adc20fb0e8d6bf4c5176e47e9d40c195e4f2d0dbd976c002	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1045	knowledge/blades/cobalt-drake.md	component	cobalt-drake	it	{"id": "blade.cobalt-drake", "lang": "it", "slot": "blade", "slug": "cobalt-drake", "type": "component", "status": "draft", "system": "BX", "aliases": ["CobaltDrake"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CobaltDrake"], "reference": "https://beyblade.wiki/cobalt-drake-blade/", "doc_version": 1, "canonical_name": "CobaltDrake"}	0657f941e26f7700ed0a94ba0ef81ba91d134fc4ceb497b6513331802bad3e3c	4	7f84633	2026-08-22 13:35:57.076988+00	\N
86	knowledge/blades/samurai-steel.md	component	samurai-steel	it	{"id": "blade.samurai-steel", "lang": "it", "slot": "blade", "slug": "samurai-steel", "type": "component", "status": "draft", "system": "BX", "aliases": ["SamuraiSteel"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Steel_Samurai"], "doc_version": 1, "canonical_name": "SamuraiSteel"}	f609408ce10934bc1cbe8d45ca8016f6b4fe90ccdb2a417687eb5979a1788586	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
712	knowledge/blades/crimson-garuda.md	component	crimson-garuda	it	{"id": "blade.crimson-garuda", "lang": "it", "slot": "blade", "slug": "crimson-garuda", "type": "component", "status": "draft", "system": "BX", "aliases": ["CrimsonGaruda"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CrimsonGaruda"], "reference": "https://beyblade.wiki/crimson-garuda-blade/", "doc_version": 1, "canonical_name": "CrimsonGaruda"}	5d365d3dfdc498d439820f139b9858d757c10fcd3cd4a09b7fcb6b0eab9f4ab2	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
87	knowledge/blades/scorpio-spear.md	component	scorpio-spear	it	{"id": "blade.scorpio-spear", "lang": "it", "slot": "blade", "slug": "scorpio-spear", "type": "component", "status": "draft", "system": "UX", "aliases": ["ScorpioSpear"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ScorpioSpear"], "doc_version": 1, "canonical_name": "ScorpioSpear"}	bb29f1adb55271b0e9885c2296c88db62db27fe68f2217b3b92c8a04ae27d76a	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1046	knowledge/blades/crimson-garuda.md	component	crimson-garuda	it	{"id": "blade.crimson-garuda", "lang": "it", "slot": "blade", "slug": "crimson-garuda", "type": "component", "status": "draft", "system": "BX", "aliases": ["CrimsonGaruda"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CrimsonGaruda"], "reference": "https://beyblade.wiki/crimson-garuda-blade/", "doc_version": 1, "canonical_name": "CrimsonGaruda"}	5d365d3dfdc498d439820f139b9858d757c10fcd3cd4a09b7fcb6b0eab9f4ab2	4	7f84633	2026-08-22 13:35:57.076988+00	\N
106	knowledge/ratchets/2-70.md	component	2-70	it	{"id": "ratchet.2-70", "lang": "it", "slot": "ratchet", "slug": "2-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["2-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_2-70"], "doc_version": 1, "canonical_name": "2-70"}	cfa683b7db2b1782c11027533fff09833181b6c462e826e0185d0417e1128ecb	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
713	knowledge/blades/croc-crunch.md	component	croc-crunch	it	{"id": "blade.croc-crunch", "lang": "it", "slot": "blade", "slug": "croc-crunch", "type": "component", "status": "draft", "system": "BX", "aliases": ["CrocCrunch"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Bite_Croc"], "reference": "https://beyblade.wiki/croc-crunch-blade/", "doc_version": 1, "canonical_name": "CrocCrunch"}	eda8d49dbd769e056545efea36561a2a4f083e3eb862fc642b96c9f1d29849a7	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
21	knowledge/blades/shark-scale.md	component	shark-scale	it	{"id": "blade.shark-scale", "lang": "it", "slot": "blade", "slug": "shark-scale", "type": "component", "status": "draft", "system": "UX", "aliases": ["Scale Shark", "SharkScale"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SharkScale"], "doc_version": 1, "canonical_name": "SharkScale"}	fdfcb9d416d146a4d9bfd5de28d056d2bef2c1976030a35971cb0eb665e701cd	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
1047	knowledge/blades/croc-crunch.md	component	croc-crunch	it	{"id": "blade.croc-crunch", "lang": "it", "slot": "blade", "slug": "croc-crunch", "type": "component", "status": "draft", "system": "BX", "aliases": ["CrocCrunch"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Bite_Croc"], "reference": "https://beyblade.wiki/croc-crunch-blade/", "doc_version": 1, "canonical_name": "CrocCrunch"}	eda8d49dbd769e056545efea36561a2a4f083e3eb862fc642b96c9f1d29849a7	4	7f84633	2026-08-22 13:35:57.076988+00	\N
159	knowledge/blades/shinobi-shadow.md	component	shinobi-shadow	it	{"id": "blade.shinobi-shadow", "lang": "it", "slot": "blade", "slug": "shinobi-shadow", "type": "component", "status": "draft", "system": "UX", "aliases": ["ShinobiShadow"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ShinobiShadow"], "doc_version": 1, "canonical_name": "ShinobiShadow"}	6c5aff5203c459457e087859092883b9dccf146e9287f6bcf225ffb789e358c8	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
714	knowledge/blades/dark.md	component	dark	it	{"id": "blade.dark", "lang": "it", "slot": "blade", "slug": "dark", "type": "component", "status": "draft", "system": "CX", "aliases": ["Dark"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Dark"], "reference": "https://beyblade.wiki/dark-main-blade/", "doc_version": 1, "canonical_name": "Dark"}	96838bf02e71409e75e0af205205d144837834c06d8537f97dacd77ed0ee46e3	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
22	knowledge/blades/silver-wolf.md	component	silver-wolf	it	{"id": "blade.silver-wolf", "lang": "it", "slot": "blade", "slug": "silver-wolf", "type": "component", "status": "draft", "system": "UX", "aliases": ["SilverWolf", "Sterling Wolf"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SilverWolf"], "doc_version": 1, "canonical_name": "SilverWolf"}	c48eaaf97da70215c4d72f2915841079929c3eeedbcb385e0d84db0e44048d1c	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
1048	knowledge/blades/dark.md	component	dark	it	{"id": "blade.dark", "lang": "it", "slot": "blade", "slug": "dark", "type": "component", "status": "draft", "system": "CX", "aliases": ["Dark"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Dark"], "reference": "https://beyblade.wiki/dark-main-blade/", "doc_version": 1, "canonical_name": "Dark"}	96838bf02e71409e75e0af205205d144837834c06d8537f97dacd77ed0ee46e3	4	7f84633	2026-08-22 13:35:57.076988+00	\N
94	knowledge/blades/tricera-press.md	component	tricera-press	it	{"id": "blade.tricera-press", "lang": "it", "slot": "blade", "slug": "tricera-press", "type": "component", "status": "draft", "system": "BX", "aliases": ["TriceraPress"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TriceraPress"], "doc_version": 1, "canonical_name": "TriceraPress"}	cca0cf12458541904e2ffdfa7da3499ff571ac6fb2326977a36414b181f13a17	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
715	knowledge/blades/darth-vader.md	component	darth-vader	it	{"id": "blade.darth-vader", "lang": "it", "slot": "blade", "slug": "darth-vader", "type": "component", "status": "draft", "system": "BX", "aliases": ["DarthVader"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Darth_Vader"], "doc_version": 1, "canonical_name": "DarthVader"}	3ed1d2c00f9071884762d9189d172ec82328aad9617e83e7499a7edea2d2abaf	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
163	knowledge/blades/tyranno-beat.md	component	tyranno-beat	it	{"id": "blade.tyranno-beat", "lang": "it", "slot": "blade", "slug": "tyranno-beat", "type": "component", "status": "draft", "system": "BX", "aliases": ["TyrannoBeat"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TyrannoBeat"], "doc_version": 1, "canonical_name": "TyrannoBeat"}	dacdb9d91dfb55608711beae720354172a30e0609625013b8e26439663a9da61	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
1049	knowledge/blades/darth-vader.md	component	darth-vader	it	{"id": "blade.darth-vader", "lang": "it", "slot": "blade", "slug": "darth-vader", "type": "component", "status": "draft", "system": "BX", "aliases": ["DarthVader"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Darth_Vader"], "doc_version": 1, "canonical_name": "DarthVader"}	3ed1d2c00f9071884762d9189d172ec82328aad9617e83e7499a7edea2d2abaf	3	7f84633	2026-08-22 13:35:57.076988+00	\N
95	knowledge/blades/tyranno-roar.md	component	tyranno-roar	it	{"id": "blade.tyranno-roar", "lang": "it", "slot": "blade", "slug": "tyranno-roar", "type": "component", "status": "draft", "system": "BX", "aliases": ["TyrannoRoar"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Roar_Tyranno"], "doc_version": 1, "canonical_name": "TyrannoRoar"}	c76deea2297073b527a65e2960a158bac1219118311f9287507c2521f41a9d38	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
716	knowledge/blades/draciel-shield.md	component	draciel-shield	it	{"id": "blade.draciel-shield", "lang": "it", "slot": "blade", "slug": "draciel-shield", "type": "component", "status": "draft", "system": "BX", "aliases": ["DracielShield"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DracielShield"], "doc_version": 1, "canonical_name": "DracielShield"}	aa46cda58de46fa7ada23243485728ba4bfcdd91e4bdbea41b7f6e99b6c7a4c1	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
96	knowledge/blades/unicorn-sting.md	component	unicorn-sting	it	{"id": "blade.unicorn-sting", "lang": "it", "slot": "blade", "slug": "unicorn-sting", "type": "component", "status": "draft", "system": "BX", "aliases": ["UnicornSting"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_UnicornSting"], "doc_version": 1, "canonical_name": "UnicornSting"}	770b35eb2a07aeab2c12b29e05b91663a72fded8850fc001ca6a723de638638e	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1090	knowledge/blades/scorpio-spear.md	component	scorpio-spear	it	{"id": "blade.scorpio-spear", "lang": "it", "slot": "blade", "slug": "scorpio-spear", "type": "component", "status": "draft", "system": "UX", "aliases": ["ScorpioSpear"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ScorpioSpear"], "reference": "https://beyblade.wiki/scorpio-spear-blade/", "doc_version": 1, "canonical_name": "ScorpioSpear"}	66681d4bbecb76107c06bf8d8ecf23eafdffec200e6d42f4d04299d51252050e	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
1050	knowledge/blades/draciel-shield.md	component	draciel-shield	it	{"id": "blade.draciel-shield", "lang": "it", "slot": "blade", "slug": "draciel-shield", "type": "component", "status": "draft", "system": "BX", "aliases": ["DracielShield"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DracielShield"], "doc_version": 1, "canonical_name": "DracielShield"}	aa46cda58de46fa7ada23243485728ba4bfcdd91e4bdbea41b7f6e99b6c7a4c1	3	7f84633	2026-08-22 13:35:57.076988+00	\N
166	knowledge/blades/viper-tail.md	component	viper-tail	it	{"id": "blade.viper-tail", "lang": "it", "slot": "blade", "slug": "viper-tail", "type": "component", "status": "draft", "system": "BX", "aliases": ["ViperTail"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ViperTail"], "doc_version": 1, "canonical_name": "ViperTail"}	1c5bc67b23668fb5111dcc06fba475e001c449d1ec98ba4e2210f05176e9e190	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
717	knowledge/blades/dragoon-storm.md	component	dragoon-storm	it	{"id": "blade.dragoon-storm", "lang": "it", "slot": "blade", "slug": "dragoon-storm", "type": "component", "status": "draft", "system": "BX", "aliases": ["DragoonStorm"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DragoonStorm"], "doc_version": 1, "canonical_name": "DragoonStorm"}	ae79ae410854e5ac83ca658da97d9757aa8ecac01af533566ce5f8c5b1002a6d	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
97	knowledge/blades/weiss-tiger.md	component	weiss-tiger	it	{"id": "blade.weiss-tiger", "lang": "it", "slot": "blade", "slug": "weiss-tiger", "type": "component", "status": "draft", "system": "BX", "aliases": ["WeissTiger"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WeissTiger"], "doc_version": 1, "canonical_name": "WeissTiger"}	d8be6a59bad7a9628c6587cc83ec2d633118ff7359d429384cd232235cc79a4d	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1051	knowledge/blades/dragoon-storm.md	component	dragoon-storm	it	{"id": "blade.dragoon-storm", "lang": "it", "slot": "blade", "slug": "dragoon-storm", "type": "component", "status": "draft", "system": "BX", "aliases": ["DragoonStorm"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DragoonStorm"], "doc_version": 1, "canonical_name": "DragoonStorm"}	ae79ae410854e5ac83ca658da97d9757aa8ecac01af533566ce5f8c5b1002a6d	3	7f84633	2026-08-22 13:35:57.076988+00	\N
98	knowledge/blades/whale-wave.md	component	whale-wave	it	{"id": "blade.whale-wave", "lang": "it", "slot": "blade", "slug": "whale-wave", "type": "component", "status": "draft", "system": "BX", "aliases": ["WhaleWave"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WhaleWave"], "doc_version": 1, "canonical_name": "WhaleWave"}	a26b82a44e611f883d38f3391c5ef8c7a13bd5ee42ca3e59c8f6f083b9e68bbb	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
718	knowledge/blades/dran-buster.md	component	dran-buster	it	{"id": "blade.dran-buster", "lang": "it", "slot": "blade", "slug": "dran-buster", "type": "component", "status": "draft", "system": "UX", "aliases": ["DranBuster"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranBuster"], "reference": "https://beyblade.wiki/dran-buster-blade/", "doc_version": 1, "canonical_name": "DranBuster"}	ae1b3240a1de6b4d0cc46f76ef56f6658515c9c931f5025aea9f6b27221ab127	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
167	knowledge/blades/wizard-arrow.md	component	wizard-arrow	it	{"id": "blade.wizard-arrow", "lang": "it", "slot": "blade", "slug": "wizard-arrow", "type": "component", "status": "draft", "system": "BX", "aliases": ["WizardArrow"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WizardArrow"], "doc_version": 1, "canonical_name": "WizardArrow"}	1841fc1d57212ce8d56d495f51f19ebf1f72fc0957e9549e3123b2a1d501a0dc	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
23	knowledge/blades/wizard-rod.md	component	wizard-rod	it	{"id": "blade.wizard-rod", "lang": "it", "slot": "blade", "slug": "wizard-rod", "type": "component", "status": "draft", "system": "UX", "aliases": ["Wand Wizard", "WizardRod"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WizardRod"], "doc_version": 1, "canonical_name": "WizardRod"}	cd02342bb14b97900bb0cfe3ec56f21f528bb4df2cb1766e46f14674a5d627bd	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
719	knowledge/blades/dran-dagger.md	component	dran-dagger	it	{"id": "blade.dran-dagger", "lang": "it", "slot": "blade", "slug": "dran-dagger", "type": "component", "status": "draft", "system": "BX", "aliases": ["DranDagger"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranDagger"], "reference": "https://beyblade.wiki/dran-dagger-blade/", "doc_version": 1, "canonical_name": "DranDagger"}	f902a87be24c25a1eb4b81fb046d0050c170e5acb04704c47bbaee817aa54e44	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
168	knowledge/blades/wyvern-gale.md	component	wyvern-gale	it	{"id": "blade.wyvern-gale", "lang": "it", "slot": "blade", "slug": "wyvern-gale", "type": "component", "status": "draft", "system": "BX", "aliases": ["WyvernGale"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WyvernGale"], "doc_version": 1, "canonical_name": "WyvernGale"}	43cda5d02d1b98738f96bf44268b274302251e994eedbd9b64a0321f1a33fbd3	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
1053	knowledge/blades/dran-dagger.md	component	dran-dagger	it	{"id": "blade.dran-dagger", "lang": "it", "slot": "blade", "slug": "dran-dagger", "type": "component", "status": "draft", "system": "BX", "aliases": ["DranDagger"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranDagger"], "reference": "https://beyblade.wiki/dran-dagger-blade/", "doc_version": 1, "canonical_name": "DranDagger"}	f902a87be24c25a1eb4b81fb046d0050c170e5acb04704c47bbaee817aa54e44	4	7f84633	2026-08-22 13:35:57.076988+00	\N
24	knowledge/lock-chips/emperor.md	component	emperor	it	{"id": "lock_chip.emperor", "lang": "it", "slot": "lock_chip", "slug": "emperor", "type": "component", "status": "draft", "system": "CX", "aliases": ["emperor"], "sources": ["https://beyblade.fandom.com/wiki/Lock_Chip_-_Emperor"], "doc_version": 1, "canonical_name": "emperor"}	3c83de418e32c96bba8ea9a0ec561291774d7ce401d99ce89c27458990a687ae	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
720	knowledge/blades/dran-sword.md	component	dran-sword	it	{"id": "blade.dran-sword", "lang": "it", "slot": "blade", "slug": "dran-sword", "type": "component", "status": "draft", "system": "BX", "aliases": ["DranSword"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranSword"], "reference": "https://beyblade.wiki/dran-sword-blade/", "doc_version": 1, "canonical_name": "DranSword"}	6debfa55e73496403d96e22cefaaf9b4f52a750c5f54c6fdd66ba8cd8830dbde	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
101	knowledge/lock-chips/valkyrie.md	component	valkyrie	it	{"id": "lock_chip.valkyrie", "lang": "it", "slot": "lock_chip", "slug": "valkyrie", "type": "component", "status": "draft", "system": "CX", "aliases": ["valkyrie"], "sources": ["https://beyblade.fandom.com/wiki/Lock_Chip_-_Valkyrie"], "doc_version": 1, "canonical_name": "valkyrie"}	c52e83355979a1872cd3748c405fdc02ba6ef47f403afab5b0f1f8df781c11a8	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1054	knowledge/blades/dran-sword.md	component	dran-sword	it	{"id": "blade.dran-sword", "lang": "it", "slot": "blade", "slug": "dran-sword", "type": "component", "status": "draft", "system": "BX", "aliases": ["DranSword"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranSword"], "reference": "https://beyblade.wiki/dran-sword-blade/", "doc_version": 1, "canonical_name": "DranSword"}	6debfa55e73496403d96e22cefaaf9b4f52a750c5f54c6fdd66ba8cd8830dbde	4	7f84633	2026-08-22 13:35:57.076988+00	\N
102	knowledge/ratchets/0-60.md	component	0-60	it	{"id": "ratchet.0-60", "lang": "it", "slot": "ratchet", "slug": "0-60", "type": "component", "status": "draft", "system": "CX", "aliases": ["0-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_0-60"], "doc_version": 1, "canonical_name": "0-60"}	ea766d0f641b903010066f34fa41de0475d6bcbe4f0533012f76147495b8996f	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
721	knowledge/blades/dranzer-spiral.md	component	dranzer-spiral	it	{"id": "blade.dranzer-spiral", "lang": "it", "slot": "blade", "slug": "dranzer-spiral", "type": "component", "status": "draft", "system": "BX", "aliases": ["DranzerSpiral"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranzerSpiral"], "reference": "https://beyblade.wiki/dranzer-spiral-blade/", "doc_version": 1, "canonical_name": "DranzerSpiral"}	acb130289e38158fa76c2a587f7af28b1fee976a418abe3c059f51f47ebe8320	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
103	knowledge/ratchets/0-70.md	component	0-70	it	{"id": "ratchet.0-70", "lang": "it", "slot": "ratchet", "slug": "0-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["0-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_0-70"], "doc_version": 1, "canonical_name": "0-70"}	9f2d4682ad8a7e8504b54b69da82d93ea02f3230cb3d7283ab1c1952284f4950	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1055	knowledge/blades/dranzer-spiral.md	component	dranzer-spiral	it	{"id": "blade.dranzer-spiral", "lang": "it", "slot": "blade", "slug": "dranzer-spiral", "type": "component", "status": "draft", "system": "BX", "aliases": ["DranzerSpiral"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranzerSpiral"], "reference": "https://beyblade.wiki/dranzer-spiral-blade/", "doc_version": 1, "canonical_name": "DranzerSpiral"}	acb130289e38158fa76c2a587f7af28b1fee976a418abe3c059f51f47ebe8320	4	7f84633	2026-08-22 13:35:57.076988+00	\N
104	knowledge/ratchets/0-80.md	component	0-80	it	{"id": "ratchet.0-80", "lang": "it", "slot": "ratchet", "slug": "0-80", "type": "component", "status": "draft", "system": "UX", "aliases": ["0-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_0-80"], "doc_version": 1, "canonical_name": "0-80"}	2cfc206c38be9ed738980e061c08d00e5d9cb01b2bfe770d9d2fb2e0806c0359	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
722	knowledge/blades/driger-slash.md	component	driger-slash	it	{"id": "blade.driger-slash", "lang": "it", "slot": "blade", "slug": "driger-slash", "type": "component", "status": "draft", "system": "BX", "aliases": ["DrigerSlash"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DrigerSlash"], "doc_version": 1, "canonical_name": "DrigerSlash"}	0fad390851e0d9eeded5cc4b8c1711db8f3fe929bea13af10c91e07560881e0d	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
25	knowledge/ratchets/1-60.md	component	1-60	it	{"id": "ratchet.1-60", "lang": "it", "slot": "ratchet", "slug": "1-60", "type": "component", "status": "draft", "system": "UX", "aliases": ["1-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-60"], "doc_version": 1, "canonical_name": "1-60"}	85512d57cc44b8256994c34b78d510af99681ecc14e5340a79966be27c6116d4	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
1056	knowledge/blades/driger-slash.md	component	driger-slash	it	{"id": "blade.driger-slash", "lang": "it", "slot": "blade", "slug": "driger-slash", "type": "component", "status": "draft", "system": "BX", "aliases": ["DrigerSlash"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DrigerSlash"], "doc_version": 1, "canonical_name": "DrigerSlash"}	0fad390851e0d9eeded5cc4b8c1711db8f3fe929bea13af10c91e07560881e0d	3	7f84633	2026-08-22 13:35:57.076988+00	\N
26	knowledge/ratchets/1-70.md	component	1-70	it	{"id": "ratchet.1-70", "lang": "it", "slot": "ratchet", "slug": "1-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["1-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-70"], "doc_version": 1, "canonical_name": "1-70"}	5ba144e75f728369f9857b4ae07b5172373678fe1160359e9d26cfdca41901f9	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
723	knowledge/blades/eclipse.md	component	eclipse	it	{"id": "blade.eclipse", "lang": "it", "slot": "blade", "slug": "eclipse", "type": "component", "status": "draft", "system": "CX", "aliases": ["Eclipse"], "sources": [], "reference": "https://beyblade.wiki/eclipse-main-blade/", "doc_version": 1, "canonical_name": "Eclipse"}	2d438932d58873d170755e46b939c423648c715b9088051b61a000e9ace76e3d	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
105	knowledge/ratchets/1-80.md	component	1-80	it	{"id": "ratchet.1-80", "lang": "it", "slot": "ratchet", "slug": "1-80", "type": "component", "status": "draft", "system": "UX", "aliases": ["1-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-80"], "doc_version": 1, "canonical_name": "1-80"}	bde6c14ac6c6abb6c060b942b022f9623b3de573d5494608b52aaaabdf7441e3	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
169	knowledge/ratchets/2-60.md	component	2-60	it	{"id": "ratchet.2-60", "lang": "it", "slot": "ratchet", "slug": "2-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["2-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_2-60"], "doc_version": 1, "canonical_name": "2-60"}	d079505cab1818fb23d066044042b5b8542a176f24943a518970af964dd0f384	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
724	knowledge/blades/flame.md	component	flame	it	{"id": "blade.flame", "lang": "it", "slot": "blade", "slug": "flame", "type": "component", "status": "draft", "system": "CX", "aliases": ["Flame"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Flame"], "reference": "https://beyblade.wiki/flame-main-blade/", "doc_version": 1, "canonical_name": "Flame"}	856ebbbe5c49ec3c8eb18d83c6961b61e8061305e886bd7270f95224ea0e39b4	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
27	knowledge/ratchets/3-60.md	component	3-60	it	{"id": "ratchet.3-60", "lang": "it", "slot": "ratchet", "slug": "3-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["3-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-60"], "doc_version": 1, "canonical_name": "3-60"}	22b774bf041cb0f4612056fb183add7d90d6b6db7be3da4ecb49898436df63fc	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
725	knowledge/blades/general-grievous.md	component	general-grievous	it	{"id": "blade.general-grievous", "lang": "it", "slot": "blade", "slug": "general-grievous", "type": "component", "status": "draft", "system": "BX", "aliases": ["GeneralGrievous"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_General_Grievous"], "doc_version": 1, "canonical_name": "GeneralGrievous"}	fc2a88b06f55b4fb05c00efb7c3256b29c5d2bef00ccd02d9ad421d64f819126	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
170	knowledge/ratchets/3-70.md	component	3-70	it	{"id": "ratchet.3-70", "lang": "it", "slot": "ratchet", "slug": "3-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["3-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-70"], "doc_version": 1, "canonical_name": "3-70"}	041c6fa0de2154657ad3e7d64aeab192263664012d356bf14dff0b80a9a2c05e	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
107	knowledge/ratchets/3-80.md	component	3-80	it	{"id": "ratchet.3-80", "lang": "it", "slot": "ratchet", "slug": "3-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["3-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-80"], "doc_version": 1, "canonical_name": "3-80"}	f87fbdcf533a9c2af72874db569ecfe92549691261a20a03c05b870a405d0396	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
726	knowledge/blades/ghost-circle.md	component	ghost-circle	it	{"id": "blade.ghost-circle", "lang": "it", "slot": "blade", "slug": "ghost-circle", "type": "component", "status": "draft", "system": "UX", "aliases": ["GhostCircle"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_GhostCircle"], "reference": "https://beyblade.wiki/ghost-circle-blade/", "doc_version": 1, "canonical_name": "GhostCircle"}	20386b48dcb8c80489a062f71d86185d7c10bc446dc7adf1cc4116de503e5777	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
108	knowledge/ratchets/4-50.md	component	4-50	it	{"id": "ratchet.4-50", "lang": "it", "slot": "ratchet", "slug": "4-50", "type": "component", "status": "draft", "system": "UX", "aliases": ["4-50"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-50"], "doc_version": 1, "canonical_name": "4-50"}	738a53500e807c3f7f02f95915ca987ec57535e957dad675ec3a18bd5030a203	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1060	knowledge/blades/ghost-circle.md	component	ghost-circle	it	{"id": "blade.ghost-circle", "lang": "it", "slot": "blade", "slug": "ghost-circle", "type": "component", "status": "draft", "system": "UX", "aliases": ["GhostCircle"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_GhostCircle"], "reference": "https://beyblade.wiki/ghost-circle-blade/", "doc_version": 1, "canonical_name": "GhostCircle"}	20386b48dcb8c80489a062f71d86185d7c10bc446dc7adf1cc4116de503e5777	4	7f84633	2026-08-22 13:35:57.076988+00	\N
109	knowledge/ratchets/4-55.md	component	4-55	it	{"id": "ratchet.4-55", "lang": "it", "slot": "ratchet", "slug": "4-55", "type": "component", "status": "draft", "system": "CX", "aliases": ["4-55"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-55"], "doc_version": 1, "canonical_name": "4-55"}	c90d52ad4e8210e6646914417c803e4f709df18d81fca18270bc6ea8e470709f	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
727	knowledge/blades/gill-shark.md	component	gill-shark	it	{"id": "blade.gill-shark", "lang": "it", "slot": "blade", "slug": "gill-shark", "type": "component", "status": "draft", "system": "BX", "aliases": ["GillShark"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Gill_Shark"], "doc_version": 1, "canonical_name": "GillShark"}	cc5260a858482422c2e42eef554216d1d0cf393ce10222f054dd90b8e467f6c5	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
110	knowledge/ratchets/4-60.md	component	4-60	it	{"id": "ratchet.4-60", "lang": "it", "slot": "ratchet", "slug": "4-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["4-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-60"], "doc_version": 1, "canonical_name": "4-60"}	f465b24f97e5142ecbf5b4719e852df38b27b1f03e7c8494c63af04efe05f3c3	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1061	knowledge/blades/gill-shark.md	component	gill-shark	it	{"id": "blade.gill-shark", "lang": "it", "slot": "blade", "slug": "gill-shark", "type": "component", "status": "draft", "system": "BX", "aliases": ["GillShark"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Gill_Shark"], "doc_version": 1, "canonical_name": "GillShark"}	cc5260a858482422c2e42eef554216d1d0cf393ce10222f054dd90b8e467f6c5	3	7f84633	2026-08-22 13:35:57.076988+00	\N
111	knowledge/ratchets/4-70.md	component	4-70	it	{"id": "ratchet.4-70", "lang": "it", "slot": "ratchet", "slug": "4-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["4-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-70"], "doc_version": 1, "canonical_name": "4-70"}	06cd5a6d717b86e38d9cb54a9057c3293f1e793ea2f365650792cbcaf69f849e	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
728	knowledge/blades/golem-rock.md	component	golem-rock	it	{"id": "blade.golem-rock", "lang": "it", "slot": "blade", "slug": "golem-rock", "type": "component", "status": "draft", "system": "UX", "aliases": ["GolemRock"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_GolemRock"], "reference": "https://beyblade.wiki/golem-rock-blade/", "doc_version": 1, "canonical_name": "GolemRock"}	3834108ae47f1c7b45a1971b129adc0d3a5c86727e49a77252732e87c2570e96	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
112	knowledge/ratchets/4-80.md	component	4-80	it	{"id": "ratchet.4-80", "lang": "it", "slot": "ratchet", "slug": "4-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["4-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-80"], "doc_version": 1, "canonical_name": "4-80"}	2239180d83e5467280266008b098eca53c6fb1e07e2fdce92051250479743505	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
28	knowledge/ratchets/5-60.md	component	5-60	it	{"id": "ratchet.5-60", "lang": "it", "slot": "ratchet", "slug": "5-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["5-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-60"], "doc_version": 1, "canonical_name": "5-60"}	4825a6f3f9e853e07fb3e9da9c4c11b2f41cd88214ccd6acb314814f64b88c19	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
729	knowledge/blades/hells-chain.md	component	hells-chain	it	{"id": "blade.hells-chain", "lang": "it", "slot": "blade", "slug": "hells-chain", "type": "component", "status": "draft", "system": "BX", "aliases": ["HellsChain"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsChain"], "reference": "https://beyblade.wiki/hells-chain-blade/", "doc_version": 1, "canonical_name": "HellsChain"}	f9c7b831001a46ba9816c8b9d61360ebcb23c5fbd3c383dd1f69f58501b3cfab	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
171	knowledge/ratchets/5-70.md	component	5-70	it	{"id": "ratchet.5-70", "lang": "it", "slot": "ratchet", "slug": "5-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["5-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-70"], "doc_version": 1, "canonical_name": "5-70"}	17ea0ae8eec11a1cda004f80707cd4b410452ef1b23879022f725c318afd40ff	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 22:14:27.709114+00
1063	knowledge/blades/hells-chain.md	component	hells-chain	it	{"id": "blade.hells-chain", "lang": "it", "slot": "blade", "slug": "hells-chain", "type": "component", "status": "draft", "system": "BX", "aliases": ["HellsChain"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsChain"], "reference": "https://beyblade.wiki/hells-chain-blade/", "doc_version": 1, "canonical_name": "HellsChain"}	f9c7b831001a46ba9816c8b9d61360ebcb23c5fbd3c383dd1f69f58501b3cfab	4	7f84633	2026-08-22 13:35:57.076988+00	\N
113	knowledge/ratchets/5-80.md	component	5-80	it	{"id": "ratchet.5-80", "lang": "it", "slot": "ratchet", "slug": "5-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["5-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-80"], "doc_version": 1, "canonical_name": "5-80"}	05d509dc28b826057fdc1740fd404002f1ae1a5fa350b7f1f40403194161bef1	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
730	knowledge/blades/hells-hammer.md	component	hells-hammer	it	{"id": "blade.hells-hammer", "lang": "it", "slot": "blade", "slug": "hells-hammer", "type": "component", "status": "draft", "system": "UX", "aliases": ["HellsHammer"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsHammer"], "reference": "https://beyblade.wiki/hells-hammer-blade/", "doc_version": 1, "canonical_name": "HellsHammer"}	1814d04eac70523e14b49357c884bf6bad87f9e5331607caa306d55998c22ad3	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
114	knowledge/ratchets/6-60.md	component	6-60	it	{"id": "ratchet.6-60", "lang": "it", "slot": "ratchet", "slug": "6-60", "type": "component", "status": "draft", "system": "CX", "aliases": ["6-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-60"], "doc_version": 1, "canonical_name": "6-60"}	5b44a128686f3837e0f45ca2442889add7a8e79b1299694c0fc7c0c3649cecad	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
115	knowledge/ratchets/6-70.md	component	6-70	it	{"id": "ratchet.6-70", "lang": "it", "slot": "ratchet", "slug": "6-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["6-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-70"], "doc_version": 1, "canonical_name": "6-70"}	ceb97111da5eea887b4d04cc78ae9a7799ff0ae4201dd9b98e35027d26bd50fc	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
731	knowledge/blades/hells-scythe.md	component	hells-scythe	it	{"id": "blade.hells-scythe", "lang": "it", "slot": "blade", "slug": "hells-scythe", "type": "component", "status": "draft", "system": "BX", "aliases": ["HellsScythe"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsScythe"], "reference": "https://beyblade.wiki/hells-scythe-blade/", "doc_version": 1, "canonical_name": "HellsScythe"}	544245229769ae6d24892c2a9dfef030b515c7678c3ec07f64e2be0f1d43b254	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
116	knowledge/ratchets/6-80.md	component	6-80	it	{"id": "ratchet.6-80", "lang": "it", "slot": "ratchet", "slug": "6-80", "type": "component", "status": "draft", "system": "CX", "aliases": ["6-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-80"], "doc_version": 1, "canonical_name": "6-80"}	9ade2fac4f85f10e65f213607b744c6e9b8a4fc002edb140f7323e789212ad5d	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1065	knowledge/blades/hells-scythe.md	component	hells-scythe	it	{"id": "blade.hells-scythe", "lang": "it", "slot": "blade", "slug": "hells-scythe", "type": "component", "status": "draft", "system": "BX", "aliases": ["HellsScythe"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsScythe"], "reference": "https://beyblade.wiki/hells-scythe-blade/", "doc_version": 1, "canonical_name": "HellsScythe"}	544245229769ae6d24892c2a9dfef030b515c7678c3ec07f64e2be0f1d43b254	4	7f84633	2026-08-22 13:35:57.076988+00	\N
29	knowledge/ratchets/9-60.md	component	9-60	it	{"id": "ratchet.9-60", "lang": "it", "slot": "ratchet", "slug": "9-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["9-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-60"], "doc_version": 1, "canonical_name": "9-60"}	042bf643247bf2de7568102c4c192cbb5c54ccbbdf57156060294c5bd57372f8	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 22:14:27.709114+00
120	knowledge/ratchets/9-65.md	component	9-65	it	{"id": "ratchet.9-65", "lang": "it", "slot": "ratchet", "slug": "9-65", "type": "component", "status": "draft", "system": "UX", "aliases": ["9-65"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-65"], "doc_version": 1, "canonical_name": "9-65"}	a20b433ca4ea52714a71224d72b699b0615729382e5481ccf5031e34c16df3bc	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
709	knowledge/blades/clock-mirage.md	component	clock-mirage	it	{"id": "blade.clock-mirage", "lang": "it", "slot": "blade", "slug": "clock-mirage", "type": "component", "status": "draft", "system": "UX", "aliases": ["ClockMirage"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ClockMirage"], "reference": "https://beyblade.wiki/clock-mirage-blade/", "doc_version": 1, "canonical_name": "ClockMirage"}	a2a913e6bfb3f4a10c44a6186983506dc1c2334bf41adb4dc23e0a16072b9dfd	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
121	knowledge/ratchets/9-70.md	component	9-70	it	{"id": "ratchet.9-70", "lang": "it", "slot": "ratchet", "slug": "9-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["9-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-70"], "doc_version": 1, "canonical_name": "9-70"}	be0366e8de34def7cccfac7e6f2990d56d6ca4f0414a14052d5f11505af58979	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
710	knowledge/blades/cobalt-dragoon.md	component	cobalt-dragoon	it	{"id": "blade.cobalt-dragoon", "lang": "it", "slot": "blade", "slug": "cobalt-dragoon", "type": "component", "status": "draft", "system": "BX", "aliases": ["CobaltDragoon"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CobaltDragoon"], "reference": "https://beyblade.wiki/cobalt-dragoon-blade/", "doc_version": 1, "canonical_name": "CobaltDragoon"}	7af1dab0c09725dd23bec5e86244a4e725fae1568a15733249af850129c3cd4c	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
122	knowledge/ratchets/9-80.md	component	9-80	it	{"id": "ratchet.9-80", "lang": "it", "slot": "ratchet", "slug": "9-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["9-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-80"], "doc_version": 1, "canonical_name": "9-80"}	99fa6679e3c3e040b323abd7757232f512271c0c30ad2e26abd5d9e6be4e14ef	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
711	knowledge/blades/cobalt-drake.md	component	cobalt-drake	it	{"id": "blade.cobalt-drake", "lang": "it", "slot": "blade", "slug": "cobalt-drake", "type": "component", "status": "draft", "system": "BX", "aliases": ["CobaltDrake"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CobaltDrake"], "reference": "https://beyblade.wiki/cobalt-drake-blade/", "doc_version": 1, "canonical_name": "CobaltDrake"}	0657f941e26f7700ed0a94ba0ef81ba91d134fc4ceb497b6513331802bad3e3c	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
123	knowledge/ratchets/m-85.md	component	m-85	it	{"id": "ratchet.m-85", "lang": "it", "slot": "ratchet", "slug": "m-85", "type": "component", "status": "draft", "system": "BX", "aliases": ["M-85"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_M-85"], "doc_version": 1, "canonical_name": "M-85"}	afcf741ca7d98e8d0543fc58f92ef798d1d9dbddc34b3babf7dfc9f284d75a2e	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 22:14:27.709114+00
1180	knowledge/blades/scorpio-spear.md	component	scorpio-spear	it	{"id": "blade.scorpio-spear", "lang": "it", "slot": "blade", "slug": "scorpio-spear", "type": "component", "status": "draft", "system": "UX", "aliases": ["ScorpioSpear"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ScorpioSpear"], "reference": "https://beyblade.wiki/scorpio-spear-blade/", "doc_version": 1, "canonical_name": "ScorpioSpear"}	a1056c5d6997660243b6367d55b5b07e82c6e8f3ebd5321d4144ca932a7e517b	5	7f84633	2026-08-22 13:52:58.967619+00	\N
228	knowledge/blades/clock-mirage.md	component	clock-mirage	it	{"id": "blade.clock-mirage", "lang": "it", "slot": "blade", "slug": "clock-mirage", "type": "component", "status": "draft", "system": "UX", "aliases": ["ClockMirage"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ClockMirage"], "reference": "https://beyblade.wiki/clock-mirage-blade/", "doc_version": 1, "canonical_name": "ClockMirage"}	a2a913e6bfb3f4a10c44a6186983506dc1c2334bf41adb4dc23e0a16072b9dfd	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1091	knowledge/blades/shark-edge.md	component	shark-edge	it	{"id": "blade.shark-edge", "lang": "it", "slot": "blade", "slug": "shark-edge", "type": "component", "status": "draft", "system": "BX", "aliases": ["SharkEdge"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SharkEdge"], "reference": "https://beyblade.wiki/shark-edge-blade/", "doc_version": 1, "canonical_name": "SharkEdge"}	7d9a28c14c1c08f0a7fbdb6fcd30b28b1df4ba8781654da45a2f0d29799e2753	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
229	knowledge/blades/cobalt-dragoon.md	component	cobalt-dragoon	it	{"id": "blade.cobalt-dragoon", "lang": "it", "slot": "blade", "slug": "cobalt-dragoon", "type": "component", "status": "draft", "system": "BX", "aliases": ["CobaltDragoon"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CobaltDragoon"], "reference": "https://beyblade.wiki/cobalt-dragoon-blade/", "doc_version": 1, "canonical_name": "CobaltDragoon"}	7af1dab0c09725dd23bec5e86244a4e725fae1568a15733249af850129c3cd4c	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1181	knowledge/blades/shark-edge.md	component	shark-edge	it	{"id": "blade.shark-edge", "lang": "it", "slot": "blade", "slug": "shark-edge", "type": "component", "status": "draft", "system": "BX", "aliases": ["SharkEdge"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SharkEdge"], "reference": "https://beyblade.wiki/shark-edge-blade/", "doc_version": 1, "canonical_name": "SharkEdge"}	5d06c52e5b8d0b4dcf8ec6a0dda5950a43daed22dc0298e55a1ec0875309c43d	5	7f84633	2026-08-22 13:52:58.967619+00	\N
230	knowledge/blades/cobalt-drake.md	component	cobalt-drake	it	{"id": "blade.cobalt-drake", "lang": "it", "slot": "blade", "slug": "cobalt-drake", "type": "component", "status": "draft", "system": "BX", "aliases": ["CobaltDrake"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CobaltDrake"], "reference": "https://beyblade.wiki/cobalt-drake-blade/", "doc_version": 1, "canonical_name": "CobaltDrake"}	0657f941e26f7700ed0a94ba0ef81ba91d134fc4ceb497b6513331802bad3e3c	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1092	knowledge/blades/shark-scale.md	component	shark-scale	it	{"id": "blade.shark-scale", "lang": "it", "slot": "blade", "slug": "shark-scale", "type": "component", "status": "draft", "system": "UX", "aliases": ["Scale Shark", "SharkScale"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SharkScale"], "reference": "https://beyblade.wiki/shark-scale-blade/", "doc_version": 1, "canonical_name": "SharkScale"}	0a446058d16f4ea254009a6b49074be3780ebb232ed865e5c475e81776d2c2fd	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
231	knowledge/blades/crimson-garuda.md	component	crimson-garuda	it	{"id": "blade.crimson-garuda", "lang": "it", "slot": "blade", "slug": "crimson-garuda", "type": "component", "status": "draft", "system": "BX", "aliases": ["CrimsonGaruda"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_CrimsonGaruda"], "reference": "https://beyblade.wiki/crimson-garuda-blade/", "doc_version": 1, "canonical_name": "CrimsonGaruda"}	5d365d3dfdc498d439820f139b9858d757c10fcd3cd4a09b7fcb6b0eab9f4ab2	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
232	knowledge/blades/croc-crunch.md	component	croc-crunch	it	{"id": "blade.croc-crunch", "lang": "it", "slot": "blade", "slug": "croc-crunch", "type": "component", "status": "draft", "system": "BX", "aliases": ["CrocCrunch"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Bite_Croc"], "reference": "https://beyblade.wiki/croc-crunch-blade/", "doc_version": 1, "canonical_name": "CrocCrunch"}	eda8d49dbd769e056545efea36561a2a4f083e3eb862fc642b96c9f1d29849a7	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1182	knowledge/blades/shark-scale.md	component	shark-scale	it	{"id": "blade.shark-scale", "lang": "it", "slot": "blade", "slug": "shark-scale", "type": "component", "status": "draft", "system": "UX", "aliases": ["Scale Shark", "SharkScale"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SharkScale"], "reference": "https://beyblade.wiki/shark-scale-blade/", "doc_version": 1, "canonical_name": "SharkScale"}	4977b48941c971389aaa296b1894ccee94379c9ef3515725ccb20c8bd71d33a3	5	7f84633	2026-08-22 13:52:58.967619+00	\N
233	knowledge/blades/dark.md	component	dark	it	{"id": "blade.dark", "lang": "it", "slot": "blade", "slug": "dark", "type": "component", "status": "draft", "system": "CX", "aliases": ["Dark"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Dark"], "reference": "https://beyblade.wiki/dark-main-blade/", "doc_version": 1, "canonical_name": "Dark"}	96838bf02e71409e75e0af205205d144837834c06d8537f97dacd77ed0ee46e3	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1096	knowledge/blades/silver-wolf.md	component	silver-wolf	it	{"id": "blade.silver-wolf", "lang": "it", "slot": "blade", "slug": "silver-wolf", "type": "component", "status": "draft", "system": "UX", "aliases": ["SilverWolf", "Sterling Wolf"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SilverWolf"], "reference": "https://beyblade.wiki/silver-wolf-blade/", "doc_version": 1, "canonical_name": "SilverWolf"}	761ad3d8a8141647d232ee6f47a467453c41f664612cb8f591aec40c34858c1a	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
144	knowledge/blades/darth-vader.md	component	darth-vader	it	{"id": "blade.darth-vader", "lang": "it", "slot": "blade", "slug": "darth-vader", "type": "component", "status": "draft", "system": "BX", "aliases": ["DarthVader"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Darth_Vader"], "doc_version": 1, "canonical_name": "DarthVader"}	3ed1d2c00f9071884762d9189d172ec82328aad9617e83e7499a7edea2d2abaf	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-22 12:20:46.065136+00
1183	knowledge/blades/silver-wolf.md	component	silver-wolf	it	{"id": "blade.silver-wolf", "lang": "it", "slot": "blade", "slug": "silver-wolf", "type": "component", "status": "draft", "system": "UX", "aliases": ["SilverWolf", "Sterling Wolf"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SilverWolf"], "reference": "https://beyblade.wiki/silver-wolf-blade/", "doc_version": 1, "canonical_name": "SilverWolf"}	d01d5ecf85738d3db46442f534d58a51d751dc0750c3affe3f0f9a4459e55894	5	7f84633	2026-08-22 13:52:58.967619+00	\N
64	knowledge/blades/draciel-shield.md	component	draciel-shield	it	{"id": "blade.draciel-shield", "lang": "it", "slot": "blade", "slug": "draciel-shield", "type": "component", "status": "draft", "system": "BX", "aliases": ["DracielShield"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DracielShield"], "doc_version": 1, "canonical_name": "DracielShield"}	aa46cda58de46fa7ada23243485728ba4bfcdd91e4bdbea41b7f6e99b6c7a4c1	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
1104	knowledge/blades/tyranno-beat.md	component	tyranno-beat	it	{"id": "blade.tyranno-beat", "lang": "it", "slot": "blade", "slug": "tyranno-beat", "type": "component", "status": "draft", "system": "BX", "aliases": ["TyrannoBeat"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TyrannoBeat"], "reference": "https://beyblade.wiki/tyranno-beat-blade/", "doc_version": 1, "canonical_name": "TyrannoBeat"}	f2ab9ab891323d422e0410f1e1498083aa6c12f03950934fd05e5a592603cf8c	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
145	knowledge/blades/dragoon-storm.md	component	dragoon-storm	it	{"id": "blade.dragoon-storm", "lang": "it", "slot": "blade", "slug": "dragoon-storm", "type": "component", "status": "draft", "system": "BX", "aliases": ["DragoonStorm"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DragoonStorm"], "doc_version": 1, "canonical_name": "DragoonStorm"}	ae79ae410854e5ac83ca658da97d9757aa8ecac01af533566ce5f8c5b1002a6d	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-22 12:20:46.065136+00
234	knowledge/blades/dran-buster.md	component	dran-buster	it	{"id": "blade.dran-buster", "lang": "it", "slot": "blade", "slug": "dran-buster", "type": "component", "status": "draft", "system": "UX", "aliases": ["DranBuster"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranBuster"], "reference": "https://beyblade.wiki/dran-buster-blade/", "doc_version": 1, "canonical_name": "DranBuster"}	ae1b3240a1de6b4d0cc46f76ef56f6658515c9c931f5025aea9f6b27221ab127	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1106	knowledge/blades/unicorn-sting.md	component	unicorn-sting	it	{"id": "blade.unicorn-sting", "lang": "it", "slot": "blade", "slug": "unicorn-sting", "type": "component", "status": "draft", "system": "BX", "aliases": ["UnicornSting"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_UnicornSting"], "reference": "https://beyblade.wiki/unicorn-sting-blade/", "doc_version": 1, "canonical_name": "UnicornSting"}	dba8415dab1c9abb0df11ac181cdff48e50b8e886f02e9d31d051944292b565e	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
235	knowledge/blades/dran-dagger.md	component	dran-dagger	it	{"id": "blade.dran-dagger", "lang": "it", "slot": "blade", "slug": "dran-dagger", "type": "component", "status": "draft", "system": "BX", "aliases": ["DranDagger"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranDagger"], "reference": "https://beyblade.wiki/dran-dagger-blade/", "doc_version": 1, "canonical_name": "DranDagger"}	f902a87be24c25a1eb4b81fb046d0050c170e5acb04704c47bbaee817aa54e44	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
236	knowledge/blades/dran-sword.md	component	dran-sword	it	{"id": "blade.dran-sword", "lang": "it", "slot": "blade", "slug": "dran-sword", "type": "component", "status": "draft", "system": "BX", "aliases": ["DranSword"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranSword"], "reference": "https://beyblade.wiki/dran-sword-blade/", "doc_version": 1, "canonical_name": "DranSword"}	6debfa55e73496403d96e22cefaaf9b4f52a750c5f54c6fdd66ba8cd8830dbde	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1185	knowledge/blades/unicorn-sting.md	component	unicorn-sting	it	{"id": "blade.unicorn-sting", "lang": "it", "slot": "blade", "slug": "unicorn-sting", "type": "component", "status": "draft", "system": "BX", "aliases": ["UnicornSting"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_UnicornSting"], "reference": "https://beyblade.wiki/unicorn-sting-blade/", "doc_version": 1, "canonical_name": "UnicornSting"}	6621707f95024c10dc63d575fbb346f2f1fe38f0828ae5e8d2173caca38719a7	5	7f84633	2026-08-22 13:52:58.967619+00	\N
237	knowledge/blades/dranzer-spiral.md	component	dranzer-spiral	it	{"id": "blade.dranzer-spiral", "lang": "it", "slot": "blade", "slug": "dranzer-spiral", "type": "component", "status": "draft", "system": "BX", "aliases": ["DranzerSpiral"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DranzerSpiral"], "reference": "https://beyblade.wiki/dranzer-spiral-blade/", "doc_version": 1, "canonical_name": "DranzerSpiral"}	acb130289e38158fa76c2a587f7af28b1fee976a418abe3c059f51f47ebe8320	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1113	knowledge/blades/wizard-rod.md	component	wizard-rod	it	{"id": "blade.wizard-rod", "lang": "it", "slot": "blade", "slug": "wizard-rod", "type": "component", "status": "draft", "system": "UX", "aliases": ["Wand Wizard", "WizardRod"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WizardRod"], "reference": "https://beyblade.wiki/wizard-rod-blade/", "doc_version": 1, "canonical_name": "WizardRod"}	45f491007d6c89d3751a7dc4b493a4ec8623223b4bc67a44537d13fef6ff0cff	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
147	knowledge/blades/driger-slash.md	component	driger-slash	it	{"id": "blade.driger-slash", "lang": "it", "slot": "blade", "slug": "driger-slash", "type": "component", "status": "draft", "system": "BX", "aliases": ["DrigerSlash"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_DrigerSlash"], "doc_version": 1, "canonical_name": "DrigerSlash"}	0fad390851e0d9eeded5cc4b8c1711db8f3fe929bea13af10c91e07560881e0d	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-22 12:20:46.065136+00
1186	knowledge/blades/wizard-rod.md	component	wizard-rod	it	{"id": "blade.wizard-rod", "lang": "it", "slot": "blade", "slug": "wizard-rod", "type": "component", "status": "draft", "system": "UX", "aliases": ["Wand Wizard", "WizardRod"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WizardRod"], "reference": "https://beyblade.wiki/wizard-rod-blade/", "doc_version": 1, "canonical_name": "WizardRod"}	c7af177577bbd0fcf31a99a5cc165fff47f810c289666f4ead456b8122de764f	5	7f84633	2026-08-22 13:52:58.967619+00	\N
238	knowledge/blades/eclipse.md	component	eclipse	it	{"id": "blade.eclipse", "lang": "it", "slot": "blade", "slug": "eclipse", "type": "component", "status": "draft", "system": "CX", "aliases": ["Eclipse"], "sources": [], "reference": "https://beyblade.wiki/eclipse-main-blade/", "doc_version": 1, "canonical_name": "Eclipse"}	2d438932d58873d170755e46b939c423648c715b9088051b61a000e9ace76e3d	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1122	knowledge/ratchets/1-60.md	component	1-60	it	{"id": "ratchet.1-60", "lang": "it", "slot": "ratchet", "slug": "1-60", "type": "component", "status": "draft", "system": "UX", "aliases": ["1-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-60"], "reference": "https://beyblade.wiki/1-60-ratchet/", "doc_version": 1, "canonical_name": "1-60"}	d50b7a02bfdcaee036f051a2abba7fbbd13d0522f9a29e23096ffa3b7327d0e2	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
239	knowledge/blades/flame.md	component	flame	it	{"id": "blade.flame", "lang": "it", "slot": "blade", "slug": "flame", "type": "component", "status": "draft", "system": "CX", "aliases": ["Flame"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Flame"], "reference": "https://beyblade.wiki/flame-main-blade/", "doc_version": 1, "canonical_name": "Flame"}	856ebbbe5c49ec3c8eb18d83c6961b61e8061305e886bd7270f95224ea0e39b4	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1187	knowledge/ratchets/1-60.md	component	1-60	it	{"id": "ratchet.1-60", "lang": "it", "slot": "ratchet", "slug": "1-60", "type": "component", "status": "draft", "system": "UX", "aliases": ["1-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-60"], "reference": "https://beyblade.wiki/1-60-ratchet/", "doc_version": 1, "canonical_name": "1-60"}	77be4200a31ecaa37453f5e194048a943f6db93d8f7a350cf6fabeddf3ef869d	5	7f84633	2026-08-22 13:52:58.967619+00	\N
150	knowledge/blades/general-grievous.md	component	general-grievous	it	{"id": "blade.general-grievous", "lang": "it", "slot": "blade", "slug": "general-grievous", "type": "component", "status": "draft", "system": "BX", "aliases": ["GeneralGrievous"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_General_Grievous"], "doc_version": 1, "canonical_name": "GeneralGrievous"}	fc2a88b06f55b4fb05c00efb7c3256b29c5d2bef00ccd02d9ad421d64f819126	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-22 12:20:46.065136+00
1123	knowledge/ratchets/1-70.md	component	1-70	it	{"id": "ratchet.1-70", "lang": "it", "slot": "ratchet", "slug": "1-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["1-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-70"], "reference": "https://beyblade.wiki/1-70-ratchet/", "doc_version": 1, "canonical_name": "1-70"}	1fac33feeb0b621da90cd0e16cacf01bb8f63c3a7cea2d00a818a32390e252bb	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
240	knowledge/blades/ghost-circle.md	component	ghost-circle	it	{"id": "blade.ghost-circle", "lang": "it", "slot": "blade", "slug": "ghost-circle", "type": "component", "status": "draft", "system": "UX", "aliases": ["GhostCircle"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_GhostCircle"], "reference": "https://beyblade.wiki/ghost-circle-blade/", "doc_version": 1, "canonical_name": "GhostCircle"}	20386b48dcb8c80489a062f71d86185d7c10bc446dc7adf1cc4116de503e5777	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1188	knowledge/ratchets/1-70.md	component	1-70	it	{"id": "ratchet.1-70", "lang": "it", "slot": "ratchet", "slug": "1-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["1-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-70"], "reference": "https://beyblade.wiki/1-70-ratchet/", "doc_version": 1, "canonical_name": "1-70"}	21f5101194a7f57909f7d84703d405e7129d28f4d4a1b5b2de54ec5cead4344b	5	7f84633	2026-08-22 13:52:58.967619+00	\N
69	knowledge/blades/gill-shark.md	component	gill-shark	it	{"id": "blade.gill-shark", "lang": "it", "slot": "blade", "slug": "gill-shark", "type": "component", "status": "draft", "system": "BX", "aliases": ["GillShark"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Gill_Shark"], "doc_version": 1, "canonical_name": "GillShark"}	cc5260a858482422c2e42eef554216d1d0cf393ce10222f054dd90b8e467f6c5	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
1124	knowledge/ratchets/1-80.md	component	1-80	it	{"id": "ratchet.1-80", "lang": "it", "slot": "ratchet", "slug": "1-80", "type": "component", "status": "draft", "system": "UX", "aliases": ["1-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-80"], "reference": "https://beyblade.wiki/1-80-ratchet/", "doc_version": 1, "canonical_name": "1-80"}	6547bacc4405f9a22526f79ac378f083ba2bb97bcfecc3f6b9c51b9051f065df	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
241	knowledge/blades/golem-rock.md	component	golem-rock	it	{"id": "blade.golem-rock", "lang": "it", "slot": "blade", "slug": "golem-rock", "type": "component", "status": "draft", "system": "UX", "aliases": ["GolemRock"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_GolemRock"], "reference": "https://beyblade.wiki/golem-rock-blade/", "doc_version": 1, "canonical_name": "GolemRock"}	3834108ae47f1c7b45a1971b129adc0d3a5c86727e49a77252732e87c2570e96	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1189	knowledge/ratchets/1-80.md	component	1-80	it	{"id": "ratchet.1-80", "lang": "it", "slot": "ratchet", "slug": "1-80", "type": "component", "status": "draft", "system": "UX", "aliases": ["1-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-80"], "reference": "https://beyblade.wiki/1-80-ratchet/", "doc_version": 1, "canonical_name": "1-80"}	8bdf227ffcb8becc2f737cd51d154bd0e3d10f78c7ad25f7c66ba0f3414b7b0d	5	7f84633	2026-08-22 13:52:58.967619+00	\N
242	knowledge/blades/hells-chain.md	component	hells-chain	it	{"id": "blade.hells-chain", "lang": "it", "slot": "blade", "slug": "hells-chain", "type": "component", "status": "draft", "system": "BX", "aliases": ["HellsChain"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsChain"], "reference": "https://beyblade.wiki/hells-chain-blade/", "doc_version": 1, "canonical_name": "HellsChain"}	f9c7b831001a46ba9816c8b9d61360ebcb23c5fbd3c383dd1f69f58501b3cfab	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1127	knowledge/ratchets/3-60.md	component	3-60	it	{"id": "ratchet.3-60", "lang": "it", "slot": "ratchet", "slug": "3-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["3-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-60"], "reference": "https://beyblade.wiki/3-60-ratchet/", "doc_version": 1, "canonical_name": "3-60"}	a056a3e051712c63d61064eda22e0d643ad00e4c022fe9cf23bffd691ec41606	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
243	knowledge/blades/hells-hammer.md	component	hells-hammer	it	{"id": "blade.hells-hammer", "lang": "it", "slot": "blade", "slug": "hells-hammer", "type": "component", "status": "draft", "system": "UX", "aliases": ["HellsHammer"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsHammer"], "reference": "https://beyblade.wiki/hells-hammer-blade/", "doc_version": 1, "canonical_name": "HellsHammer"}	1814d04eac70523e14b49357c884bf6bad87f9e5331607caa306d55998c22ad3	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1190	knowledge/ratchets/3-60.md	component	3-60	it	{"id": "ratchet.3-60", "lang": "it", "slot": "ratchet", "slug": "3-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["3-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-60"], "reference": "https://beyblade.wiki/3-60-ratchet/", "doc_version": 1, "canonical_name": "3-60"}	140daa0d934405cfb25f5cb8877df092a26343a28475682eb9ed7aa27c8340ed	5	7f84633	2026-08-22 13:52:58.967619+00	\N
244	knowledge/blades/hells-scythe.md	component	hells-scythe	it	{"id": "blade.hells-scythe", "lang": "it", "slot": "blade", "slug": "hells-scythe", "type": "component", "status": "draft", "system": "BX", "aliases": ["HellsScythe"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_HellsScythe"], "reference": "https://beyblade.wiki/hells-scythe-blade/", "doc_version": 1, "canonical_name": "HellsScythe"}	544245229769ae6d24892c2a9dfef030b515c7678c3ec07f64e2be0f1d43b254	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1128	knowledge/ratchets/3-70.md	component	3-70	it	{"id": "ratchet.3-70", "lang": "it", "slot": "ratchet", "slug": "3-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["3-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-70"], "reference": "https://beyblade.wiki/3-70-ratchet/", "doc_version": 1, "canonical_name": "3-70"}	bc5d76c1c46df56267b43f4c90d6c52043b97159953b12bc21b9f27fff0bada5	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
74	knowledge/blades/hover-wyvern.md	component	hover-wyvern	it	{"id": "blade.hover-wyvern", "lang": "it", "slot": "blade", "slug": "hover-wyvern", "type": "component", "status": "draft", "system": "UX", "aliases": ["HoverWyvern"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Hover_Wyvern"], "doc_version": 1, "canonical_name": "HoverWyvern"}	205fcd8275c70dfca2e7ad551c8d281897d3af3d63b2ce9147ad2036f5de165a	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
1191	knowledge/ratchets/3-70.md	component	3-70	it	{"id": "ratchet.3-70", "lang": "it", "slot": "ratchet", "slug": "3-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["3-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-70"], "reference": "https://beyblade.wiki/3-70-ratchet/", "doc_version": 1, "canonical_name": "3-70"}	4206b091305fafe82abb5b8a7686784cd54c0639ddf511ee5d08889851306891	5	7f84633	2026-08-22 13:52:58.967619+00	\N
245	knowledge/blades/impact-drake.md	component	impact-drake	it	{"id": "blade.impact-drake", "lang": "it", "slot": "blade", "slug": "impact-drake", "type": "component", "status": "draft", "system": "UX", "aliases": ["ImpactDrake"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ImpactDrake"], "reference": "https://beyblade.wiki/impact-drake-blade/", "doc_version": 1, "canonical_name": "ImpactDrake"}	455683720bb2e4a83d562b5125c212242bf859f2c409b04c821116f7e1dfec57	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1130	knowledge/ratchets/4-50.md	component	4-50	it	{"id": "ratchet.4-50", "lang": "it", "slot": "ratchet", "slug": "4-50", "type": "component", "status": "draft", "system": "UX", "aliases": ["4-50"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-50"], "reference": "https://beyblade.wiki/4-50-ratchet/", "doc_version": 1, "canonical_name": "4-50"}	1a4da1588019690f5b4d96f117200d35c49d8ad380fb1216f45f53dbbe62a040	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
246	knowledge/blades/knight-lance.md	component	knight-lance	it	{"id": "blade.knight-lance", "lang": "it", "slot": "blade", "slug": "knight-lance", "type": "component", "status": "draft", "system": "BX", "aliases": ["KnightLance"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightLance"], "reference": "https://beyblade.wiki/knight-lance-blade/", "doc_version": 1, "canonical_name": "KnightLance"}	8458b3309ed0064236ae232137850c7ab8bd48b818b93e5ad6e7299168d54e09	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1192	knowledge/ratchets/4-50.md	component	4-50	it	{"id": "ratchet.4-50", "lang": "it", "slot": "ratchet", "slug": "4-50", "type": "component", "status": "draft", "system": "UX", "aliases": ["4-50"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-50"], "reference": "https://beyblade.wiki/4-50-ratchet/", "doc_version": 1, "canonical_name": "4-50"}	01e6157f73f2d2d78581ad654e5153bfd121829f4aa75a924cdab21e9cdd77ad	5	7f84633	2026-08-22 13:52:58.967619+00	\N
1131	knowledge/ratchets/4-55.md	component	4-55	it	{"id": "ratchet.4-55", "lang": "it", "slot": "ratchet", "slug": "4-55", "type": "component", "status": "draft", "system": "CX", "aliases": ["4-55"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-55"], "reference": "https://beyblade.wiki/4-55-ratchet/", "doc_version": 1, "canonical_name": "4-55"}	06a3db057b40bdd83b35b2eff9c2a7beb370fd4b3cafc875866636777d7f36ed	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
247	knowledge/blades/knight-mail.md	component	knight-mail	it	{"id": "blade.knight-mail", "lang": "it", "slot": "blade", "slug": "knight-mail", "type": "component", "status": "draft", "system": "UX", "aliases": ["KnightMail"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightMail"], "reference": "https://beyblade.wiki/knight-mail-blade/", "doc_version": 1, "canonical_name": "KnightMail"}	ca25d7c4bb5d4816f8146cbfab7f0cf240049a6ac1cbbc4bc95e2cb25dcd7454	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1193	knowledge/ratchets/4-55.md	component	4-55	it	{"id": "ratchet.4-55", "lang": "it", "slot": "ratchet", "slug": "4-55", "type": "component", "status": "draft", "system": "CX", "aliases": ["4-55"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-55"], "reference": "https://beyblade.wiki/4-55-ratchet/", "doc_version": 1, "canonical_name": "4-55"}	a533651712af02ad8dc17ca956535faf0065823cd054cc89ef00b058b14b4df8	5	7f84633	2026-08-22 13:52:58.967619+00	\N
248	knowledge/blades/knight-shield-blade.md	component	knight-shield-blade	it	{"id": "blade.knight-shield-blade", "lang": "it", "slot": "blade", "slug": "knight-shield-blade", "type": "component", "status": "draft", "system": "BX", "aliases": ["KnightShield", "knight-shield-blade"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightShield"], "reference": "https://beyblade.wiki/knight-shield-blade/", "doc_version": 1, "canonical_name": "KnightShield"}	c7ad8a1fe8258bcfadb51eb6f07fdf508e1db874121abd411dfbb0b28464daa5	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1135	knowledge/ratchets/5-60.md	component	5-60	it	{"id": "ratchet.5-60", "lang": "it", "slot": "ratchet", "slug": "5-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["5-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-60"], "reference": "https://beyblade.wiki/5-60-ratchet/", "doc_version": 1, "canonical_name": "5-60"}	39e71ff1dae6e42c8712dab15c8f877103c5cd21ba55ee3a7ca79f7b996be8a7	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
249	knowledge/blades/leon-claw.md	component	leon-claw	it	{"id": "blade.leon-claw", "lang": "it", "slot": "blade", "slug": "leon-claw", "type": "component", "status": "draft", "system": "BX", "aliases": ["LeonClaw"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_LeonClaw"], "reference": "https://beyblade.wiki/leon-claw-blade/", "doc_version": 1, "canonical_name": "LeonClaw"}	2d8fa0f5e2a5611aa74dfd6982d87747bf53af3d3558c577b678d789a3a3d618	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1194	knowledge/ratchets/5-60.md	component	5-60	it	{"id": "ratchet.5-60", "lang": "it", "slot": "ratchet", "slug": "5-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["5-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-60"], "reference": "https://beyblade.wiki/5-60-ratchet/", "doc_version": 1, "canonical_name": "5-60"}	f41903cf5dbb225219cf3dc38c5ba6b5ec01dc999dd188fe7c81251ac1824649	5	7f84633	2026-08-22 13:52:58.967619+00	\N
250	knowledge/blades/leon-crest.md	component	leon-crest	it	{"id": "blade.leon-crest", "lang": "it", "slot": "blade", "slug": "leon-crest", "type": "component", "status": "draft", "system": "UX", "aliases": ["LeonCrest"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_LeonCrest"], "reference": "https://beyblade.wiki/leon-crest-blade/", "doc_version": 1, "canonical_name": "LeonCrest"}	d836ad354d7970b1e7455a79237a01a3ffd205d35d7416535b154ecd80a26277	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1138	knowledge/ratchets/6-60.md	component	6-60	it	{"id": "ratchet.6-60", "lang": "it", "slot": "ratchet", "slug": "6-60", "type": "component", "status": "draft", "system": "CX", "aliases": ["6-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-60"], "reference": "https://beyblade.wiki/6-60-ratchet/", "doc_version": 1, "canonical_name": "6-60"}	96c14fb03af56fe2eddcb0e9e5b9d1f88c253d63e74a25295c5662ac8d580390	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
251	knowledge/blades/mammoth-tusk.md	component	mammoth-tusk	it	{"id": "blade.mammoth-tusk", "lang": "it", "slot": "blade", "slug": "mammoth-tusk", "type": "component", "status": "draft", "system": "BX", "aliases": ["MammothTusk"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Tusk_Mammoth"], "reference": "https://beyblade.wiki/mammoth-tusk-blade/", "doc_version": 1, "canonical_name": "MammothTusk"}	b93cc90402ae9fe238040f841d505329a0a5a6c7d03be0f1b6fc592146162e2f	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1195	knowledge/ratchets/6-60.md	component	6-60	it	{"id": "ratchet.6-60", "lang": "it", "slot": "ratchet", "slug": "6-60", "type": "component", "status": "draft", "system": "CX", "aliases": ["6-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-60"], "reference": "https://beyblade.wiki/6-60-ratchet/", "doc_version": 1, "canonical_name": "6-60"}	788164a7f5ca5cc5309ed76cd306a727f7a19157963be83362a2a65673fd9e7f	5	7f84633	2026-08-22 13:52:58.967619+00	\N
252	knowledge/blades/might.md	component	might	it	{"id": "blade.might", "lang": "it", "slot": "blade", "slug": "might", "type": "component", "status": "draft", "system": "CX", "aliases": ["Might"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Might"], "reference": "https://beyblade.wiki/might-main-blade/", "doc_version": 1, "canonical_name": "Might"}	cc972ee2bdff9538f9aa6f0e962f4ca0ef94f26de6aad336dcb1986e718f6804	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1141	knowledge/ratchets/7-60.md	component	7-60	it	{"id": "ratchet.7-60", "lang": "it", "slot": "ratchet", "slug": "7-60", "type": "component", "status": "draft", "system": "UX", "aliases": ["7-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_7-60"], "doc_version": 1, "canonical_name": "7-60"}	e14b3b90e26def93ab57f8bc6acedfcccceeab8ddb36dd81b56bdbd29cbf8e7a	3	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
154	knowledge/blades/moff-gideon.md	component	moff-gideon	it	{"id": "blade.moff-gideon", "lang": "it", "slot": "blade", "slug": "moff-gideon", "type": "component", "status": "draft", "system": "BX", "aliases": ["MoffGideon"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Moff_Gideon"], "doc_version": 1, "canonical_name": "MoffGideon"}	96e2bbc5c5ac3d224a5f4fdb4b1fe1d0e6644ea8d6811da582c25668b846e586	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-22 12:20:46.065136+00
1196	knowledge/ratchets/7-60.md	component	7-60	it	{"id": "ratchet.7-60", "lang": "it", "slot": "ratchet", "slug": "7-60", "type": "component", "status": "draft", "system": "UX", "aliases": ["7-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_7-60"], "doc_version": 1, "canonical_name": "7-60"}	03ee08547f1c7e1cb8738249d3a0a39c922b9958e2e8639728516a210c5dc6c0	4	7f84633	2026-08-22 13:52:58.967619+00	\N
1142	knowledge/ratchets/7-70.md	component	7-70	it	{"id": "ratchet.7-70", "lang": "it", "slot": "ratchet", "slug": "7-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["7-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_7-70"], "doc_version": 1, "canonical_name": "7-70"}	d68a118b5388ce098e52f4f8bd2dc07246018257cddd72d1c968e6faa5e06142	3	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
155	knowledge/blades/mosasaurus.md	component	mosasaurus	it	{"id": "blade.mosasaurus", "lang": "it", "slot": "blade", "slug": "mosasaurus", "type": "component", "status": "draft", "system": "BX", "aliases": ["Mosasaurus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TriceraSpiky"], "doc_version": 1, "canonical_name": "Mosasaurus"}	02e683cec6e0413f86dcdb4bdd68fbf15293f0e5a59d93ed0ddb6ec02ab990e9	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-22 12:20:46.065136+00
1197	knowledge/ratchets/7-70.md	component	7-70	it	{"id": "ratchet.7-70", "lang": "it", "slot": "ratchet", "slug": "7-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["7-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_7-70"], "doc_version": 1, "canonical_name": "7-70"}	326468db94f86c2c412979516d13c47091a51d5fa6a49672acabc77d0fa98175	4	7f84633	2026-08-22 13:52:58.967619+00	\N
18	knowledge/blades/optimus-primal.md	component	optimus-primal	it	{"id": "blade.optimus-primal", "lang": "it", "slot": "blade", "slug": "optimus-primal", "type": "component", "status": "draft", "system": "BX", "aliases": ["OptimusPrimal"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Optimus_Primal"], "doc_version": 1, "canonical_name": "OptimusPrimal"}	994650588698d214831ae22364996ed62e5c5873a4a3067d1b753790bbd70d21	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-22 12:20:46.065136+00
1144	knowledge/ratchets/9-60.md	component	9-60	it	{"id": "ratchet.9-60", "lang": "it", "slot": "ratchet", "slug": "9-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["9-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-60"], "reference": "https://beyblade.wiki/9-60-ratchet/", "doc_version": 1, "canonical_name": "9-60"}	0f23ee0b29f3de20f280798f3e595ca4dc4c41ae98d233654ad16ed5d35b9366	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
19	knowledge/blades/optimus-prime.md	component	optimus-prime	it	{"id": "blade.optimus-prime", "lang": "it", "slot": "blade", "slug": "optimus-prime", "type": "component", "status": "draft", "system": "BX", "aliases": ["OptimusPrime"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Optimus_Prime"], "doc_version": 1, "canonical_name": "OptimusPrime"}	1ff32e9875c37b120988404be4c0e1a5c165b6e16e369a36fb3411b482752673	1	7f84633	2026-08-21 21:28:49.949694+00	2026-08-22 12:20:46.065136+00
1198	knowledge/ratchets/9-60.md	component	9-60	it	{"id": "ratchet.9-60", "lang": "it", "slot": "ratchet", "slug": "9-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["9-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-60"], "reference": "https://beyblade.wiki/9-60-ratchet/", "doc_version": 1, "canonical_name": "9-60"}	e28135ce357f2ac688b8e641c3897f1557370288556682f5e0be8a7286226a19	5	7f84633	2026-08-22 13:52:58.967619+00	\N
253	knowledge/blades/phoenix-feather.md	component	phoenix-feather	it	{"id": "blade.phoenix-feather", "lang": "it", "slot": "blade", "slug": "phoenix-feather", "type": "component", "status": "draft", "system": "BX", "aliases": ["PhoenixFeather"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixFeather"], "reference": "https://beyblade.wiki/phoenix-feather-blade/", "doc_version": 1, "canonical_name": "PhoenixFeather"}	c481078e821342d95d01b936f6e42cfc58804c5ca0918b44a123e7707eacb053	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1146	knowledge/ratchets/9-70.md	component	9-70	it	{"id": "ratchet.9-70", "lang": "it", "slot": "ratchet", "slug": "9-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["9-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-70"], "reference": "https://beyblade.wiki/9-70-ratchet/", "doc_version": 1, "canonical_name": "9-70"}	88080fb7919620c3230187b251fc8a576e4e5cecee734ca7fdfbacef8ab999f6	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
254	knowledge/blades/phoenix-rudder.md	component	phoenix-rudder	it	{"id": "blade.phoenix-rudder", "lang": "it", "slot": "blade", "slug": "phoenix-rudder", "type": "component", "status": "draft", "system": "UX", "aliases": ["PhoenixRudder"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixRudder"], "reference": "https://beyblade.wiki/phoenix-rudder-blade/", "doc_version": 1, "canonical_name": "PhoenixRudder"}	f5e42ea9494b76161ae0ee98b15b2639b88b2dd3ffd070d8d589dd2bbfd9f71b	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1199	knowledge/ratchets/9-70.md	component	9-70	it	{"id": "ratchet.9-70", "lang": "it", "slot": "ratchet", "slug": "9-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["9-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-70"], "reference": "https://beyblade.wiki/9-70-ratchet/", "doc_version": 1, "canonical_name": "9-70"}	228295d41b61dfcd1fa29c5a52f6622fcfd09b712571875efbf85ae313e18d7a	5	7f84633	2026-08-22 13:52:58.967619+00	\N
255	knowledge/blades/phoenix-wing.md	component	phoenix-wing	it	{"id": "blade.phoenix-wing", "lang": "it", "slot": "blade", "slug": "phoenix-wing", "type": "component", "status": "draft", "system": "BX", "aliases": ["PhoenixSoar (Youngtoys)", "PhoenixWing", "Soar Phoenix"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixWing"], "reference": "https://beyblade.wiki/phoenix-wing-blade/", "doc_version": 1, "canonical_name": "PhoenixWing"}	e9df8e6ddc00c4d562d853a638c6169f988525e1eb374516efef4bd4d4610244	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
82	knowledge/blades/ptera-swing.md	component	ptera-swing	it	{"id": "blade.ptera-swing", "lang": "it", "slot": "blade", "slug": "ptera-swing", "type": "component", "status": "draft", "system": "BX", "aliases": ["PteraSwing"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Talon_Ptera"], "doc_version": 1, "canonical_name": "PteraSwing"}	db63855af2f17e323bd143d043bca38d44c37e97481da84861a448e62d9bb88e	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
156	knowledge/blades/quetzalcoatlus.md	component	ptera-swing	it	{"id": "blade.quetzalcoatlus", "lang": "it", "slot": "blade", "slug": "quetzalcoatlus", "type": "component", "status": "draft", "system": "BX", "aliases": ["Quetzalcoatlus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Talon_Ptera"], "doc_version": 1, "canonical_name": "Quetzalcoatlus"}	9ce43337f2f8c2eb441c8932837691e3919be402c1491613540b6ee0c1b3a5b6	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-22 12:20:46.065136+00
256	knowledge/blades/reaper.md	component	reaper	it	{"id": "blade.reaper", "lang": "it", "slot": "blade", "slug": "reaper", "type": "component", "status": "draft", "system": "CX", "aliases": ["Reaper"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Reaper"], "reference": "https://beyblade.wiki/reaper-main-blade/", "doc_version": 1, "canonical_name": "Reaper"}	55ba1344fb38a92607dcc50b95cc0618d663801c44299a2a94b3174121729738	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1200	knowledge/blades/ptera-swing.md	component	ptera-swing	it	{"id": "blade.ptera-swing", "lang": "it", "slot": "blade", "slug": "ptera-swing", "type": "component", "status": "draft", "system": "BX", "aliases": ["PteraSwing", "Quetzalcoatlus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Talon_Ptera"], "doc_version": 1, "canonical_name": "PteraSwing"}	ac5123f2ada2f3fda47a1ad03459b0b1edd52f2df93005295852e83b5d2df142	4	614daa3	2026-08-24 10:30:51.32741+00	\N
257	knowledge/blades/rhino-horn.md	component	rhino-horn	it	{"id": "blade.rhino-horn", "lang": "it", "slot": "blade", "slug": "rhino-horn", "type": "component", "status": "draft", "system": "BX", "aliases": ["RhinoHorn"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_RhinoHorn"], "reference": "https://beyblade.wiki/rhino-horn-blade/", "doc_version": 1, "canonical_name": "RhinoHorn"}	c2a2a58bb90f6aee61d5f7766ed8d9a2bc95768623ff4d572b69d50b73702f4b	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
83	knowledge/blades/rock-leone.md	component	rock-leone	it	{"id": "blade.rock-leone", "lang": "it", "slot": "blade", "slug": "rock-leone", "type": "component", "status": "draft", "system": "BX", "aliases": ["RockLeone"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Rock_Leone"], "doc_version": 1, "canonical_name": "RockLeone"}	efc7a2a6aa174bebb7bdfe7241ed989061579f3839a3340df5e7675d892ff1e8	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
258	knowledge/blades/samurai-calibur.md	component	samurai-calibur	it	{"id": "blade.samurai-calibur", "lang": "it", "slot": "blade", "slug": "samurai-calibur", "type": "component", "status": "draft", "system": "BX", "aliases": ["SamuraiCalibur"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SamuraiCalibur"], "reference": "https://beyblade.wiki/samurai-calibur-blade/", "doc_version": 1, "canonical_name": "SamuraiCalibur"}	c03058d37c51cb38d3c64e16f3dd4708f10c9115c08d8f26d52fdf8122a1d6eb	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
259	knowledge/blades/samurai-saber.md	component	samurai-saber	it	{"id": "blade.samurai-saber", "lang": "it", "slot": "blade", "slug": "samurai-saber", "type": "component", "status": "draft", "system": "UX", "aliases": ["SamuraiSaber"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SamuraiSaber"], "reference": "https://beyblade.wiki/samurai-saber-blade/", "doc_version": 1, "canonical_name": "SamuraiSaber"}	19c3ab800258b416ccb25c130e0348abff47ff8a9ca47b24974be6aa0b7fc33d	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
260	knowledge/blades/samurai-steel.md	component	samurai-steel	it	{"id": "blade.samurai-steel", "lang": "it", "slot": "blade", "slug": "samurai-steel", "type": "component", "status": "draft", "system": "BX", "aliases": ["SamuraiSteel"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Steel_Samurai"], "reference": "https://beyblade.wiki/samurai-steel-blade/", "doc_version": 1, "canonical_name": "SamuraiSteel"}	8205ea75fb2d1136c0a53f78902e77cc4c2a1a84e035b90f1692595f4496e378	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
261	knowledge/blades/scorpio-spear.md	component	scorpio-spear	it	{"id": "blade.scorpio-spear", "lang": "it", "slot": "blade", "slug": "scorpio-spear", "type": "component", "status": "draft", "system": "UX", "aliases": ["ScorpioSpear"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ScorpioSpear"], "reference": "https://beyblade.wiki/scorpio-spear-blade/", "doc_version": 1, "canonical_name": "ScorpioSpear"}	66681d4bbecb76107c06bf8d8ecf23eafdffec200e6d42f4d04299d51252050e	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1184	knowledge/blades/tyranno-beat.md	component	tyranno-beat	it	{"id": "blade.tyranno-beat", "lang": "it", "slot": "blade", "slug": "tyranno-beat", "type": "component", "status": "draft", "system": "BX", "aliases": ["TyrannoBeat"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TyrannoBeat"], "reference": "https://beyblade.wiki/tyranno-beat-blade/", "doc_version": 1, "canonical_name": "TyrannoBeat"}	46073a8586000f1eaa10e381d027081dceeb97fb99543c4485f053750c96a31b	5	7f84633	2026-08-22 13:52:58.967619+00	2026-08-24 10:36:37.852929+00
262	knowledge/blades/shark-edge.md	component	shark-edge	it	{"id": "blade.shark-edge", "lang": "it", "slot": "blade", "slug": "shark-edge", "type": "component", "status": "draft", "system": "BX", "aliases": ["SharkEdge"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SharkEdge"], "reference": "https://beyblade.wiki/shark-edge-blade/", "doc_version": 1, "canonical_name": "SharkEdge"}	7d9a28c14c1c08f0a7fbdb6fcd30b28b1df4ba8781654da45a2f0d29799e2753	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1201	knowledge/blades/tyranno-beat.md	component	tyranno-beat	it	{"id": "blade.tyranno-beat", "lang": "it", "slot": "blade", "slug": "tyranno-beat", "type": "component", "status": "draft", "system": "BX", "aliases": ["TyrannoBeat", "T.Rex"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TyrannoBeat"], "reference": "https://beyblade.wiki/tyranno-beat-blade/", "doc_version": 1, "canonical_name": "TyrannoBeat"}	39cfd5f5e8986fc0af804e9baa30b8634223c7db0168d340365e1073bffd9718	6	7f0d2df	2026-08-24 10:36:37.852929+00	\N
263	knowledge/blades/shark-scale.md	component	shark-scale	it	{"id": "blade.shark-scale", "lang": "it", "slot": "blade", "slug": "shark-scale", "type": "component", "status": "draft", "system": "UX", "aliases": ["Scale Shark", "SharkScale"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SharkScale"], "reference": "https://beyblade.wiki/shark-scale-blade/", "doc_version": 1, "canonical_name": "SharkScale"}	0a446058d16f4ea254009a6b49074be3780ebb232ed865e5c475e81776d2c2fd	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
89	knowledge/blades/shelter-drake.md	component	shelter-drake	it	{"id": "blade.shelter-drake", "lang": "it", "slot": "blade", "slug": "shelter-drake", "type": "component", "status": "draft", "system": "BX", "aliases": ["ShelterDrake"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ShelterDrake"], "doc_version": 1, "canonical_name": "ShelterDrake"}	915f8d15a86bef7ca813b4c30dd05b48e89dde65f582a5ec1411c01323c8c2a7	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
90	knowledge/blades/shinobi-knife.md	component	shinobi-knife	it	{"id": "blade.shinobi-knife", "lang": "it", "slot": "blade", "slug": "shinobi-knife", "type": "component", "status": "draft", "system": "BX", "aliases": ["ShinobiKnife"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Knife_Shinobi"], "doc_version": 1, "canonical_name": "ShinobiKnife"}	ebecf84820ad501d948b6095cab76b037b8766b10f177bd9e097ce52a29f3628	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
264	knowledge/blades/shinobi-shadow.md	component	shinobi-shadow	it	{"id": "blade.shinobi-shadow", "lang": "it", "slot": "blade", "slug": "shinobi-shadow", "type": "component", "status": "draft", "system": "UX", "aliases": ["ShinobiShadow"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ShinobiShadow"], "reference": "https://beyblade.wiki/shinobi-shadow-blade/", "doc_version": 1, "canonical_name": "ShinobiShadow"}	16735bff203e1564bc7746015ab0ee62155978aa9cf905cb613d22c4cd35b825	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
265	knowledge/blades/silver-wolf.md	component	silver-wolf	it	{"id": "blade.silver-wolf", "lang": "it", "slot": "blade", "slug": "silver-wolf", "type": "component", "status": "draft", "system": "UX", "aliases": ["SilverWolf", "Sterling Wolf"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SilverWolf"], "reference": "https://beyblade.wiki/silver-wolf-blade/", "doc_version": 1, "canonical_name": "SilverWolf"}	761ad3d8a8141647d232ee6f47a467453c41f664612cb8f591aec40c34858c1a	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
91	knowledge/blades/sphinx-cowl.md	component	sphinx-cowl	it	{"id": "blade.sphinx-cowl", "lang": "it", "slot": "blade", "slug": "sphinx-cowl", "type": "component", "status": "draft", "system": "BX", "aliases": ["SphinxCowl"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SphinxCowl"], "doc_version": 1, "canonical_name": "SphinxCowl"}	290d526a972a6f73471c5f8159b4ec32b561306c97b54a5425be3c0a28762e4e	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
161	knowledge/blades/t-rex.md	component	tyranno-beat	it	{"id": "blade.t-rex", "lang": "it", "slot": "blade", "slug": "t-rex", "type": "component", "status": "draft", "system": "BX", "aliases": ["T.Rex"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TyrannoBeat"], "doc_version": 1, "canonical_name": "T.Rex"}	65e3fba5d15c7def83acbfde64de4a3846d7cf0bbd5bd148663df29dcbdd0155	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-22 12:20:46.065136+00
92	knowledge/blades/spider-man.md	component	spider-man	it	{"id": "blade.spider-man", "lang": "it", "slot": "blade", "slug": "spider-man", "type": "component", "status": "draft", "system": "BX", "aliases": ["Spider-Man"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Spider-Man"], "doc_version": 1, "canonical_name": "Spider-Man"}	e1bd50f0ca68deefe5c1a4fb17714030e1cf3ee102e9c908ad3ce20129606f7e	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
1057	knowledge/blades/eclipse.md	component	eclipse	it	{"id": "blade.eclipse", "lang": "it", "slot": "blade", "slug": "eclipse", "type": "component", "status": "draft", "system": "CX", "aliases": ["Eclipse"], "sources": [], "reference": "https://beyblade.wiki/eclipse-main-blade/", "doc_version": 1, "canonical_name": "Eclipse"}	2d438932d58873d170755e46b939c423648c715b9088051b61a000e9ace76e3d	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-24 10:56:07.922616+00
160	knowledge/blades/spinosaurus.md	component	spinosaurus	it	{"id": "blade.spinosaurus", "lang": "it", "slot": "blade", "slug": "spinosaurus", "type": "component", "status": "draft", "system": "BX", "aliases": ["Spinosaurus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Roar_Tyranno"], "doc_version": 1, "canonical_name": "Spinosaurus"}	9705450f9e14a0cf8544c30af75aa70fca610ddf2825bd35b582f67fd56638d5	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-22 12:20:46.065136+00
1202	knowledge/blades/eclipse.md	component	eclipse	it	{"id": "blade.eclipse", "lang": "it", "slot": "blade", "slug": "eclipse", "type": "component", "status": "draft", "system": "CX", "aliases": ["Eclipse"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Eclipse"], "reference": "https://beyblade.wiki/eclipse-main-blade/", "doc_version": 1, "canonical_name": "Eclipse"}	08545ae12df5dac0e9bded8c7668157eab207474054ebefaac42ba357461c8a5	5	f5b4356	2026-08-24 10:56:07.922616+00	\N
1058	knowledge/blades/flame.md	component	flame	it	{"id": "blade.flame", "lang": "it", "slot": "blade", "slug": "flame", "type": "component", "status": "draft", "system": "CX", "aliases": ["Flame"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Flame"], "reference": "https://beyblade.wiki/flame-main-blade/", "doc_version": 1, "canonical_name": "Flame"}	856ebbbe5c49ec3c8eb18d83c6961b61e8061305e886bd7270f95224ea0e39b4	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-24 10:56:07.922616+00
93	knowledge/blades/tackle-goat.md	component	tackle-goat	it	{"id": "blade.tackle-goat", "lang": "it", "slot": "blade", "slug": "tackle-goat", "type": "component", "status": "draft", "system": "BX", "aliases": ["TackleGoat"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Tackle_Goat"], "doc_version": 1, "canonical_name": "TackleGoat"}	11c687af30c692d0cb80859627cc353e744d76d465d89e2eb4283db0cdd8c6c0	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
1203	knowledge/blades/flame.md	component	flame	it	{"id": "blade.flame", "lang": "it", "slot": "blade", "slug": "flame", "type": "component", "status": "draft", "system": "CX", "aliases": ["Flame"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Flame"], "reference": "https://beyblade.wiki/flame-main-blade/", "doc_version": 1, "canonical_name": "Flame"}	18f42091c581dab2343ddaf1ea8332a4ea1c6e6b68239ec22820d519de5f02ac	5	f5b4356	2026-08-24 10:56:07.922616+00	\N
162	knowledge/blades/thanos.md	component	thanos	it	{"id": "blade.thanos", "lang": "it", "slot": "blade", "slug": "thanos", "type": "component", "status": "draft", "system": "BX", "aliases": ["Thanos"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Thanos"], "doc_version": 1, "canonical_name": "Thanos"}	4b7d2502130cc27543e797fa4e49356467e7c76725521dce0de0a03a7cb50828	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-22 12:20:46.065136+00
1059	knowledge/blades/general-grievous.md	component	general-grievous	it	{"id": "blade.general-grievous", "lang": "it", "slot": "blade", "slug": "general-grievous", "type": "component", "status": "draft", "system": "BX", "aliases": ["GeneralGrievous"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_General_Grievous"], "doc_version": 1, "canonical_name": "GeneralGrievous"}	fc2a88b06f55b4fb05c00efb7c3256b29c5d2bef00ccd02d9ad421d64f819126	3	7f84633	2026-08-22 13:35:57.076988+00	2026-08-24 10:56:07.922616+00
266	knowledge/blades/tricera-press.md	component	tricera-press	it	{"id": "blade.tricera-press", "lang": "it", "slot": "blade", "slug": "tricera-press", "type": "component", "status": "draft", "system": "BX", "aliases": ["TriceraPress"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TriceraPress"], "reference": "https://beyblade.wiki/tricera-press-blade/", "doc_version": 1, "canonical_name": "TriceraPress"}	09a7d206ad0084d364df552e13289dbc304d4cd378f4e5c48eb72575e1fe9b77	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1204	knowledge/blades/general-grievous.md	component	general-grievous	it	{"id": "blade.general-grievous", "lang": "it", "slot": "blade", "slug": "general-grievous", "type": "component", "status": "draft", "system": "BX", "aliases": ["GeneralGrievous"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_General_Grievous"], "doc_version": 1, "canonical_name": "GeneralGrievous"}	2d42bdeda4726ddc7e9946397728fd08cacfc0aca2bf784a46f90dc7d1615142	4	f5b4356	2026-08-24 10:56:07.922616+00	\N
267	knowledge/blades/tyranno-beat.md	component	tyranno-beat	it	{"id": "blade.tyranno-beat", "lang": "it", "slot": "blade", "slug": "tyranno-beat", "type": "component", "status": "draft", "system": "BX", "aliases": ["TyrannoBeat"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TyrannoBeat"], "reference": "https://beyblade.wiki/tyranno-beat-blade/", "doc_version": 1, "canonical_name": "TyrannoBeat"}	f2ab9ab891323d422e0410f1e1498083aa6c12f03950934fd05e5a592603cf8c	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1074	knowledge/blades/might.md	component	might	it	{"id": "blade.might", "lang": "it", "slot": "blade", "slug": "might", "type": "component", "status": "draft", "system": "CX", "aliases": ["Might"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Might"], "reference": "https://beyblade.wiki/might-main-blade/", "doc_version": 1, "canonical_name": "Might"}	cc972ee2bdff9538f9aa6f0e962f4ca0ef94f26de6aad336dcb1986e718f6804	4	7f84633	2026-08-22 13:35:57.076988+00	2026-08-24 10:56:07.922616+00
268	knowledge/blades/tyranno-roar.md	component	tyranno-roar	it	{"id": "blade.tyranno-roar", "lang": "it", "slot": "blade", "slug": "tyranno-roar", "type": "component", "status": "draft", "system": "BX", "aliases": ["TyrannoRoar"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Roar_Tyranno"], "reference": "https://beyblade.wiki/tyranno-roar-blade/", "doc_version": 1, "canonical_name": "TyrannoRoar"}	1cfff00220b87054624657bb374509c7a57b7b5f6a9da4d277357ba2d26492ca	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1205	knowledge/blades/might.md	component	might	it	{"id": "blade.might", "lang": "it", "slot": "blade", "slug": "might", "type": "component", "status": "draft", "system": "CX", "aliases": ["Might"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Might"], "reference": "https://beyblade.wiki/might-main-blade/", "doc_version": 1, "canonical_name": "Might"}	64947ecc727f34b1ea09310a4cb973207336d5f4a21872d5e573e38f186d99bf	5	f5b4356	2026-08-24 10:56:07.922616+00	\N
269	knowledge/blades/unicorn-sting.md	component	unicorn-sting	it	{"id": "blade.unicorn-sting", "lang": "it", "slot": "blade", "slug": "unicorn-sting", "type": "component", "status": "draft", "system": "BX", "aliases": ["UnicornSting"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_UnicornSting"], "reference": "https://beyblade.wiki/unicorn-sting-blade/", "doc_version": 1, "canonical_name": "UnicornSting"}	dba8415dab1c9abb0df11ac181cdff48e50b8e886f02e9d31d051944292b565e	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
1206	knowledge/blades/yell-kong.md	component	yell-kong	it	{"id": "blade.yell-kong", "lang": "it", "slot": "blade", "slug": "yell-kong", "type": "component", "status": "draft", "system": "BX", "aliases": ["YellKong"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Yell_Kong"], "doc_version": 1, "canonical_name": "YellKong"}	e9f92fcdb2f02912c0f080b82b72f84088b75e4f6fada43f5172d3341cf9ac1f	4	f5b4356	2026-08-24 10:56:07.922616+00	\N
164	knowledge/blades/venom.md	component	venom	it	{"id": "blade.venom", "lang": "it", "slot": "blade", "slug": "venom", "type": "component", "status": "draft", "system": "BX", "aliases": ["Venom"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Venom"], "doc_version": 1, "canonical_name": "Venom"}	fd75b82f27f316372f463feea2c7a555ead6d324fe964059e81d593d0b939020	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-22 12:20:46.065136+00
165	knowledge/blades/victory-valkyrie.md	component	victory-valkyrie	it	{"id": "blade.victory-valkyrie", "lang": "it", "slot": "blade", "slug": "victory-valkyrie", "type": "component", "status": "draft", "system": "BX", "aliases": ["VictoryValkyrie"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_VictoryValkyrie"], "doc_version": 1, "canonical_name": "VictoryValkyrie"}	b616f4deaf6f562b826404728865ce8741f888d21a4ec65684879e90cab865c1	1	7f84633	2026-08-21 21:54:36.900683+00	2026-08-22 12:20:46.065136+00
270	knowledge/blades/viper-tail.md	component	viper-tail	it	{"id": "blade.viper-tail", "lang": "it", "slot": "blade", "slug": "viper-tail", "type": "component", "status": "draft", "system": "BX", "aliases": ["ViperTail"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ViperTail"], "reference": "https://beyblade.wiki/viper-tail-blade/", "doc_version": 1, "canonical_name": "ViperTail"}	8ac6b143946df3e0bd80d9d3f07e479deba9348dbebc136e7effd94047313db1	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
271	knowledge/blades/weiss-tiger.md	component	weiss-tiger	it	{"id": "blade.weiss-tiger", "lang": "it", "slot": "blade", "slug": "weiss-tiger", "type": "component", "status": "draft", "system": "BX", "aliases": ["WeissTiger"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WeissTiger"], "reference": "https://beyblade.wiki/weiss-tiger-blade/", "doc_version": 1, "canonical_name": "WeissTiger"}	6c01c54826c70bee7759bb4f5c600fcb82fdbc5a6aea0a4559447c5a395daadb	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
272	knowledge/blades/whale-wave.md	component	whale-wave	it	{"id": "blade.whale-wave", "lang": "it", "slot": "blade", "slug": "whale-wave", "type": "component", "status": "draft", "system": "BX", "aliases": ["WhaleWave"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WhaleWave"], "reference": "https://beyblade.wiki/whale-wave-blade/", "doc_version": 1, "canonical_name": "WhaleWave"}	16cb3e906fe2f7ec256d2361bc593d2636c4374276e825c5a83cb305f937d719	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
773	knowledge/blades/venom.md	component	venom	it	{"id": "blade.venom", "lang": "it", "slot": "blade", "slug": "venom", "type": "component", "status": "draft", "system": "BX", "aliases": ["Venom"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Venom"], "doc_version": 1, "canonical_name": "Venom"}	fd75b82f27f316372f463feea2c7a555ead6d324fe964059e81d593d0b939020	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
273	knowledge/blades/wizard-arrow.md	component	wizard-arrow	it	{"id": "blade.wizard-arrow", "lang": "it", "slot": "blade", "slug": "wizard-arrow", "type": "component", "status": "draft", "system": "BX", "aliases": ["WizardArrow"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WizardArrow"], "reference": "https://beyblade.wiki/wizard-arrow-blade/", "doc_version": 1, "canonical_name": "WizardArrow"}	9cc50293b8cd1dc3f780d24524fec373dc691700f8b227b5c8578bcde8ba4da7	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
274	knowledge/blades/wizard-rod.md	component	wizard-rod	it	{"id": "blade.wizard-rod", "lang": "it", "slot": "blade", "slug": "wizard-rod", "type": "component", "status": "draft", "system": "UX", "aliases": ["Wand Wizard", "WizardRod"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WizardRod"], "reference": "https://beyblade.wiki/wizard-rod-blade/", "doc_version": 1, "canonical_name": "WizardRod"}	ba2509f12c00b19944cee8139919117556de60ac5f169f0a59191d933095ec24	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
275	knowledge/blades/wyvern-gale.md	component	wyvern-gale	it	{"id": "blade.wyvern-gale", "lang": "it", "slot": "blade", "slug": "wyvern-gale", "type": "component", "status": "draft", "system": "BX", "aliases": ["WyvernGale"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WyvernGale"], "reference": "https://beyblade.wiki/wyvern-gale-blade/", "doc_version": 1, "canonical_name": "WyvernGale"}	438a8bfba1742fdcc31a85057cb9b1e5bf6ad755c9f7ee617f4b76bd20a94c50	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
99	knowledge/blades/xeno-xcalibur.md	component	xeno-xcalibur	it	{"id": "blade.xeno-xcalibur", "lang": "it", "slot": "blade", "slug": "xeno-xcalibur", "type": "component", "status": "draft", "system": "BX", "aliases": ["XenoXcalibur"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_XenoXcalibur"], "doc_version": 1, "canonical_name": "XenoXcalibur"}	a5824ddb0fda0234946690f1b571983e44661d987ce7c8c6c4bf20954990d185	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
100	knowledge/blades/yell-kong.md	component	yell-kong	it	{"id": "blade.yell-kong", "lang": "it", "slot": "blade", "slug": "yell-kong", "type": "component", "status": "draft", "system": "BX", "aliases": ["YellKong"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Yell_Kong"], "doc_version": 1, "canonical_name": "YellKong"}	b60d3d937461cf3f1f36f4248fec5e233dcc920e429b4ece0604b43c13ebfdeb	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
276	knowledge/lock-chips/emperor.md	component	emperor	it	{"id": "lock_chip.emperor", "lang": "it", "slot": "lock_chip", "slug": "emperor", "type": "component", "status": "draft", "system": "CX", "aliases": ["emperor"], "sources": ["https://beyblade.fandom.com/wiki/Lock_Chip_-_Emperor"], "reference": "https://beyblade.wiki/emperor-lock-chip/", "doc_version": 1, "canonical_name": "emperor"}	6c31fdb1be497915e6a3dccdd1091af6717c4ec6ffc843791a8a934e431a2113	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
277	knowledge/lock-chips/valkyrie.md	component	valkyrie	it	{"id": "lock_chip.valkyrie", "lang": "it", "slot": "lock_chip", "slug": "valkyrie", "type": "component", "status": "draft", "system": "CX", "aliases": ["valkyrie"], "sources": ["https://beyblade.fandom.com/wiki/Lock_Chip_-_Valkyrie"], "reference": "https://beyblade.wiki/valkyrie-lock-chip/", "doc_version": 1, "canonical_name": "valkyrie"}	477c21c5471d728711e46d93e49178cd8c5c50a47da149df2ae66727a1dd2921	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
118	knowledge/ratchets/7-70.md	component	7-70	it	{"id": "ratchet.7-70", "lang": "it", "slot": "ratchet", "slug": "7-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["7-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_7-70"], "doc_version": 1, "canonical_name": "7-70"}	d68a118b5388ce098e52f4f8bd2dc07246018257cddd72d1c968e6faa5e06142	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
278	knowledge/ratchets/0-60.md	component	0-60	it	{"id": "ratchet.0-60", "lang": "it", "slot": "ratchet", "slug": "0-60", "type": "component", "status": "draft", "system": "CX", "aliases": ["0-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_0-60"], "reference": "https://beyblade.wiki/0-60-ratchet/", "doc_version": 1, "canonical_name": "0-60"}	a88f6f79d00be491c0a0016d1856885bea3b29dcc9f101705775691e4bacf659	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
279	knowledge/ratchets/0-70.md	component	0-70	it	{"id": "ratchet.0-70", "lang": "it", "slot": "ratchet", "slug": "0-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["0-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_0-70"], "reference": "https://beyblade.wiki/0-70-ratchet/", "doc_version": 1, "canonical_name": "0-70"}	79dc126ebe798ff672d290a80ffc392b8f10d65cc494cdb4e525e0ec46c7e9a2	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
280	knowledge/ratchets/0-80.md	component	0-80	it	{"id": "ratchet.0-80", "lang": "it", "slot": "ratchet", "slug": "0-80", "type": "component", "status": "draft", "system": "UX", "aliases": ["0-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_0-80"], "reference": "https://beyblade.wiki/0-80-ratchet/", "doc_version": 1, "canonical_name": "0-80"}	768aec5a2598709beff17d11fd0533c591eaffeec7dbc23e17b0f75741e1d8c5	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
281	knowledge/ratchets/1-60.md	component	1-60	it	{"id": "ratchet.1-60", "lang": "it", "slot": "ratchet", "slug": "1-60", "type": "component", "status": "draft", "system": "UX", "aliases": ["1-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-60"], "reference": "https://beyblade.wiki/1-60-ratchet/", "doc_version": 1, "canonical_name": "1-60"}	d50b7a02bfdcaee036f051a2abba7fbbd13d0522f9a29e23096ffa3b7327d0e2	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
282	knowledge/ratchets/1-70.md	component	1-70	it	{"id": "ratchet.1-70", "lang": "it", "slot": "ratchet", "slug": "1-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["1-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-70"], "reference": "https://beyblade.wiki/1-70-ratchet/", "doc_version": 1, "canonical_name": "1-70"}	1fac33feeb0b621da90cd0e16cacf01bb8f63c3a7cea2d00a818a32390e252bb	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
283	knowledge/ratchets/1-80.md	component	1-80	it	{"id": "ratchet.1-80", "lang": "it", "slot": "ratchet", "slug": "1-80", "type": "component", "status": "draft", "system": "UX", "aliases": ["1-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-80"], "reference": "https://beyblade.wiki/1-80-ratchet/", "doc_version": 1, "canonical_name": "1-80"}	6547bacc4405f9a22526f79ac378f083ba2bb97bcfecc3f6b9c51b9051f065df	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
284	knowledge/ratchets/2-60.md	component	2-60	it	{"id": "ratchet.2-60", "lang": "it", "slot": "ratchet", "slug": "2-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["2-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_2-60"], "reference": "https://beyblade.wiki/2-60-ratchet/", "doc_version": 1, "canonical_name": "2-60"}	bf60501bf978e1530e49e0b2df2ae7292f84429aa4901935a130e2a60838d7c9	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
285	knowledge/ratchets/2-70.md	component	2-70	it	{"id": "ratchet.2-70", "lang": "it", "slot": "ratchet", "slug": "2-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["2-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_2-70"], "reference": "https://beyblade.wiki/2-70-ratchet/", "doc_version": 1, "canonical_name": "2-70"}	28be7d60054a503bb939731704ecd049185d750f402ff84d20a5bd49f0e1f33c	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
286	knowledge/ratchets/3-60.md	component	3-60	it	{"id": "ratchet.3-60", "lang": "it", "slot": "ratchet", "slug": "3-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["3-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-60"], "reference": "https://beyblade.wiki/3-60-ratchet/", "doc_version": 1, "canonical_name": "3-60"}	a056a3e051712c63d61064eda22e0d643ad00e4c022fe9cf23bffd691ec41606	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
287	knowledge/ratchets/3-70.md	component	3-70	it	{"id": "ratchet.3-70", "lang": "it", "slot": "ratchet", "slug": "3-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["3-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-70"], "reference": "https://beyblade.wiki/3-70-ratchet/", "doc_version": 1, "canonical_name": "3-70"}	bc5d76c1c46df56267b43f4c90d6c52043b97159953b12bc21b9f27fff0bada5	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
288	knowledge/ratchets/3-80.md	component	3-80	it	{"id": "ratchet.3-80", "lang": "it", "slot": "ratchet", "slug": "3-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["3-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-80"], "reference": "https://beyblade.wiki/3-80-ratchet/", "doc_version": 1, "canonical_name": "3-80"}	8e7eeafc16f62b3dd369949cc74e74e7c9407f91fde24df2fc158d7c6a5a36cc	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
289	knowledge/ratchets/4-50.md	component	4-50	it	{"id": "ratchet.4-50", "lang": "it", "slot": "ratchet", "slug": "4-50", "type": "component", "status": "draft", "system": "UX", "aliases": ["4-50"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-50"], "reference": "https://beyblade.wiki/4-50-ratchet/", "doc_version": 1, "canonical_name": "4-50"}	1a4da1588019690f5b4d96f117200d35c49d8ad380fb1216f45f53dbbe62a040	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
290	knowledge/ratchets/4-55.md	component	4-55	it	{"id": "ratchet.4-55", "lang": "it", "slot": "ratchet", "slug": "4-55", "type": "component", "status": "draft", "system": "CX", "aliases": ["4-55"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-55"], "reference": "https://beyblade.wiki/4-55-ratchet/", "doc_version": 1, "canonical_name": "4-55"}	06a3db057b40bdd83b35b2eff9c2a7beb370fd4b3cafc875866636777d7f36ed	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
291	knowledge/ratchets/4-60.md	component	4-60	it	{"id": "ratchet.4-60", "lang": "it", "slot": "ratchet", "slug": "4-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["4-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-60"], "reference": "https://beyblade.wiki/4-60-ratchet/", "doc_version": 1, "canonical_name": "4-60"}	c742730a9c5c650a112a3eac4cf738cdd642d99e87852cffd866bd160c96c065	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
292	knowledge/ratchets/4-70.md	component	4-70	it	{"id": "ratchet.4-70", "lang": "it", "slot": "ratchet", "slug": "4-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["4-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-70"], "reference": "https://beyblade.wiki/4-70-ratchet/", "doc_version": 1, "canonical_name": "4-70"}	17a1c71bb98015c60755b5d899dfa3a9fb4d99cc4cab49023e66c27954fcb861	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
293	knowledge/ratchets/4-80.md	component	4-80	it	{"id": "ratchet.4-80", "lang": "it", "slot": "ratchet", "slug": "4-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["4-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-80"], "reference": "https://beyblade.wiki/4-80-ratchet/", "doc_version": 1, "canonical_name": "4-80"}	7d091d67a452141a989530c2b38b5c72e0cc18b8dc8abee1e787e89412c38ba0	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
294	knowledge/ratchets/5-60.md	component	5-60	it	{"id": "ratchet.5-60", "lang": "it", "slot": "ratchet", "slug": "5-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["5-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-60"], "reference": "https://beyblade.wiki/5-60-ratchet/", "doc_version": 1, "canonical_name": "5-60"}	39e71ff1dae6e42c8712dab15c8f877103c5cd21ba55ee3a7ca79f7b996be8a7	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
295	knowledge/ratchets/5-70.md	component	5-70	it	{"id": "ratchet.5-70", "lang": "it", "slot": "ratchet", "slug": "5-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["5-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-70"], "reference": "https://beyblade.wiki/5-70-ratchet/", "doc_version": 1, "canonical_name": "5-70"}	7759ecd3bf4d4e10007f5e75816da504807f39a3a43c0268651cedd1f148aad7	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
296	knowledge/ratchets/5-80.md	component	5-80	it	{"id": "ratchet.5-80", "lang": "it", "slot": "ratchet", "slug": "5-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["5-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-80"], "reference": "https://beyblade.wiki/5-80-ratchet/", "doc_version": 1, "canonical_name": "5-80"}	d0f4956e1a8316213de72f45ac25f667a99a7f5069d0f5e7fdb9b2e7d756d63b	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
297	knowledge/ratchets/6-60.md	component	6-60	it	{"id": "ratchet.6-60", "lang": "it", "slot": "ratchet", "slug": "6-60", "type": "component", "status": "draft", "system": "CX", "aliases": ["6-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-60"], "reference": "https://beyblade.wiki/6-60-ratchet/", "doc_version": 1, "canonical_name": "6-60"}	96c14fb03af56fe2eddcb0e9e5b9d1f88c253d63e74a25295c5662ac8d580390	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
298	knowledge/ratchets/6-70.md	component	6-70	it	{"id": "ratchet.6-70", "lang": "it", "slot": "ratchet", "slug": "6-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["6-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-70"], "reference": "https://beyblade.wiki/6-70-ratchet/", "doc_version": 1, "canonical_name": "6-70"}	630fb1919f3f248b0978726535389afc3b39bf4fc2b2eeb7091e89d7bba7e8ae	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
299	knowledge/ratchets/6-80.md	component	6-80	it	{"id": "ratchet.6-80", "lang": "it", "slot": "ratchet", "slug": "6-80", "type": "component", "status": "draft", "system": "CX", "aliases": ["6-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-80"], "reference": "https://beyblade.wiki/6-80-ratchet/", "doc_version": 1, "canonical_name": "6-80"}	08e2e0d05efaa7268cfc2ea2a339156cdfcad449fc697f5fd625903fa580adc5	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
119	knowledge/ratchets/7-80.md	component	7-80	it	{"id": "ratchet.7-80", "lang": "it", "slot": "ratchet", "slug": "7-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["7-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_7-80"], "doc_version": 1, "canonical_name": "7-80"}	443d067705cfb0b6ee35d97f8c51a26cfaac1ea36822a7392e73c9e5ed542047	1	7f84633	2026-08-21 21:33:08.208309+00	2026-08-22 12:20:46.065136+00
1066	knowledge/blades/hover-wyvern.md	component	hover-wyvern	it	{"id": "blade.hover-wyvern", "lang": "it", "slot": "blade", "slug": "hover-wyvern", "type": "component", "status": "draft", "system": "UX", "aliases": ["HoverWyvern"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Hover_Wyvern"], "doc_version": 1, "canonical_name": "HoverWyvern"}	205fcd8275c70dfca2e7ad551c8d281897d3af3d63b2ce9147ad2036f5de165a	3	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:52:58.967619+00
300	knowledge/ratchets/9-60.md	component	9-60	it	{"id": "ratchet.9-60", "lang": "it", "slot": "ratchet", "slug": "9-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["9-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-60"], "reference": "https://beyblade.wiki/9-60-ratchet/", "doc_version": 1, "canonical_name": "9-60"}	0f23ee0b29f3de20f280798f3e595ca4dc4c41ae98d233654ad16ed5d35b9366	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
301	knowledge/ratchets/9-65.md	component	9-65	it	{"id": "ratchet.9-65", "lang": "it", "slot": "ratchet", "slug": "9-65", "type": "component", "status": "draft", "system": "UX", "aliases": ["9-65"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-65"], "reference": "https://beyblade.wiki/9-65-ratchet/", "doc_version": 1, "canonical_name": "9-65"}	ab7e9dfccd21b7a404f69a8fde07d63d19a87d98989ebb73a6f04c8b13126def	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
302	knowledge/ratchets/9-70.md	component	9-70	it	{"id": "ratchet.9-70", "lang": "it", "slot": "ratchet", "slug": "9-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["9-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-70"], "reference": "https://beyblade.wiki/9-70-ratchet/", "doc_version": 1, "canonical_name": "9-70"}	88080fb7919620c3230187b251fc8a576e4e5cecee734ca7fdfbacef8ab999f6	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
303	knowledge/ratchets/9-80.md	component	9-80	it	{"id": "ratchet.9-80", "lang": "it", "slot": "ratchet", "slug": "9-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["9-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-80"], "reference": "https://beyblade.wiki/9-80-ratchet/", "doc_version": 1, "canonical_name": "9-80"}	faaccac5077a5090d0a177e77ea8fedc614210aecfe20aa627d78e9ef4e4477a	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
304	knowledge/ratchets/m-85.md	component	m-85	it	{"id": "ratchet.m-85", "lang": "it", "slot": "ratchet", "slug": "m-85", "type": "component", "status": "draft", "system": "BX", "aliases": ["M-85"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_M-85"], "reference": "https://beyblade.wiki/m-85-ratchet/", "doc_version": 1, "canonical_name": "M-85"}	6fe045b752aa69545e069ae74ef3e72d5aa57d6698d71a47275400b80036a739	2	7f84633	2026-08-21 22:14:27.709114+00	2026-08-22 12:20:46.065136+00
7	knowledge/regole/identita-combo.md	rule	\N	it	{"id": "rule.identita-combo", "lang": "it", "type": "rule", "status": "ok", "sources": ["decisione di modellazione del progetto, 2026-08-21"], "doc_version": 1}	635b101235de981d61a5cdb4476de474bf3e4465ee252c8f02729c09a7121b6d	1	7f84633	2026-08-21 21:05:02.818768+00	2026-08-22 12:20:46.065136+00
732	knowledge/blades/hover-wyvern.md	component	hover-wyvern	it	{"id": "blade.hover-wyvern", "lang": "it", "slot": "blade", "slug": "hover-wyvern", "type": "component", "status": "draft", "system": "UX", "aliases": ["HoverWyvern"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Hover_Wyvern"], "doc_version": 1, "canonical_name": "HoverWyvern"}	205fcd8275c70dfca2e7ad551c8d281897d3af3d63b2ce9147ad2036f5de165a	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
733	knowledge/blades/impact-drake.md	component	impact-drake	it	{"id": "blade.impact-drake", "lang": "it", "slot": "blade", "slug": "impact-drake", "type": "component", "status": "draft", "system": "UX", "aliases": ["ImpactDrake"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ImpactDrake"], "reference": "https://beyblade.wiki/impact-drake-blade/", "doc_version": 1, "canonical_name": "ImpactDrake"}	455683720bb2e4a83d562b5125c212242bf859f2c409b04c821116f7e1dfec57	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
734	knowledge/blades/knight-lance.md	component	knight-lance	it	{"id": "blade.knight-lance", "lang": "it", "slot": "blade", "slug": "knight-lance", "type": "component", "status": "draft", "system": "BX", "aliases": ["KnightLance"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightLance"], "reference": "https://beyblade.wiki/knight-lance-blade/", "doc_version": 1, "canonical_name": "KnightLance"}	8458b3309ed0064236ae232137850c7ab8bd48b818b93e5ad6e7299168d54e09	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1068	knowledge/blades/knight-lance.md	component	knight-lance	it	{"id": "blade.knight-lance", "lang": "it", "slot": "blade", "slug": "knight-lance", "type": "component", "status": "draft", "system": "BX", "aliases": ["KnightLance"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightLance"], "reference": "https://beyblade.wiki/knight-lance-blade/", "doc_version": 1, "canonical_name": "KnightLance"}	8458b3309ed0064236ae232137850c7ab8bd48b818b93e5ad6e7299168d54e09	4	7f84633	2026-08-22 13:35:57.076988+00	\N
735	knowledge/blades/knight-mail.md	component	knight-mail	it	{"id": "blade.knight-mail", "lang": "it", "slot": "blade", "slug": "knight-mail", "type": "component", "status": "draft", "system": "UX", "aliases": ["KnightMail"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightMail"], "reference": "https://beyblade.wiki/knight-mail-blade/", "doc_version": 1, "canonical_name": "KnightMail"}	ca25d7c4bb5d4816f8146cbfab7f0cf240049a6ac1cbbc4bc95e2cb25dcd7454	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1069	knowledge/blades/knight-mail.md	component	knight-mail	it	{"id": "blade.knight-mail", "lang": "it", "slot": "blade", "slug": "knight-mail", "type": "component", "status": "draft", "system": "UX", "aliases": ["KnightMail"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightMail"], "reference": "https://beyblade.wiki/knight-mail-blade/", "doc_version": 1, "canonical_name": "KnightMail"}	ca25d7c4bb5d4816f8146cbfab7f0cf240049a6ac1cbbc4bc95e2cb25dcd7454	4	7f84633	2026-08-22 13:35:57.076988+00	\N
736	knowledge/blades/knight-shield-blade.md	component	knight-shield-blade	it	{"id": "blade.knight-shield-blade", "lang": "it", "slot": "blade", "slug": "knight-shield-blade", "type": "component", "status": "draft", "system": "BX", "aliases": ["KnightShield", "knight-shield-blade"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_KnightShield"], "reference": "https://beyblade.wiki/knight-shield-blade/", "doc_version": 1, "canonical_name": "KnightShield"}	c7ad8a1fe8258bcfadb51eb6f07fdf508e1db874121abd411dfbb0b28464daa5	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
737	knowledge/blades/leon-claw.md	component	leon-claw	it	{"id": "blade.leon-claw", "lang": "it", "slot": "blade", "slug": "leon-claw", "type": "component", "status": "draft", "system": "BX", "aliases": ["LeonClaw"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_LeonClaw"], "reference": "https://beyblade.wiki/leon-claw-blade/", "doc_version": 1, "canonical_name": "LeonClaw"}	2d8fa0f5e2a5611aa74dfd6982d87747bf53af3d3558c577b678d789a3a3d618	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1071	knowledge/blades/leon-claw.md	component	leon-claw	it	{"id": "blade.leon-claw", "lang": "it", "slot": "blade", "slug": "leon-claw", "type": "component", "status": "draft", "system": "BX", "aliases": ["LeonClaw"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_LeonClaw"], "reference": "https://beyblade.wiki/leon-claw-blade/", "doc_version": 1, "canonical_name": "LeonClaw"}	2d8fa0f5e2a5611aa74dfd6982d87747bf53af3d3558c577b678d789a3a3d618	4	7f84633	2026-08-22 13:35:57.076988+00	\N
738	knowledge/blades/leon-crest.md	component	leon-crest	it	{"id": "blade.leon-crest", "lang": "it", "slot": "blade", "slug": "leon-crest", "type": "component", "status": "draft", "system": "UX", "aliases": ["LeonCrest"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_LeonCrest"], "reference": "https://beyblade.wiki/leon-crest-blade/", "doc_version": 1, "canonical_name": "LeonCrest"}	d836ad354d7970b1e7455a79237a01a3ffd205d35d7416535b154ecd80a26277	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1072	knowledge/blades/leon-crest.md	component	leon-crest	it	{"id": "blade.leon-crest", "lang": "it", "slot": "blade", "slug": "leon-crest", "type": "component", "status": "draft", "system": "UX", "aliases": ["LeonCrest"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_LeonCrest"], "reference": "https://beyblade.wiki/leon-crest-blade/", "doc_version": 1, "canonical_name": "LeonCrest"}	d836ad354d7970b1e7455a79237a01a3ffd205d35d7416535b154ecd80a26277	4	7f84633	2026-08-22 13:35:57.076988+00	\N
739	knowledge/blades/mammoth-tusk.md	component	mammoth-tusk	it	{"id": "blade.mammoth-tusk", "lang": "it", "slot": "blade", "slug": "mammoth-tusk", "type": "component", "status": "draft", "system": "BX", "aliases": ["MammothTusk"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Tusk_Mammoth"], "reference": "https://beyblade.wiki/mammoth-tusk-blade/", "doc_version": 1, "canonical_name": "MammothTusk"}	b93cc90402ae9fe238040f841d505329a0a5a6c7d03be0f1b6fc592146162e2f	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1073	knowledge/blades/mammoth-tusk.md	component	mammoth-tusk	it	{"id": "blade.mammoth-tusk", "lang": "it", "slot": "blade", "slug": "mammoth-tusk", "type": "component", "status": "draft", "system": "BX", "aliases": ["MammothTusk"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Tusk_Mammoth"], "reference": "https://beyblade.wiki/mammoth-tusk-blade/", "doc_version": 1, "canonical_name": "MammothTusk"}	b93cc90402ae9fe238040f841d505329a0a5a6c7d03be0f1b6fc592146162e2f	4	7f84633	2026-08-22 13:35:57.076988+00	\N
740	knowledge/blades/might.md	component	might	it	{"id": "blade.might", "lang": "it", "slot": "blade", "slug": "might", "type": "component", "status": "draft", "system": "CX", "aliases": ["Might"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Might"], "reference": "https://beyblade.wiki/might-main-blade/", "doc_version": 1, "canonical_name": "Might"}	cc972ee2bdff9538f9aa6f0e962f4ca0ef94f26de6aad336dcb1986e718f6804	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
741	knowledge/blades/moff-gideon.md	component	moff-gideon	it	{"id": "blade.moff-gideon", "lang": "it", "slot": "blade", "slug": "moff-gideon", "type": "component", "status": "draft", "system": "BX", "aliases": ["MoffGideon"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Moff_Gideon"], "doc_version": 1, "canonical_name": "MoffGideon"}	96e2bbc5c5ac3d224a5f4fdb4b1fe1d0e6644ea8d6811da582c25668b846e586	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1075	knowledge/blades/moff-gideon.md	component	moff-gideon	it	{"id": "blade.moff-gideon", "lang": "it", "slot": "blade", "slug": "moff-gideon", "type": "component", "status": "draft", "system": "BX", "aliases": ["MoffGideon"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Moff_Gideon"], "doc_version": 1, "canonical_name": "MoffGideon"}	96e2bbc5c5ac3d224a5f4fdb4b1fe1d0e6644ea8d6811da582c25668b846e586	3	7f84633	2026-08-22 13:35:57.076988+00	\N
742	knowledge/blades/mosasaurus.md	component	mosasaurus	it	{"id": "blade.mosasaurus", "lang": "it", "slot": "blade", "slug": "mosasaurus", "type": "component", "status": "draft", "system": "BX", "aliases": ["Mosasaurus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TriceraSpiky"], "doc_version": 1, "canonical_name": "Mosasaurus"}	02e683cec6e0413f86dcdb4bdd68fbf15293f0e5a59d93ed0ddb6ec02ab990e9	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1076	knowledge/blades/mosasaurus.md	component	mosasaurus	it	{"id": "blade.mosasaurus", "lang": "it", "slot": "blade", "slug": "mosasaurus", "type": "component", "status": "draft", "system": "BX", "aliases": ["Mosasaurus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TriceraSpiky"], "doc_version": 1, "canonical_name": "Mosasaurus"}	02e683cec6e0413f86dcdb4bdd68fbf15293f0e5a59d93ed0ddb6ec02ab990e9	3	7f84633	2026-08-22 13:35:57.076988+00	\N
743	knowledge/blades/optimus-primal.md	component	optimus-primal	it	{"id": "blade.optimus-primal", "lang": "it", "slot": "blade", "slug": "optimus-primal", "type": "component", "status": "draft", "system": "BX", "aliases": ["OptimusPrimal"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Optimus_Primal"], "doc_version": 1, "canonical_name": "OptimusPrimal"}	994650588698d214831ae22364996ed62e5c5873a4a3067d1b753790bbd70d21	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1077	knowledge/blades/optimus-primal.md	component	optimus-primal	it	{"id": "blade.optimus-primal", "lang": "it", "slot": "blade", "slug": "optimus-primal", "type": "component", "status": "draft", "system": "BX", "aliases": ["OptimusPrimal"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Optimus_Primal"], "doc_version": 1, "canonical_name": "OptimusPrimal"}	994650588698d214831ae22364996ed62e5c5873a4a3067d1b753790bbd70d21	3	7f84633	2026-08-22 13:35:57.076988+00	\N
744	knowledge/blades/optimus-prime.md	component	optimus-prime	it	{"id": "blade.optimus-prime", "lang": "it", "slot": "blade", "slug": "optimus-prime", "type": "component", "status": "draft", "system": "BX", "aliases": ["OptimusPrime"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Optimus_Prime"], "doc_version": 1, "canonical_name": "OptimusPrime"}	1ff32e9875c37b120988404be4c0e1a5c165b6e16e369a36fb3411b482752673	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1078	knowledge/blades/optimus-prime.md	component	optimus-prime	it	{"id": "blade.optimus-prime", "lang": "it", "slot": "blade", "slug": "optimus-prime", "type": "component", "status": "draft", "system": "BX", "aliases": ["OptimusPrime"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Optimus_Prime"], "doc_version": 1, "canonical_name": "OptimusPrime"}	1ff32e9875c37b120988404be4c0e1a5c165b6e16e369a36fb3411b482752673	3	7f84633	2026-08-22 13:35:57.076988+00	\N
745	knowledge/blades/phoenix-feather.md	component	phoenix-feather	it	{"id": "blade.phoenix-feather", "lang": "it", "slot": "blade", "slug": "phoenix-feather", "type": "component", "status": "draft", "system": "BX", "aliases": ["PhoenixFeather"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixFeather"], "reference": "https://beyblade.wiki/phoenix-feather-blade/", "doc_version": 1, "canonical_name": "PhoenixFeather"}	c481078e821342d95d01b936f6e42cfc58804c5ca0918b44a123e7707eacb053	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1079	knowledge/blades/phoenix-feather.md	component	phoenix-feather	it	{"id": "blade.phoenix-feather", "lang": "it", "slot": "blade", "slug": "phoenix-feather", "type": "component", "status": "draft", "system": "BX", "aliases": ["PhoenixFeather"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixFeather"], "reference": "https://beyblade.wiki/phoenix-feather-blade/", "doc_version": 1, "canonical_name": "PhoenixFeather"}	c481078e821342d95d01b936f6e42cfc58804c5ca0918b44a123e7707eacb053	4	7f84633	2026-08-22 13:35:57.076988+00	\N
746	knowledge/blades/phoenix-rudder.md	component	phoenix-rudder	it	{"id": "blade.phoenix-rudder", "lang": "it", "slot": "blade", "slug": "phoenix-rudder", "type": "component", "status": "draft", "system": "UX", "aliases": ["PhoenixRudder"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixRudder"], "reference": "https://beyblade.wiki/phoenix-rudder-blade/", "doc_version": 1, "canonical_name": "PhoenixRudder"}	f5e42ea9494b76161ae0ee98b15b2639b88b2dd3ffd070d8d589dd2bbfd9f71b	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1080	knowledge/blades/phoenix-rudder.md	component	phoenix-rudder	it	{"id": "blade.phoenix-rudder", "lang": "it", "slot": "blade", "slug": "phoenix-rudder", "type": "component", "status": "draft", "system": "UX", "aliases": ["PhoenixRudder"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixRudder"], "reference": "https://beyblade.wiki/phoenix-rudder-blade/", "doc_version": 1, "canonical_name": "PhoenixRudder"}	f5e42ea9494b76161ae0ee98b15b2639b88b2dd3ffd070d8d589dd2bbfd9f71b	4	7f84633	2026-08-22 13:35:57.076988+00	\N
754	knowledge/blades/samurai-saber.md	component	samurai-saber	it	{"id": "blade.samurai-saber", "lang": "it", "slot": "blade", "slug": "samurai-saber", "type": "component", "status": "draft", "system": "UX", "aliases": ["SamuraiSaber"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SamuraiSaber"], "reference": "https://beyblade.wiki/samurai-saber-blade/", "doc_version": 1, "canonical_name": "SamuraiSaber"}	19c3ab800258b416ccb25c130e0348abff47ff8a9ca47b24974be6aa0b7fc33d	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
747	knowledge/blades/phoenix-wing.md	component	phoenix-wing	it	{"id": "blade.phoenix-wing", "lang": "it", "slot": "blade", "slug": "phoenix-wing", "type": "component", "status": "draft", "system": "BX", "aliases": ["PhoenixSoar (Youngtoys)", "PhoenixWing", "Soar Phoenix"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_PhoenixWing"], "reference": "https://beyblade.wiki/phoenix-wing-blade/", "doc_version": 1, "canonical_name": "PhoenixWing"}	e9df8e6ddc00c4d562d853a638c6169f988525e1eb374516efef4bd4d4610244	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
748	knowledge/blades/ptera-swing.md	component	ptera-swing	it	{"id": "blade.ptera-swing", "lang": "it", "slot": "blade", "slug": "ptera-swing", "type": "component", "status": "draft", "system": "BX", "aliases": ["PteraSwing"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Talon_Ptera"], "doc_version": 1, "canonical_name": "PteraSwing"}	db63855af2f17e323bd143d043bca38d44c37e97481da84861a448e62d9bb88e	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
750	knowledge/blades/reaper.md	component	reaper	it	{"id": "blade.reaper", "lang": "it", "slot": "blade", "slug": "reaper", "type": "component", "status": "draft", "system": "CX", "aliases": ["Reaper"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Reaper"], "reference": "https://beyblade.wiki/reaper-main-blade/", "doc_version": 1, "canonical_name": "Reaper"}	55ba1344fb38a92607dcc50b95cc0618d663801c44299a2a94b3174121729738	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1084	knowledge/blades/reaper.md	component	reaper	it	{"id": "blade.reaper", "lang": "it", "slot": "blade", "slug": "reaper", "type": "component", "status": "draft", "system": "CX", "aliases": ["Reaper"], "sources": ["https://beyblade.fandom.com/wiki/Main_Blade_-_Reaper"], "reference": "https://beyblade.wiki/reaper-main-blade/", "doc_version": 1, "canonical_name": "Reaper"}	55ba1344fb38a92607dcc50b95cc0618d663801c44299a2a94b3174121729738	4	7f84633	2026-08-22 13:35:57.076988+00	\N
751	knowledge/blades/rhino-horn.md	component	rhino-horn	it	{"id": "blade.rhino-horn", "lang": "it", "slot": "blade", "slug": "rhino-horn", "type": "component", "status": "draft", "system": "BX", "aliases": ["RhinoHorn"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_RhinoHorn"], "reference": "https://beyblade.wiki/rhino-horn-blade/", "doc_version": 1, "canonical_name": "RhinoHorn"}	c2a2a58bb90f6aee61d5f7766ed8d9a2bc95768623ff4d572b69d50b73702f4b	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1085	knowledge/blades/rhino-horn.md	component	rhino-horn	it	{"id": "blade.rhino-horn", "lang": "it", "slot": "blade", "slug": "rhino-horn", "type": "component", "status": "draft", "system": "BX", "aliases": ["RhinoHorn"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_RhinoHorn"], "reference": "https://beyblade.wiki/rhino-horn-blade/", "doc_version": 1, "canonical_name": "RhinoHorn"}	c2a2a58bb90f6aee61d5f7766ed8d9a2bc95768623ff4d572b69d50b73702f4b	4	7f84633	2026-08-22 13:35:57.076988+00	\N
752	knowledge/blades/rock-leone.md	component	rock-leone	it	{"id": "blade.rock-leone", "lang": "it", "slot": "blade", "slug": "rock-leone", "type": "component", "status": "draft", "system": "BX", "aliases": ["RockLeone"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Rock_Leone"], "doc_version": 1, "canonical_name": "RockLeone"}	efc7a2a6aa174bebb7bdfe7241ed989061579f3839a3340df5e7675d892ff1e8	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1086	knowledge/blades/rock-leone.md	component	rock-leone	it	{"id": "blade.rock-leone", "lang": "it", "slot": "blade", "slug": "rock-leone", "type": "component", "status": "draft", "system": "BX", "aliases": ["RockLeone"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Rock_Leone"], "doc_version": 1, "canonical_name": "RockLeone"}	efc7a2a6aa174bebb7bdfe7241ed989061579f3839a3340df5e7675d892ff1e8	3	7f84633	2026-08-22 13:35:57.076988+00	\N
753	knowledge/blades/samurai-calibur.md	component	samurai-calibur	it	{"id": "blade.samurai-calibur", "lang": "it", "slot": "blade", "slug": "samurai-calibur", "type": "component", "status": "draft", "system": "BX", "aliases": ["SamuraiCalibur"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SamuraiCalibur"], "reference": "https://beyblade.wiki/samurai-calibur-blade/", "doc_version": 1, "canonical_name": "SamuraiCalibur"}	c03058d37c51cb38d3c64e16f3dd4708f10c9115c08d8f26d52fdf8122a1d6eb	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1087	knowledge/blades/samurai-calibur.md	component	samurai-calibur	it	{"id": "blade.samurai-calibur", "lang": "it", "slot": "blade", "slug": "samurai-calibur", "type": "component", "status": "draft", "system": "BX", "aliases": ["SamuraiCalibur"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SamuraiCalibur"], "reference": "https://beyblade.wiki/samurai-calibur-blade/", "doc_version": 1, "canonical_name": "SamuraiCalibur"}	c03058d37c51cb38d3c64e16f3dd4708f10c9115c08d8f26d52fdf8122a1d6eb	4	7f84633	2026-08-22 13:35:57.076988+00	\N
749	knowledge/blades/quetzalcoatlus.md	component	ptera-swing	it	{"id": "blade.quetzalcoatlus", "lang": "it", "slot": "blade", "slug": "quetzalcoatlus", "type": "component", "status": "draft", "system": "BX", "aliases": ["Quetzalcoatlus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Talon_Ptera"], "doc_version": 1, "canonical_name": "Quetzalcoatlus"}	9ce43337f2f8c2eb441c8932837691e3919be402c1491613540b6ee0c1b3a5b6	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1083	knowledge/blades/quetzalcoatlus.md	component	ptera-swing	it	{"id": "blade.quetzalcoatlus", "lang": "it", "slot": "blade", "slug": "quetzalcoatlus", "type": "component", "status": "draft", "system": "BX", "aliases": ["Quetzalcoatlus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Talon_Ptera"], "doc_version": 1, "canonical_name": "Quetzalcoatlus"}	9ce43337f2f8c2eb441c8932837691e3919be402c1491613540b6ee0c1b3a5b6	3	7f84633	2026-08-22 13:35:57.076988+00	2026-08-24 10:30:26.880122+00
1082	knowledge/blades/ptera-swing.md	component	ptera-swing	it	{"id": "blade.ptera-swing", "lang": "it", "slot": "blade", "slug": "ptera-swing", "type": "component", "status": "draft", "system": "BX", "aliases": ["PteraSwing"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Talon_Ptera"], "doc_version": 1, "canonical_name": "PteraSwing"}	db63855af2f17e323bd143d043bca38d44c37e97481da84861a448e62d9bb88e	3	7f84633	2026-08-22 13:35:57.076988+00	2026-08-24 10:30:51.32741+00
1088	knowledge/blades/samurai-saber.md	component	samurai-saber	it	{"id": "blade.samurai-saber", "lang": "it", "slot": "blade", "slug": "samurai-saber", "type": "component", "status": "draft", "system": "UX", "aliases": ["SamuraiSaber"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SamuraiSaber"], "reference": "https://beyblade.wiki/samurai-saber-blade/", "doc_version": 1, "canonical_name": "SamuraiSaber"}	19c3ab800258b416ccb25c130e0348abff47ff8a9ca47b24974be6aa0b7fc33d	4	7f84633	2026-08-22 13:35:57.076988+00	\N
755	knowledge/blades/samurai-steel.md	component	samurai-steel	it	{"id": "blade.samurai-steel", "lang": "it", "slot": "blade", "slug": "samurai-steel", "type": "component", "status": "draft", "system": "BX", "aliases": ["SamuraiSteel"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Steel_Samurai"], "reference": "https://beyblade.wiki/samurai-steel-blade/", "doc_version": 1, "canonical_name": "SamuraiSteel"}	8205ea75fb2d1136c0a53f78902e77cc4c2a1a84e035b90f1692595f4496e378	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1089	knowledge/blades/samurai-steel.md	component	samurai-steel	it	{"id": "blade.samurai-steel", "lang": "it", "slot": "blade", "slug": "samurai-steel", "type": "component", "status": "draft", "system": "BX", "aliases": ["SamuraiSteel"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Steel_Samurai"], "reference": "https://beyblade.wiki/samurai-steel-blade/", "doc_version": 1, "canonical_name": "SamuraiSteel"}	8205ea75fb2d1136c0a53f78902e77cc4c2a1a84e035b90f1692595f4496e378	4	7f84633	2026-08-22 13:35:57.076988+00	\N
756	knowledge/blades/scorpio-spear.md	component	scorpio-spear	it	{"id": "blade.scorpio-spear", "lang": "it", "slot": "blade", "slug": "scorpio-spear", "type": "component", "status": "draft", "system": "UX", "aliases": ["ScorpioSpear"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ScorpioSpear"], "reference": "https://beyblade.wiki/scorpio-spear-blade/", "doc_version": 1, "canonical_name": "ScorpioSpear"}	66681d4bbecb76107c06bf8d8ecf23eafdffec200e6d42f4d04299d51252050e	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
757	knowledge/blades/shark-edge.md	component	shark-edge	it	{"id": "blade.shark-edge", "lang": "it", "slot": "blade", "slug": "shark-edge", "type": "component", "status": "draft", "system": "BX", "aliases": ["SharkEdge"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SharkEdge"], "reference": "https://beyblade.wiki/shark-edge-blade/", "doc_version": 1, "canonical_name": "SharkEdge"}	7d9a28c14c1c08f0a7fbdb6fcd30b28b1df4ba8781654da45a2f0d29799e2753	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
758	knowledge/blades/shark-scale.md	component	shark-scale	it	{"id": "blade.shark-scale", "lang": "it", "slot": "blade", "slug": "shark-scale", "type": "component", "status": "draft", "system": "UX", "aliases": ["Scale Shark", "SharkScale"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SharkScale"], "reference": "https://beyblade.wiki/shark-scale-blade/", "doc_version": 1, "canonical_name": "SharkScale"}	0a446058d16f4ea254009a6b49074be3780ebb232ed865e5c475e81776d2c2fd	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
759	knowledge/blades/shelter-drake.md	component	shelter-drake	it	{"id": "blade.shelter-drake", "lang": "it", "slot": "blade", "slug": "shelter-drake", "type": "component", "status": "draft", "system": "BX", "aliases": ["ShelterDrake"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ShelterDrake"], "doc_version": 1, "canonical_name": "ShelterDrake"}	915f8d15a86bef7ca813b4c30dd05b48e89dde65f582a5ec1411c01323c8c2a7	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1093	knowledge/blades/shelter-drake.md	component	shelter-drake	it	{"id": "blade.shelter-drake", "lang": "it", "slot": "blade", "slug": "shelter-drake", "type": "component", "status": "draft", "system": "BX", "aliases": ["ShelterDrake"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ShelterDrake"], "doc_version": 1, "canonical_name": "ShelterDrake"}	915f8d15a86bef7ca813b4c30dd05b48e89dde65f582a5ec1411c01323c8c2a7	3	7f84633	2026-08-22 13:35:57.076988+00	\N
760	knowledge/blades/shinobi-knife.md	component	shinobi-knife	it	{"id": "blade.shinobi-knife", "lang": "it", "slot": "blade", "slug": "shinobi-knife", "type": "component", "status": "draft", "system": "BX", "aliases": ["ShinobiKnife"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Knife_Shinobi"], "doc_version": 1, "canonical_name": "ShinobiKnife"}	ebecf84820ad501d948b6095cab76b037b8766b10f177bd9e097ce52a29f3628	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1094	knowledge/blades/shinobi-knife.md	component	shinobi-knife	it	{"id": "blade.shinobi-knife", "lang": "it", "slot": "blade", "slug": "shinobi-knife", "type": "component", "status": "draft", "system": "BX", "aliases": ["ShinobiKnife"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Knife_Shinobi"], "doc_version": 1, "canonical_name": "ShinobiKnife"}	ebecf84820ad501d948b6095cab76b037b8766b10f177bd9e097ce52a29f3628	3	7f84633	2026-08-22 13:35:57.076988+00	\N
761	knowledge/blades/shinobi-shadow.md	component	shinobi-shadow	it	{"id": "blade.shinobi-shadow", "lang": "it", "slot": "blade", "slug": "shinobi-shadow", "type": "component", "status": "draft", "system": "UX", "aliases": ["ShinobiShadow"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ShinobiShadow"], "reference": "https://beyblade.wiki/shinobi-shadow-blade/", "doc_version": 1, "canonical_name": "ShinobiShadow"}	16735bff203e1564bc7746015ab0ee62155978aa9cf905cb613d22c4cd35b825	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1095	knowledge/blades/shinobi-shadow.md	component	shinobi-shadow	it	{"id": "blade.shinobi-shadow", "lang": "it", "slot": "blade", "slug": "shinobi-shadow", "type": "component", "status": "draft", "system": "UX", "aliases": ["ShinobiShadow"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ShinobiShadow"], "reference": "https://beyblade.wiki/shinobi-shadow-blade/", "doc_version": 1, "canonical_name": "ShinobiShadow"}	16735bff203e1564bc7746015ab0ee62155978aa9cf905cb613d22c4cd35b825	4	7f84633	2026-08-22 13:35:57.076988+00	\N
762	knowledge/blades/silver-wolf.md	component	silver-wolf	it	{"id": "blade.silver-wolf", "lang": "it", "slot": "blade", "slug": "silver-wolf", "type": "component", "status": "draft", "system": "UX", "aliases": ["SilverWolf", "Sterling Wolf"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SilverWolf"], "reference": "https://beyblade.wiki/silver-wolf-blade/", "doc_version": 1, "canonical_name": "SilverWolf"}	761ad3d8a8141647d232ee6f47a467453c41f664612cb8f591aec40c34858c1a	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
763	knowledge/blades/sphinx-cowl.md	component	sphinx-cowl	it	{"id": "blade.sphinx-cowl", "lang": "it", "slot": "blade", "slug": "sphinx-cowl", "type": "component", "status": "draft", "system": "BX", "aliases": ["SphinxCowl"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SphinxCowl"], "doc_version": 1, "canonical_name": "SphinxCowl"}	290d526a972a6f73471c5f8159b4ec32b561306c97b54a5425be3c0a28762e4e	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1097	knowledge/blades/sphinx-cowl.md	component	sphinx-cowl	it	{"id": "blade.sphinx-cowl", "lang": "it", "slot": "blade", "slug": "sphinx-cowl", "type": "component", "status": "draft", "system": "BX", "aliases": ["SphinxCowl"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_SphinxCowl"], "doc_version": 1, "canonical_name": "SphinxCowl"}	290d526a972a6f73471c5f8159b4ec32b561306c97b54a5425be3c0a28762e4e	3	7f84633	2026-08-22 13:35:57.076988+00	\N
764	knowledge/blades/spider-man.md	component	spider-man	it	{"id": "blade.spider-man", "lang": "it", "slot": "blade", "slug": "spider-man", "type": "component", "status": "draft", "system": "BX", "aliases": ["Spider-Man"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Spider-Man"], "doc_version": 1, "canonical_name": "Spider-Man"}	e1bd50f0ca68deefe5c1a4fb17714030e1cf3ee102e9c908ad3ce20129606f7e	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1098	knowledge/blades/spider-man.md	component	spider-man	it	{"id": "blade.spider-man", "lang": "it", "slot": "blade", "slug": "spider-man", "type": "component", "status": "draft", "system": "BX", "aliases": ["Spider-Man"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Spider-Man"], "doc_version": 1, "canonical_name": "Spider-Man"}	e1bd50f0ca68deefe5c1a4fb17714030e1cf3ee102e9c908ad3ce20129606f7e	3	7f84633	2026-08-22 13:35:57.076988+00	\N
765	knowledge/blades/spinosaurus.md	component	spinosaurus	it	{"id": "blade.spinosaurus", "lang": "it", "slot": "blade", "slug": "spinosaurus", "type": "component", "status": "draft", "system": "BX", "aliases": ["Spinosaurus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Roar_Tyranno"], "doc_version": 1, "canonical_name": "Spinosaurus"}	9705450f9e14a0cf8544c30af75aa70fca610ddf2825bd35b582f67fd56638d5	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
767	knowledge/blades/tackle-goat.md	component	tackle-goat	it	{"id": "blade.tackle-goat", "lang": "it", "slot": "blade", "slug": "tackle-goat", "type": "component", "status": "draft", "system": "BX", "aliases": ["TackleGoat"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Tackle_Goat"], "doc_version": 1, "canonical_name": "TackleGoat"}	11c687af30c692d0cb80859627cc353e744d76d465d89e2eb4283db0cdd8c6c0	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1101	knowledge/blades/tackle-goat.md	component	tackle-goat	it	{"id": "blade.tackle-goat", "lang": "it", "slot": "blade", "slug": "tackle-goat", "type": "component", "status": "draft", "system": "BX", "aliases": ["TackleGoat"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Tackle_Goat"], "doc_version": 1, "canonical_name": "TackleGoat"}	11c687af30c692d0cb80859627cc353e744d76d465d89e2eb4283db0cdd8c6c0	3	7f84633	2026-08-22 13:35:57.076988+00	\N
768	knowledge/blades/thanos.md	component	thanos	it	{"id": "blade.thanos", "lang": "it", "slot": "blade", "slug": "thanos", "type": "component", "status": "draft", "system": "BX", "aliases": ["Thanos"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Thanos"], "doc_version": 1, "canonical_name": "Thanos"}	4b7d2502130cc27543e797fa4e49356467e7c76725521dce0de0a03a7cb50828	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1102	knowledge/blades/thanos.md	component	thanos	it	{"id": "blade.thanos", "lang": "it", "slot": "blade", "slug": "thanos", "type": "component", "status": "draft", "system": "BX", "aliases": ["Thanos"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Thanos"], "doc_version": 1, "canonical_name": "Thanos"}	4b7d2502130cc27543e797fa4e49356467e7c76725521dce0de0a03a7cb50828	3	7f84633	2026-08-22 13:35:57.076988+00	\N
766	knowledge/blades/t-rex.md	component	tyranno-beat	it	{"id": "blade.t-rex", "lang": "it", "slot": "blade", "slug": "t-rex", "type": "component", "status": "draft", "system": "BX", "aliases": ["T.Rex"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TyrannoBeat"], "doc_version": 1, "canonical_name": "T.Rex"}	65e3fba5d15c7def83acbfde64de4a3846d7cf0bbd5bd148663df29dcbdd0155	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1100	knowledge/blades/t-rex.md	component	tyranno-beat	it	{"id": "blade.t-rex", "lang": "it", "slot": "blade", "slug": "t-rex", "type": "component", "status": "draft", "system": "BX", "aliases": ["T.Rex"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TyrannoBeat"], "doc_version": 1, "canonical_name": "T.Rex"}	65e3fba5d15c7def83acbfde64de4a3846d7cf0bbd5bd148663df29dcbdd0155	3	7f84633	2026-08-22 13:35:57.076988+00	2026-08-24 10:36:30.989359+00
1099	knowledge/blades/spinosaurus.md	component	spinosaurus	it	{"id": "blade.spinosaurus", "lang": "it", "slot": "blade", "slug": "spinosaurus", "type": "component", "status": "draft", "system": "BX", "aliases": ["Spinosaurus"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Roar_Tyranno"], "doc_version": 1, "canonical_name": "Spinosaurus"}	9705450f9e14a0cf8544c30af75aa70fca610ddf2825bd35b582f67fd56638d5	3	7f84633	2026-08-22 13:35:57.076988+00	2026-08-24 10:44:57.797487+00
769	knowledge/blades/tricera-press.md	component	tricera-press	it	{"id": "blade.tricera-press", "lang": "it", "slot": "blade", "slug": "tricera-press", "type": "component", "status": "draft", "system": "BX", "aliases": ["TriceraPress"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TriceraPress"], "reference": "https://beyblade.wiki/tricera-press-blade/", "doc_version": 1, "canonical_name": "TriceraPress"}	09a7d206ad0084d364df552e13289dbc304d4cd378f4e5c48eb72575e1fe9b77	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1103	knowledge/blades/tricera-press.md	component	tricera-press	it	{"id": "blade.tricera-press", "lang": "it", "slot": "blade", "slug": "tricera-press", "type": "component", "status": "draft", "system": "BX", "aliases": ["TriceraPress"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TriceraPress"], "reference": "https://beyblade.wiki/tricera-press-blade/", "doc_version": 1, "canonical_name": "TriceraPress"}	09a7d206ad0084d364df552e13289dbc304d4cd378f4e5c48eb72575e1fe9b77	4	7f84633	2026-08-22 13:35:57.076988+00	\N
770	knowledge/blades/tyranno-beat.md	component	tyranno-beat	it	{"id": "blade.tyranno-beat", "lang": "it", "slot": "blade", "slug": "tyranno-beat", "type": "component", "status": "draft", "system": "BX", "aliases": ["TyrannoBeat"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_TyrannoBeat"], "reference": "https://beyblade.wiki/tyranno-beat-blade/", "doc_version": 1, "canonical_name": "TyrannoBeat"}	f2ab9ab891323d422e0410f1e1498083aa6c12f03950934fd05e5a592603cf8c	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
771	knowledge/blades/tyranno-roar.md	component	tyranno-roar	it	{"id": "blade.tyranno-roar", "lang": "it", "slot": "blade", "slug": "tyranno-roar", "type": "component", "status": "draft", "system": "BX", "aliases": ["TyrannoRoar"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Roar_Tyranno"], "reference": "https://beyblade.wiki/tyranno-roar-blade/", "doc_version": 1, "canonical_name": "TyrannoRoar"}	1cfff00220b87054624657bb374509c7a57b7b5f6a9da4d277357ba2d26492ca	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1105	knowledge/blades/tyranno-roar.md	component	tyranno-roar	it	{"id": "blade.tyranno-roar", "lang": "it", "slot": "blade", "slug": "tyranno-roar", "type": "component", "status": "draft", "system": "BX", "aliases": ["TyrannoRoar"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Roar_Tyranno"], "reference": "https://beyblade.wiki/tyranno-roar-blade/", "doc_version": 1, "canonical_name": "TyrannoRoar"}	1cfff00220b87054624657bb374509c7a57b7b5f6a9da4d277357ba2d26492ca	4	7f84633	2026-08-22 13:35:57.076988+00	\N
772	knowledge/blades/unicorn-sting.md	component	unicorn-sting	it	{"id": "blade.unicorn-sting", "lang": "it", "slot": "blade", "slug": "unicorn-sting", "type": "component", "status": "draft", "system": "BX", "aliases": ["UnicornSting"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_UnicornSting"], "reference": "https://beyblade.wiki/unicorn-sting-blade/", "doc_version": 1, "canonical_name": "UnicornSting"}	dba8415dab1c9abb0df11ac181cdff48e50b8e886f02e9d31d051944292b565e	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1107	knowledge/blades/venom.md	component	venom	it	{"id": "blade.venom", "lang": "it", "slot": "blade", "slug": "venom", "type": "component", "status": "draft", "system": "BX", "aliases": ["Venom"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Venom"], "doc_version": 1, "canonical_name": "Venom"}	fd75b82f27f316372f463feea2c7a555ead6d324fe964059e81d593d0b939020	3	7f84633	2026-08-22 13:35:57.076988+00	\N
774	knowledge/blades/victory-valkyrie.md	component	victory-valkyrie	it	{"id": "blade.victory-valkyrie", "lang": "it", "slot": "blade", "slug": "victory-valkyrie", "type": "component", "status": "draft", "system": "BX", "aliases": ["VictoryValkyrie"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_VictoryValkyrie"], "doc_version": 1, "canonical_name": "VictoryValkyrie"}	b616f4deaf6f562b826404728865ce8741f888d21a4ec65684879e90cab865c1	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1108	knowledge/blades/victory-valkyrie.md	component	victory-valkyrie	it	{"id": "blade.victory-valkyrie", "lang": "it", "slot": "blade", "slug": "victory-valkyrie", "type": "component", "status": "draft", "system": "BX", "aliases": ["VictoryValkyrie"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_VictoryValkyrie"], "doc_version": 1, "canonical_name": "VictoryValkyrie"}	b616f4deaf6f562b826404728865ce8741f888d21a4ec65684879e90cab865c1	3	7f84633	2026-08-22 13:35:57.076988+00	\N
775	knowledge/blades/viper-tail.md	component	viper-tail	it	{"id": "blade.viper-tail", "lang": "it", "slot": "blade", "slug": "viper-tail", "type": "component", "status": "draft", "system": "BX", "aliases": ["ViperTail"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ViperTail"], "reference": "https://beyblade.wiki/viper-tail-blade/", "doc_version": 1, "canonical_name": "ViperTail"}	8ac6b143946df3e0bd80d9d3f07e479deba9348dbebc136e7effd94047313db1	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1109	knowledge/blades/viper-tail.md	component	viper-tail	it	{"id": "blade.viper-tail", "lang": "it", "slot": "blade", "slug": "viper-tail", "type": "component", "status": "draft", "system": "BX", "aliases": ["ViperTail"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_ViperTail"], "reference": "https://beyblade.wiki/viper-tail-blade/", "doc_version": 1, "canonical_name": "ViperTail"}	8ac6b143946df3e0bd80d9d3f07e479deba9348dbebc136e7effd94047313db1	4	7f84633	2026-08-22 13:35:57.076988+00	\N
776	knowledge/blades/weiss-tiger.md	component	weiss-tiger	it	{"id": "blade.weiss-tiger", "lang": "it", "slot": "blade", "slug": "weiss-tiger", "type": "component", "status": "draft", "system": "BX", "aliases": ["WeissTiger"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WeissTiger"], "reference": "https://beyblade.wiki/weiss-tiger-blade/", "doc_version": 1, "canonical_name": "WeissTiger"}	6c01c54826c70bee7759bb4f5c600fcb82fdbc5a6aea0a4559447c5a395daadb	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1110	knowledge/blades/weiss-tiger.md	component	weiss-tiger	it	{"id": "blade.weiss-tiger", "lang": "it", "slot": "blade", "slug": "weiss-tiger", "type": "component", "status": "draft", "system": "BX", "aliases": ["WeissTiger"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WeissTiger"], "reference": "https://beyblade.wiki/weiss-tiger-blade/", "doc_version": 1, "canonical_name": "WeissTiger"}	6c01c54826c70bee7759bb4f5c600fcb82fdbc5a6aea0a4559447c5a395daadb	4	7f84633	2026-08-22 13:35:57.076988+00	\N
777	knowledge/blades/whale-wave.md	component	whale-wave	it	{"id": "blade.whale-wave", "lang": "it", "slot": "blade", "slug": "whale-wave", "type": "component", "status": "draft", "system": "BX", "aliases": ["WhaleWave"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WhaleWave"], "reference": "https://beyblade.wiki/whale-wave-blade/", "doc_version": 1, "canonical_name": "WhaleWave"}	16cb3e906fe2f7ec256d2361bc593d2636c4374276e825c5a83cb305f937d719	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1111	knowledge/blades/whale-wave.md	component	whale-wave	it	{"id": "blade.whale-wave", "lang": "it", "slot": "blade", "slug": "whale-wave", "type": "component", "status": "draft", "system": "BX", "aliases": ["WhaleWave"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WhaleWave"], "reference": "https://beyblade.wiki/whale-wave-blade/", "doc_version": 1, "canonical_name": "WhaleWave"}	16cb3e906fe2f7ec256d2361bc593d2636c4374276e825c5a83cb305f937d719	4	7f84633	2026-08-22 13:35:57.076988+00	\N
778	knowledge/blades/wizard-arrow.md	component	wizard-arrow	it	{"id": "blade.wizard-arrow", "lang": "it", "slot": "blade", "slug": "wizard-arrow", "type": "component", "status": "draft", "system": "BX", "aliases": ["WizardArrow"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WizardArrow"], "reference": "https://beyblade.wiki/wizard-arrow-blade/", "doc_version": 1, "canonical_name": "WizardArrow"}	9cc50293b8cd1dc3f780d24524fec373dc691700f8b227b5c8578bcde8ba4da7	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1112	knowledge/blades/wizard-arrow.md	component	wizard-arrow	it	{"id": "blade.wizard-arrow", "lang": "it", "slot": "blade", "slug": "wizard-arrow", "type": "component", "status": "draft", "system": "BX", "aliases": ["WizardArrow"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WizardArrow"], "reference": "https://beyblade.wiki/wizard-arrow-blade/", "doc_version": 1, "canonical_name": "WizardArrow"}	9cc50293b8cd1dc3f780d24524fec373dc691700f8b227b5c8578bcde8ba4da7	4	7f84633	2026-08-22 13:35:57.076988+00	\N
779	knowledge/blades/wizard-rod.md	component	wizard-rod	it	{"id": "blade.wizard-rod", "lang": "it", "slot": "blade", "slug": "wizard-rod", "type": "component", "status": "draft", "system": "UX", "aliases": ["Wand Wizard", "WizardRod"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WizardRod"], "reference": "https://beyblade.wiki/wizard-rod-blade/", "doc_version": 1, "canonical_name": "WizardRod"}	ba2509f12c00b19944cee8139919117556de60ac5f169f0a59191d933095ec24	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
780	knowledge/blades/wyvern-gale.md	component	wyvern-gale	it	{"id": "blade.wyvern-gale", "lang": "it", "slot": "blade", "slug": "wyvern-gale", "type": "component", "status": "draft", "system": "BX", "aliases": ["WyvernGale"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WyvernGale"], "reference": "https://beyblade.wiki/wyvern-gale-blade/", "doc_version": 1, "canonical_name": "WyvernGale"}	438a8bfba1742fdcc31a85057cb9b1e5bf6ad755c9f7ee617f4b76bd20a94c50	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1114	knowledge/blades/wyvern-gale.md	component	wyvern-gale	it	{"id": "blade.wyvern-gale", "lang": "it", "slot": "blade", "slug": "wyvern-gale", "type": "component", "status": "draft", "system": "BX", "aliases": ["WyvernGale"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_WyvernGale"], "reference": "https://beyblade.wiki/wyvern-gale-blade/", "doc_version": 1, "canonical_name": "WyvernGale"}	438a8bfba1742fdcc31a85057cb9b1e5bf6ad755c9f7ee617f4b76bd20a94c50	4	7f84633	2026-08-22 13:35:57.076988+00	\N
781	knowledge/blades/xeno-xcalibur.md	component	xeno-xcalibur	it	{"id": "blade.xeno-xcalibur", "lang": "it", "slot": "blade", "slug": "xeno-xcalibur", "type": "component", "status": "draft", "system": "BX", "aliases": ["XenoXcalibur"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_XenoXcalibur"], "doc_version": 1, "canonical_name": "XenoXcalibur"}	a5824ddb0fda0234946690f1b571983e44661d987ce7c8c6c4bf20954990d185	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1115	knowledge/blades/xeno-xcalibur.md	component	xeno-xcalibur	it	{"id": "blade.xeno-xcalibur", "lang": "it", "slot": "blade", "slug": "xeno-xcalibur", "type": "component", "status": "draft", "system": "BX", "aliases": ["XenoXcalibur"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_XenoXcalibur"], "doc_version": 1, "canonical_name": "XenoXcalibur"}	a5824ddb0fda0234946690f1b571983e44661d987ce7c8c6c4bf20954990d185	3	7f84633	2026-08-22 13:35:57.076988+00	\N
782	knowledge/blades/yell-kong.md	component	yell-kong	it	{"id": "blade.yell-kong", "lang": "it", "slot": "blade", "slug": "yell-kong", "type": "component", "status": "draft", "system": "BX", "aliases": ["YellKong"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Yell_Kong"], "doc_version": 1, "canonical_name": "YellKong"}	b60d3d937461cf3f1f36f4248fec5e233dcc920e429b4ece0604b43c13ebfdeb	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
783	knowledge/lock-chips/emperor.md	component	emperor	it	{"id": "lock_chip.emperor", "lang": "it", "slot": "lock_chip", "slug": "emperor", "type": "component", "status": "draft", "system": "CX", "aliases": ["emperor"], "sources": ["https://beyblade.fandom.com/wiki/Lock_Chip_-_Emperor"], "reference": "https://beyblade.wiki/emperor-lock-chip/", "doc_version": 1, "canonical_name": "emperor"}	6c31fdb1be497915e6a3dccdd1091af6717c4ec6ffc843791a8a934e431a2113	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1116	knowledge/blades/yell-kong.md	component	yell-kong	it	{"id": "blade.yell-kong", "lang": "it", "slot": "blade", "slug": "yell-kong", "type": "component", "status": "draft", "system": "BX", "aliases": ["YellKong"], "sources": ["https://beyblade.fandom.com/wiki/Blade_-_Yell_Kong"], "doc_version": 1, "canonical_name": "YellKong"}	b60d3d937461cf3f1f36f4248fec5e233dcc920e429b4ece0604b43c13ebfdeb	3	7f84633	2026-08-22 13:35:57.076988+00	2026-08-24 10:56:07.922616+00
1117	knowledge/lock-chips/emperor.md	component	emperor	it	{"id": "lock_chip.emperor", "lang": "it", "slot": "lock_chip", "slug": "emperor", "type": "component", "status": "draft", "system": "CX", "aliases": ["emperor"], "sources": ["https://beyblade.fandom.com/wiki/Lock_Chip_-_Emperor"], "reference": "https://beyblade.wiki/emperor-lock-chip/", "doc_version": 1, "canonical_name": "emperor"}	6c31fdb1be497915e6a3dccdd1091af6717c4ec6ffc843791a8a934e431a2113	4	7f84633	2026-08-22 13:35:57.076988+00	\N
784	knowledge/lock-chips/valkyrie.md	component	valkyrie	it	{"id": "lock_chip.valkyrie", "lang": "it", "slot": "lock_chip", "slug": "valkyrie", "type": "component", "status": "draft", "system": "CX", "aliases": ["valkyrie"], "sources": ["https://beyblade.fandom.com/wiki/Lock_Chip_-_Valkyrie"], "reference": "https://beyblade.wiki/valkyrie-lock-chip/", "doc_version": 1, "canonical_name": "valkyrie"}	477c21c5471d728711e46d93e49178cd8c5c50a47da149df2ae66727a1dd2921	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1118	knowledge/lock-chips/valkyrie.md	component	valkyrie	it	{"id": "lock_chip.valkyrie", "lang": "it", "slot": "lock_chip", "slug": "valkyrie", "type": "component", "status": "draft", "system": "CX", "aliases": ["valkyrie"], "sources": ["https://beyblade.fandom.com/wiki/Lock_Chip_-_Valkyrie"], "reference": "https://beyblade.wiki/valkyrie-lock-chip/", "doc_version": 1, "canonical_name": "valkyrie"}	477c21c5471d728711e46d93e49178cd8c5c50a47da149df2ae66727a1dd2921	4	7f84633	2026-08-22 13:35:57.076988+00	\N
785	knowledge/ratchets/0-60.md	component	0-60	it	{"id": "ratchet.0-60", "lang": "it", "slot": "ratchet", "slug": "0-60", "type": "component", "status": "draft", "system": "CX", "aliases": ["0-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_0-60"], "reference": "https://beyblade.wiki/0-60-ratchet/", "doc_version": 1, "canonical_name": "0-60"}	a88f6f79d00be491c0a0016d1856885bea3b29dcc9f101705775691e4bacf659	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1119	knowledge/ratchets/0-60.md	component	0-60	it	{"id": "ratchet.0-60", "lang": "it", "slot": "ratchet", "slug": "0-60", "type": "component", "status": "draft", "system": "CX", "aliases": ["0-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_0-60"], "reference": "https://beyblade.wiki/0-60-ratchet/", "doc_version": 1, "canonical_name": "0-60"}	a88f6f79d00be491c0a0016d1856885bea3b29dcc9f101705775691e4bacf659	4	7f84633	2026-08-22 13:35:57.076988+00	\N
786	knowledge/ratchets/0-70.md	component	0-70	it	{"id": "ratchet.0-70", "lang": "it", "slot": "ratchet", "slug": "0-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["0-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_0-70"], "reference": "https://beyblade.wiki/0-70-ratchet/", "doc_version": 1, "canonical_name": "0-70"}	79dc126ebe798ff672d290a80ffc392b8f10d65cc494cdb4e525e0ec46c7e9a2	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1120	knowledge/ratchets/0-70.md	component	0-70	it	{"id": "ratchet.0-70", "lang": "it", "slot": "ratchet", "slug": "0-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["0-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_0-70"], "reference": "https://beyblade.wiki/0-70-ratchet/", "doc_version": 1, "canonical_name": "0-70"}	79dc126ebe798ff672d290a80ffc392b8f10d65cc494cdb4e525e0ec46c7e9a2	4	7f84633	2026-08-22 13:35:57.076988+00	\N
787	knowledge/ratchets/0-80.md	component	0-80	it	{"id": "ratchet.0-80", "lang": "it", "slot": "ratchet", "slug": "0-80", "type": "component", "status": "draft", "system": "UX", "aliases": ["0-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_0-80"], "reference": "https://beyblade.wiki/0-80-ratchet/", "doc_version": 1, "canonical_name": "0-80"}	768aec5a2598709beff17d11fd0533c591eaffeec7dbc23e17b0f75741e1d8c5	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1121	knowledge/ratchets/0-80.md	component	0-80	it	{"id": "ratchet.0-80", "lang": "it", "slot": "ratchet", "slug": "0-80", "type": "component", "status": "draft", "system": "UX", "aliases": ["0-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_0-80"], "reference": "https://beyblade.wiki/0-80-ratchet/", "doc_version": 1, "canonical_name": "0-80"}	768aec5a2598709beff17d11fd0533c591eaffeec7dbc23e17b0f75741e1d8c5	4	7f84633	2026-08-22 13:35:57.076988+00	\N
788	knowledge/ratchets/1-60.md	component	1-60	it	{"id": "ratchet.1-60", "lang": "it", "slot": "ratchet", "slug": "1-60", "type": "component", "status": "draft", "system": "UX", "aliases": ["1-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-60"], "reference": "https://beyblade.wiki/1-60-ratchet/", "doc_version": 1, "canonical_name": "1-60"}	d50b7a02bfdcaee036f051a2abba7fbbd13d0522f9a29e23096ffa3b7327d0e2	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
789	knowledge/ratchets/1-70.md	component	1-70	it	{"id": "ratchet.1-70", "lang": "it", "slot": "ratchet", "slug": "1-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["1-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-70"], "reference": "https://beyblade.wiki/1-70-ratchet/", "doc_version": 1, "canonical_name": "1-70"}	1fac33feeb0b621da90cd0e16cacf01bb8f63c3a7cea2d00a818a32390e252bb	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
790	knowledge/ratchets/1-80.md	component	1-80	it	{"id": "ratchet.1-80", "lang": "it", "slot": "ratchet", "slug": "1-80", "type": "component", "status": "draft", "system": "UX", "aliases": ["1-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_1-80"], "reference": "https://beyblade.wiki/1-80-ratchet/", "doc_version": 1, "canonical_name": "1-80"}	6547bacc4405f9a22526f79ac378f083ba2bb97bcfecc3f6b9c51b9051f065df	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
791	knowledge/ratchets/2-60.md	component	2-60	it	{"id": "ratchet.2-60", "lang": "it", "slot": "ratchet", "slug": "2-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["2-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_2-60"], "reference": "https://beyblade.wiki/2-60-ratchet/", "doc_version": 1, "canonical_name": "2-60"}	bf60501bf978e1530e49e0b2df2ae7292f84429aa4901935a130e2a60838d7c9	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1125	knowledge/ratchets/2-60.md	component	2-60	it	{"id": "ratchet.2-60", "lang": "it", "slot": "ratchet", "slug": "2-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["2-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_2-60"], "reference": "https://beyblade.wiki/2-60-ratchet/", "doc_version": 1, "canonical_name": "2-60"}	bf60501bf978e1530e49e0b2df2ae7292f84429aa4901935a130e2a60838d7c9	4	7f84633	2026-08-22 13:35:57.076988+00	\N
792	knowledge/ratchets/2-70.md	component	2-70	it	{"id": "ratchet.2-70", "lang": "it", "slot": "ratchet", "slug": "2-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["2-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_2-70"], "reference": "https://beyblade.wiki/2-70-ratchet/", "doc_version": 1, "canonical_name": "2-70"}	28be7d60054a503bb939731704ecd049185d750f402ff84d20a5bd49f0e1f33c	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1126	knowledge/ratchets/2-70.md	component	2-70	it	{"id": "ratchet.2-70", "lang": "it", "slot": "ratchet", "slug": "2-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["2-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_2-70"], "reference": "https://beyblade.wiki/2-70-ratchet/", "doc_version": 1, "canonical_name": "2-70"}	28be7d60054a503bb939731704ecd049185d750f402ff84d20a5bd49f0e1f33c	4	7f84633	2026-08-22 13:35:57.076988+00	\N
793	knowledge/ratchets/3-60.md	component	3-60	it	{"id": "ratchet.3-60", "lang": "it", "slot": "ratchet", "slug": "3-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["3-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-60"], "reference": "https://beyblade.wiki/3-60-ratchet/", "doc_version": 1, "canonical_name": "3-60"}	a056a3e051712c63d61064eda22e0d643ad00e4c022fe9cf23bffd691ec41606	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
794	knowledge/ratchets/3-70.md	component	3-70	it	{"id": "ratchet.3-70", "lang": "it", "slot": "ratchet", "slug": "3-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["3-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-70"], "reference": "https://beyblade.wiki/3-70-ratchet/", "doc_version": 1, "canonical_name": "3-70"}	bc5d76c1c46df56267b43f4c90d6c52043b97159953b12bc21b9f27fff0bada5	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
795	knowledge/ratchets/3-80.md	component	3-80	it	{"id": "ratchet.3-80", "lang": "it", "slot": "ratchet", "slug": "3-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["3-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-80"], "reference": "https://beyblade.wiki/3-80-ratchet/", "doc_version": 1, "canonical_name": "3-80"}	8e7eeafc16f62b3dd369949cc74e74e7c9407f91fde24df2fc158d7c6a5a36cc	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1129	knowledge/ratchets/3-80.md	component	3-80	it	{"id": "ratchet.3-80", "lang": "it", "slot": "ratchet", "slug": "3-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["3-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_3-80"], "reference": "https://beyblade.wiki/3-80-ratchet/", "doc_version": 1, "canonical_name": "3-80"}	8e7eeafc16f62b3dd369949cc74e74e7c9407f91fde24df2fc158d7c6a5a36cc	4	7f84633	2026-08-22 13:35:57.076988+00	\N
796	knowledge/ratchets/4-50.md	component	4-50	it	{"id": "ratchet.4-50", "lang": "it", "slot": "ratchet", "slug": "4-50", "type": "component", "status": "draft", "system": "UX", "aliases": ["4-50"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-50"], "reference": "https://beyblade.wiki/4-50-ratchet/", "doc_version": 1, "canonical_name": "4-50"}	1a4da1588019690f5b4d96f117200d35c49d8ad380fb1216f45f53dbbe62a040	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
797	knowledge/ratchets/4-55.md	component	4-55	it	{"id": "ratchet.4-55", "lang": "it", "slot": "ratchet", "slug": "4-55", "type": "component", "status": "draft", "system": "CX", "aliases": ["4-55"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-55"], "reference": "https://beyblade.wiki/4-55-ratchet/", "doc_version": 1, "canonical_name": "4-55"}	06a3db057b40bdd83b35b2eff9c2a7beb370fd4b3cafc875866636777d7f36ed	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
798	knowledge/ratchets/4-60.md	component	4-60	it	{"id": "ratchet.4-60", "lang": "it", "slot": "ratchet", "slug": "4-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["4-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-60"], "reference": "https://beyblade.wiki/4-60-ratchet/", "doc_version": 1, "canonical_name": "4-60"}	c742730a9c5c650a112a3eac4cf738cdd642d99e87852cffd866bd160c96c065	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1132	knowledge/ratchets/4-60.md	component	4-60	it	{"id": "ratchet.4-60", "lang": "it", "slot": "ratchet", "slug": "4-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["4-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-60"], "reference": "https://beyblade.wiki/4-60-ratchet/", "doc_version": 1, "canonical_name": "4-60"}	c742730a9c5c650a112a3eac4cf738cdd642d99e87852cffd866bd160c96c065	4	7f84633	2026-08-22 13:35:57.076988+00	\N
799	knowledge/ratchets/4-70.md	component	4-70	it	{"id": "ratchet.4-70", "lang": "it", "slot": "ratchet", "slug": "4-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["4-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-70"], "reference": "https://beyblade.wiki/4-70-ratchet/", "doc_version": 1, "canonical_name": "4-70"}	17a1c71bb98015c60755b5d899dfa3a9fb4d99cc4cab49023e66c27954fcb861	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1133	knowledge/ratchets/4-70.md	component	4-70	it	{"id": "ratchet.4-70", "lang": "it", "slot": "ratchet", "slug": "4-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["4-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-70"], "reference": "https://beyblade.wiki/4-70-ratchet/", "doc_version": 1, "canonical_name": "4-70"}	17a1c71bb98015c60755b5d899dfa3a9fb4d99cc4cab49023e66c27954fcb861	4	7f84633	2026-08-22 13:35:57.076988+00	\N
800	knowledge/ratchets/4-80.md	component	4-80	it	{"id": "ratchet.4-80", "lang": "it", "slot": "ratchet", "slug": "4-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["4-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-80"], "reference": "https://beyblade.wiki/4-80-ratchet/", "doc_version": 1, "canonical_name": "4-80"}	7d091d67a452141a989530c2b38b5c72e0cc18b8dc8abee1e787e89412c38ba0	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1134	knowledge/ratchets/4-80.md	component	4-80	it	{"id": "ratchet.4-80", "lang": "it", "slot": "ratchet", "slug": "4-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["4-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_4-80"], "reference": "https://beyblade.wiki/4-80-ratchet/", "doc_version": 1, "canonical_name": "4-80"}	7d091d67a452141a989530c2b38b5c72e0cc18b8dc8abee1e787e89412c38ba0	4	7f84633	2026-08-22 13:35:57.076988+00	\N
801	knowledge/ratchets/5-60.md	component	5-60	it	{"id": "ratchet.5-60", "lang": "it", "slot": "ratchet", "slug": "5-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["5-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-60"], "reference": "https://beyblade.wiki/5-60-ratchet/", "doc_version": 1, "canonical_name": "5-60"}	39e71ff1dae6e42c8712dab15c8f877103c5cd21ba55ee3a7ca79f7b996be8a7	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
802	knowledge/ratchets/5-70.md	component	5-70	it	{"id": "ratchet.5-70", "lang": "it", "slot": "ratchet", "slug": "5-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["5-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-70"], "reference": "https://beyblade.wiki/5-70-ratchet/", "doc_version": 1, "canonical_name": "5-70"}	7759ecd3bf4d4e10007f5e75816da504807f39a3a43c0268651cedd1f148aad7	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1136	knowledge/ratchets/5-70.md	component	5-70	it	{"id": "ratchet.5-70", "lang": "it", "slot": "ratchet", "slug": "5-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["5-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-70"], "reference": "https://beyblade.wiki/5-70-ratchet/", "doc_version": 1, "canonical_name": "5-70"}	7759ecd3bf4d4e10007f5e75816da504807f39a3a43c0268651cedd1f148aad7	4	7f84633	2026-08-22 13:35:57.076988+00	\N
803	knowledge/ratchets/5-80.md	component	5-80	it	{"id": "ratchet.5-80", "lang": "it", "slot": "ratchet", "slug": "5-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["5-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-80"], "reference": "https://beyblade.wiki/5-80-ratchet/", "doc_version": 1, "canonical_name": "5-80"}	d0f4956e1a8316213de72f45ac25f667a99a7f5069d0f5e7fdb9b2e7d756d63b	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1137	knowledge/ratchets/5-80.md	component	5-80	it	{"id": "ratchet.5-80", "lang": "it", "slot": "ratchet", "slug": "5-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["5-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_5-80"], "reference": "https://beyblade.wiki/5-80-ratchet/", "doc_version": 1, "canonical_name": "5-80"}	d0f4956e1a8316213de72f45ac25f667a99a7f5069d0f5e7fdb9b2e7d756d63b	4	7f84633	2026-08-22 13:35:57.076988+00	\N
804	knowledge/ratchets/6-60.md	component	6-60	it	{"id": "ratchet.6-60", "lang": "it", "slot": "ratchet", "slug": "6-60", "type": "component", "status": "draft", "system": "CX", "aliases": ["6-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-60"], "reference": "https://beyblade.wiki/6-60-ratchet/", "doc_version": 1, "canonical_name": "6-60"}	96c14fb03af56fe2eddcb0e9e5b9d1f88c253d63e74a25295c5662ac8d580390	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
805	knowledge/ratchets/6-70.md	component	6-70	it	{"id": "ratchet.6-70", "lang": "it", "slot": "ratchet", "slug": "6-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["6-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-70"], "reference": "https://beyblade.wiki/6-70-ratchet/", "doc_version": 1, "canonical_name": "6-70"}	630fb1919f3f248b0978726535389afc3b39bf4fc2b2eeb7091e89d7bba7e8ae	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1139	knowledge/ratchets/6-70.md	component	6-70	it	{"id": "ratchet.6-70", "lang": "it", "slot": "ratchet", "slug": "6-70", "type": "component", "status": "draft", "system": "BX", "aliases": ["6-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-70"], "reference": "https://beyblade.wiki/6-70-ratchet/", "doc_version": 1, "canonical_name": "6-70"}	630fb1919f3f248b0978726535389afc3b39bf4fc2b2eeb7091e89d7bba7e8ae	4	7f84633	2026-08-22 13:35:57.076988+00	\N
806	knowledge/ratchets/6-80.md	component	6-80	it	{"id": "ratchet.6-80", "lang": "it", "slot": "ratchet", "slug": "6-80", "type": "component", "status": "draft", "system": "CX", "aliases": ["6-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-80"], "reference": "https://beyblade.wiki/6-80-ratchet/", "doc_version": 1, "canonical_name": "6-80"}	08e2e0d05efaa7268cfc2ea2a339156cdfcad449fc697f5fd625903fa580adc5	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1140	knowledge/ratchets/6-80.md	component	6-80	it	{"id": "ratchet.6-80", "lang": "it", "slot": "ratchet", "slug": "6-80", "type": "component", "status": "draft", "system": "CX", "aliases": ["6-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_6-80"], "reference": "https://beyblade.wiki/6-80-ratchet/", "doc_version": 1, "canonical_name": "6-80"}	08e2e0d05efaa7268cfc2ea2a339156cdfcad449fc697f5fd625903fa580adc5	4	7f84633	2026-08-22 13:35:57.076988+00	\N
807	knowledge/ratchets/7-60.md	component	7-60	it	{"id": "ratchet.7-60", "lang": "it", "slot": "ratchet", "slug": "7-60", "type": "component", "status": "draft", "system": "UX", "aliases": ["7-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_7-60"], "doc_version": 1, "canonical_name": "7-60"}	e14b3b90e26def93ab57f8bc6acedfcccceeab8ddb36dd81b56bdbd29cbf8e7a	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
808	knowledge/ratchets/7-70.md	component	7-70	it	{"id": "ratchet.7-70", "lang": "it", "slot": "ratchet", "slug": "7-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["7-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_7-70"], "doc_version": 1, "canonical_name": "7-70"}	d68a118b5388ce098e52f4f8bd2dc07246018257cddd72d1c968e6faa5e06142	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
809	knowledge/ratchets/7-80.md	component	7-80	it	{"id": "ratchet.7-80", "lang": "it", "slot": "ratchet", "slug": "7-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["7-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_7-80"], "doc_version": 1, "canonical_name": "7-80"}	443d067705cfb0b6ee35d97f8c51a26cfaac1ea36822a7392e73c9e5ed542047	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1143	knowledge/ratchets/7-80.md	component	7-80	it	{"id": "ratchet.7-80", "lang": "it", "slot": "ratchet", "slug": "7-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["7-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_7-80"], "doc_version": 1, "canonical_name": "7-80"}	443d067705cfb0b6ee35d97f8c51a26cfaac1ea36822a7392e73c9e5ed542047	3	7f84633	2026-08-22 13:35:57.076988+00	\N
810	knowledge/ratchets/9-60.md	component	9-60	it	{"id": "ratchet.9-60", "lang": "it", "slot": "ratchet", "slug": "9-60", "type": "component", "status": "draft", "system": "BX", "aliases": ["9-60"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-60"], "reference": "https://beyblade.wiki/9-60-ratchet/", "doc_version": 1, "canonical_name": "9-60"}	0f23ee0b29f3de20f280798f3e595ca4dc4c41ae98d233654ad16ed5d35b9366	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
811	knowledge/ratchets/9-65.md	component	9-65	it	{"id": "ratchet.9-65", "lang": "it", "slot": "ratchet", "slug": "9-65", "type": "component", "status": "draft", "system": "UX", "aliases": ["9-65"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-65"], "reference": "https://beyblade.wiki/9-65-ratchet/", "doc_version": 1, "canonical_name": "9-65"}	ab7e9dfccd21b7a404f69a8fde07d63d19a87d98989ebb73a6f04c8b13126def	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1145	knowledge/ratchets/9-65.md	component	9-65	it	{"id": "ratchet.9-65", "lang": "it", "slot": "ratchet", "slug": "9-65", "type": "component", "status": "draft", "system": "UX", "aliases": ["9-65"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-65"], "reference": "https://beyblade.wiki/9-65-ratchet/", "doc_version": 1, "canonical_name": "9-65"}	ab7e9dfccd21b7a404f69a8fde07d63d19a87d98989ebb73a6f04c8b13126def	4	7f84633	2026-08-22 13:35:57.076988+00	\N
812	knowledge/ratchets/9-70.md	component	9-70	it	{"id": "ratchet.9-70", "lang": "it", "slot": "ratchet", "slug": "9-70", "type": "component", "status": "draft", "system": "UX", "aliases": ["9-70"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-70"], "reference": "https://beyblade.wiki/9-70-ratchet/", "doc_version": 1, "canonical_name": "9-70"}	88080fb7919620c3230187b251fc8a576e4e5cecee734ca7fdfbacef8ab999f6	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
813	knowledge/ratchets/9-80.md	component	9-80	it	{"id": "ratchet.9-80", "lang": "it", "slot": "ratchet", "slug": "9-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["9-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-80"], "reference": "https://beyblade.wiki/9-80-ratchet/", "doc_version": 1, "canonical_name": "9-80"}	faaccac5077a5090d0a177e77ea8fedc614210aecfe20aa627d78e9ef4e4477a	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1147	knowledge/ratchets/9-80.md	component	9-80	it	{"id": "ratchet.9-80", "lang": "it", "slot": "ratchet", "slug": "9-80", "type": "component", "status": "draft", "system": "BX", "aliases": ["9-80"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_9-80"], "reference": "https://beyblade.wiki/9-80-ratchet/", "doc_version": 1, "canonical_name": "9-80"}	faaccac5077a5090d0a177e77ea8fedc614210aecfe20aa627d78e9ef4e4477a	4	7f84633	2026-08-22 13:35:57.076988+00	\N
814	knowledge/ratchets/m-85.md	component	m-85	it	{"id": "ratchet.m-85", "lang": "it", "slot": "ratchet", "slug": "m-85", "type": "component", "status": "draft", "system": "BX", "aliases": ["M-85"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_M-85"], "reference": "https://beyblade.wiki/m-85-ratchet/", "doc_version": 1, "canonical_name": "M-85"}	6fe045b752aa69545e069ae74ef3e72d5aa57d6698d71a47275400b80036a739	3	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1148	knowledge/ratchets/m-85.md	component	m-85	it	{"id": "ratchet.m-85", "lang": "it", "slot": "ratchet", "slug": "m-85", "type": "component", "status": "draft", "system": "BX", "aliases": ["M-85"], "sources": ["https://beyblade.fandom.com/wiki/Ratchet_-_M-85"], "reference": "https://beyblade.wiki/m-85-ratchet/", "doc_version": 1, "canonical_name": "M-85"}	6fe045b752aa69545e069ae74ef3e72d5aa57d6698d71a47275400b80036a739	4	7f84633	2026-08-22 13:35:57.076988+00	\N
815	knowledge/regole/identita-combo.md	rule	\N	it	{"id": "rule.identita-combo", "lang": "it", "type": "rule", "status": "ok", "sources": ["decisione di modellazione del progetto, 2026-08-21"], "doc_version": 1}	635b101235de981d61a5cdb4476de474bf3e4465ee252c8f02729c09a7121b6d	2	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 13:35:57.076988+00
1149	knowledge/regole/identita-combo.md	rule	\N	it	{"id": "rule.identita-combo", "lang": "it", "type": "rule", "status": "ok", "sources": ["decisione di modellazione del progetto, 2026-08-21"], "doc_version": 1}	635b101235de981d61a5cdb4476de474bf3e4465ee252c8f02729c09a7121b6d	3	7f84633	2026-08-22 13:35:57.076988+00	\N
\.


--
-- Data for Name: kb_ingest_run; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kb_ingest_run (id, git_sha, started_at, finished_at, docs_seen, docs_changed, chunks_embedded, chunks_skipped, error) FROM stdin;
3	7f84633	2026-08-21 19:32:30.71431+00	2026-08-21 19:32:30.71431+00	171	0	0	0	\N
7	7f84633	2026-08-21 19:33:10.510075+00	2026-08-21 19:33:10.510075+00	2	2	5	0	\N
8	7f84633	2026-08-21 19:33:10.982564+00	2026-08-21 19:33:10.982564+00	2	0	0	5	\N
9	7f84633	2026-08-21 19:33:24.843786+00	2026-08-21 19:33:24.843786+00	2	1	1	4	\N
10	7f84633	2026-08-21 19:33:38.977882+00	2026-08-21 19:33:38.977882+00	2	1	1	4	\N
11	7f84633	2026-08-21 19:38:56.735876+00	2026-08-21 19:38:56.735876+00	171	0	0	0	\N
12	7f84633	2026-08-21 21:05:02.818768+00	2026-08-21 21:05:02.818768+00	172	1	5	0	\N
13	7f84633	2026-08-21 21:28:49.949694+00	2026-08-21 21:28:49.949694+00	172	22	43	5	\N
14	7f84633	2026-08-21 21:33:08.208309+00	2026-08-21 21:33:08.208309+00	172	94	138	48	\N
15	7f84633	2026-08-21 21:54:36.900683+00	2026-08-21 21:54:36.900683+00	172	48	79	186	\N
16	7f84633	2026-08-21 22:14:27.709114+00	2026-08-21 22:14:27.709114+00	172	133	447	65	\N
22	7f84633	2026-08-22 12:20:46.065136+00	2026-08-22 12:20:46.065136+00	172	167	512	0	\N
24	7f84633	2026-08-22 13:35:57.076988+00	2026-08-22 13:35:57.076988+00	172	167	513	0	\N
25	7f84633	2026-08-22 13:52:58.967619+00	2026-08-22 13:52:58.967619+00	172	50	50	500	\N
26	614daa3	2026-08-24 10:30:51.32741+00	2026-08-24 10:30:51.32741+00	171	1	1	547	\N
27	7f0d2df	2026-08-24 10:36:37.852929+00	2026-08-24 10:36:37.852929+00	170	1	1	545	\N
28	c81f259	2026-08-24 10:45:04.832593+00	2026-08-24 10:45:04.832593+00	170	0	0	544	\N
29	f5b4356	2026-08-24 10:56:07.922616+00	2026-08-24 10:56:07.922616+00	170	5	5	539	\N
\.


--
-- Data for Name: lock_chip_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lock_chip_stats (lock_chip, primi_posti, secondi_posti, terzi_posti, punteggio_totale, season, quarti_posti) FROM stdin;
valkyrie	0	0	0	0	Off Season 2025	0
emperor	1	1	0	468	Off Season 2025	0
None	29	29	57	14316	Off Season 2025	0
\.


--
-- Data for Name: meta_snapshot; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meta_snapshot (id, source, source_ref, captured_at, lock_chip, over_blade, blade, assist_blade, ratchet, "bit", points, win_count, combo_rank, rank_change, imported_at) FROM stdin;
1	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	Hexa	218	218	1	—	2026-08-22 13:50:55.165178+00
2	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-70	LowRush	83	83	2	—	2026-08-22 13:50:55.165178+00
3	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	5-60	Elevate	45	45	3	—	2026-08-22 13:50:55.165178+00
4	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-50	Rush	41	41	4	—	2026-08-22 13:50:55.165178+00
5	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-60	Rush	41	41	4	⬆️ 2	2026-08-22 13:50:55.165178+00
6	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-60	FreeBall	38	38	6	⬆️ 7	2026-08-22 13:50:55.165178+00
7	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	FreeBall	34	34	7	⬆️ 1	2026-08-22 13:50:55.165178+00
8	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	6-60	Hexa	31	31	8	⬆️ 3	2026-08-22 13:50:55.165178+00
9	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	9-60	FreeBall	31	31	8	—	2026-08-22 13:50:55.165178+00
10	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	9-60	Elevate	27	27	10	⬇️ 3	2026-08-22 13:50:55.165178+00
11	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	7-60	Level	27	27	10	⬆️ 1	2026-08-22 13:50:55.165178+00
12	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	Hexa	24	24	12	New	2026-08-22 13:50:55.165178+00
13	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	LowRush	21	21	13	⬇️ 8	2026-08-22 13:50:55.165178+00
14	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	3-60	Rush	19	19	14	⬆️ 3	2026-08-22 13:50:55.165178+00
15	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-60	Rush	18	18	15	⬆️ 4	2026-08-22 13:50:55.165178+00
16	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	Rush	18	18	15	⬇️ 1	2026-08-22 13:50:55.165178+00
17	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	FreeBall	15	15	17	⬆️ 9	2026-08-22 13:50:55.165178+00
18	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-60	LowRush	14	14	18	⬇️ 2	2026-08-22 13:50:55.165178+00
19	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	7-70	Level	14	14	18	⬆️ 2	2026-08-22 13:50:55.165178+00
20	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	3-60	LowRush	13	13	20	⬆️ 6	2026-08-22 13:50:55.165178+00
21	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-50	LowRush	12	12	21	⬇️ 11	2026-08-22 13:50:55.165178+00
22	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	9-60	Elevate	12	12	21	⬆️ 46	2026-08-22 13:50:55.165178+00
23	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	9-60	FreeBall	11	11	23	⬇️ 6	2026-08-22 13:50:55.165178+00
24	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-50	Kick	11	11	23	⬆️ 30	2026-08-22 13:50:55.165178+00
25	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-70	Kick	10	10	25	⬇️ 5	2026-08-22 13:50:55.165178+00
26	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-60	FreeBall	10	10	25	⬇️ 1	2026-08-22 13:50:55.165178+00
27	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	3-60	Rush	10	10	25	⬆️ 13	2026-08-22 13:50:55.165178+00
28	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-70	Rush	10	10	25	⬇️ 5	2026-08-22 13:50:55.165178+00
29	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	1-60	Rush	9	9	29	⬆️ 38	2026-08-22 13:50:55.165178+00
30	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-50	FreeBall	9	9	29	⬆️ 9	2026-08-22 13:50:55.165178+00
31	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	9-60	LowOrb	9	9	29	⬆️ 38	2026-08-22 13:50:55.165178+00
32	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	9-60	Hexa	8	8	32	⬆️ 73	2026-08-22 13:50:55.165178+00
33	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	9-60	LowRush	8	8	32	⬆️ 6	2026-08-22 13:50:55.165178+00
34	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	Kick	8	8	32	⬆️ 21	2026-08-22 13:50:55.165178+00
35	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-50	Rush	8	8	32	⬇️ 12	2026-08-22 13:50:55.165178+00
36	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-70	Rush	8	8	32	⬆️ 6	2026-08-22 13:50:55.165178+00
37	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-60	Kick	8	8	32	⬆️ 35	2026-08-22 13:50:55.165178+00
38	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-70	LowRush	8	8	32	⬇️ 6	2026-08-22 13:50:55.165178+00
39	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-60	Kick	8	8	32	⬆️ 35	2026-08-22 13:50:55.165178+00
40	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-50	LowRush	8	8	32	⬆️ 21	2026-08-22 13:50:55.165178+00
41	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	9-60	FreeBall	8	8	32	⬆️ 73	2026-08-22 13:50:55.165178+00
42	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-70	FreeBall	8	8	32	⬆️ 139	2026-08-22 13:50:55.165178+00
43	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	Kick	7	7	43	⬆️ 24	2026-08-22 13:50:55.165178+00
44	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	1-60	LowRush	7	7	43	⬆️ 62	2026-08-22 13:50:55.165178+00
45	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-80	Rush	7	7	43	⬆️ 62	2026-08-22 13:50:55.165178+00
46	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-70	Kick	7	7	43	⬆️ 62	2026-08-22 13:50:55.165178+00
47	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	4-50	LowRush	6	6	47	⬇️ 14	2026-08-22 13:50:55.165178+00
48	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	Taper	6	6	47	⬆️ 6	2026-08-22 13:50:55.165178+00
49	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-50	Level	6	6	47	⬆️ 58	2026-08-22 13:50:55.165178+00
50	google-sheet	gid=1662183816	2026-08-21	\N	\N	ClockMirage	\N	4-55	LowOrb	6	6	47	⬇️ 21	2026-08-22 13:50:55.165178+00
51	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-60	LowRush	6	6	47	⬆️ 124	2026-08-22 13:50:55.165178+00
52	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	7-60	Rush	6	6	47	⬇️ 32	2026-08-22 13:50:55.165178+00
53	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	3-60	LowRush	6	6	47	⬇️ 9	2026-08-22 13:50:55.165178+00
54	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-60	LowOrb	6	6	47	⬇️ 9	2026-08-22 13:50:55.165178+00
55	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	Merge	6	6	47	New	2026-08-22 13:50:55.165178+00
56	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	Ball	5	5	56	⬇️ 18	2026-08-22 13:50:55.165178+00
57	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	9-60	Ball	5	5	56	⬇️ 18	2026-08-22 13:50:55.165178+00
58	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-70	Hexa	5	5	56	⬇️ 23	2026-08-22 13:50:55.165178+00
59	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	LowOrb	5	5	56	New	2026-08-22 13:50:55.165178+00
60	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	7-60	Rush	5	5	56	⬇️ 3	2026-08-22 13:50:55.165178+00
61	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-50	Kick	5	5	56	⬇️ 23	2026-08-22 13:50:55.165178+00
62	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	Level	5	5	56	⬇️ 18	2026-08-22 13:50:55.165178+00
63	google-sheet	gid=1662183816	2026-08-21	\N	\N	ClockMirage	\N	7-55	LowOrb	5	5	56	⬇️ 30	2026-08-22 13:50:55.165178+00
64	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	1-60	Elevate	5	5	56	⬇️ 18	2026-08-22 13:50:55.165178+00
65	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	9-60	Kick	5	5	56	⬇️ 3	2026-08-22 13:50:55.165178+00
66	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	9-60	Rush	5	5	56	⬇️ 18	2026-08-22 13:50:55.165178+00
67	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	9-60	Level	5	5	56	⬆️ 115	2026-08-22 13:50:55.165178+00
68	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-60	Ball	5	5	56	⬆️ 11	2026-08-22 13:50:55.165178+00
69	google-sheet	gid=1662183816	2026-08-21	Plastic	Peak	Delta	Heavy	3-60	Kick	5	5	56	New	2026-08-22 13:50:55.165178+00
70	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	7-60	Hexa	4	4	70	⬇️ 44	2026-08-22 13:50:55.165178+00
71	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	Unite	4	4	70	⬇️ 3	2026-08-22 13:50:55.165178+00
72	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	7-60	Level	4	4	70	⬆️ 101	2026-08-22 13:50:55.165178+00
73	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-70	FreeBall	4	4	70	⬇️ 32	2026-08-22 13:50:55.165178+00
74	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-70	Jolt	4	4	70	⬆️ 101	2026-08-22 13:50:55.165178+00
75	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	7-60	LowRush	4	4	70	⬇️ 17	2026-08-22 13:50:55.165178+00
76	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	9-60	Rush	4	4	70	⬇️ 32	2026-08-22 13:50:55.165178+00
77	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	1-60	LowRush	4	4	70	New	2026-08-22 13:50:55.165178+00
78	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	5-60	Rush	4	4	70	New	2026-08-22 13:50:55.165178+00
79	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	3-60	Kick	4	4	70	⬇️ 3	2026-08-22 13:50:55.165178+00
80	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	7-60	Kick	4	4	70	⬆️ 101	2026-08-22 13:50:55.165178+00
81	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	1-60	Hexa	4	4	70	⬇️ 3	2026-08-22 13:50:55.165178+00
82	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-60	Orb	4	4	70	New	2026-08-22 13:50:55.165178+00
83	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	9-60	LowRush	4	4	70	⬇️ 3	2026-08-22 13:50:55.165178+00
84	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	Unite	4	4	70	New	2026-08-22 13:50:55.165178+00
85	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	Jolt	4	4	70	New	2026-08-22 13:50:55.165178+00
86	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	9-60	Wedge	3	3	86	⬇️ 19	2026-08-22 13:50:55.165178+00
87	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-80	Hexa	3	3	86	⬆️ 85	2026-08-22 13:50:55.165178+00
88	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	3-60	Hexa	3	3	86	⬇️ 48	2026-08-22 13:50:55.165178+00
89	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	Rush	3	3	86	⬆️ 19	2026-08-22 13:50:55.165178+00
90	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	3-60	Kick	3	3	86	⬇️ 19	2026-08-22 13:50:55.165178+00
91	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	1-50	Rush	3	3	86	⬇️ 53	2026-08-22 13:50:55.165178+00
92	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	6-60	LowRush	3	3	86	New	2026-08-22 13:50:55.165178+00
93	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-50	Jolt	3	3	86	⬇️ 33	2026-08-22 13:50:55.165178+00
94	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-70	LowRush	3	3	86	⬆️ 85	2026-08-22 13:50:55.165178+00
95	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	9-60	Kick	3	3	86	⬇️ 19	2026-08-22 13:50:55.165178+00
96	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	5-60	LowRush	3	3	86	⬆️ 85	2026-08-22 13:50:55.165178+00
97	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-70	LowOrb	3	3	86	⬆️ 85	2026-08-22 13:50:55.165178+00
98	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	4-50	Level	3	3	86	⬆️ 19	2026-08-22 13:50:55.165178+00
99	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-60	Hexa	3	3	86	⬆️ 19	2026-08-22 13:50:55.165178+00
100	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	7-70	LowRush	3	3	86	⬇️ 33	2026-08-22 13:50:55.165178+00
101	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	9-60	Wedge	3	3	86	⬆️ 85	2026-08-22 13:50:55.165178+00
102	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	1-50	Elevate	3	3	86	⬇️ 19	2026-08-22 13:50:55.165178+00
103	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	1-60	Rush	3	3	86	⬆️ 19	2026-08-22 13:50:55.165178+00
104	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	9-60	LowRush	3	3	86	⬇️ 33	2026-08-22 13:50:55.165178+00
105	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-80	Jolt	3	3	86	New	2026-08-22 13:50:55.165178+00
106	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	6-60	Wedge	3	3	86	⬆️ 85	2026-08-22 13:50:55.165178+00
107	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	1-60	UnderNeedle	3	3	86	⬆️ 19	2026-08-22 13:50:55.165178+00
108	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	3-60	FreeBall	3	3	86	New	2026-08-22 13:50:55.165178+00
109	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-60	Wedge	3	3	86	⬇️ 19	2026-08-22 13:50:55.165178+00
110	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	7-60	Hexa	3	3	86	New	2026-08-22 13:50:55.165178+00
111	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	3-60	FreeBall	3	3	86	⬆️ 85	2026-08-22 13:50:55.165178+00
112	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	RubberAccel	3	3	86	New	2026-08-22 13:50:55.165178+00
113	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Free	9-60	FreeBall	3	3	86	New	2026-08-22 13:50:55.165178+00
114	google-sheet	gid=1662183816	2026-08-21	\N	\N	MummyCurse	\N	9-60	Wedge	3	3	86	⬆️ 85	2026-08-22 13:50:55.165178+00
115	google-sheet	gid=1662183816	2026-08-21	\N	\N	MummyCurse	\N	7-60	Wedge	3	3	86	⬆️ 85	2026-08-22 13:50:55.165178+00
116	google-sheet	gid=1662183816	2026-08-21	\N	\N	LightningL-Drago	\N	7-60	Level	3	3	86	New	2026-08-22 13:50:55.165178+00
117	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-50	Hexa	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
118	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	3-60	Ball	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
119	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	5-60	Hexa	2	2	117	New	2026-08-22 13:50:55.165178+00
120	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	Point	2	2	117	New	2026-08-22 13:50:55.165178+00
121	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	9-60	LowOrb	2	2	117	⬇️ 64	2026-08-22 13:50:55.165178+00
122	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	Jolt	2	2	117	New	2026-08-22 13:50:55.165178+00
123	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	Wedge	2	2	117	⬇️ 50	2026-08-22 13:50:55.165178+00
124	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	5-60	FreeBall	2	2	117	New	2026-08-22 13:50:55.165178+00
125	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	3-60	FreeBall	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
126	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	9-60	FreeBall	2	2	117	New	2026-08-22 13:50:55.165178+00
127	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	7-60	LowRush	2	2	117	⬇️ 50	2026-08-22 13:50:55.165178+00
128	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	9-60	LowRush	2	2	117	⬇️ 12	2026-08-22 13:50:55.165178+00
129	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	9-60	Rush	2	2	117	⬇️ 50	2026-08-22 13:50:55.165178+00
130	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-60	Level	2	2	117	New	2026-08-22 13:50:55.165178+00
131	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	9-60	Jolt	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
132	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	4-50	Rush	2	2	117	New	2026-08-22 13:50:55.165178+00
133	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	Jolt	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
134	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-60	Taper	2	2	117	New	2026-08-22 13:50:55.165178+00
135	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	Orb	2	2	117	New	2026-08-22 13:50:55.165178+00
136	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	LowOrb	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
137	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-70	Level	2	2	117	⬇️ 50	2026-08-22 13:50:55.165178+00
138	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	7-60	Rush	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
139	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	4-50	Kick	2	2	117	⬇️ 50	2026-08-22 13:50:55.165178+00
140	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	Point	2	2	117	New	2026-08-22 13:50:55.165178+00
141	google-sheet	gid=1662183816	2026-08-21	\N	\N	ClockMirage	\N	4-55	UnderNeedle	2	2	117	⬇️ 50	2026-08-22 13:50:55.165178+00
142	google-sheet	gid=1662183816	2026-08-21	\N	\N	ClockMirage	\N	7-55	FreeBall	2	2	117	⬇️ 79	2026-08-22 13:50:55.165178+00
143	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	7-60	Yielding	2	2	117	New	2026-08-22 13:50:55.165178+00
144	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	5-70	Elevate	2	2	117	New	2026-08-22 13:50:55.165178+00
145	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	1-50	Zap	2	2	117	New	2026-08-22 13:50:55.165178+00
146	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	5-60	Level	2	2	117	New	2026-08-22 13:50:55.165178+00
147	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	9-60	Point	2	2	117	New	2026-08-22 13:50:55.165178+00
148	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	1-60	Rush	2	2	117	New	2026-08-22 13:50:55.165178+00
149	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	1-70	Kick	2	2	117	⬇️ 50	2026-08-22 13:50:55.165178+00
150	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	1-70	LowRush	2	2	117	New	2026-08-22 13:50:55.165178+00
151	google-sheet	gid=1662183816	2026-08-21	\N	\N	ImpactDrake	\N	1-60	Level	2	2	117	New	2026-08-22 13:50:55.165178+00
152	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-60	Level	2	2	117	⬇️ 91	2026-08-22 13:50:55.165178+00
153	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	9-60	FreeBall	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
154	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-50	Taper	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
155	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	3-60	Jolt	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
156	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-60	Hexa	2	2	117	New	2026-08-22 13:50:55.165178+00
157	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	9-60	Point	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
158	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	7-60	Jolt	2	2	117	New	2026-08-22 13:50:55.165178+00
159	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	9-60	LowOrb	2	2	117	New	2026-08-22 13:50:55.165178+00
160	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	9-60	Hexa	2	2	117	New	2026-08-22 13:50:55.165178+00
161	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	3-60	FreeBall	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
162	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	1-60	Rush	2	2	117	New	2026-08-22 13:50:55.165178+00
163	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	9-60	Wedge	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
164	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	7-60	LowRush	2	2	117	New	2026-08-22 13:50:55.165178+00
165	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	5-70	Level	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
166	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	1-60	Level	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
167	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-80	FreeBall	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
168	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	7-60	FreeBall	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
169	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-70	Wedge	2	2	117	⬇️ 12	2026-08-22 13:50:55.165178+00
170	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	9-60	Hexa	2	2	117	New	2026-08-22 13:50:55.165178+00
171	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	9-60	FreeBall	2	2	117	⬇️ 50	2026-08-22 13:50:55.165178+00
172	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	3-60	Kick	2	2	117	New	2026-08-22 13:50:55.165178+00
173	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	7-60	Rush	2	2	117	⬇️ 12	2026-08-22 13:50:55.165178+00
174	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	9-60	Rush	2	2	117	⬇️ 50	2026-08-22 13:50:55.165178+00
175	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	1-50	Level	2	2	117	New	2026-08-22 13:50:55.165178+00
176	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	9-60	Kick	2	2	117	⬇️ 93	2026-08-22 13:50:55.165178+00
177	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Wheel	9-60	Level	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
178	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	Point	2	2	117	New	2026-08-22 13:50:55.165178+00
179	google-sheet	gid=1662183816	2026-08-21	Metal	Break	Blitz	Heavy	1-50	LowRush	2	2	117	⬇️ 12	2026-08-22 13:50:55.165178+00
180	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Heavy	3-60	Kick	2	2	117	New	2026-08-22 13:50:55.165178+00
181	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Heavy	1-50	LowRush	2	2	117	⬇️ 50	2026-08-22 13:50:55.165178+00
182	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Heavy	1-50	Kick	2	2	117	New	2026-08-22 13:50:55.165178+00
183	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Heavy	9-60	Kick	2	2	117	⬇️ 50	2026-08-22 13:50:55.165178+00
184	google-sheet	gid=1662183816	2026-08-21	\N	\N	WeissTiger	\N	6-60	Kick	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
185	google-sheet	gid=1662183816	2026-08-21	Plastic	Guard	Fortress	Wheel	9-60	Hexa	2	2	117	New	2026-08-22 13:50:55.165178+00
186	google-sheet	gid=1662183816	2026-08-21	\N	\N	MummyCurse	\N	1-60	Wedge	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
187	google-sheet	gid=1662183816	2026-08-21	\N	\N	MummyCurse	\N	1-50	Hexa	2	2	117	New	2026-08-22 13:50:55.165178+00
188	google-sheet	gid=1662183816	2026-08-21	\N	\N	HoverWyvern	\N	1-60	Rush	2	2	117	New	2026-08-22 13:50:55.165178+00
189	google-sheet	gid=1662183816	2026-08-21	\N	\N	HoverWyvern	\N	9-60	Kick	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
190	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightShield	\N	1-60	UnderNeedle	2	2	117	New	2026-08-22 13:50:55.165178+00
191	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightShield	\N	7-60	Elevate	2	2	117	New	2026-08-22 13:50:55.165178+00
192	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsScythe	\N	9-60	FreeBall	2	2	117	⬆️ 54	2026-08-22 13:50:55.165178+00
193	google-sheet	gid=1662183816	2026-08-21	\N	\N	UnicornSting	\N	9-60	Point	2	2	117	New	2026-08-22 13:50:55.165178+00
194	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranDagger	\N	3-60	LowRush	2	2	117	New	2026-08-22 13:50:55.165178+00
195	google-sheet	gid=1662183816	2026-08-21	\N	\N	CrimsonGaruda	\N	7-60	Kick	2	2	117	New	2026-08-22 13:50:55.165178+00
196	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiCalibur	\N	9-60	Ball	2	2	117	New	2026-08-22 13:50:55.165178+00
197	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightMail	\N	9-60	LowRush	2	2	117	New	2026-08-22 13:50:55.165178+00
198	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightMail	\N	1-50	Ignition	2	2	117	New	2026-08-22 13:50:55.165178+00
199	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsHammer	\N	9-60	Point	2	2	117	New	2026-08-22 13:50:55.165178+00
200	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightLance	\N	9-60	LowOrb	2	2	117	New	2026-08-22 13:50:55.165178+00
201	google-sheet	gid=1662183816	2026-08-21	\N	\N	GhostCircle	\N	9-60	Ball	2	2	117	New	2026-08-22 13:50:55.165178+00
202	google-sheet	gid=1662183816	2026-08-21	Plastic	Peak	Delta	Heavy	3-60	LowRush	2	2	117	New	2026-08-22 13:50:55.165178+00
203	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranStrike	\N	9-60	Kick	2	2	117	New	2026-08-22 13:50:55.165178+00
204	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	7-60	LowRush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
205	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-50	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
206	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-70	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
207	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	Orb	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
208	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	HighNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
209	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	5-70	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
210	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-70	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
211	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	9-60	Orb	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
212	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	7-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
213	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	7-60	LowOrb	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
214	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	3-60	Dot	1	1	204	New	2026-08-22 13:50:55.165178+00
215	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	RubberAccel	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
216	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-60	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
217	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	9-70	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
218	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	1-70	Kick	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
219	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardRod	\N	9-70	Ball	1	1	204	New	2026-08-22 13:50:55.165178+00
220	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	5-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
221	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	9-60	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
222	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	1-60	GearRush	1	1	204	New	2026-08-22 13:50:55.165178+00
223	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	3-60	Flat	1	1	204	New	2026-08-22 13:50:55.165178+00
224	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	3-60	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
225	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	9-70	WallBall	1	1	204	New	2026-08-22 13:50:55.165178+00
226	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	1-50	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
227	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	9-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
228	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	2-80	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
229	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	5-80	Flat	1	1	204	New	2026-08-22 13:50:55.165178+00
230	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	7-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
231	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	9-60	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
232	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	1-70	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
233	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	5-60	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
234	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	9-80	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
235	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	9-60	WallBall	1	1	204	New	2026-08-22 13:50:55.165178+00
236	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	9-60	GearFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
237	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	1-60	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
238	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	1-50	Kick	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
239	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	2-70	HighTaper	1	1	204	New	2026-08-22 13:50:55.165178+00
240	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	1-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
241	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	3-70	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
242	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	3-70	Flat	1	1	204	New	2026-08-22 13:50:55.165178+00
243	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	3-60	Cyclone	1	1	204	New	2026-08-22 13:50:55.165178+00
244	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	1-80	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
245	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	4-50	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
246	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	3-60	Point	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
247	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	7-60	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
248	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	0-70	RubberAccel	1	1	204	New	2026-08-22 13:50:55.165178+00
249	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixWing	\N	1-50	LowRush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
250	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	9-70	Rush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
251	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	9-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
252	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	5-60	FreeBall	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
253	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	5-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
254	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	6-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
255	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	6-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
256	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-50	LowOrb	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
257	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-70	LowFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
258	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	4-50	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
259	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-80	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
260	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	Hexa	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
261	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-70	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
262	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-80	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
263	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	Wedge	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
264	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	9-70	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
265	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-60	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
266	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	2-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
267	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	4-55	WallBall	1	1	204	New	2026-08-22 13:50:55.165178+00
268	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-70	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
269	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	Unite	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
270	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-50	Point	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
271	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-60	LowOrb	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
272	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	4-50	Point	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
273	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	7-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
274	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	4-50	LowOrb	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
275	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	5-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
276	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	1-60	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
277	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	4-50	UnderFlat	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
278	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	5-60	Jolt	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
279	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	4-50	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
280	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	3-60	Ball	1	1	204	New	2026-08-22 13:50:55.165178+00
281	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	5-60	Level	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
282	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkScale	\N	5-70	TransKick	1	1	204	New	2026-08-22 13:50:55.165178+00
283	google-sheet	gid=1662183816	2026-08-21	\N	\N	ClockMirage	\N	4-55	Ball	1	1	204	New	2026-08-22 13:50:55.165178+00
284	google-sheet	gid=1662183816	2026-08-21	\N	\N	ClockMirage	\N	7-55	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
285	google-sheet	gid=1662183816	2026-08-21	\N	\N	ClockMirage	\N	9-65	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
286	google-sheet	gid=1662183816	2026-08-21	\N	\N	ClockMirage	\N	3-85	DiskBall	1	1	204	New	2026-08-22 13:50:55.165178+00
287	google-sheet	gid=1662183816	2026-08-21	\N	\N	ClockMirage	\N	7-55	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
288	google-sheet	gid=1662183816	2026-08-21	\N	\N	ClockMirage	\N	7-55	UnderNeedle	1	1	204	⬇️ 137	2026-08-22 13:50:55.165178+00
289	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	7-60	RubberAccel	1	1	204	New	2026-08-22 13:50:55.165178+00
290	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	9-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
291	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	5-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
292	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	4-50	Level	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
293	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	9-60	Rush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
294	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	6-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
295	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	2-70	BoundSpike	1	1	204	New	2026-08-22 13:50:55.165178+00
296	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	7-55	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
297	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	7-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
298	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	7-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
299	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	7-70	WallBall	1	1	204	New	2026-08-22 13:50:55.165178+00
300	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	7-60	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
301	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDragoon	\N	3-60	Elevate	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
302	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	1-50	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
303	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	1-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
304	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	4-50	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
305	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	5-60	LowFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
306	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	3-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
307	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	9-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
308	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	3-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
309	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	1-70	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
310	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	1-50	Ignition	1	1	204	New	2026-08-22 13:50:55.165178+00
311	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	3-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
312	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	3-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
313	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	3-70	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
314	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	3-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
315	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	7-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
316	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	9-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
317	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	9-60	GearFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
318	google-sheet	gid=1662183816	2026-08-21	\N	\N	SharkEdge	\N	1-50	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
319	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoRoar	\N	9-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
320	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoRoar	\N	3-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
321	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoRoar	\N	6-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
322	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoRoar	\N	9-60	LowFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
323	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoRoar	\N	9-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
324	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	9-70	GearPoint	1	1	204	New	2026-08-22 13:50:55.165178+00
325	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	1-50	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
326	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	7-70	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
327	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	7-70	Kick	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
328	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	7-70	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
329	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	9-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
330	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	9-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
331	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	9-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
332	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	7-60	Rush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
333	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	3-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
334	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	9-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
335	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	9-70	Rush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
336	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	5-60	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
337	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	1-70	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
338	google-sheet	gid=1662183816	2026-08-21	\N	\N	TyrannoBeat	\N	2-70	Needle	1	1	204	New	2026-08-22 13:50:55.165178+00
339	google-sheet	gid=1662183816	2026-08-21	\N	\N	WhaleWave	\N	1-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
340	google-sheet	gid=1662183816	2026-08-21	\N	\N	WhaleWave	\N	1-80	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
341	google-sheet	gid=1662183816	2026-08-21	\N	\N	WhaleWave	\N	5-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
342	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDrake	\N	9-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
343	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDrake	\N	3-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
344	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDrake	\N	9-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
345	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDrake	\N	9-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
346	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDrake	\N	5-60	LowFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
347	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDrake	\N	1-60	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
348	google-sheet	gid=1662183816	2026-08-21	\N	\N	CobaltDrake	\N	1-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
349	google-sheet	gid=1662183816	2026-08-21	\N	\N	ImpactDrake	\N	7-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
350	google-sheet	gid=1662183816	2026-08-21	\N	\N	ImpactDrake	\N	1-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
351	google-sheet	gid=1662183816	2026-08-21	\N	\N	ImpactDrake	\N	1-50	RubberAccel	1	1	204	New	2026-08-22 13:50:55.165178+00
352	google-sheet	gid=1662183816	2026-08-21	\N	\N	ImpactDrake	\N	7-70	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
353	google-sheet	gid=1662183816	2026-08-21	\N	\N	ImpactDrake	\N	3-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
354	google-sheet	gid=1662183816	2026-08-21	\N	\N	ImpactDrake	\N	6-60	TransPoint	1	1	204	New	2026-08-22 13:50:55.165178+00
355	google-sheet	gid=1662183816	2026-08-21	\N	\N	ImpactDrake	\N	1-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
356	google-sheet	gid=1662183816	2026-08-21	\N	\N	ImpactDrake	\N	5-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
357	google-sheet	gid=1662183816	2026-08-21	\N	\N	ImpactDrake	\N	7-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
358	google-sheet	gid=1662183816	2026-08-21	\N	\N	ImpactDrake	\N	1-60	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
359	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	3-60	Unite	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
360	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-50	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
361	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	3-70	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
362	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	7-70	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
363	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	7-60	LowRush	1	1	204	⬇️ 137	2026-08-22 13:50:55.165178+00
364	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	3-70	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
365	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-70	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
366	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-50	RubberAccel	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
367	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	9-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
368	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	7-60	Level	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
369	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-50	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
370	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-70	Level	1	1	204	⬇️ 151	2026-08-22 13:50:55.165178+00
371	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	3-60	LowFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
372	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	7-60	Point	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
373	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	3-60	Level	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
374	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-60	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
375	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
376	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-70	Point	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
377	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	3-70	Accel	1	1	204	New	2026-08-22 13:50:55.165178+00
378	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	9-60	Flat	1	1	204	New	2026-08-22 13:50:55.165178+00
379	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-70	FreeFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
380	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	9-70	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
381	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-60	Point	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
382	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	9-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
383	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	3-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
384	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	9-60	Taper	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
385	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	9-70	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
386	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	3-60	FreeFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
387	google-sheet	gid=1662183816	2026-08-21	\N	\N	AeroPegasus	\N	1-50	LowFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
388	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	1-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
389	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	7-60	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
390	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	9-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
391	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	1-50	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
392	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	7-60	LowRush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
393	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	3-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
394	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	9-60	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
395	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	0-80	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
396	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	1-50	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
397	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	9-60	BoundSpike	1	1	204	New	2026-08-22 13:50:55.165178+00
398	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	5-70	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
399	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	7-80	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
400	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	6-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
401	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	1-50	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
402	google-sheet	gid=1662183816	2026-08-21	\N	\N	GolemRock	\N	7-60	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
403	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	8-70	Level	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
404	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	7-70	Zap	1	1	204	New	2026-08-22 13:50:55.165178+00
405	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	1-50	LowRush	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
406	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	1-50	Level	1	1	204	⬇️ 137	2026-08-22 13:50:55.165178+00
407	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	3-60	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
408	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	9-60	Level	1	1	204	⬇️ 151	2026-08-22 13:50:55.165178+00
409	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	3-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
410	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	1-70	Level	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
411	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	3-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
412	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	5-60	Elevate	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
413	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	6-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
414	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	9-70	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
415	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	4-70	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
416	google-sheet	gid=1662183816	2026-08-21	\N	\N	MeteorDragoon	\N	7-60	Ignition	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
417	google-sheet	gid=1662183816	2026-08-21	Plastic	Break	Blitz	Heavy	1-50	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
418	google-sheet	gid=1662183816	2026-08-21	Plastic	Break	Blitz	Heavy	5-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
419	google-sheet	gid=1662183816	2026-08-21	Plastic	Break	Blitz	Heavy	1-60	LowRush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
420	google-sheet	gid=1662183816	2026-08-21	Plastic	Break	Blitz	Heavy	9-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
421	google-sheet	gid=1662183816	2026-08-21	Plastic	Break	Blitz	Jaggy	4-50	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
422	google-sheet	gid=1662183816	2026-08-21	Plastic	Break	Blitz	Jaggy	1-50	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
423	google-sheet	gid=1662183816	2026-08-21	Plastic	Break	Blitz	Knuckle	1-50	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
424	google-sheet	gid=1662183816	2026-08-21	Plastic	Break	Blitz	Knuckle	5-60	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
425	google-sheet	gid=1662183816	2026-08-21	Plastic	Break	Blitz	Wheel	5-60	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
426	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	3-80	FreeBall	1	1	204	⬇️ 151	2026-08-22 13:50:55.165178+00
427	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-70	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
428	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-70	Orb	1	1	204	New	2026-08-22 13:50:55.165178+00
429	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-60	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
430	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	1-60	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
431	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	3-60	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
432	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	3-70	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
433	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	8-70	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
434	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-70	Ball	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
435	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	6-70	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
436	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	1-70	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
437	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	3-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
438	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-60	Hexa	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
439	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	3-80	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
440	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	4-80	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
441	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	1-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
442	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	9-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
443	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	6-70	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
444	google-sheet	gid=1662183816	2026-08-21	\N	\N	SilverWolf	\N	1-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
445	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	1-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
446	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	3-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
447	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	3-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
448	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	6-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
449	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	3-60	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
450	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	1-50	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
451	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	9-60	Yielding	1	1	204	New	2026-08-22 13:50:55.165178+00
452	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	3-60	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
453	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	9-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
454	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	7-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
455	google-sheet	gid=1662183816	2026-08-21	\N	\N	ScorpioSpear	\N	9-60	Kick	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
456	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	1-60	Kick	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
457	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	6-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
458	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	1-50	Kick	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
459	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	9-60	Hexa	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
460	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	5-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
461	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	1-50	LowFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
462	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	4-50	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
463	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	3-60	LowRush	1	1	204	⬇️ 137	2026-08-22 13:50:55.165178+00
464	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	9-60	Level	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
465	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Heavy	1-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
466	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Wheel	7-70	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
467	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Wheel	9-70	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
468	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Wheel	9-60	Zap	1	1	204	New	2026-08-22 13:50:55.165178+00
469	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Wheel	9-60	Hexa	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
470	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Free	9-70	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
471	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Blast	Slash	8-70	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
472	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Hunt	Wheel	9-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
473	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Hunt	Wheel	1-70	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
474	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Hunt	Heavy	3-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
475	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Kraken	Slash	3-85	Orb	1	1	204	New	2026-08-22 13:50:55.165178+00
476	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Kraken	Heavy	1-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
477	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	WallBall	1	1	204	New	2026-08-22 13:50:55.165178+00
478	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	TransKick	1	1	204	New	2026-08-22 13:50:55.165178+00
479	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	DiskBall	1	1	204	New	2026-08-22 13:50:55.165178+00
480	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
481	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	Ball	1	1	204	New	2026-08-22 13:50:55.165178+00
482	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
483	google-sheet	gid=1662183816	2026-08-21	\N	\N	BulletGriffon	\N	\N	GearPoint	1	1	204	New	2026-08-22 13:50:55.165178+00
484	google-sheet	gid=1662183816	2026-08-21	Metal	Break	Blitz	Heavy	1-50	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
485	google-sheet	gid=1662183816	2026-08-21	Metal	Break	Blitz	Heavy	1-50	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
486	google-sheet	gid=1662183816	2026-08-21	Metal	Break	Blitz	Heavy	1-50	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
487	google-sheet	gid=1662183816	2026-08-21	Metal	Break	Blitz	Knuckle	1-50	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
488	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Heavy	9-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
489	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Heavy	3-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
490	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Heavy	1-50	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
491	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Heavy	1-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
492	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Heavy	1-60	Orb	1	1	204	New	2026-08-22 13:50:55.165178+00
493	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Heavy	9-60	Taper	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
494	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Heavy	9-60	LowRush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
495	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Heavy	1-50	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
496	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Wheel	9-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
497	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Wheel	9-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
498	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Wheel	9-60	Yielding	1	1	204	New	2026-08-22 13:50:55.165178+00
499	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Free	7-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
500	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Blast	Odd	1-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
501	google-sheet	gid=1662183816	2026-08-21	\N	\N	WeissTiger	\N	9-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
502	google-sheet	gid=1662183816	2026-08-21	\N	\N	WeissTiger	\N	3-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
503	google-sheet	gid=1662183816	2026-08-21	\N	\N	WeissTiger	\N	9-60	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
504	google-sheet	gid=1662183816	2026-08-21	\N	\N	WeissTiger	\N	6-70	TransPoint	1	1	204	New	2026-08-22 13:50:55.165178+00
505	google-sheet	gid=1662183816	2026-08-21	Plastic	Guard	Fortress	Slash	3-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
506	google-sheet	gid=1662183816	2026-08-21	Plastic	Guard	Fortress	Wheel	7-60	Rush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
507	google-sheet	gid=1662183816	2026-08-21	Plastic	Guard	Fortress	Heavy	1-70	DiskBall	1	1	204	New	2026-08-22 13:50:55.165178+00
508	google-sheet	gid=1662183816	2026-08-21	Plastic	Guard	Fortress	Heavy	1-60	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
509	google-sheet	gid=1662183816	2026-08-21	Plastic	Guard	Fortress	Vertical	8-70	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
510	google-sheet	gid=1662183816	2026-08-21	\N	\N	MummyCurse	\N	3-60	Hexa	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
511	google-sheet	gid=1662183816	2026-08-21	\N	\N	MummyCurse	\N	1-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
512	google-sheet	gid=1662183816	2026-08-21	\N	\N	MummyCurse	\N	1-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
513	google-sheet	gid=1662183816	2026-08-21	\N	\N	MummyCurse	\N	9-60	Yielding	1	1	204	New	2026-08-22 13:50:55.165178+00
514	google-sheet	gid=1662183816	2026-08-21	\N	\N	MummyCurse	\N	1-60	LowOrb	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
515	google-sheet	gid=1662183816	2026-08-21	\N	\N	MummyCurse	\N	1-60	Hexa	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
516	google-sheet	gid=1662183816	2026-08-21	\N	\N	MummyCurse	\N	9-70	Ball	1	1	204	New	2026-08-22 13:50:55.165178+00
517	google-sheet	gid=1662183816	2026-08-21	\N	\N	MummyCurse	\N	7-70	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
518	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Brave	Heavy	7-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
519	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Brave	Heavy	9-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
520	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Flare	Heavy	1-50	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
521	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Flare	Heavy	3-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
522	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Flare	Wheel	7-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
523	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Flare	Wheel	9-60	LowFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
524	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Flare	Wheel	7-60	Kick	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
525	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Flare	Wheel	9-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
526	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Flare	Jaggy	1-80	UnderFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
527	google-sheet	gid=1662183816	2026-08-21	\N	\N	HoverWyvern	\N	3-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
528	google-sheet	gid=1662183816	2026-08-21	\N	\N	HoverWyvern	\N	9-60	Jolt	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
529	google-sheet	gid=1662183816	2026-08-21	\N	\N	HoverWyvern	\N	7-70	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
530	google-sheet	gid=1662183816	2026-08-21	\N	\N	HoverWyvern	\N	3-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
531	google-sheet	gid=1662183816	2026-08-21	\N	\N	HoverWyvern	\N	9-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
532	google-sheet	gid=1662183816	2026-08-21	\N	\N	HoverWyvern	\N	8-70	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
533	google-sheet	gid=1662183816	2026-08-21	\N	\N	HoverWyvern	\N	9-60	WallBall	1	1	204	New	2026-08-22 13:50:55.165178+00
534	google-sheet	gid=1662183816	2026-08-21	\N	\N	HoverWyvern	\N	3-60	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
535	google-sheet	gid=1662183816	2026-08-21	\N	\N	HoverWyvern	\N	3-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
536	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Arc	Zillion	3-70	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
537	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Arc	Free	9-70	Orb	1	1	204	New	2026-08-22 13:50:55.165178+00
538	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Arc	Round	3-60	Ball	1	1	204	New	2026-08-22 13:50:55.165178+00
539	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Might	Free	5-80	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
540	google-sheet	gid=1662183816	2026-08-21	Metal	Flow	Rage	Erase	3-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
541	google-sheet	gid=1662183816	2026-08-21	Metal	Flow	Rage	Heavy	7-70	LowRush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
542	google-sheet	gid=1662183816	2026-08-21	Metal	Flow	Rage	Heavy	9-60	Kick	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
543	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Brush	Jaggy	1-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
544	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Brush	Jaggy	4-50	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
545	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Brush	Slash	1-50	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
546	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Brush	Heavy	1-50	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
547	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Brave	Slash	9-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
548	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Brave	Jaggy	1-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
549	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Brave	Charge	9-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
550	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Dark	Bumper	7-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
551	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Dark	Slash	9-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
552	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightShield	\N	3-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
553	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightShield	\N	7-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
554	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightShield	\N	1-50	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
555	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightShield	\N	3-60	HighTaper	1	1	204	New	2026-08-22 13:50:55.165178+00
556	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightShield	\N	2-70	Orb	1	1	204	New	2026-08-22 13:50:55.165178+00
557	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightShield	\N	1-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
558	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightShield	\N	5-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
559	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightShield	\N	1-60	Wedge	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
560	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightShield	\N	3-60	Yielding	1	1	204	New	2026-08-22 13:50:55.165178+00
561	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightShield	\N	7-70	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
562	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsScythe	\N	9-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
563	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsScythe	\N	9-60	Ball	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
564	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsScythe	\N	1-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
565	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsScythe	\N	1-50	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
566	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsScythe	\N	7-80	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
567	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsScythe	\N	5-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
568	google-sheet	gid=1662183816	2026-08-21	\N	\N	UnicornSting	\N	9-60	FreeBall	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
569	google-sheet	gid=1662183816	2026-08-21	\N	\N	UnicornSting	\N	7-70	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
570	google-sheet	gid=1662183816	2026-08-21	\N	\N	UnicornSting	\N	6-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
571	google-sheet	gid=1662183816	2026-08-21	\N	\N	UnicornSting	\N	3-60	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
572	google-sheet	gid=1662183816	2026-08-21	\N	\N	UnicornSting	\N	6-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
573	google-sheet	gid=1662183816	2026-08-21	\N	\N	UnicornSting	\N	0-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
574	google-sheet	gid=1662183816	2026-08-21	\N	\N	UnicornSting	\N	9-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
575	google-sheet	gid=1662183816	2026-08-21	\N	\N	UnicornSting	\N	1-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
576	google-sheet	gid=1662183816	2026-08-21	\N	\N	OptimusPrimal	\N	1-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
577	google-sheet	gid=1662183816	2026-08-21	\N	\N	OptimusPrimal	\N	1-50	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
578	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranDagger	\N	1-50	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
579	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranDagger	\N	4-60	Rush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
580	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranDagger	\N	1-50	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
581	google-sheet	gid=1662183816	2026-08-21	\N	\N	CrimsonGaruda	\N	9-60	Level	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
582	google-sheet	gid=1662183816	2026-08-21	\N	\N	CrimsonGaruda	\N	5-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
583	google-sheet	gid=1662183816	2026-08-21	\N	\N	CrimsonGaruda	\N	3-60	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
584	google-sheet	gid=1662183816	2026-08-21	\N	\N	CrimsonGaruda	\N	7-80	GearUnite	1	1	204	New	2026-08-22 13:50:55.165178+00
585	google-sheet	gid=1662183816	2026-08-21	\N	\N	CrimsonGaruda	\N	4-55	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
586	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiCalibur	\N	3-60	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
587	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiCalibur	\N	4-50	UnderFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
588	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiCalibur	\N	9-60	Level	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
589	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiCalibur	\N	1-60	WallBall	1	1	204	New	2026-08-22 13:50:55.165178+00
590	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiCalibur	\N	9-70	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
591	google-sheet	gid=1662183816	2026-08-21	\N	\N	ShinobiShadow	\N	7-60	LowFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
592	google-sheet	gid=1662183816	2026-08-21	\N	\N	ShinobiShadow	\N	1-50	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
593	google-sheet	gid=1662183816	2026-08-21	Plastic	Flow	Rage	Heavy	3-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
594	google-sheet	gid=1662183816	2026-08-21	Plastic	Flow	Rage	Heavy	7-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
595	google-sheet	gid=1662183816	2026-08-21	Plastic	Flow	Rage	Heavy	6-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
596	google-sheet	gid=1662183816	2026-08-21	Plastic	Flow	Rage	Heavy	4-50	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
597	google-sheet	gid=1662183816	2026-08-21	Plastic	Flow	Rage	Heavy	3-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
598	google-sheet	gid=1662183816	2026-08-21	Plastic	Flow	Rage	Heavy	1-50	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
599	google-sheet	gid=1662183816	2026-08-21	Plastic	Flow	Rage	Heavy	9-60	Kick	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
600	google-sheet	gid=1662183816	2026-08-21	Plastic	Flow	Rage	Free	6-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
601	google-sheet	gid=1662183816	2026-08-21	Plastic	Flow	Rage	Erase	4-55	Yielding	1	1	204	New	2026-08-22 13:50:55.165178+00
602	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightMail	\N	1-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
603	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightMail	\N	5-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
604	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightMail	\N	1-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
605	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightMail	\N	7-60	LowRush	1	1	204	⬇️ 99	2026-08-22 13:50:55.165178+00
606	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightMail	\N	0-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
607	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranSword	\N	9-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
608	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranSword	\N	3-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
609	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranSword	\N	3-60	Flat	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
610	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranSword	\N	3-60	GearFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
611	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranSword	\N	8-70	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
612	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsHammer	\N	7-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
613	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsHammer	\N	3-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
614	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsHammer	\N	9-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
615	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsHammer	\N	9-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
616	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsHammer	\N	9-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
617	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsHammer	\N	3-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
618	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsHammer	\N	3-80	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
619	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsHammer	\N	M-85	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
620	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsHammer	\N	7-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
621	google-sheet	gid=1662183816	2026-08-21	\N	\N	PteraSwing	\N	1-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
622	google-sheet	gid=1662183816	2026-08-21	\N	\N	PteraSwing	\N	6-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
623	google-sheet	gid=1662183816	2026-08-21	\N	\N	PteraSwing	\N	1-70	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
624	google-sheet	gid=1662183816	2026-08-21	\N	\N	HellsChain	\N	9-70	Orb	1	1	204	New	2026-08-22 13:50:55.165178+00
625	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixFeather	\N	3-60	Level	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
626	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixFeather	\N	3-70	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
627	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixFeather	\N	2-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
628	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixFeather	\N	9-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
629	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixFeather	\N	7-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
630	google-sheet	gid=1662183816	2026-08-21	\N	\N	BlackShell	\N	7-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
631	google-sheet	gid=1662183816	2026-08-21	\N	\N	BlackShell	\N	1-50	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
632	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardArrow	\N	9-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
633	google-sheet	gid=1662183816	2026-08-21	\N	\N	WizardArrow	\N	9-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
634	google-sheet	gid=1662183816	2026-08-21	\N	\N	LeonCrest	\N	9-80	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
635	google-sheet	gid=1662183816	2026-08-21	\N	\N	LeonCrest	\N	7-60	DiskBall	1	1	204	New	2026-08-22 13:50:55.165178+00
636	google-sheet	gid=1662183816	2026-08-21	\N	\N	LeonCrest	\N	3-70	Orb	1	1	204	New	2026-08-22 13:50:55.165178+00
637	google-sheet	gid=1662183816	2026-08-21	\N	\N	LeonCrest	\N	7-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
638	google-sheet	gid=1662183816	2026-08-21	\N	\N	LeonCrest	\N	3-60	Ball	1	1	204	New	2026-08-22 13:50:55.165178+00
639	google-sheet	gid=1662183816	2026-08-21	\N	\N	LeonCrest	\N	7-70	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
640	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiSaber	\N	9-60	Level	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
641	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiSaber	\N	1-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
642	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiSaber	\N	7-60	Ball	1	1	204	New	2026-08-22 13:50:55.165178+00
643	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiSaber	\N	1-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
644	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiSaber	\N	9-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
645	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiSaber	\N	9-60	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
646	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiSaber	\N	3-60	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
647	google-sheet	gid=1662183816	2026-08-21	\N	\N	SamuraiSaber	\N	6-80	Ball	1	1	204	New	2026-08-22 13:50:55.165178+00
648	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Flare	Heavy	1-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
649	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Flare	Heavy	9-60	WallWedge	1	1	204	New	2026-08-22 13:50:55.165178+00
650	google-sheet	gid=1662183816	2026-08-21	\N	\N	VictoryValkyrie	\N	1-70	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
651	google-sheet	gid=1662183816	2026-08-21	\N	\N	VictoryValkyrie	\N	3-60	GearFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
652	google-sheet	gid=1662183816	2026-08-21	\N	\N	OrochiCluster	\N	7-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
653	google-sheet	gid=1662183816	2026-08-21	\N	\N	OrochiCluster	\N	1-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
654	google-sheet	gid=1662183816	2026-08-21	\N	\N	OrochiCluster	\N	7-60	Kick	1	1	204	⬇️ 137	2026-08-22 13:50:55.165178+00
655	google-sheet	gid=1662183816	2026-08-21	\N	\N	OrochiCluster	\N	7-60	Level	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
656	google-sheet	gid=1662183816	2026-08-21	\N	\N	OrochiCluster	\N	9-60	Rush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
657	google-sheet	gid=1662183816	2026-08-21	\N	\N	TriceraPress	\N	9-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
658	google-sheet	gid=1662183816	2026-08-21	\N	\N	TriceraPress	\N	3-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
659	google-sheet	gid=1662183816	2026-08-21	\N	\N	LightningL-Drago	\N	M-85	Merge	1	1	204	New	2026-08-22 13:50:55.165178+00
660	google-sheet	gid=1662183816	2026-08-21	\N	\N	LightningL-Drago	\N	5-60	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
661	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixRudder	\N	9-60	Yielding	1	1	204	New	2026-08-22 13:50:55.165178+00
662	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixRudder	\N	4-70	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
663	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixRudder	\N	9-70	WallBall	1	1	204	New	2026-08-22 13:50:55.165178+00
664	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixRudder	\N	1-50	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
665	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixRudder	\N	9-60	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
666	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixRudder	\N	9-70	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
667	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixRudder	\N	9-70	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
668	google-sheet	gid=1662183816	2026-08-21	\N	\N	PhoenixRudder	\N	4-60	GearRush	1	1	204	New	2026-08-22 13:50:55.165178+00
669	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranBuster	\N	4-50	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
670	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranBuster	\N	4-50	LowFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
671	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranBuster	\N	1-80	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
672	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranBuster	\N	1-50	LowRush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
673	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranBuster	\N	1-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
674	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranBuster	\N	1-50	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
675	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranBuster	\N	5-60	Ignition	1	1	204	New	2026-08-22 13:50:55.165178+00
676	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranBuster	\N	3-60	LowRush	1	1	204	⬇️ 33	2026-08-22 13:50:55.165178+00
677	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranBuster	\N	3-60	Cyclone	1	1	204	New	2026-08-22 13:50:55.165178+00
678	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranBuster	\N	3-70	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
679	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightLance	\N	1-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
680	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightLance	\N	3-60	Flat	1	1	204	New	2026-08-22 13:50:55.165178+00
681	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightLance	\N	6-60	LowFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
682	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightLance	\N	6-60	WallWedge	1	1	204	New	2026-08-22 13:50:55.165178+00
683	google-sheet	gid=1662183816	2026-08-21	\N	\N	KnightLance	\N	7-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
684	google-sheet	gid=1662183816	2026-08-21	\N	\N	RedHulk	\N	7-70	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
685	google-sheet	gid=1662183816	2026-08-21	\N	\N	RedHulk	\N	7-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
686	google-sheet	gid=1662183816	2026-08-21	\N	\N	RedHulk	\N	4-50	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
687	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Reaper	Bumper	3-85	UnderNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
688	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Reaper	Turn	3-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
689	google-sheet	gid=1662183816	2026-08-21	\N	\N	RhinoHorn	\N	4-55	RubberAccel	1	1	204	New	2026-08-22 13:50:55.165178+00
690	google-sheet	gid=1662183816	2026-08-21	\N	\N	RhinoHorn	\N	1-80	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
691	google-sheet	gid=1662183816	2026-08-21	\N	\N	RhinoHorn	\N	7-70	Flat	1	1	204	New	2026-08-22 13:50:55.165178+00
692	google-sheet	gid=1662183816	2026-08-21	\N	\N	ShinobiKnife	\N	3-85	UnderFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
693	google-sheet	gid=1662183816	2026-08-21	\N	\N	GhostCircle	\N	7-55	Quake	1	1	204	New	2026-08-22 13:50:55.165178+00
694	google-sheet	gid=1662183816	2026-08-21	\N	\N	GhostCircle	\N	9-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
695	google-sheet	gid=1662183816	2026-08-21	\N	\N	GhostCircle	\N	7-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
696	google-sheet	gid=1662183816	2026-08-21	\N	\N	GhostCircle	\N	9-60	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
697	google-sheet	gid=1662183816	2026-08-21	\N	\N	DragoonStorm	\N	4-50	GearNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
698	google-sheet	gid=1662183816	2026-08-21	Metal	Guard	Fortress	Wheel	9-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
699	google-sheet	gid=1662183816	2026-08-21	Metal	Guard	Fortress	Wheel	7-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
700	google-sheet	gid=1662183816	2026-08-21	\N	\N	ShelterDrake	\N	3-60	Needle	1	1	204	New	2026-08-22 13:50:55.165178+00
701	google-sheet	gid=1662183816	2026-08-21	\N	\N	ShelterDrake	\N	1-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
702	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Flame	Dual	3-60	Ball	1	1	204	New	2026-08-22 13:50:55.165178+00
703	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Flame	Wheel	5-80	WallBall	1	1	204	New	2026-08-22 13:50:55.165178+00
704	google-sheet	gid=1662183816	2026-08-21	\N	\N	HackViking	\N	9-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
705	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Stag	Wheel	9-60	GearNeedle	1	1	204	New	2026-08-22 13:50:55.165178+00
706	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Stag	Charge	9-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
707	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Stag	Vertical	9-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
708	google-sheet	gid=1662183816	2026-08-21	\N	\N	RockLeone	\N	5-60	LowFlat	1	1	204	New	2026-08-22 13:50:55.165178+00
709	google-sheet	gid=1662183816	2026-08-21	\N	\N	RockLeone	\N	7-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
710	google-sheet	gid=1662183816	2026-08-21	\N	\N	RockLeone	\N	7-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
711	google-sheet	gid=1662183816	2026-08-21	\N	\N	RockLeone	\N	7-60	Unite	1	1	204	New	2026-08-22 13:50:55.165178+00
712	google-sheet	gid=1662183816	2026-08-21	Metal	Flow	Delta	Heavy	9-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
713	google-sheet	gid=1662183816	2026-08-21	Metal	Flow	Delta	Heavy	7-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
714	google-sheet	gid=1662183816	2026-08-21	Metal	Peak	Delta	Heavy	9-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
715	google-sheet	gid=1662183816	2026-08-21	Metal	Peak	Delta	Heavy	3-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
716	google-sheet	gid=1662183816	2026-08-21	Plastic	Peak	Delta	Heavy	1-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
717	google-sheet	gid=1662183816	2026-08-21	Plastic	Peak	Delta	Heavy	1-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
718	google-sheet	gid=1662183816	2026-08-21	Plastic	Peak	Delta	Heavy	7-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
719	google-sheet	gid=1662183816	2026-08-21	Plastic	Peak	Delta	Heavy	9-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
720	google-sheet	gid=1662183816	2026-08-21	Plastic	Peak	Delta	Heavy	9-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
721	google-sheet	gid=1662183816	2026-08-21	Plastic	Peak	Delta	Knuckle	1-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
722	google-sheet	gid=1662183816	2026-08-21	Plastic	Peak	Delta	Jaggy	3-60	LowOrb	1	1	204	New	2026-08-22 13:50:55.165178+00
723	google-sheet	gid=1662183816	2026-08-21	Plastic	Peak	Delta	Jaggy	9-70	Orb	1	1	204	New	2026-08-22 13:50:55.165178+00
724	google-sheet	gid=1662183816	2026-08-21	Plastic	Peak	Delta	Odd	1-60	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
725	google-sheet	gid=1662183816	2026-08-21	Plastic	Flow	Hornet	Heavy	4-70	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
726	google-sheet	gid=1662183816	2026-08-21	\N	\N	CrocCrunch	\N	3-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
727	google-sheet	gid=1662183816	2026-08-21	\N	\N	CrocCrunch	\N	3-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
728	google-sheet	gid=1662183816	2026-08-21	\N	\N	CrocCrunch	\N	5-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
729	google-sheet	gid=1662183816	2026-08-21	Plastic	Flow	Delta	Heavy	3-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
730	google-sheet	gid=1662183816	2026-08-21	Plastic	Flow	Delta	Heavy	6-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
731	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranStrike	\N	9-70	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
732	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranStrike	\N	1-50	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
733	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranStrike	\N	7-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
734	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranStrike	\N	7-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
735	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranStrike	\N	1-60	RubberAccel	1	1	204	New	2026-08-22 13:50:55.165178+00
736	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranStrike	\N	9-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
737	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranStrike	\N	3-60	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
738	google-sheet	gid=1662183816	2026-08-21	\N	\N	DranStrike	\N	9-60	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
739	google-sheet	gid=1662183816	2026-08-21	Plastic	Peak	Blitz	Odd	1-50	LowRush	1	1	204	New	2026-08-22 13:50:55.165178+00
740	google-sheet	gid=1662183816	2026-08-21	\N	\N	GillShark	\N	5-80	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
741	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Reaper	Free	9-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
742	google-sheet	gid=1662183816	2026-08-21	\N	\N	CutterShinobi	\N	\N	Elevate	1	1	204	New	2026-08-22 13:50:55.165178+00
743	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Eclipse	Heavy	9-60	Taper	1	1	204	New	2026-08-22 13:50:55.165178+00
744	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Eclipse	Wheel	9-60	Jolt	1	1	204	New	2026-08-22 13:50:55.165178+00
745	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Eclipse	Dual	5-70	Level	1	1	204	New	2026-08-22 13:50:55.165178+00
746	google-sheet	gid=1662183816	2026-08-21	Plastic	Break	Delta	Heavy	9-60	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
747	google-sheet	gid=1662183816	2026-08-21	Plastic	\N	Fortress	Wheel	8-70	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
748	google-sheet	gid=1662183816	2026-08-21	\N	\N	BearScratch	\N	3-70	Kick	1	1	204	New	2026-08-22 13:50:55.165178+00
749	google-sheet	gid=1662183816	2026-08-21	\N	\N	StormSpriggan	\N	7-60	Rush	1	1	204	New	2026-08-22 13:50:55.165178+00
750	google-sheet	gid=1662183816	2026-08-21	\N	\N	DrigerSlash	\N	7-60	Point	1	1	204	New	2026-08-22 13:50:55.165178+00
751	google-sheet	gid=1662183816	2026-08-21	Metal	Flow	Fortress	Wheel	6-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
752	google-sheet	gid=1662183816	2026-08-21	\N	\N	MammothTusk	\N	9-60	Wedge	1	1	204	New	2026-08-22 13:50:55.165178+00
753	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Might	Wheel	7-60	Hexa	1	1	204	New	2026-08-22 13:50:55.165178+00
754	google-sheet	gid=1662183816	2026-08-21	Metal	\N	Might	Heavy	9-60	TransKick	1	1	204	New	2026-08-22 13:50:55.165178+00
755	google-sheet	gid=1662183816	2026-08-21	\N	\N	Obi-WanKenobi	\N	6-60	FreeBall	1	1	204	New	2026-08-22 13:50:55.165178+00
\.


--
-- Data for Name: player_regional_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.player_regional_stats (player_id, player_name, region, season, points, tournaments_played, wins, top4, updated_at, platform) FROM stdin;
72938c5e-d4d5-4682-9fe1-516aa45f51ad	Il_mitico_ulisse	Campania	Off Season 2025	35	2	0	0	2026-08-21 17:27:05.551398	challengermode
c86e41d2-23f9-4820-be62-33ed802f9897	Camistar	Campania	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
79ae80d4-9e52-465a-a3b5-67a4427e0679	yuriymo	Campania	Off Season 2025	50	2	0	0	2026-08-21 17:27:05.551398	challengermode
96ff4c7f-ae31-46c2-9c7a-a4dde068f206	Yulang_	Campania	Off Season 2025	75	2	0	1	2026-08-21 17:27:05.551398	challengermode
374dd633-8222-41eb-a76a-c155ce0d5e72	Disparter 120	Campania	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
db2bec8d-2c30-42b0-950a-f09b25b4edaa	Raff2770	Campania	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
c05be628-0b2b-4225-a4cc-5df3aaf332da	RayDark27	Campania	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
c22a9e64-da54-437c-bcd0-4f53535d3350	Solixi-Trinity	Campania	Off Season 2025	105	2	0	1	2026-08-21 17:27:05.551398	challengermode
6708c485-be3b-4e7a-9126-046755fe77ad	Vincent97	Campania	Off Season 2025	20	2	0	0	2026-08-21 17:27:05.551398	challengermode
b12dbd71-a701-467a-993a-4d9bb09879b1	CrocchettaBagnata	Campania	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
69acac52-bd59-482e-8e9c-7ace2eef8cad	KaotikAres	Campania	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
510e04c1-8db1-471a-ae32-9701520a720f	kuribatto	Campania	Off Season 2025	50	2	0	0	2026-08-21 17:27:05.551398	challengermode
c8d4838f-ee6f-451d-a16b-21b532cde98b	Nonnechik99	Campania	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
8db2a1c1-72a0-44a5-b8e0-27c236a9afb9	V2HEL	Campania	Off Season 2025	50	2	0	0	2026-08-21 17:27:05.551398	challengermode
9c78170c-0b9c-4491-88ab-baa817ff7951	Bernyfur	Campania	Off Season 2025	125	2	1	1	2026-08-21 17:27:05.551398	challengermode
01eecb73-3dc0-46c3-a2be-c0cd0fefbf9c	Bellockamp	Campania	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
c351e820-8649-4d05-9097-e6b2708d14b1	BLADER X 85	Campania	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
6ef8d6cd-683f-403d-bfd5-b7c3b8351ef3	ofraton	Campania	Off Season 2025	80	1	0	1	2026-08-21 17:27:05.551398	challengermode
fc705f84-15eb-488b-af47-459a19305c2b	sasaмaи	Campania	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
d6abd100-0300-49df-9d70-4a11c408157d	antmemoli92	Campania	Off Season 2025	65	1	0	1	2026-08-21 17:27:05.551398	challengermode
2e874f6b-3d11-495f-baab-fcbfc927106c	Lorsilver	Campania	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
53face5a-1fa9-4d2c-8f75-70e430adbecb	YuriFas	Campania	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
902c6636-6aa0-4def-8b0d-edfb23ed5722	Fonzy_87	Campania	Off Season 2025	65	2	0	0	2026-08-21 17:27:05.551398	challengermode
7b93216a-d77e-479f-8d1e-5ad2bc604f6d	Laerte1	Campania	Off Season 2025	75	2	0	1	2026-08-21 17:27:05.551398	challengermode
b956f704-a5cc-42c1-a76e-728cc030ce2a	Paskqualo	Umbria	Off Season 2025	230	5	1	1	2026-08-21 17:27:05.551398	challengermode
55c70b52-40d6-4c65-bf69-6798204d54a3	AnDrEai	Umbria	Off Season 2025	315	6	0	3	2026-08-21 17:27:05.551398	challengermode
c9b251bd-03ec-49ee-99ae-36959f63b1cd	Griennel	Umbria	Off Season 2025	230	5	1	1	2026-08-21 17:27:05.551398	challengermode
f6f47a62-9aa5-4303-8b1c-d4caefdc509e	Nick111R96	Umbria	Off Season 2025	120	2	0	1	2026-08-21 17:27:05.551398	challengermode
bf0d2c91-4798-4294-a798-6bfe3e810ef3	CrazyFoll	Umbria	Off Season 2025	260	6	1	3	2026-08-21 17:27:05.551398	challengermode
52af5e3d-7923-4c50-96b1-b4ffae064824	yori99	Umbria	Off Season 2025	230	5	1	1	2026-08-21 17:27:05.551398	challengermode
eefad2d2-1c4b-42cd-8496-b4260ead3128	Leonardoash	Umbria	Off Season 2025	60	3	0	0	2026-08-21 17:27:05.551398	challengermode
736d1acf-027c-4128-8c07-540aae993ed8	ZEF99	Umbria	Off Season 2025	225	5	0	1	2026-08-21 17:27:05.551398	challengermode
2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	TEVO_	Umbria	Off Season 2025	465	7	2	5	2026-08-21 17:27:05.551398	challengermode
875ccc4e-4d96-4412-a7fc-b1460cf734a0	-Marshall-	Umbria	Off Season 2025	220	5	0	2	2026-08-21 17:27:05.551398	challengermode
f7158e1d-4e03-4ad1-b85f-b61d5829f48b	JirayaSensei90	Umbria	Off Season 2025	200	6	0	2	2026-08-21 17:27:05.551398	challengermode
ed4be371-c8de-4a84-b047-9f27592821e8	L’umido	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
efac570e-02e5-481b-9d8b-8599130e1c1d	SqualoToro	Umbria	Off Season 2025	20	2	0	0	2026-08-21 17:27:05.551398	challengermode
adfabaf2-0cd7-4d06-8bf9-2149affa44cf	Nuccio	Umbria	Off Season 2025	35	2	0	0	2026-08-21 17:27:05.551398	challengermode
4d3f97b1-28ec-42de-bb6b-529c4f440b53	MattoSquash	Umbria	Off Season 2025	80	2	0	0	2026-08-21 17:27:05.551398	challengermode
62151adf-2864-4938-becf-489b015d6147	R2V3	Umbria	Off Season 2025	20	2	0	0	2026-08-21 17:27:05.551398	challengermode
ab2fc160-d23b-4507-b9e6-0a687377cff7	Stinco di Unicorno	Umbria	Off Season 2025	65	2	0	0	2026-08-21 17:27:05.551398	challengermode
6aa4c853-90f9-4292-8cf4-dd6a0b0b4d66	M33w	Umbria	Off Season 2025	60	3	0	0	2026-08-21 17:27:05.551398	challengermode
003452fd-56da-46f4-8d20-95bc13d6e2a8	Fr3x	Umbria	Off Season 2025	90	3	0	0	2026-08-21 17:27:05.551398	challengermode
9515229f-3cf7-4870-9b17-42516832c2fa	Leon__	Umbria	Off Season 2025	90	2	0	1	2026-08-21 17:27:05.551398	challengermode
6433156e-ba76-4d4e-9013-4bc834b5c004	PAJA94	Umbria	Off Season 2025	90	2	0	1	2026-08-21 17:27:05.551398	challengermode
f1cf8ce4-049d-4fdc-ae33-0bb1974011d4	Il_Conte	Umbria	Off Season 2025	65	2	0	0	2026-08-21 17:27:05.551398	challengermode
74725cde-7604-4bf7-b314-0da61d74c48e	Sushin	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
e030df21-2645-4e31-a39c-f0e5e85747fd	bedenetta	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
ef96fbf0-7b02-43d0-ab47-3f05c18e2248	PastooR	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
6465e0a8-8631-476b-89ae-989e4ff97e19	idignio_01	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
8771d685-dbf4-47f9-aeef-fe587ddf38f3	Matita Fish	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
3432caad-f9ac-48c0-8011-22d32680a889	Bob_23	Umbria	Off Season 2025	165	2	1	2	2026-08-21 17:27:05.551398	challengermode
2d1207d1-b591-4196-8e95-b883989f288d	neko_hana00	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
2b4b3450-2945-4778-adf9-78fb6cb3822b	Proxim	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
9284b32b-f0e1-4aa9-83a7-dc11f1c62dcc	Jeck22	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
022df10c-aa13-4566-8c95-4f05f4a806b7	The Fallen (ex SonOfR)	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
c145c6ce-8dd3-4edd-9738-ec2dc50b64d8	NoMoreStar	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
74094d7f-c487-4483-95e9-7f35c056ea84	Sapessi	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
edb40a25-17c6-4f4f-9be7-55e6082a4883	Pulce	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
bd37261a-b2a4-4b4b-9c09-20fe4f10f4b1	Heldarth	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
fee82c11-0c2e-4113-bdfb-85a239141d77	MisterGiraffe	Umbria	Off Season 2025	20	2	0	0	2026-08-21 17:27:05.551398	challengermode
d10f3f9d-35cc-418f-befe-ede9748594a6	Brikthor	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
2b497895-080c-4138-9da3-453368501bac	Zertras	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
12cebd5b-356d-4bd9-a4d4-f88ad18cf59f	Lemm_77	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
8eddd258-8cb5-404d-b811-2c9d4ea66f3b	TeoFil795	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
b6bf50b2-6b37-4ad7-aef3-e95c84a9c2fe	ThE_HiTmAn88	Umbria	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
f1bbd938-5dff-49e1-8829-2430d8200819	ShootingStarR	Umbria	Off Season 2025	50	2	0	0	2026-08-21 17:27:05.551398	challengermode
6e69d2d0-ccd4-424c-bf62-c9489a9acc26	babamavs90	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
d50e37bf-7aa3-4ad0-af35-05d915af99e1	Absolte	Umbria	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
61b555c7-3980-4240-ac7d-7df697d4e596	Std::cout << "Reixi";	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
96bae4b6-e1ff-4500-8322-87458126b14e	Bolly95	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
2db4c771-059a-4ffd-99e6-2fb1826be418	itsfloinn	Umbria	Off Season 2025	185	4	0	1	2026-08-21 17:27:05.551398	challengermode
436bbecb-e481-4919-9580-c5a81cbd3ea1	Shadow_Myrcel	Umbria	Off Season 2025	35	2	0	0	2026-08-21 17:27:05.551398	challengermode
fbe08cae-c480-49da-aa11-5967b6621f3b	Post91	Umbria	Off Season 2025	65	1	0	1	2026-08-21 17:27:05.551398	challengermode
af457a79-ba52-4520-a43d-b7961d16ff57	Aldres	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
fcea24c3-7d62-4fc1-8242-7f932468846b	GreenMont	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
a65b479e-8cb2-470f-844a-659eac3344ba	_GinTonic_	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
2239f39f-63b6-49ed-925e-38ece98e0d5c	Lox97	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
e086e084-2791-4fa9-9ad0-cf46c4edaf62	Leofguerri	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
cc3e7119-2e36-493a-9434-dc5f141ec909	ErjonMusk	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
14226d5d-9fb7-4305-bffa-9e0657510da2	Yozen17	Umbria	Off Season 2025	115	4	0	0	2026-08-21 17:27:05.551398	challengermode
33d8b898-a1b5-4236-bac9-5b884ecdd548	Peppino D. Capri	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
0b9f9a53-2884-4201-b64b-3e3cb0c9b606	Spinzilla	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
c3f1ac81-070a-4039-8f71-c6085c7dbfff	Oz Arcadia	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
44f078be-5cf3-47da-bf84-a53f44123a9b	IlGrigio	Umbria	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
e7b1d625-a033-436b-bdaf-86e7a3dcaaa3	Blackdranzer1	Campania	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
8b107f55-9609-4711-b33a-f322e684a678	NR-Pone_1	Campania	Off Season 2025	65	1	0	1	2026-08-21 17:27:05.551398	challengermode
be9f0491-8cef-4802-839f-37ab49329e34	BoBnica	Campania	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
e5a1fa49-3994-4f44-804e-f2ef35800191	ananassata	Campania	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
230b2e6c-ffaf-4221-b463-daf7ffda1631	Giuzoz	Campania	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
3fcf773a-ed59-40db-a826-b489b096f676	Paky21	Campania	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
bd706fac-9bf4-4a7d-b35e-a018b48a4bcf	Sigismuth	Campania	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
716d75c8-e712-490c-b157-30aebfb03ed8	Cardcaptor_yue	Campania	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
fbdc994f-18e6-4ff1-897d-c25d7b50c4bb	Blayder p	Campania	Off Season 2025	100	1	1	1	2026-08-21 17:27:05.551398	challengermode
bc721971-5d53-4ac0-9f92-2acb52717b51	distruttore	Campania	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
527ffa94-2073-4a74-a006-89092ff9a9b7	xReko	Campania	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
a5287476-9f4e-408d-ac76-3e06c8ab8bd3	SnAke1245	Campania	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
12ba1dcc-c40b-42e8-9f9c-db7c3767741d	ROXY28	Campania	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
967c7cf7-2954-43c1-975b-ee7afb895e55	Noalone	Campania	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
e017fb67-e90e-4935-a633-caf9ae32f463	zef_99	Umbria	Off Season 2025	80	1	0	1	2026-08-21 17:27:05.551398	challengermode
da54d0b7-7af4-475c-9617-e89198753a30	WizardBusters	Umbria	Off Season 2025	67	2	0	1	2026-08-21 17:27:05.551398	challengermode
dfa6a31d-c1d8-4508-8c84-2da6a3c79d13	Leo Faraghini	Umbria	Off Season 2025	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
c7551aab-a6b8-4f47-aab4-2de70d53d518	Piadina 13	Umbria	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
510e04c1-8db1-471a-ae32-9701520a720f	kuribatto	Campania	Season 2026	410	13	1	3	2026-08-21 17:27:05.551398	challengermode
2cfbb6c6-cf12-4e3b-9d2b-9e824d60b154	Mounting Flame	Campania	Season 2026	30	4	0	0	2026-08-21 17:27:05.551398	challengermode
2bbd2c66-684d-4146-945a-cd1c92b8c323	Marshxq-Trinity	Campania	Season 2026	80	5	0	0	2026-08-21 17:27:05.551398	challengermode
f5a671cd-52c9-4363-991d-8b2a54696483	roby_3rr0r	Campania	Season 2026	275	12	0	3	2026-08-21 17:27:05.551398	challengermode
8677cae0-10ff-4d35-92c4-9c40bfbf7836	00_Zeta_00	Campania	Season 2026	390	14	0	3	2026-08-21 17:27:05.551398	challengermode
9c78170c-0b9c-4491-88ab-baa817ff7951	Bernyfur	Campania	Season 2026	95	6	0	0	2026-08-21 17:27:05.551398	challengermode
3c3a6f7a-ce90-4d1d-986e-02d598e0385f	NexGenn	Campania	Season 2026	315	14	1	1	2026-08-21 17:27:05.551398	challengermode
aacea775-6308-4324-8580-f03201508a10	sinojosart	Campania	Season 2026	110	4	0	1	2026-08-21 17:27:05.551398	challengermode
58e6b464-49b0-427c-a63d-02f6f7792e9c	Zazzu	Campania	Season 2026	60	3	0	0	2026-08-21 17:27:05.551398	challengermode
9b93a58d-8f3c-46c2-8205-032b8b6e9e87	zeitrum	Campania	Season 2026	115	9	0	0	2026-08-21 17:27:05.551398	challengermode
ee053163-c587-493b-9b06-823925949fff	Scorpio_Stryker	Campania	Season 2026	165	13	0	0	2026-08-21 17:27:05.551398	challengermode
43e8fc3a-3272-4cc2-97d2-35bf52b238cb	GermanetorArchitéktōn	Campania	Season 2026	135	7	0	1	2026-08-21 17:27:05.551398	challengermode
3448bdd0-e58a-423e-bcb2-f65762ea2caf	Rollin’	Campania	Season 2026	100	5	0	1	2026-08-21 17:27:05.551398	challengermode
bf19270b-64e7-4c44-8c20-8f9b2fd1b3b0	Esponyta	Campania	Season 2026	185	10	0	0	2026-08-21 17:27:05.551398	challengermode
095c892b-4f4b-414b-be98-fd1348786466	Bombolaro95	Campania	Season 2026	95	5	0	0	2026-08-21 17:27:05.551398	challengermode
0abcf0b2-302e-4d29-af0e-f37986aaec25	Ryry96	Campania	Season 2026	310	11	1	2	2026-08-21 17:27:05.551398	challengermode
3d928d91-0176-4758-9ed1-a2c09dcbabc0	Acampora	Campania	Season 2026	150	3	0	2	2026-08-21 17:27:05.551398	challengermode
d4efcd31-bbcd-420b-b4b6-24b4ff3f23e1	Giuliano_BeyReyal	Campania	Season 2026	420	12	2	2	2026-08-21 17:27:05.551398	challengermode
6708c485-be3b-4e7a-9126-046755fe77ad	Vincent97	Campania	Season 2026	185	9	0	1	2026-08-21 17:27:05.551398	challengermode
b74ae68c-c70e-4995-991d-263a9726dce9	kroono99	Campania	Season 2026	25	3	0	0	2026-08-21 17:27:05.551398	challengermode
816f963a-046b-4633-ba2e-e28524eca751	FraMatt	Campania	Season 2026	85	4	0	0	2026-08-21 17:27:05.551398	challengermode
9d77e83f-18ff-4875-b907-689825701938	NFedeZ	Campania	Season 2026	185	6	0	2	2026-08-21 17:27:05.551398	challengermode
acf918c0-b96e-4868-b4b8-cba99b1e5be8	exc_alibur	Campania	Season 2026	145	8	0	0	2026-08-21 17:27:05.551398	challengermode
3696fd57-4ec0-4083-ae83-fcb9e5ac38bc	Lemans	Campania	Season 2026	200	4	1	2	2026-08-21 17:27:05.551398	challengermode
57d343b4-6a1c-4ab2-9637-7c46f5f8fd64	Pako_pr	Campania	Season 2026	25	3	0	0	2026-08-21 17:27:05.551398	challengermode
edd31761-bbbb-46a9-a991-2cf38714d952	3Drakko3	Campania	Season 2026	40	4	0	0	2026-08-21 17:27:05.551398	challengermode
e446557c-4395-4267-928b-895394aed647	Vyper_blade	Campania	Season 2026	140	14	0	0	2026-08-21 17:27:05.551398	challengermode
bc721971-5d53-4ac0-9f92-2acb52717b51	distruttore	Campania	Season 2026	320	14	0	3	2026-08-21 17:27:05.551398	challengermode
21fedf5c-1913-4657-9761-6177227c6804	Solaris!	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
27123ef8-6f21-4afa-9f05-63da58012118	Guxisar	Campania	Season 2026	380	14	0	3	2026-08-21 17:27:05.551398	challengermode
bc90ecf7-f7c9-443f-8da0-c69469dedbd3	Oconnor	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
0364c388-63b3-4828-bb92-5571fea3833a	lukesnobody	Campania	Season 2026	240	7	0	2	2026-08-21 17:27:05.551398	challengermode
16617cde-6509-4e13-bc26-49968d529d48	lukelonker	Campania	Season 2026	30	3	0	0	2026-08-21 17:27:05.551398	challengermode
32f1b53b-14f6-46b5-a4ea-31536e96adea	Loptr	Campania	Season 2026	225	11	0	0	2026-08-21 17:27:05.551398	challengermode
fc705f84-15eb-488b-af47-459a19305c2b	sasaмaи	Campania	Season 2026	305	9	1	2	2026-08-21 17:27:05.551398	challengermode
6b3b4711-aaaa-4e77-84c0-bbaf79e02a25	PatriotShark	Campania	Season 2026	85	9	0	0	2026-08-21 17:27:05.551398	challengermode
27712861-639f-49da-b450-9e4b928f2bcc	Ciottolina	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
ef4c62eb-dd02-4b18-b573-45d8c0d625c7	Il Vagabondo	Campania	Season 2026	75	4	0	0	2026-08-21 17:27:05.551398	challengermode
a9a47a88-2d0c-43ff-9e39-6cacdfb2e3ec	#darkgigi	Campania	Season 2026	135	6	0	0	2026-08-21 17:27:05.551398	challengermode
6ef8d6cd-683f-403d-bfd5-b7c3b8351ef3	ofraton	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
3c7c76cf-7dd4-4bd6-80f7-5d6a24f7c9c1	FRANCO!	Campania	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challengermode
92aee5b9-5a4a-4971-bd11-6d84ef05b0c1	Konjo92	Campania	Season 2026	75	6	0	0	2026-08-21 17:27:05.551398	challengermode
35e525bc-ece5-4e0c-bbf9-5f568c698678	monkey•X•vitto	Campania	Season 2026	115	4	0	1	2026-08-21 17:27:05.551398	challengermode
e04e3d0f-53ac-4771-8d1b-814f533f507b	Bey Watch	Campania	Season 2026	35	2	0	0	2026-08-21 17:27:05.551398	challengermode
755da97f-e6fc-46a6-88e1-e20ad160b5d9	Maki_T_Sapæ	Campania	Season 2026	35	2	0	0	2026-08-21 17:27:05.551398	challengermode
6738b6ab-f81b-491a-8e77-6879a2c42e0c	GUALZO	Campania	Season 2026	95	4	0	0	2026-08-21 17:27:05.551398	challengermode
03a1a28c-7933-4726-a4bd-f304bf07a529	MΛNU	Campania	Season 2026	10	2	0	0	2026-08-21 17:27:05.551398	challengermode
1e71792b-fae8-477a-9f33-d2f323787d9b	GrumoCore	Campania	Season 2026	65	2	0	0	2026-08-21 17:27:05.551398	challengermode
902c6636-6aa0-4def-8b0d-edfb23ed5722	Fonzy_87	Campania	Season 2026	140	5	0	1	2026-08-21 17:27:05.551398	challengermode
50179e51-4645-48d0-9960-f65bed7ba3eb	Misterious reaper	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
d1f71c2d-7b2b-43b3-974d-807bca124c68	KaotikAres [Nuovo Ordine Mondiale]	Campania	Season 2026	35	2	0	0	2026-08-21 17:27:05.551398	challengermode
848dfff5-5e21-4ffd-bf90-32b4f3b7b69a	Civrill [Nuovo Ordine Mondiale]	Campania	Season 2026	10	2	0	0	2026-08-21 17:27:05.551398	challengermode
0891a2de-6d84-4fed-9eca-00fb2cfede49	hungryvala	Campania	Season 2026	125	4	1	1	2026-08-21 17:27:05.551398	challengermode
c70a83f5-cd49-4026-a1f2-b6cea58378ff	Diego_01	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
43ae2158-5642-4d29-85da-151ce04e8e38	Hitninja	Campania	Season 2026	45	3	0	0	2026-08-21 17:27:05.551398	challengermode
19d49de6-5a29-409a-86a2-727b675720d3	TekNiko	Campania	Season 2026	255	5	2	2	2026-08-21 17:27:05.551398	challengermode
2a403a54-1a3d-4d0a-bfb2-02f04e92acb2	Blader F	Campania	Season 2026	390	11	1	2	2026-08-21 17:27:05.551398	challengermode
74437637-9b6a-4495-9a42-4ba0abeadcc5	Hitara	Campania	Season 2026	60	2	0	1	2026-08-21 17:27:05.551398	challengermode
7f7386b7-c449-43f3-a7ac-4a0baa0f8835	Axon hillock	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
2b9e5a38-7d9c-4011-bd5a-e0cadcef71db	Fatafaga	Campania	Season 2026	15	2	0	0	2026-08-21 17:27:05.551398	challengermode
72938c5e-d4d5-4682-9fe1-516aa45f51ad	Il_mitico_ulisse	Campania	Season 2026	105	3	0	0	2026-08-21 17:27:05.551398	challengermode
e7b1d625-a033-436b-bdaf-86e7a3dcaaa3	Blackdranzer1	Campania	Season 2026	60	3	0	0	2026-08-21 17:27:05.551398	challengermode
1630a406-7f5a-426e-a613-e3c4fe0f6207	Anticlea1	Campania	Season 2026	60	3	0	0	2026-08-21 17:27:05.551398	challengermode
7b93216a-d77e-479f-8d1e-5ad2bc604f6d	Laerte1	Campania	Season 2026	115	3	0	1	2026-08-21 17:27:05.551398	challengermode
2d0832f2-a217-4710-8098-9c79ba11b72c	Blader's Y	Campania	Season 2026	190	8	0	2	2026-08-21 17:27:05.551398	challengermode
d6abd100-0300-49df-9d70-4a11c408157d	antmemoli92	Campania	Season 2026	120	8	0	0	2026-08-21 17:27:05.551398	challengermode
b12dbd71-a701-467a-993a-4d9bb09879b1	CrocchettaBagnata	Campania	Season 2026	265	9	0	1	2026-08-21 17:27:05.551398	challengermode
84879145-9349-4f3e-a282-6d9dc6702dc2	zPesce2002	Campania	Season 2026	75	4	0	1	2026-08-21 17:27:05.551398	challengermode
1d612a04-7972-4a6f-b594-bb42d0ce7a3b	WhitefangBBX	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
caec2c1e-41e3-4c6a-9450-eec01e592eea	Heron98	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
34db7b70-ce92-4bf3-82df-d2b1c70238c6	Lisb94	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
93f7ee08-e806-47f6-8cde-1ac312506303	Chips25	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
0a3b962a-ea36-4d25-a44b-2c9f683ab8f6	PiRatA X	Campania	Season 2026	30	2	0	0	2026-08-21 17:27:05.551398	challengermode
e917ad9c-bee3-4421-83ac-bb6b500ea66b	Ciucione	Campania	Season 2026	15	2	0	0	2026-08-21 17:27:05.551398	challengermode
139b8dc5-f6f9-4f23-b14d-3ad34c63b82c	Burner3401	Campania	Season 2026	175	10	0	1	2026-08-21 17:27:05.551398	challengermode
c05be628-0b2b-4225-a4cc-5df3aaf332da	RayDark27	Campania	Season 2026	115	3	0	1	2026-08-21 17:27:05.551398	challengermode
7573490a-ce07-4868-8e45-3631dc8a10fe	dottor ghoul	Campania	Season 2026	50	4	0	0	2026-08-21 17:27:05.551398	challengermode
8cb46257-687f-4b5f-acff-38b6ccc8b22b	BLADERX85	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
2e12e4f1-8301-45e2-813b-04f3d445aac8	Blenz	Campania	Season 2026	30	3	0	0	2026-08-21 17:27:05.551398	challengermode
788bb6c0-c0bd-4111-b35d-2c39af146f29	YungDarko	Campania	Season 2026	80	3	0	1	2026-08-21 17:27:05.551398	challengermode
5cddca64-fdf9-4358-b395-0929c4a5c312	GallinaPadovana	Campania	Season 2026	280	11	1	1	2026-08-21 17:27:05.551398	challengermode
e2b92461-3a9e-493c-9ba7-0b22f1a784f7	Friz96	Campania	Season 2026	35	4	0	0	2026-08-21 17:27:05.551398	challengermode
7bcbf08b-3a2e-40a5-97d4-338f1895e3ae	Arkstant	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
fd2bd884-a41f-4ec5-aa0c-f49f93c00eeb	AmazingRodeo	Campania	Season 2026	190	10	0	0	2026-08-21 17:27:05.551398	challengermode
61de8664-2604-4f22-b11d-f0bce9c296b2	Inkedoggo	Campania	Season 2026	65	8	0	0	2026-08-21 17:27:05.551398	challengermode
467fe00e-ea50-42ef-9107-fd414722ecef	Sear.	Campania	Season 2026	145	9	0	0	2026-08-21 17:27:05.551398	challengermode
e14d6478-a528-473b-a1e6-ca5bd5fcc4f1	fikro25	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
6a3f28dc-dc03-4629-b59d-a8d6e4a93239	Wynver	Campania	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challengermode
403cc3c4-b17e-4700-ad16-9c599e8bd275	dr.pavone	Campania	Season 2026	205	6	0	1	2026-08-21 17:27:05.551398	challengermode
f709ca5b-9692-4050-a85b-acee1fe39b40	Dr.Venom	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
593e29df-85e0-4085-b85d-2b09d6e67c3d	Diego Demogorgone	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
a5d17c61-9f86-4722-b433-95e2f82a2e94	ReginaLia	Campania	Season 2026	45	5	0	0	2026-08-21 17:27:05.551398	challengermode
ac2308f8-8911-417a-9564-03cc3ce54663	KamadoFrancy	Campania	Season 2026	55	5	0	0	2026-08-21 17:27:05.551398	challengermode
40406601-2a11-4724-8e23-fdaf7cd043e5	Mayaprincy	Campania	Season 2026	105	5	0	1	2026-08-21 17:27:05.551398	challengermode
04414507-6240-4189-bd32-efee693b7858	FrankPH	Campania	Season 2026	70	2	0	1	2026-08-21 17:27:05.551398	challengermode
39215df5-f9d1-48a9-975d-d604f34c224a	Alessandro.IV	Campania	Season 2026	135	5	0	0	2026-08-21 17:27:05.551398	challengermode
f8c5dc51-a074-4b1e-aa17-5449007bcb75	kartahype	Campania	Season 2026	50	2	0	0	2026-08-21 17:27:05.551398	challengermode
01eecb73-3dc0-46c3-a2be-c0cd0fefbf9c	Bellockamp	Campania	Season 2026	365	6	2	3	2026-08-21 17:27:05.551398	challengermode
5adeb7ef-eb10-4146-a2d3-7457625b5a7f	Martkus	Campania	Season 2026	155	7	0	1	2026-08-21 17:27:05.551398	challengermode
c8d4838f-ee6f-451d-a16b-21b532cde98b	Nonnechik99	Campania	Season 2026	175	8	0	1	2026-08-21 17:27:05.551398	challengermode
aa2da3d6-d884-4f7c-9f45-c68e7bdb2713	Skyrlez	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
f10772ae-c852-47a0-9f30-8be78d90cbbe	~Hisoka~	Campania	Season 2026	230	4	1	3	2026-08-21 17:27:05.551398	challengermode
8faaa737-0ae6-479f-bbd8-e5271c343fb6	Ku$h	Campania	Season 2026	75	3	0	1	2026-08-21 17:27:05.551398	challengermode
ef0cdf16-38f1-4f68-9dfa-5fc2cdaa2843	KaidoDalleNuvole	Campania	Season 2026	100	3	0	1	2026-08-21 17:27:05.551398	challengermode
fa64971f-4378-43f9-a97b-ed1c68beb8d1	Vgenny1712	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
287d6cdd-cc41-487a-982f-f5169a4f3e47	NR - Ndreh	Campania	Season 2026	80	6	0	0	2026-08-21 17:27:05.551398	challengermode
8b107f55-9609-4711-b33a-f322e684a678	NR-Pone_1	Campania	Season 2026	265	9	0	2	2026-08-21 17:27:05.551398	challengermode
db2bec8d-2c30-42b0-950a-f09b25b4edaa	Raff2770	Campania	Season 2026	120	5	0	1	2026-08-21 17:27:05.551398	challengermode
60021a5c-31ee-4cbf-85d7-e0cf4f351638	Danny_BX	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
275b6a29-05fb-474c-8c19-12a83ef6ab42	Lukket98	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
c729752a-5433-487c-911c-bd5b15968aaf	ReginaPingu	Campania	Season 2026	20	2	0	0	2026-08-21 17:27:05.551398	challengermode
e1c7fad1-8a22-4c15-984c-ce0cd3edc731	Vixit	Campania	Season 2026	15	2	0	0	2026-08-21 17:27:05.551398	challengermode
49c3496a-46f0-4fe0-8747-094a922f9425	giammafo	Campania	Season 2026	50	2	0	0	2026-08-21 17:27:05.551398	challengermode
9c1f3462-9d1a-467a-91b9-f3680d9a69d8	G-Zep	Campania	Season 2026	50	2	0	0	2026-08-21 17:27:05.551398	challengermode
db4e8a8b-4388-4252-9363-730db9dd3c6f	Bagheera97	Campania	Season 2026	40	3	0	0	2026-08-21 17:27:05.551398	challengermode
12ac11cf-1f4f-497f-baf8-15a7aee548c0	Gallo Lecchese	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
c22a9e64-da54-437c-bcd0-4f53535d3350	Solixi-Trinity	Campania	Season 2026	105	5	0	0	2026-08-21 17:27:05.551398	challengermode
1f156cdc-e360-460f-98c8-8952b964b7c2	NTS_Vinsitrè	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
23f27122-ebd8-4311-b1f5-7f45fe600592	NR-Lewis	Campania	Season 2026	50	2	0	0	2026-08-21 17:27:05.551398	challengermode
496965f2-a314-4c0a-a3dc-9843aef7de50	NR-GeCarb	Campania	Season 2026	200	8	0	0	2026-08-21 17:27:05.551398	challengermode
03b63a9e-9009-4d19-93be-5bb061e73c26	NR-Yamcha	Campania	Season 2026	65	4	0	0	2026-08-21 17:27:05.551398	challengermode
551c4452-a25a-4ee9-9abb-536d2e007125	NR-Andrew21111	Campania	Season 2026	135	4	0	1	2026-08-21 17:27:05.551398	challengermode
38577c32-577b-4b3a-8a47-dc421aa49ded	Il Sire	Umbria	Season 2026	100	3	0	1	2026-08-21 17:27:05.551398	challengermode
c9b251bd-03ec-49ee-99ae-36959f63b1cd	Griennel	Umbria	Season 2026	115	3	0	1	2026-08-21 17:27:05.551398	challengermode
55c70b52-40d6-4c65-bf69-6798204d54a3	AnDrEai	Umbria	Season 2026	100	3	0	1	2026-08-21 17:27:05.551398	challengermode
36e18412-0785-4948-a49d-2058f3884fc8	Redavil	Umbria	Season 2026	115	3	0	1	2026-08-21 17:27:05.551398	challengermode
a790cce5-04cb-4762-bc53-31eaed9cb7bd	Nico_Pao	Umbria	Season 2026	160	3	0	1	2026-08-21 17:27:05.551398	challengermode
cc3e7119-2e36-493a-9434-dc5f141ec909	ErjonMusk	Umbria	Season 2026	120	2	0	1	2026-08-21 17:27:05.551398	challengermode
33d8b898-a1b5-4236-bac9-5b884ecdd548	Peppino D. Capri	Umbria	Season 2026	80	2	0	1	2026-08-21 17:27:05.551398	challengermode
f1cf8ce4-049d-4fdc-ae33-0bb1974011d4	Il_Conte	Umbria	Season 2026	55	1	0	1	2026-08-21 17:27:05.551398	challengermode
62151adf-2864-4938-becf-489b015d6147	R2V3	Umbria	Season 2026	135	2	0	2	2026-08-21 17:27:05.551398	challengermode
7ad01f72-8a88-401f-acb7-991dcfc6392a	Rico__	Umbria	Season 2026	65	2	0	0	2026-08-21 17:27:05.551398	challengermode
ceebf5c8-a932-42bc-a58b-a9be686b8d99	vinny_pblack	Umbria	Season 2026	105	2	0	1	2026-08-21 17:27:05.551398	challengermode
b956f704-a5cc-42c1-a76e-728cc030ce2a	Paskqualo	Umbria	Season 2026	90	3	0	0	2026-08-21 17:27:05.551398	challengermode
866904d2-261e-4938-adeb-d3eeeaa3a593	Neder95	Umbria	Season 2026	155	2	1	2	2026-08-21 17:27:05.551398	challengermode
d18b3b7e-d18b-4887-94cc-35a89b50198e	MrBenni	Umbria	Season 2026	110	2	1	1	2026-08-21 17:27:05.551398	challengermode
12cebd5b-356d-4bd9-a4d4-f88ad18cf59f	Lemm_77	Umbria	Season 2026	200	2	2	2	2026-08-21 17:27:05.551398	challengermode
bf0d2c91-4798-4294-a798-6bfe3e810ef3	CrazyFoll	Umbria	Season 2026	105	3	0	1	2026-08-21 17:27:05.551398	challengermode
5bf0bf06-669c-47f1-a966-4cc7c9612fc8	Baglio91	Umbria	Season 2026	80	2	0	0	2026-08-21 17:27:05.551398	challengermode
52af5e3d-7923-4c50-96b1-b4ffae064824	yori99	Umbria	Season 2026	130	3	0	1	2026-08-21 17:27:05.551398	challengermode
3cf76949-6b0e-4ce1-a937-86bc23984296	TotoHnk	Campania	Season 2026	60	3	0	0	2026-08-21 17:27:05.551398	challengermode
cf8a8f23-3991-4123-9832-a3803767f7ff	damian_gallo	Campania	Season 2026	25	3	0	0	2026-08-21 17:27:05.551398	challengermode
d5f42b78-de73-4e34-84cf-e0eb1021bcc6	AltaDefinizione	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
6969fb62-dd75-47c5-8070-0794dded1c0a	Unxam	Campania	Season 2026	55	3	0	0	2026-08-21 17:27:05.551398	challengermode
e2fe286f-fed2-4e17-80d8-0952a105d4e0	Gegy	Campania	Season 2026	100	6	0	0	2026-08-21 17:27:05.551398	challengermode
0a85fe72-b616-4ef7-8206-6b5fa6162f79	Gyge	Campania	Season 2026	210	6	1	2	2026-08-21 17:27:05.551398	challengermode
d05bdf82-2992-4bcd-9fa1-904a5cc5d287	ZioRaGe	Campania	Season 2026	50	2	0	0	2026-08-21 17:27:05.551398	challengermode
4eebe286-35b9-43af-959e-d436a9c4d95a	Merysz	Campania	Season 2026	60	3	0	0	2026-08-21 17:27:05.551398	challengermode
27390f80-766d-41e8-8504-9cbb2790a7bb	Mathaius3rd	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
74094d7f-c487-4483-95e9-7f35c056ea84	Sapessi	Umbria	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
fbe08cae-c480-49da-aa11-5967b6621f3b	Post91	Umbria	Season 2026	100	1	1	1	2026-08-21 17:27:05.551398	challengermode
d10f3f9d-35cc-418f-befe-ede9748594a6	Brikthor	Umbria	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
SpaceGirlfriend	SpaceGirlfriend	Global	Season 2026	275	3	1	1	2026-08-21 17:27:05.551398	challonge
b4306212-ab9b-4e0a-929e-5c17df8b208d	Vieniquichenontifaccioniente	Umbria	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
2b4b3450-2945-4778-adf9-78fb6cb3822b	Proxim	Umbria	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
8bb91297-a184-4691-a7f7-4b75352e37ca	Vale la pena	Umbria	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
edb40a25-17c6-4f4f-9be7-55e6082a4883	Pulce	Umbria	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
2db4c771-059a-4ffd-99e6-2fb1826be418	itsfloinn	Umbria	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
875ccc4e-4d96-4412-a7fc-b1460cf734a0	-Marshall-	Umbria	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
2239f39f-63b6-49ed-925e-38ece98e0d5c	Lox97	Umbria	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
73249216-c888-48da-b795-1ce6f39addb9	Dark cobalto	Umbria	Season 2026	50	2	0	0	2026-08-21 17:27:05.551398	challengermode
25bdb96d-cbe4-4fb5-a3f6-c41822d486ea	Ares_93	Umbria	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
f7092f5d-9072-43c9-ab5a-fa8e4f04eb88	Dramione	Umbria	Season 2026	65	1	0	1	2026-08-21 17:27:05.551398	challengermode
a01d6111-12ad-45a9-911f-b28f3c3b3d95	Crimson Valkyrie	Umbria	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
d97ee0fa-a913-4c32-9e71-417af6894ce2	Blayder x	Umbria	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
c4073bd2-9225-423d-bf60-c6693713f5c2	Anonymous__	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
65211ae3-26b1-4c23-8c9a-d35ab4b90664	Zeppolino	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
627c7b66-6632-4684-babb-90741a653884	Libanese	Campania	Season 2026	135	3	1	1	2026-08-21 17:27:05.551398	challengermode
8eab6f0a-feaf-4f8c-984a-e8335b5611c4	Elmutanda	Campania	Season 2026	10	2	0	0	2026-08-21 17:27:05.551398	challengermode
a32021be-add2-4a31-b09f-c898c81e8a80	NR-gio_gios_gio	Campania	Season 2026	50	3	0	0	2026-08-21 17:27:05.551398	challengermode
230f91c4-6915-48a1-bc4b-b6e4d15429f0	Tenok	Campania	Season 2026	235	6	1	1	2026-08-21 17:27:05.551398	challengermode
28acc080-0664-4633-9763-c66d6ce74fa3	raffos92	Campania	Season 2026	100	6	0	0	2026-08-21 17:27:05.551398	challengermode
a849be8c-caf6-4afc-88d0-2d0ce3cdbe7e	_Green_	Campania	Season 2026	220	8	1	1	2026-08-21 17:27:05.551398	challengermode
2d6cf6b7-4517-487d-91e6-807d73692cc0	Matt3o_swmg	Campania	Season 2026	65	4	0	0	2026-08-21 17:27:05.551398	challengermode
fbb39197-1cc6-4241-b112-b9d80d1efde1	ofuentes98	Campania	Season 2026	15	2	0	0	2026-08-21 17:27:05.551398	challengermode
79ae80d4-9e52-465a-a3b5-67a4427e0679	yuriymo	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
3a0beb11-b003-4b77-83ea-b88c69f9c247	NTS_Copino	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
9961817a-00d3-4040-b73b-277794d5f32b	David91	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
f976c459-ee36-4ee7-8c7c-8f80171922fa	ObscureChimera	Campania	Season 2026	65	4	0	0	2026-08-21 17:27:05.551398	challengermode
57bbe1e1-df33-4939-97e6-aba9fb812692	LoyalX	Campania	Season 2026	35	3	0	0	2026-08-21 17:27:05.551398	challengermode
1e870905-b78f-410b-b3c5-1f4653fd59f7	Amun_Ra	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
8ba8cdb9-6cc2-438a-b618-8d7d8d3ba70c	Vinzqualcosa	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
8db2a1c1-72a0-44a5-b8e0-27c236a9afb9	V2HEL	Campania	Season 2026	95	4	0	0	2026-08-21 17:27:05.551398	challengermode
963f5231-52f7-41f3-9ae6-e697411ba43d	El Varro	Campania	Season 2026	70	2	0	1	2026-08-21 17:27:05.551398	challengermode
e4f50b74-c9a8-4041-a710-d16fd3f332c5	TatoZ	Campania	Season 2026	40	3	0	0	2026-08-21 17:27:05.551398	challengermode
42e32e37-2907-443f-808d-d8958f5f0aca	dran enjoyer	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
4f68ea5e-8c48-4a24-9704-e6f7b777db77	Andycer07	Campania	Season 2026	120	2	0	1	2026-08-21 17:27:05.551398	challengermode
eef5e34a-5a1f-4694-84c9-8ad463283741	LoSharkista	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
f535f79e-6d2c-4199-8cdc-e3fc15a8caad	Solexias	Campania	Season 2026	25	3	0	0	2026-08-21 17:27:05.551398	challengermode
9a78cf60-c7d4-40ed-aa1f-a385cbf035d3	.Mostro.	Campania	Season 2026	40	3	0	0	2026-08-21 17:27:05.551398	challengermode
66eeb3f1-7f9f-4290-8e49-392a0610ae67	Mammadisperata	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
16b4d7a8-3b16-4304-aa47-f0e64aab8354	ll_DARKSOUL_ll	Campania	Season 2026	15	2	0	0	2026-08-21 17:27:05.551398	challengermode
b01ee5ee-96e2-414e-88c2-77d94fbd065c	Nereide [Nuovo Ordine Mondiale]	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
589d7819-91eb-429f-b778-0393e602e98d	syryox	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
b33daa65-54c7-4c50-9fc3-4993d3428586	Carlitaa	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
a56c769d-984d-4252-b1aa-377b933f35e7	User with user id a56c769d-984d-4252-b1aa-377b933f35e7 deleted at 7/10/2026 3:05:10 PM	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
737c6bac-da0f-48dd-a87e-149004e62fa5	dario17_	Campania	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
6174c33c-67e5-4d57-bf84-afec895de592	Salvatore2	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
3412facf-e387-4278-b1b3-cc8586de07f7	OMEGAWOLF98	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
25fd4b89-8288-4b00-9870-1df2d6f3c5dc	Lightswornn	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
0e73a0a3-3bee-4d77-a4e1-2b9c827044f4	cavFreccia	Campania	Season 2026	70	2	0	1	2026-08-21 17:27:05.551398	challengermode
cb50f90c-6f20-47d6-b1a8-4f2e58c53d67	realtino	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
71ba17c6-6877-4412-980b-c89afa795e91	Giangino	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
0ff76fd8-e01e-4a4b-ba48-7cf11f927393	NoMorePhil	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
1dff54a7-52bd-4a24-abad-ba143466cfb0	Dooma!	Campania	Season 2026	35	2	0	0	2026-08-21 17:27:05.551398	challengermode
30a22db4-c6fd-4a4f-9693-ae6af306fbd2	LiL_Sleepy	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
010965df-a74c-4533-9f97-5bee2ae7f7e6	SalGat	Campania	Season 2026	35	4	0	0	2026-08-21 17:27:05.551398	challengermode
21bb3dea-0010-4c23-910f-261131f43fee	MEGURUPRIME	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
d42a62a5-4fd1-411a-b21c-aaff796fb7b3	Daniele Cammarota	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
a5287476-9f4e-408d-ac76-3e06c8ab8bd3	SnAke1245	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
12ba1dcc-c40b-42e8-9f9c-db7c3767741d	ROXY28	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
a687a961-1f3f-42a2-95b0-8bffa6904ee3	7even7even7even	Campania	Season 2026	35	2	0	0	2026-08-21 17:27:05.551398	challengermode
b475d15a-a6c9-46a2-b46a-d1d969ee8c9a	PIRATE X	Campania	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
7be3503c-8e15-45b3-9d66-a86165db989e	Dom d. Vita	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
ca698742-8ee0-41d8-9328-d65599b5bfdf	Nollax_Yukiko	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
faf3b121-5760-404a-9b4b-230f9fc7d2dc	Deku10	Umbria	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challengermode
ac3db1f3-f699-4b58-84be-9de1879b9a3c	MrGattoTetro	Umbria	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
9284b32b-f0e1-4aa9-83a7-dc11f1c62dcc	Jeck22	Umbria	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
2a0ddd1a-6115-4a45-8c05-f8fc09d3a51a	TEVO_	Umbria	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
3a7aabd3-74f3-46ab-9f07-861104223570	300%	Umbria	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
cfab4ca0-06c8-4a4d-947d-501e82a93130	anonimus_	Umbria	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
119dcb25-2c2c-4dbf-a337-3cbddaba1cc5	FilippoChallenger	Umbria	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
ff96f609-c53b-41aa-bdf6-bee19d0423ce	Obelisk13	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
11194000-8ab2-4ff9-8e88-f5b66459df1a	Xxgiuseppe	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
8e9a6c25-83cb-475b-adf6-e4e5748dd458	#cedvis	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
6978bda1-e9ea-497b-8dee-12f88bde3bb1	punchmaster	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
9b2e6da8-fbfe-40b1-91ca-f228859571aa	IL CREMOSO	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
a193276c-d14f-43b3-8554-78980577251c	Squalo_martello.	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
565cf96b-9435-4c3c-bb00-68b86df8bf92	_Dark_33	Campania	Season 2026	40	3	0	0	2026-08-21 17:27:05.551398	challengermode
53face5a-1fa9-4d2c-8f75-70e430adbecb	YuriFas	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
d7ea44a5-2642-4fc5-b0d0-10cbfddb5c13	PizzaFritt	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
ed33c614-e07d-4edb-9025-6436c77d2331	SAINT BULL	Campania	Season 2026	2	1	0	0	2026-08-21 17:27:05.551398	challengermode
91e201f5-3483-48d5-a8ec-c37bf37349fa	_Ayane_	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
e81387d6-5f1b-4549-9f3f-985519df72e1	Aucelluzzo35	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
34bbe0b1-337d-49df-887d-3e0bce966650	mattia7x	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
ee867918-ee9f-41b2-be95-4289b4a0f600	CERVIX01	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
eb43c8a2-b880-4376-afa4-f726bbf77ac4	mdm7_bb	Campania	Season 2026	25	1	0	0	2026-08-21 17:27:05.551398	challengermode
4ddcf47b-c7e4-4738-b808-1b51457f33c5	PepitaBagnata	Campania	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challengermode
e661d9da-14d4-43ec-bf9e-bdbb21b698b3	Simone Zullo	Campania	Season 2026	5	1	0	0	2026-08-21 17:27:05.551398	challengermode
Hyskel	Hyskel	Global	Season 2026	390	2	1	1	2026-08-21 17:27:05.551398	challonge
Zanna85	Zanna85	Global	Season 2026	240	1	0	1	2026-08-21 17:27:05.551398	challonge
_arAle_	_arAle_	Global	Season 2026	140	1	0	1	2026-08-21 17:27:05.551398	challonge
Raidenkiuby	Raidenkiuby	Global	Season 2026	200	2	0	1	2026-08-21 17:27:05.551398	challonge
Xliga	Xliga	Global	Season 2026	130	2	0	0	2026-08-21 17:27:05.551398	challonge
masterpippo	masterpippo	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
edomark	edomark	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Twins_2016	Twins_2016	Global	Season 2026	785	5	1	3	2026-08-21 17:27:05.551398	challonge
POWDER_07	POWDER_07	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
BladerX1	BladerX1	Global	Season 2026	115	4	0	0	2026-08-21 17:27:05.551398	challonge
Pr1m0s	Pr1m0s	Global	Season 2026	760	6	1	2	2026-08-21 17:27:05.551398	challonge
Edo2016	Edo2016	Global	Season 2026	185	4	0	0	2026-08-21 17:27:05.551398	challonge
Fried_Toxic_Rice	Fried_Toxic_Rice	Global	Season 2026	510	5	0	2	2026-08-21 17:27:05.551398	challonge
leogiova	leogiova	Global	Season 2026	320	2	0	1	2026-08-21 17:27:05.551398	challonge
Dheidhara	Dheidhara	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Alexsp93	Alexsp93	Global	Season 2026	55	2	0	0	2026-08-21 17:27:05.551398	challonge
FranciBerto	FranciBerto	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Scarlet25	Scarlet25	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Bellaccia	Bellaccia	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
Giaruto	Giaruto	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
RikuGG_	RikuGG_	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Draxler811_	Draxler811_	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Cosetta00	Cosetta00	Global	Season 2026	40	2	0	0	2026-08-21 17:27:05.551398	challonge
Chef_Rossini	Chef_Rossini	Global	Season 2026	70	3	0	0	2026-08-21 17:27:05.551398	challonge
Enri2016	Enri2016	Global	Season 2026	120	4	0	0	2026-08-21 17:27:05.551398	challonge
MetalClover	MetalClover	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Sarina01	Sarina01	Global	Season 2026	140	4	0	0	2026-08-21 17:27:05.551398	challonge
LeohLKing	LeohLKing	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
#MaiunaGioia	#MaiunaGioia	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
Vergio101	Vergio101	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
AndrewLKing	AndrewLKing	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
KinomiyaTakao	KinomiyaTakao	Global	Season 2026	25	2	0	0	2026-08-21 17:27:05.551398	challonge
Ehisnam	Ehisnam	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
SledgeHammer94	SledgeHammer94	Global	Season 2026	100	2	0	0	2026-08-21 17:27:05.551398	challonge
India_Pale_Ale	India_Pale_Ale	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Xtiranno	Xtiranno	Global	Season 2026	110	3	0	0	2026-08-21 17:27:05.551398	challonge
Tomax09	Tomax09	Global	Season 2026	25	2	0	0	2026-08-21 17:27:05.551398	challonge
Blader N	Blader N	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Asriel2	Asriel2	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Pevons	Pevons	Global	Season 2026	40	2	0	0	2026-08-21 17:27:05.551398	challonge
Idignio	Idignio	Global	Season 2026	50	2	0	0	2026-08-21 17:27:05.551398	challonge
DrHats	DrHats	Global	Season 2026	435	4	1	1	2026-08-21 17:27:05.551398	challonge
Buscaduto	Buscaduto	Global	Season 2026	110	1	0	1	2026-08-21 17:27:05.551398	challonge
BLÅCKJÅCK	BLÅCKJÅCK	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
GerroBlader	GerroBlader	Global	Season 2026	190	2	0	1	2026-08-21 17:27:05.551398	challonge
KaghemushaSama	KaghemushaSama	Global	Season 2026	250	7	0	0	2026-08-21 17:27:05.551398	challonge
ToMs0	ToMs0	Global	Season 2026	70	2	0	0	2026-08-21 17:27:05.551398	challonge
Jimmy1996	Jimmy1996	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
Vinci31	Vinci31	Global	Season 2026	100	3	0	0	2026-08-21 17:27:05.551398	challonge
Laura19	Laura19	Global	Season 2026	240	7	0	1	2026-08-21 17:27:05.551398	challonge
Cricco	Cricco	Global	Season 2026	70	2	0	0	2026-08-21 17:27:05.551398	challonge
4RTV	4RTV	Global	Season 2026	200	2	0	1	2026-08-21 17:27:05.551398	challonge
Gabrimarche	Gabrimarche	Global	Season 2026	110	5	0	0	2026-08-21 17:27:05.551398	challonge
Cobralori	Cobralori	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
FrancisFordTrottola	FrancisFordTrottola	Global	Season 2026	600	7	1	1	2026-08-21 17:27:05.551398	challonge
KPopBlade	KPopBlade	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
cosonakking3000	cosonakking3000	Global	Season 2026	85	3	0	0	2026-08-21 17:27:05.551398	challonge
Tiresia_	Tiresia_	Global	Season 2026	85	2	0	0	2026-08-21 17:27:05.551398	challonge
Sapux	Sapux	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Ros Bey	Ros Bey	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Superabo56	Superabo56	Global	Season 2026	70	2	0	0	2026-08-21 17:27:05.551398	challonge
TirannoNico	TirannoNico	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Mazinga2016	Mazinga2016	Global	Season 2026	85	3	0	0	2026-08-21 17:27:05.551398	challonge
smvr8	smvr8	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Jakson	Jakson	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Shadow	Shadow	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Nico13	Nico13	Global	Season 2026	65	4	0	0	2026-08-21 17:27:05.551398	challonge
Deca96	Deca96	Global	Season 2026	330	2	1	1	2026-08-21 17:27:05.551398	challonge
Alnas	Alnas	Global	Season 2026	80	1	0	1	2026-08-21 17:27:05.551398	challonge
_Eva01	_Eva01	Global	Season 2026	120	3	0	0	2026-08-21 17:27:05.551398	challonge
Pobaz98	Pobaz98	Global	Season 2026	90	2	0	0	2026-08-21 17:27:05.551398	challonge
SaltyKessi	SaltyKessi	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
ROSBLADE	ROSBLADE	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Maestro_Miyagi	Maestro_Miyagi	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
RingLords	RingLords	Global	Season 2026	165	4	0	0	2026-08-21 17:27:05.551398	challonge
AlanLee86	AlanLee86	Global	Season 2026	70	2	0	0	2026-08-21 17:27:05.551398	challonge
beerdcello66	beerdcello66	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Matty92bey	Matty92bey	Global	Season 2026	95	2	0	0	2026-08-21 17:27:05.551398	challonge
Bicbo	Bicbo	Global	Season 2026	725	5	1	2	2026-08-21 17:27:05.551398	challonge
JuliusHyodo	JuliusHyodo	Global	Season 2026	350	4	0	1	2026-08-21 17:27:05.551398	challonge
AuraTaccons	AuraTaccons	Global	Season 2026	140	1	0	1	2026-08-21 17:27:05.551398	challonge
ShonBeyXx	ShonBeyXx	Global	Season 2026	715	10	1	2	2026-08-21 17:27:05.551398	challonge
Ubekage	Ubekage	Global	Season 2026	340	4	0	1	2026-08-21 17:27:05.551398	challonge
Emmet77	Emmet77	Global	Season 2026	150	5	0	0	2026-08-21 17:27:05.551398	challonge
Nerkio	Nerkio	Global	Season 2026	405	7	0	1	2026-08-21 17:27:05.551398	challonge
Mr_Fuffolone	Mr_Fuffolone	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Massimassi	Massimassi	Global	Season 2026	325	8	0	0	2026-08-21 17:27:05.551398	challonge
Miani83	Miani83	Global	Season 2026	710	8	1	1	2026-08-21 17:27:05.551398	challonge
Jonathan2011	Jonathan2011	Global	Season 2026	405	10	0	1	2026-08-21 17:27:05.551398	challonge
Gabbob	Gabbob	Global	Season 2026	145	2	0	0	2026-08-21 17:27:05.551398	challonge
Newteam91	Newteam91	Global	Season 2026	110	3	0	0	2026-08-21 17:27:05.551398	challonge
Ludix96	Ludix96	Global	Season 2026	125	3	0	0	2026-08-21 17:27:05.551398	challonge
Federeeeco	Federeeeco	Global	Season 2026	695	8	1	2	2026-08-21 17:27:05.551398	challonge
Bastoos	Bastoos	Global	Season 2026	195	5	0	0	2026-08-21 17:27:05.551398	challonge
Marty20xx	Marty20xx	Global	Season 2026	135	4	0	0	2026-08-21 17:27:05.551398	challonge
Jay_Mugiwara	Jay_Mugiwara	Global	Season 2026	440	5	1	1	2026-08-21 17:27:05.551398	challonge
Brian303	Brian303	Global	Season 2026	85	3	0	0	2026-08-21 17:27:05.551398	challonge
Crusblade	Crusblade	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Red	Red	Global	Season 2026	85	2	0	0	2026-08-21 17:27:05.551398	challonge
Barone83	Barone83	Global	Season 2026	260	6	0	1	2026-08-21 17:27:05.551398	challonge
Musshu	Musshu	Global	Season 2026	100	4	0	0	2026-08-21 17:27:05.551398	challonge
Mr_Tuna_Head	Mr_Tuna_Head	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
Gringo	Gringo	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Brettbbx	Brettbbx	Global	Season 2026	325	9	0	0	2026-08-21 17:27:05.551398	challonge
_M1RAGE_	_M1RAGE_	Global	Season 2026	205	5	0	1	2026-08-21 17:27:05.551398	challonge
JohnBey	JohnBey	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Paolomu_99	Paolomu_99	Global	Season 2026	285	6	0	1	2026-08-21 17:27:05.551398	challonge
_D_Hakkai	_D_Hakkai	Global	Season 2026	1095	10	2	3	2026-08-21 17:27:05.551398	challonge
SoraKurosaki	SoraKurosaki	Global	Season 2026	295	2	0	1	2026-08-21 17:27:05.551398	challonge
idril20xx	idril20xx	Global	Season 2026	135	4	0	0	2026-08-21 17:27:05.551398	challonge
Toncho04	Toncho04	Global	Season 2026	190	4	0	0	2026-08-21 17:27:05.551398	challonge
Anatra_finale	Anatra_finale	Global	Season 2026	265	5	0	2	2026-08-21 17:27:05.551398	challonge
GengisChad	GengisChad	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
SoLollo	SoLollo	Global	Season 2026	40	2	0	0	2026-08-21 17:27:05.551398	challonge
Alicino_AFST	Alicino_AFST	Global	Season 2026	55	3	0	0	2026-08-21 17:27:05.551398	challonge
Balentine_AFST	Balentine_AFST	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Rednoe	Rednoe	Global	Season 2026	400	1	1	1	2026-08-21 17:27:05.551398	challonge
JerryUomoFagiolo	JerryUomoFagiolo	Global	Season 2026	120	1	0	1	2026-08-21 17:27:05.551398	challonge
ell_deablo	ell_deablo	Global	Season 2026	90	1	0	0	2026-08-21 17:27:05.551398	challonge
HADES93	HADES93	Global	Season 2026	65	1	0	0	2026-08-21 17:27:05.551398	challonge
Matty93	Matty93	Global	Season 2026	65	1	0	0	2026-08-21 17:27:05.551398	challonge
Simojr98	Simojr98	Global	Season 2026	65	1	0	0	2026-08-21 17:27:05.551398	challonge
Thalor	Thalor	Global	Season 2026	65	1	0	0	2026-08-21 17:27:05.551398	challonge
Cippi	Cippi	Global	Season 2026	50	1	0	0	2026-08-21 17:27:05.551398	challonge
Mr.Co	Mr.Co	Global	Season 2026	50	1	0	0	2026-08-21 17:27:05.551398	challonge
Sara_loca_99	Sara_loca_99	Global	Season 2026	50	1	0	0	2026-08-21 17:27:05.551398	challonge
Belair_	Belair_	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
ManuBart	ManuBart	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
gidio96	gidio96	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
CAMSO	CAMSO	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Moffone	Moffone	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
SeregonX	SeregonX	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Furia888	Furia888	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
The_brother_91	The_brother_91	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
TheGreat_Kurama	TheGreat_Kurama	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Pacis	Pacis	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Corinzio	Corinzio	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Korise	Korise	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Remio	Remio	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
B14g10	B14g10	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
MuLaN_X	MuLaN_X	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Filiphs24	Filiphs24	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Fumo95	Fumo95	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Sephiroth555	Sephiroth555	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Rmastu	Rmastu	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
bas1	bas1	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
AleCecca	AleCecca	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
OffTravel	OffTravel	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
polly91mat	polly91mat	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
BladderN	BladderN	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Edèku	Edèku	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Simorux	Simorux	Global	Season 2026	395	2	1	1	2026-08-21 17:27:05.551398	challonge
MGNathan	MGNathan	Global	Season 2026	240	1	0	1	2026-08-21 17:27:05.551398	challonge
FLOGGY_THE_WIZARD	FLOGGY_THE_WIZARD	Global	Season 2026	185	2	0	1	2026-08-21 17:27:05.551398	challonge
Pivessio	Pivessio	Global	Season 2026	110	1	0	1	2026-08-21 17:27:05.551398	challonge
ataler_f2	ataler_f2	Global	Season 2026	150	2	0	0	2026-08-21 17:27:05.551398	challonge
Ennardo	Ennardo	Global	Season 2026	125	2	0	0	2026-08-21 17:27:05.551398	challonge
MZtore	MZtore	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Ryzer_og	Ryzer_og	Global	Season 2026	170	2	0	1	2026-08-21 17:27:05.551398	challonge
DonLopez	DonLopez	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
Tijen	Tijen	Global	Season 2026	100	2	0	0	2026-08-21 17:27:05.551398	challonge
KhromeRyughu67	KhromeRyughu67	Global	Season 2026	210	2	0	1	2026-08-21 17:27:05.551398	challonge
AlessioC_05	AlessioC_05	Global	Season 2026	140	1	0	1	2026-08-21 17:27:05.551398	challonge
alberto_ruffy	alberto_ruffy	Global	Season 2026	140	1	0	1	2026-08-21 17:27:05.551398	challonge
Euge7198	Euge7198	Global	Season 2026	140	1	0	1	2026-08-21 17:27:05.551398	challonge
KUROSU10	KUROSU10	Global	Season 2026	140	1	0	1	2026-08-21 17:27:05.551398	challonge
Cerys04	Cerys04	Global	Season 2026	110	1	0	1	2026-08-21 17:27:05.551398	challonge
Izba_prj	Izba_prj	Global	Season 2026	230	2	0	2	2026-08-21 17:27:05.551398	challonge
Niihon	Niihon	Global	Season 2026	110	1	0	1	2026-08-21 17:27:05.551398	challonge
Niko2410	Niko2410	Global	Season 2026	110	1	0	1	2026-08-21 17:27:05.551398	challonge
Zaelion	Zaelion	Global	Season 2026	110	1	0	1	2026-08-21 17:27:05.551398	challonge
zero_90	zero_90	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Kapparella	Kapparella	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Ranur	Ranur	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Loris	Loris	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Dallaio	Dallaio	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Limboh	Limboh	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
EXO358	EXO358	Global	Season 2026	150	2	0	0	2026-08-21 17:27:05.551398	challonge
youngsta1017	youngsta1017	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Isabey	Isabey	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
IMEØN	IMEØN	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Andrephoenix	Andrephoenix	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
_Freezer_	_Freezer_	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
johnnyrobomeka	johnnyrobomeka	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Hammer_Savio	Hammer_Savio	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
donnola_17	donnola_17	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Cris391	Cris391	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
ABBACS	ABBACS	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Jonny_21	Jonny_21	Global	Season 2026	125	2	0	0	2026-08-21 17:27:05.551398	challonge
Avventuriero	Avventuriero	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
1V0	1V0	Global	Season 2026	125	2	0	0	2026-08-21 17:27:05.551398	challonge
_aletreecko_	_aletreecko_	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
Bey_Sabbath	Bey_Sabbath	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
Jean_05	Jean_05	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
__ENGINE__	__ENGINE__	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
ElbryanXV	ElbryanXV	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
Imperatore_Level22	Imperatore_Level22	Global	Season 2026	400	3	1	2	2026-08-21 17:27:05.551398	challonge
Ikigai06	Ikigai06	Global	Season 2026	200	1	0	1	2026-08-21 17:27:05.551398	challonge
PennaRigata	PennaRigata	Global	Season 2026	120	1	0	1	2026-08-21 17:27:05.551398	challonge
Acesword	Acesword	Global	Season 2026	90	1	0	1	2026-08-21 17:27:05.551398	challonge
AlphaXEND	AlphaXEND	Global	Season 2026	85	2	0	0	2026-08-21 17:27:05.551398	challonge
robb_430	robb_430	Global	Season 2026	130	2	0	0	2026-08-21 17:27:05.551398	challonge
alessandro_iv	alessandro_iv	Global	Season 2026	340	3	0	2	2026-08-21 17:27:05.551398	challonge
BladerLui	BladerLui	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
louissan	louissan	Global	Season 2026	105	2	0	0	2026-08-21 17:27:05.551398	challonge
Aster94	Aster94	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
GyroRad	GyroRad	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
duemilaventitre	duemilaventitre	Global	Season 2026	185	3	0	1	2026-08-21 17:27:05.551398	challonge
P_Rocka	P_Rocka	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
B3rserker	B3rserker	Global	Season 2026	50	2	0	0	2026-08-21 17:27:05.551398	challonge
ToninoX	ToninoX	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Manty72	Manty72	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Sharkina😈	Sharkina😈	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
LaLacrimaDeFragtrap	LaLacrimaDeFragtrap	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
Masèō_8	Masèō_8	Global	Season 2026	55	2	0	1	2026-08-21 17:27:05.551398	challonge
Adrixp08	Adrixp08	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Scavabuchi	Scavabuchi	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Blader126	Blader126	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Stabi23	Stabi23	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Miba88	Miba88	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
mariovongola	mariovongola	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Cool_man01	Cool_man01	Global	Season 2026	20	2	0	0	2026-08-21 17:27:05.551398	challonge
Blaster_Hydra	Blaster_Hydra	Global	Season 2026	650	2	2	2	2026-08-21 17:27:05.551398	challonge
EsDeeShark	EsDeeShark	Global	Season 2026	550	5	0	2	2026-08-21 17:27:05.551398	challonge
Giann19	Giann19	Global	Season 2026	170	2	0	1	2026-08-21 17:27:05.551398	challonge
Sunshine	Sunshine	Global	Season 2026	220	3	0	1	2026-08-21 17:27:05.551398	challonge
3NTØNY	3NTØNY	Global	Season 2026	420	4	0	1	2026-08-21 17:27:05.551398	challonge
Myridar	Myridar	Global	Season 2026	155	4	0	0	2026-08-21 17:27:05.551398	challonge
Souten_no_ken	Souten_no_ken	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Bronev	Bronev	Global	Season 2026	95	3	0	0	2026-08-21 17:27:05.551398	challonge
Deledea	Deledea	Global	Season 2026	110	2	0	0	2026-08-21 17:27:05.551398	challonge
DooMS20	DooMS20	Global	Season 2026	70	2	0	0	2026-08-21 17:27:05.551398	challonge
MaT1806	MaT1806	Global	Season 2026	120	2	0	0	2026-08-21 17:27:05.551398	challonge
Orticoltore	Orticoltore	Global	Season 2026	160	5	0	0	2026-08-21 17:27:05.551398	challonge
SfornaPatateDolci	SfornaPatateDolci	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Snoop17	Snoop17	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Ste67_Motivated	Ste67_Motivated	Global	Season 2026	385	3	1	1	2026-08-21 17:27:05.551398	challonge
Fyxit	Fyxit	Global	Season 2026	100	2	0	0	2026-08-21 17:27:05.551398	challonge
Suaveeee	Suaveeee	Global	Season 2026	75	3	0	0	2026-08-21 17:27:05.551398	challonge
Ispanico1986	Ispanico1986	Global	Season 2026	225	3	0	1	2026-08-21 17:27:05.551398	challonge
Jaypoy	Jaypoy	Global	Season 2026	60	3	0	0	2026-08-21 17:27:05.551398	challonge
Xaldin99	Xaldin99	Global	Season 2026	200	3	0	1	2026-08-21 17:27:05.551398	challonge
EOT_Negros	EOT_Negros	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Chriss18	Chriss18	Global	Season 2026	40	2	0	0	2026-08-21 17:27:05.551398	challonge
SnoopDoggX	SnoopDoggX	Global	Season 2026	190	4	0	1	2026-08-21 17:27:05.551398	challonge
Ryckylyck	Ryckylyck	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
SIGLA	SIGLA	Global	Season 2026	65	3	0	0	2026-08-21 17:27:05.551398	challonge
Tiziano_Banano	Tiziano_Banano	Global	Season 2026	605	5	1	1	2026-08-21 17:27:05.551398	challonge
SyNC0	SyNC0	Global	Season 2026	75	3	0	0	2026-08-21 17:27:05.551398	challonge
_J_O_K_E_R_	_J_O_K_E_R_	Global	Season 2026	295	5	0	1	2026-08-21 17:27:05.551398	challonge
CrudeliaDeMon	CrudeliaDeMon	Global	Season 2026	510	4	1	1	2026-08-21 17:27:05.551398	challonge
Enrico_Pakinko	Enrico_Pakinko	Global	Season 2026	85	3	0	0	2026-08-21 17:27:05.551398	challonge
Mr_baobab	Mr_baobab	Global	Season 2026	410	5	1	1	2026-08-21 17:27:05.551398	challonge
Gique	Gique	Global	Season 2026	20	2	0	0	2026-08-21 17:27:05.551398	challonge
chicosnef	chicosnef	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
EarvS	EarvS	Global	Season 2026	25	2	0	0	2026-08-21 17:27:05.551398	challonge
Blade_Sabbath	Blade_Sabbath	Global	Season 2026	35	3	0	0	2026-08-21 17:27:05.551398	challonge
ChiperZero1	ChiperZero1	Global	Season 2026	25	2	0	0	2026-08-21 17:27:05.551398	challonge
Lore_knight	Lore_knight	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Santa89	Santa89	Global	Season 2026	40	2	0	0	2026-08-21 17:27:05.551398	challonge
ToRoAdry	ToRoAdry	Global	Season 2026	190	3	0	1	2026-08-21 17:27:05.551398	challonge
Donkeymax	Donkeymax	Global	Season 2026	85	3	0	0	2026-08-21 17:27:05.551398	challonge
Giammi	Giammi	Global	Season 2026	75	3	0	0	2026-08-21 17:27:05.551398	challonge
Renegaderene	Renegaderene	Global	Season 2026	35	3	0	0	2026-08-21 17:27:05.551398	challonge
Giko89	Giko89	Global	Season 2026	35	3	0	0	2026-08-21 17:27:05.551398	challonge
Alo_thegunsl1nger	Alo_thegunsl1nger	Global	Season 2026	20	2	0	0	2026-08-21 17:27:05.551398	challonge
_Snoozer	_Snoozer	Global	Season 2026	150	1	1	1	2026-08-21 17:27:05.551398	challonge
Eziusnanni	Eziusnanni	Global	Season 2026	75	2	0	1	2026-08-21 17:27:05.551398	challonge
Ganga	Ganga	Global	Season 2026	20	1	0	0	2026-08-21 17:27:05.551398	challonge
Mara	Mara	Global	Season 2026	20	1	0	0	2026-08-21 17:27:05.551398	challonge
ELCULON	ELCULON	Global	Season 2026	485	5	0	1	2026-08-21 17:27:05.551398	challonge
_Greta_96	_Greta_96	Global	Season 2026	260	5	0	0	2026-08-21 17:27:05.551398	challonge
_Kenzo	_Kenzo	Global	Season 2026	105	2	0	0	2026-08-21 17:27:05.551398	challonge
Beltram	Beltram	Global	Season 2026	90	1	0	0	2026-08-21 17:27:05.551398	challonge
Dante9053	Dante9053	Global	Season 2026	135	5	0	0	2026-08-21 17:27:05.551398	challonge
Dedours	Dedours	Global	Season 2026	80	2	0	0	2026-08-21 17:27:05.551398	challonge
Nonnonanni	Nonnonanni	Global	Season 2026	65	1	0	0	2026-08-21 17:27:05.551398	challonge
nova	nova	Global	Season 2026	275	3	0	1	2026-08-21 17:27:05.551398	challonge
Palissandro	Palissandro	Global	Season 2026	425	7	0	1	2026-08-21 17:27:05.551398	challonge
RoboBarat	RoboBarat	Global	Season 2026	75	2	0	0	2026-08-21 17:27:05.551398	challonge
CrispyDanger	CrispyDanger	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Escariota	Escariota	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
ll_Ezecutor-iBh	ll_Ezecutor-iBh	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
LucaZambro	LucaZambro	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
_Marks	_Marks	Global	Season 2026	105	3	0	0	2026-08-21 17:27:05.551398	challonge
Merca94	Merca94	Global	Season 2026	120	2	0	1	2026-08-21 17:27:05.551398	challonge
DemonSampei	DemonSampei	Global	Season 2026	515	5	1	2	2026-08-21 17:27:05.551398	challonge
PhilRy	PhilRy	Global	Season 2026	85	2	0	0	2026-08-21 17:27:05.551398	challonge
Viper X	Viper X	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Wolverine	Wolverine	Global	Season 2026	40	2	0	0	2026-08-21 17:27:05.551398	challonge
IronGabry	IronGabry	Global	Season 2026	70	2	0	0	2026-08-21 17:27:05.551398	challonge
Giammi08	Giammi08	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Charizard_18	Charizard_18	Global	Season 2026	40	3	0	0	2026-08-21 17:27:05.551398	challonge
Adri_81	Adri_81	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
PrincipessaPeach	PrincipessaPeach	Global	Season 2026	25	2	0	0	2026-08-21 17:27:05.551398	challonge
DeadSpall	DeadSpall	Global	Season 2026	70	2	0	0	2026-08-21 17:27:05.551398	challonge
Scrotobleyder	Scrotobleyder	Global	Season 2026	55	3	0	0	2026-08-21 17:27:05.551398	challonge
TeoBerto	TeoBerto	Global	Season 2026	270	3	0	1	2026-08-21 17:27:05.551398	challonge
Fra86170	Fra86170	Global	Season 2026	115	4	0	0	2026-08-21 17:27:05.551398	challonge
SfornaPatate	SfornaPatate	Global	Season 2026	245	3	0	1	2026-08-21 17:27:05.551398	challonge
BruteForce	BruteForce	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Redd0	Redd0	Global	Season 2026	800	6	1	3	2026-08-21 17:27:05.551398	challonge
LL_blader_15	LL_blader_15	Global	Season 2026	30	2	0	0	2026-08-21 17:27:05.551398	challonge
Skizzo10	Skizzo10	Global	Season 2026	270	3	0	1	2026-08-21 17:27:05.551398	challonge
StormPrelude	StormPrelude	Global	Season 2026	40	2	0	0	2026-08-21 17:27:05.551398	challonge
gioepifani	gioepifani	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
CrudeliaDeMon	CrudeliaDeMon	Global	Off Season 2025	400	1	1	1	2026-08-21 17:27:05.551398	challonge
ContactBlader	ContactBlader	Global	Off Season 2025	280	1	0	1	2026-08-21 17:27:05.551398	challonge
Deledea	Deledea	Global	Off Season 2025	160	1	0	1	2026-08-21 17:27:05.551398	challonge
Oh_Nico	Oh_Nico	Global	Off Season 2025	120	1	0	1	2026-08-21 17:27:05.551398	challonge
Skizzo10	Skizzo10	Global	Off Season 2025	90	1	0	0	2026-08-21 17:27:05.551398	challonge
SIGLA	SIGLA	Global	Off Season 2025	90	1	0	0	2026-08-21 17:27:05.551398	challonge
Sunshine	Sunshine	Global	Off Season 2025	90	1	0	0	2026-08-21 17:27:05.551398	challonge
Escariota	Escariota	Global	Off Season 2025	90	1	0	0	2026-08-21 17:27:05.551398	challonge
ELCULON	ELCULON	Global	Off Season 2025	65	1	0	0	2026-08-21 17:27:05.551398	challonge
Dedours	Dedours	Global	Off Season 2025	65	1	0	0	2026-08-21 17:27:05.551398	challonge
Tiziano_Banano	Tiziano_Banano	Global	Off Season 2025	65	1	0	0	2026-08-21 17:27:05.551398	challonge
Leventiel	Leventiel	Global	Off Season 2025	65	1	0	0	2026-08-21 17:27:05.551398	challonge
EOT_Negros	EOT_Negros	Global	Off Season 2025	50	1	0	0	2026-08-21 17:27:05.551398	challonge
Wm7	Wm7	Global	Off Season 2025	50	1	0	0	2026-08-21 17:27:05.551398	challonge
SfornaPatate	SfornaPatate	Global	Off Season 2025	50	1	0	0	2026-08-21 17:27:05.551398	challonge
Renegaderene	Renegaderene	Global	Off Season 2025	50	1	0	0	2026-08-21 17:27:05.551398	challonge
♤PhilRy♤	♤PhilRy♤	Global	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challonge
LucaZambro	LucaZambro	Global	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Bigsimmy	Bigsimmy	Global	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challonge
StormPrelude	StormPrelude	Global	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Spartaco31	Spartaco31	Global	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Bronev	Bronev	Global	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challonge
ChiperZero1	ChiperZero1	Global	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Nonnonanni	Nonnonanni	Global	Off Season 2025	40	1	0	0	2026-08-21 17:27:05.551398	challonge
TreZLionS	TreZLionS	Global	Off Season 2025	30	1	0	0	2026-08-21 17:27:05.551398	challonge
NOVA	NOVA	Global	Off Season 2025	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Xaldin99	Xaldin99	Global	Off Season 2025	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Jaypoy	Jaypoy	Global	Off Season 2025	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Khaleesi07	Khaleesi07	Global	Off Season 2025	30	1	0	0	2026-08-21 17:27:05.551398	challonge
EarvS	EarvS	Global	Off Season 2025	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Anna70	Anna70	Global	Off Season 2025	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Beltram	Beltram	Global	Off Season 2025	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Suaveeee	Suaveeee	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Papadriou	Papadriou	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Pikachu_16	Pikachu_16	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Cico	Cico	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
MaT1806	MaT1806	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
CrispyDanger	CrispyDanger	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Skǫll	Skǫll	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Condor15	Condor15	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Myridar	Myridar	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
ToRoAdry	ToRoAdry	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
_Marks	_Marks	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
GZeta	GZeta	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
BonnyBong	BonnyBong	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Mikelone	Mikelone	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Viper X	Viper X	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Charizard_18	Charizard_18	Global	Off Season 2025	15	1	0	0	2026-08-21 17:27:05.551398	challonge
RedBandicoot	RedBandicoot	Global	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Giovermir	Giovermir	Global	Off Season 2025	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Justjack90	Justjack90	Global	Season 2026	350	1	1	1	2026-08-21 17:27:05.551398	challonge
Spartaco31	Spartaco31	Global	Season 2026	190	2	0	1	2026-08-21 17:27:05.551398	challonge
_Ezecutor_iBh	_Ezecutor_iBh	Global	Season 2026	125	2	0	0	2026-08-21 17:27:05.551398	challonge
ContactBlader	ContactBlader	Global	Season 2026	90	2	0	0	2026-08-21 17:27:05.551398	challonge
Khaleesi07	Khaleesi07	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Anna70	Anna70	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
Pikachu_16	Pikachu_16	Global	Season 2026	60	2	0	0	2026-08-21 17:27:05.551398	challonge
Bigsimmy	Bigsimmy	Global	Season 2026	60	3	0	0	2026-08-21 17:27:05.551398	challonge
KOB_14	KOB_14	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Linkin_Shark	Linkin_Shark	Global	Season 2026	20	2	0	0	2026-08-21 17:27:05.551398	challonge
RedBandicoot	RedBandicoot	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
N3k019	N3k019	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Aaronjulz	Aaronjulz	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Wm7	Wm7	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Nanibleyder	Nanibleyder	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Cannyburst	Cannyburst	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
YoshiroDaiShi_26_teo	YoshiroDaiShi_26_teo	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Frakki	Frakki	Global	Season 2026	400	1	1	1	2026-08-21 17:27:05.551398	challonge
Dase05_	Dase05_	Global	Season 2026	280	1	0	1	2026-08-21 17:27:05.551398	challonge
Piramide_	Piramide_	Global	Season 2026	160	1	0	1	2026-08-21 17:27:05.551398	challonge
Vexel666	Vexel666	Global	Season 2026	120	1	0	1	2026-08-21 17:27:05.551398	challonge
Andy_bbx	Andy_bbx	Global	Season 2026	90	1	0	0	2026-08-21 17:27:05.551398	challonge
ILDISTO	ILDISTO	Global	Season 2026	90	1	0	0	2026-08-21 17:27:05.551398	challonge
AuraFarming	AuraFarming	Global	Season 2026	90	1	0	0	2026-08-21 17:27:05.551398	challonge
Matzuda	Matzuda	Global	Season 2026	90	1	0	0	2026-08-21 17:27:05.551398	challonge
Giacomo_Proiettile	Giacomo_Proiettile	Global	Season 2026	65	1	0	0	2026-08-21 17:27:05.551398	challonge
Banaleo49	Banaleo49	Global	Season 2026	65	1	0	0	2026-08-21 17:27:05.551398	challonge
Halloween5264	Halloween5264	Global	Season 2026	65	1	0	0	2026-08-21 17:27:05.551398	challonge
Sofi19	Sofi19	Global	Season 2026	65	1	0	0	2026-08-21 17:27:05.551398	challonge
IamVulgus	IamVulgus	Global	Season 2026	50	1	0	0	2026-08-21 17:27:05.551398	challonge
Raula97	Raula97	Global	Season 2026	50	1	0	0	2026-08-21 17:27:05.551398	challonge
Mago_Nero	Mago_Nero	Global	Season 2026	50	1	0	0	2026-08-21 17:27:05.551398	challonge
Mergimiliano	Mergimiliano	Global	Season 2026	50	1	0	0	2026-08-21 17:27:05.551398	challonge
Fambrini	Fambrini	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Doctor_monkey	Doctor_monkey	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
JustPlus	JustPlus	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
RyoSaeba	RyoSaeba	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
CrystalClod	CrystalClod	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Firefre	Firefre	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Dipi999	Dipi999	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Cosciu	Cosciu	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Giakos98	Giakos98	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Debyx	Debyx	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Indian_Chey7	Indian_Chey7	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Brandix	Brandix	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
LeleGianne	LeleGianne	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Tiamat27	Tiamat27	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
_vic_	_vic_	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Jacksoncross2017	Jacksoncross2017	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Loreo_	Loreo_	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Kiokka	Kiokka	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Edoardo23	Edoardo23	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Mattia17	Mattia17	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Giovanni_Stempy	Giovanni_Stempy	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Solfa3	Solfa3	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Abbandono_97	Abbandono_97	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Lirlandese	Lirlandese	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Tanjiro67	Tanjiro67	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Kriperus	Kriperus	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Matteilpro15	Matteilpro15	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Danki0_0	Danki0_0	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Hanayrim	Hanayrim	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Kira45	Kira45	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
FrancescoLuti	FrancescoLuti	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Eliopuccinelli	Eliopuccinelli	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Righello	Righello	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Liam2016	Liam2016	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Aldo_Abbaglio	Aldo_Abbaglio	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
GS9	GS9	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Gabriele10	Gabriele10	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Danielx17	Danielx17	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
YouHateBryan	YouHateBryan	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
eldefensor	eldefensor	Global	Season 2026	135	2	0	0	2026-08-21 17:27:05.551398	challonge
Kein_Tamerg	Kein_Tamerg	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Riccio97	Riccio97	Global	Season 2026	95	2	0	0	2026-08-21 17:27:05.551398	challonge
Shagor	Shagor	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
Farinella	Farinella	Global	Season 2026	95	2	0	0	2026-08-21 17:27:05.551398	challonge
Ceci91	Ceci91	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
Giovy	Giovy	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
RòX	RòX	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
MrLoba29	MrLoba29	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
drramik	drramik	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Nicolino1977	Nicolino1977	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
Laura90	Laura90	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
KKLord	KKLord	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Nastyyy27	Nastyyy27	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Francy	Francy	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Jiimmyyy	Jiimmyyy	Global	Season 2026	90	2	0	0	2026-08-21 17:27:05.551398	challonge
ThunderMatthew	ThunderMatthew	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Trexgiulio	Trexgiulio	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
keg0	keg0	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Nunze	Nunze	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Conralori	Conralori	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
LBladerLui	LBladerLui	Global	Season 2026	250	1	1	1	2026-08-21 17:27:05.551398	challonge
Nonnechik99	Nonnechik99	Global	Season 2026	100	1	0	1	2026-08-21 17:27:05.551398	challonge
yuriymo	yuriymo	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
Atarassìa - spacegames-bus	Atarassìa - spacegames-bus	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Diletta	Diletta	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
SoloBuildEsotiche	SoloBuildEsotiche	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Umbeole	Umbeole	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Konjo92	Konjo92	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
BlueMida	BlueMida	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
The Watcher	The Watcher	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Ridnegar	Ridnegar	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
D3M1GR4	D3M1GR4	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
GinTony	GinTony	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Ravezim	Ravezim	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Tano_Ferblade16	Tano_Ferblade16	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Doungeons &Dragons Niihon	Doungeons &Dragons Niihon	Global	Season 2026	300	1	1	1	2026-08-21 17:27:05.551398	challonge
magteo	magteo	Global	Season 2026	200	1	0	1	2026-08-21 17:27:05.551398	challonge
GorillaZ_98	GorillaZ_98	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Minerol1	Minerol1	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Leviatano95	Leviatano95	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
Slide_Off	Slide_Off	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
TanoST	TanoST	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
Doungeons&Dragons Niihon	Doungeons&Dragons Niihon	Global	Season 2026	300	1	1	1	2026-08-21 17:27:05.551398	challonge
Grizzly_97	Grizzly_97	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
RUMI	RUMI	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Bore33	Bore33	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Antonio Rinaldi	Antonio Rinaldi	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Loris_Phoenix	Loris_Phoenix	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Fedeco98	Fedeco98	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Soar_Ale	Soar_Ale	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Skio69	Skio69	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
LukeMcWall	LukeMcWall	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Malviobbld	Malviobbld	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
BLAYDER X	BLAYDER X	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
NathLL	NathLL	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
PietroMerola	PietroMerola	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
riiching901	riiching901	Global	Season 2026	445	3	1	1	2026-08-21 17:27:05.551398	challonge
Leo140419	Leo140419	Global	Season 2026	120	1	0	1	2026-08-21 17:27:05.551398	challonge
LucaNP	LucaNP	Global	Season 2026	535	6	0	2	2026-08-21 17:27:05.551398	challonge
Daniele_S	Daniele_S	Global	Season 2026	160	3	0	0	2026-08-21 17:27:05.551398	challonge
Depa19	Depa19	Global	Season 2026	180	5	0	0	2026-08-21 17:27:05.551398	challonge
FReechain	FReechain	Global	Season 2026	65	1	0	0	2026-08-21 17:27:05.551398	challonge
Geco91	Geco91	Global	Season 2026	65	1	0	0	2026-08-21 17:27:05.551398	challonge
IRObb	IRObb	Global	Season 2026	65	1	0	0	2026-08-21 17:27:05.551398	challonge
Mad_Blade	Mad_Blade	Global	Season 2026	230	6	0	0	2026-08-21 17:27:05.551398	challonge
Monkey_King_Tattoo	Monkey_King_Tattoo	Global	Season 2026	315	5	0	1	2026-08-21 17:27:05.551398	challonge
Shaka1985	Shaka1985	Global	Season 2026	110	4	0	0	2026-08-21 17:27:05.551398	challonge
GHOST__23	GHOST__23	Global	Season 2026	285	3	0	1	2026-08-21 17:27:05.551398	challonge
SickNova	SickNova	Global	Season 2026	280	2	0	1	2026-08-21 17:27:05.551398	challonge
Ho_pianto_sono_triste_datemi_BlastRosso	Ho_pianto_sono_triste_datemi_BlastRosso	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
plus_exe	plus_exe	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Nomade7	Nomade7	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
elbisc	elbisc	Global	Season 2026	115	4	0	1	2026-08-21 17:27:05.551398	challonge
Prof_Lele	Prof_Lele	Global	Season 2026	30	2	0	0	2026-08-21 17:27:05.551398	challonge
Podas	Podas	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
_Vento	_Vento	Global	Season 2026	100	5	0	0	2026-08-21 17:27:05.551398	challonge
ChrisZec	ChrisZec	Global	Season 2026	85	4	0	0	2026-08-21 17:27:05.551398	challonge
BladerXF	BladerXF	Global	Season 2026	55	3	0	0	2026-08-21 17:27:05.551398	challonge
Leni17	Leni17	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Tramu_BV	Tramu_BV	Global	Season 2026	450	5	1	2	2026-08-21 17:27:05.551398	challonge
Caramella72	Caramella72	Global	Season 2026	50	3	0	0	2026-08-21 17:27:05.551398	challonge
Gullit23	Gullit23	Global	Season 2026	95	2	0	0	2026-08-21 17:27:05.551398	challonge
RionX	RionX	Global	Season 2026	65	4	0	0	2026-08-21 17:27:05.551398	challonge
black0vt_TMN	black0vt_TMN	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
DOMN	DOMN	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Eclissatore	Eclissatore	Global	Season 2026	70	3	0	0	2026-08-21 17:27:05.551398	challonge
_inghetta_	_inghetta_	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Vittorino81rm	Vittorino81rm	Global	Season 2026	80	3	0	0	2026-08-21 17:27:05.551398	challonge
GerardoDelia	GerardoDelia	Global	Season 2026	255	8	0	1	2026-08-21 17:27:05.551398	challonge
Manuelo_	Manuelo_	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Hachiko_	Hachiko_	Global	Season 2026	95	2	0	0	2026-08-21 17:27:05.551398	challonge
DARIONEOLLARE	DARIONEOLLARE	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
LorenzoLSD	LorenzoLSD	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
LeoRyu	LeoRyu	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Akkaw1	Akkaw1	Global	Season 2026	70	2	0	0	2026-08-21 17:27:05.551398	challonge
Stupeficium	Stupeficium	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Turbo73	Turbo73	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
LolloNanairo	LolloNanairo	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Killva	Killva	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Mi_ha_costretto_Lorenzo	Mi_ha_costretto_Lorenzo	Global	Season 2026	140	1	0	1	2026-08-21 17:27:05.551398	challonge
VaultBoy91	VaultBoy91	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
PePe49	PePe49	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
SeccoD91	SeccoD91	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
RascalNBC	RascalNBC	Global	Season 2026	265	5	0	1	2026-08-21 17:27:05.551398	challonge
BestiaGiallaX	BestiaGiallaX	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Mhasik	Mhasik	Global	Season 2026	150	2	0	1	2026-08-21 17:27:05.551398	challonge
Racche210	Racche210	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
ErConfy_BV	ErConfy_BV	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Seppiozzo	Seppiozzo	Global	Season 2026	20	2	0	0	2026-08-21 17:27:05.551398	challonge
_Zein	_Zein	Global	Season 2026	440	5	1	2	2026-08-21 17:27:05.551398	challonge
Taccons	Taccons	Global	Season 2026	160	1	0	1	2026-08-21 17:27:05.551398	challonge
Lucifero88	Lucifero88	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
BromisS	BromisS	Global	Season 2026	780	5	2	2	2026-08-21 17:27:05.551398	challonge
Domiziano	Domiziano	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Andrea_90	Andrea_90	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Donpi2	Donpi2	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Dains_Celance	Dains_Celance	Global	Season 2026	30	2	0	0	2026-08-21 17:27:05.551398	challonge
22baymax	22baymax	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
DarkMagici4n	DarkMagici4n	Global	Season 2026	220	2	0	1	2026-08-21 17:27:05.551398	challonge
EdoLaFenice	EdoLaFenice	Global	Season 2026	100	1	0	1	2026-08-21 17:27:05.551398	challonge
Blader_F_2018	Blader_F_2018	Global	Season 2026	80	1	0	1	2026-08-21 17:27:05.551398	challonge
BeshtiOne	BeshtiOne	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
Nicolas_14	Nicolas_14	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
TommyBX	TommyBX	Global	Season 2026	70	2	0	0	2026-08-21 17:27:05.551398	challonge
Guerins98	Guerins98	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
ZyroBeastPink	ZyroBeastPink	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Luffy15	Luffy15	Global	Season 2026	40	2	0	0	2026-08-21 17:27:05.551398	challonge
xSam16	xSam16	Global	Season 2026	90	2	0	0	2026-08-21 17:27:05.551398	challonge
whiteknight_	whiteknight_	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
Raffy2016	Raffy2016	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Lorenzix	Lorenzix	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
FRENCK	FRENCK	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
GabYoshi	GabYoshi	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
LoSportivo	LoSportivo	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Daruma86	Daruma86	Global	Season 2026	90	2	0	1	2026-08-21 17:27:05.551398	challonge
ItsImogen	ItsImogen	Global	Season 2026	20	2	0	0	2026-08-21 17:27:05.551398	challonge
Fede2016	Fede2016	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
MarioShark	MarioShark	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Edoardodg	Edoardodg	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
loleva	loleva	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Unhunexio	Unhunexio	Global	Season 2026	250	1	1	1	2026-08-21 17:27:05.551398	challonge
SansOnne	SansOnne	Global	Season 2026	160	1	0	1	2026-08-21 17:27:05.551398	challonge
sdwDancer	sdwDancer	Global	Season 2026	100	1	0	1	2026-08-21 17:27:05.551398	challonge
Scooby_Nac	Scooby_Nac	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
FranLu	FranLu	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
Vincenzo68	Vincenzo68	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
NordicPain	NordicPain	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Allessio1702	Allessio1702	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Karletto	Karletto	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Giuseppe2018	Giuseppe2018	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Mattia16	Mattia16	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
RikiAndrea	RikiAndrea	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
GIOMASKpro355	GIOMASKpro355	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Supporto_Emotivo	Supporto_Emotivo	Global	Season 2026	285	2	0	1	2026-08-21 17:27:05.551398	challonge
Dadolow98	Dadolow98	Global	Season 2026	140	1	0	1	2026-08-21 17:27:05.551398	challonge
Sikaka	Sikaka	Global	Season 2026	155	3	0	0	2026-08-21 17:27:05.551398	challonge
Kute	Kute	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Casper14	Casper14	Global	Season 2026	70	2	0	0	2026-08-21 17:27:05.551398	challonge
xXAX96Xx	xXAX96Xx	Global	Season 2026	125	2	0	0	2026-08-21 17:27:05.551398	challonge
Gigigi_	Gigigi_	Global	Season 2026	180	3	0	0	2026-08-21 17:27:05.551398	challonge
lil_LOTC	lil_LOTC	Global	Season 2026	160	2	0	1	2026-08-21 17:27:05.551398	challonge
Tomahhh	Tomahhh	Global	Season 2026	70	4	0	0	2026-08-21 17:27:05.551398	challonge
ilFaraone96	ilFaraone96	Global	Season 2026	60	2	0	0	2026-08-21 17:27:05.551398	challonge
Thiass	Thiass	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Ma_stro_nzo	Ma_stro_nzo	Global	Season 2026	120	2	0	1	2026-08-21 17:27:05.551398	challonge
Sarcai	Sarcai	Global	Season 2026	75	4	0	0	2026-08-21 17:27:05.551398	challonge
Benobeno	Benobeno	Global	Season 2026	160	4	0	0	2026-08-21 17:27:05.551398	challonge
Bass96	Bass96	Global	Season 2026	115	4	0	0	2026-08-21 17:27:05.551398	challonge
Serse	Serse	Global	Season 2026	60	2	0	0	2026-08-21 17:27:05.551398	challonge
Bosco027	Bosco027	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
_Aeonax_	_Aeonax_	Global	Season 2026	155	3	0	0	2026-08-21 17:27:05.551398	challonge
Teschio96	Teschio96	Global	Season 2026	30	2	0	0	2026-08-21 17:27:05.551398	challonge
N_O_X_	N_O_X_	Global	Season 2026	30	2	0	0	2026-08-21 17:27:05.551398	challonge
GrazyGip	GrazyGip	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Don Lorenzo	Don Lorenzo	Global	Season 2026	55	3	0	0	2026-08-21 17:27:05.551398	challonge
Marmaxx	Marmaxx	Global	Season 2026	25	2	0	0	2026-08-21 17:27:05.551398	challonge
Citpit	Citpit	Global	Season 2026	70	3	0	0	2026-08-21 17:27:05.551398	challonge
Squalessandro	Squalessandro	Global	Season 2026	25	2	0	0	2026-08-21 17:27:05.551398	challonge
Kute_	Kute_	Global	Season 2026	370	2	1	1	2026-08-21 17:27:05.551398	challonge
Ivoboye	Ivoboye	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Kh0zaky	Kh0zaky	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Yurix01	Yurix01	Global	Season 2026	30	2	0	0	2026-08-21 17:27:05.551398	challonge
La_Jade	La_Jade	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
EdoPambi	EdoPambi	Global	Season 2026	25	2	0	0	2026-08-21 17:27:05.551398	challonge
SigIvan	SigIvan	Global	Season 2026	120	1	0	1	2026-08-21 17:27:05.551398	challonge
Gibby14	Gibby14	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Salas_1	Salas_1	Global	Season 2026	375	3	1	1	2026-08-21 17:27:05.551398	challonge
Ma_stron_zo	Ma_stron_zo	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
gorillaz	gorillaz	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Malevolovo	Malevolovo	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Toaultra	Toaultra	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
FrancisRookie96	FrancisRookie96	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Vitto95	Vitto95	Global	Season 2026	200	1	0	1	2026-08-21 17:27:05.551398	challonge
Talion99	Talion99	Global	Season 2026	90	1	0	1	2026-08-21 17:27:05.551398	challonge
Davide	Davide	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Midorina	Midorina	Global	Season 2026	85	2	0	0	2026-08-21 17:27:05.551398	challonge
Coppyy	Coppyy	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Claudio94	Claudio94	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Alemartini	Alemartini	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
PerSempre	PerSempre	Global	Season 2026	645	6	1	3	2026-08-21 17:27:05.551398	challonge
Luca_Capoch	Luca_Capoch	Global	Season 2026	350	3	0	2	2026-08-21 17:27:05.551398	challonge
Sagro	Sagro	Global	Season 2026	100	1	0	1	2026-08-21 17:27:05.551398	challonge
Batmann91	Batmann91	Global	Season 2026	240	3	0	2	2026-08-21 17:27:05.551398	challonge
Blair888	Blair888	Global	Season 2026	85	3	0	0	2026-08-21 17:27:05.551398	challonge
Ilbadrone	Ilbadrone	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
Luca_Bellaveglia	Luca_Bellaveglia	Global	Season 2026	560	3	2	2	2026-08-21 17:27:05.551398	challonge
NovaBless	NovaBless	Global	Season 2026	105	3	0	0	2026-08-21 17:27:05.551398	challonge
CALPISREDCOMET	CALPISREDCOMET	Global	Season 2026	75	3	0	0	2026-08-21 17:27:05.551398	challonge
Pika__27	Pika__27	Global	Season 2026	100	3	0	0	2026-08-21 17:27:05.551398	challonge
Edo	Edo	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
Darkmok	Darkmok	Global	Season 2026	90	3	0	0	2026-08-21 17:27:05.551398	challonge
Lallalalla	Lallalalla	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Konau	Konau	Global	Season 2026	100	4	0	0	2026-08-21 17:27:05.551398	challonge
Fle95a	Fle95a	Global	Season 2026	80	3	0	0	2026-08-21 17:27:05.551398	challonge
Freud911	Freud911	Global	Season 2026	160	1	0	1	2026-08-21 17:27:05.551398	challonge
BigRicco	BigRicco	Global	Season 2026	80	1	0	1	2026-08-21 17:27:05.551398	challonge
Deku90	Deku90	Global	Season 2026	100	2	0	0	2026-08-21 17:27:05.551398	challonge
Lucacolt	Lucacolt	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Rosefield95	Rosefield95	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Bio__	Bio__	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
TheNask	TheNask	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Dragosandro	Dragosandro	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Deadnos	Deadnos	Global	Season 2026	100	1	0	1	2026-08-21 17:27:05.551398	challonge
Boo37	Boo37	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
Sagro_AFST	Sagro_AFST	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
UNDER100	UNDER100	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
Thagomizer	Thagomizer	Global	Season 2026	405	4	0	2	2026-08-21 17:27:05.551398	challonge
El_Olvido	El_Olvido	Global	Season 2026	140	1	0	1	2026-08-21 17:27:05.551398	challonge
Sampei_the_Blader	Sampei_the_Blader	Global	Season 2026	230	2	0	2	2026-08-21 17:27:05.551398	challonge
JasonX_10	JasonX_10	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Leventiel	Leventiel	Global	Season 2026	135	2	0	0	2026-08-21 17:27:05.551398	challonge
Gab_17	Gab_17	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
Botta00	Botta00	Global	Season 2026	145	3	0	0	2026-08-21 17:27:05.551398	challonge
JackC84	JackC84	Global	Season 2026	65	3	0	0	2026-08-21 17:27:05.551398	challonge
RagazzoScheletro	RagazzoScheletro	Global	Season 2026	110	2	0	0	2026-08-21 17:27:05.551398	challonge
Malato_per_favore	Malato_per_favore	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Vichingo	Vichingo	Global	Season 2026	100	2	0	0	2026-08-21 17:27:05.551398	challonge
PartisanTunic	PartisanTunic	Global	Season 2026	60	2	0	0	2026-08-21 17:27:05.551398	challonge
Xayrevers45	Xayrevers45	Global	Season 2026	40	2	0	0	2026-08-21 17:27:05.551398	challonge
YukiYux	YukiYux	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Fabbo_97	Fabbo_97	Global	Season 2026	75	3	0	0	2026-08-21 17:27:05.551398	challonge
HoRubatoIlFondoCassa	HoRubatoIlFondoCassa	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
LoydNinja	LoydNinja	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
fedone	fedone	Global	Season 2026	25	2	0	0	2026-08-21 17:27:05.551398	challonge
Quereloperdiffamazione	Quereloperdiffamazione	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Bakudomo	Bakudomo	Global	Season 2026	140	3	0	1	2026-08-21 17:27:05.551398	challonge
RyanT_07	RyanT_07	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Zio_Fra74	Zio_Fra74	Global	Season 2026	30	2	0	0	2026-08-21 17:27:05.551398	challonge
XTHOM	XTHOM	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
_Steffo_	_Steffo_	Global	Season 2026	100	2	0	1	2026-08-21 17:27:05.551398	challonge
Goburin69	Goburin69	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
AleF81	AleF81	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Kooiji	Kooiji	Global	Season 2026	240	1	0	1	2026-08-21 17:27:05.551398	challonge
AmetDj	AmetDj	Global	Season 2026	110	1	0	1	2026-08-21 17:27:05.551398	challonge
Samublade	Samublade	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Kigen	Kigen	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
Valebisso	Valebisso	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Francesco15	Francesco15	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Enea_Mazza	Enea_Mazza	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Seiesse	Seiesse	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
GabrieleChiarenza	GabrieleChiarenza	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
VoxDubium	VoxDubium	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
LDL18	LDL18	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Zigozago284	Zigozago284	Global	Season 2026	115	2	0	1	2026-08-21 17:27:05.551398	challonge
Aokira77	Aokira77	Global	Season 2026	95	2	0	1	2026-08-21 17:27:05.551398	challonge
KnightK	KnightK	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
cacci351	cacci351	Global	Season 2026	95	3	0	0	2026-08-21 17:27:05.551398	challonge
Zurukuma	Zurukuma	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
RikyFire	RikyFire	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
LordTz	LordTz	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Dark_ritow	Dark_ritow	Global	Season 2026	175	4	0	1	2026-08-21 17:27:05.551398	challonge
ThePitcher	ThePitcher	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
MaccheRonin	MaccheRonin	Global	Season 2026	95	3	0	0	2026-08-21 17:27:05.551398	challonge
Maso19	Maso19	Global	Season 2026	20	2	0	0	2026-08-21 17:27:05.551398	challonge
BLADEREMA	BLADEREMA	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Gabriele19	Gabriele19	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
UnamxriDotExe	UnamxriDotExe	Global	Season 2026	150	1	1	1	2026-08-21 17:27:05.551398	challonge
Misosone	Misosone	Global	Season 2026	20	1	0	0	2026-08-21 17:27:05.551398	challonge
fonty94	fonty94	Global	Season 2026	20	1	0	0	2026-08-21 17:27:05.551398	challonge
Andrytrik	Andrytrik	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
HarimaKenji	HarimaKenji	Global	Season 2026	120	1	0	1	2026-08-21 17:27:05.551398	challonge
Pico7	Pico7	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
M4rti	M4rti	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
Piero145	Piero145	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
Khepri01	Khepri01	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
VentoAran	VentoAran	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
RoboRobo	RoboRobo	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
D_Hakkai	D_Hakkai	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
SuperSonicGjo	SuperSonicGjo	Global	Season 2026	30	2	0	0	2026-08-21 17:27:05.551398	challonge
Pigi_fenix	Pigi_fenix	Global	Season 2026	170	3	0	1	2026-08-21 17:27:05.551398	challonge
hellboy_76	hellboy_76	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Flavio2015	Flavio2015	Global	Season 2026	20	2	0	0	2026-08-21 17:27:05.551398	challonge
Maxdavi100	Maxdavi100	Global	Season 2026	50	3	0	0	2026-08-21 17:27:05.551398	challonge
BusterDran	BusterDran	Global	Season 2026	230	3	0	2	2026-08-21 17:27:05.551398	challonge
Leon1990	Leon1990	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Leoshadow	Leoshadow	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
EgilTheWanderer	EgilTheWanderer	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
FrancoGalbazzi	FrancoGalbazzi	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Ragnarovi	Ragnarovi	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
hellboy_09	hellboy_09	Global	Season 2026	75	2	0	0	2026-08-21 17:27:05.551398	challonge
LupoAlbano97	LupoAlbano97	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
BladeryX	BladeryX	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
GIULIODARK	GIULIODARK	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Flavietto_8	Flavietto_8	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Topodadoccia	Topodadoccia	Global	Season 2026	240	1	0	1	2026-08-21 17:27:05.551398	challonge
Polargh	Polargh	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
Wukan	Wukan	Global	Season 2026	80	1	0	0	2026-08-21 17:27:05.551398	challonge
FetusGrinder	FetusGrinder	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
SickShok	SickShok	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
Jack_CBR	Jack_CBR	Global	Season 2026	40	1	0	0	2026-08-21 17:27:05.551398	challonge
ZioGabrio	ZioGabrio	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Rorasev	Rorasev	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Senza_Rod_sono_una_frode	Senza_Rod_sono_una_frode	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Big_TunaX	Big_TunaX	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Artorias94	Artorias94	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
MatteoFolle	MatteoFolle	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Napo_bx	Napo_bx	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Bumbey	Bumbey	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Julescio	Julescio	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Trottolina_Amorosa	Trottolina_Amorosa	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
picci8	picci8	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Turbo73_Ruben	Turbo73_Ruben	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
Themistokles16	Themistokles16	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Aridran	Aridran	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Drysepht	Drysepht	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
BleaderA	BleaderA	Global	Season 2026	260	2	1	1	2026-08-21 17:27:05.551398	challonge
Youngsnapp10	Youngsnapp10	Global	Season 2026	175	2	0	1	2026-08-21 17:27:05.551398	challonge
anima_L	anima_L	Global	Season 2026	100	1	0	1	2026-08-21 17:27:05.551398	challonge
Noktis1O	Noktis1O	Global	Season 2026	80	1	0	1	2026-08-21 17:27:05.551398	challonge
Donguz	Donguz	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
PoverettoKid	PoverettoKid	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
HarukoEbi	HarukoEbi	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
Spadaccino	Spadaccino	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
MetalRaffo	MetalRaffo	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
KapraStyle	KapraStyle	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Rosy66	Rosy66	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Espionerion	Espionerion	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Eminenza_grigia	Eminenza_grigia	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
LasagnaVulvosa	LasagnaVulvosa	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
peps10	peps10	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
IL_PL_99	IL_PL_99	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Leone400	Leone400	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
SharkDav_98	SharkDav_98	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Andy_One	Andy_One	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Jhon	Jhon	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Rengoku10	Rengoku10	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
LPhoenix1	LPhoenix1	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Jacksada	Jacksada	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
ElevateKid	ElevateKid	Global	Season 2026	250	1	1	1	2026-08-21 17:27:05.551398	challonge
YoUnG_SnApP10	YoUnG_SnApP10	Global	Season 2026	100	1	0	1	2026-08-21 17:27:05.551398	challonge
Autocratico fascista	Autocratico fascista	Global	Season 2026	60	1	0	0	2026-08-21 17:27:05.551398	challonge
ZzaWarudo	ZzaWarudo	Global	Season 2026	105	2	0	0	2026-08-21 17:27:05.551398	challonge
Robides	Robides	Global	Season 2026	105	3	0	0	2026-08-21 17:27:05.551398	challonge
Goblin_69	Goblin_69	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Xlarax	Xlarax	Global	Season 2026	85	2	0	0	2026-08-21 17:27:05.551398	challonge
_Gabii_	_Gabii_	Global	Season 2026	45	3	0	0	2026-08-21 17:27:05.551398	challonge
Seven861	Seven861	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
TheGhost2015	TheGhost2015	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Rayblad25	Rayblad25	Global	Season 2026	35	3	0	0	2026-08-21 17:27:05.551398	challonge
LeonardoDiCarpi	LeonardoDiCarpi	Global	Season 2026	120	1	0	1	2026-08-21 17:27:05.551398	challonge
Nicx15	Nicx15	Global	Season 2026	100	2	0	1	2026-08-21 17:27:05.551398	challonge
Pesyb	Pesyb	Global	Season 2026	100	2	0	0	2026-08-21 17:27:05.551398	challonge
TheSituation14	TheSituation14	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Seven	Seven	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Devis_Ucarlo	Devis_Ucarlo	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
DystopianViper39	DystopianViper39	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
Blaster_Chimera98	Blaster_Chimera98	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
Blader_A15	Blader_A15	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
_Jinx	_Jinx	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Buster_Duck	Buster_Duck	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Feder000	Feder000	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Shackur87	Shackur87	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
MatteMantovani	MatteMantovani	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Hudi15	Hudi15	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
_Sketchy_	_Sketchy_	Global	Season 2026	60	2	0	0	2026-08-21 17:27:05.551398	challonge
GiacomoLuzzi	GiacomoLuzzi	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
_DkAngelo_	_DkAngelo_	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
gorillaz3	gorillaz3	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
ToX	ToX	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
_Ezecutor-iBh	_Ezecutor-iBh	Global	Season 2026	140	1	0	1	2026-08-21 17:27:05.551398	challonge
Walter	Walter	Global	Season 2026	110	1	0	1	2026-08-21 17:27:05.551398	challonge
Oh_Nico	Oh_Nico	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
Wolverine23	Wolverine23	Global	Season 2026	55	1	0	0	2026-08-21 17:27:05.551398	challonge
BonnyBong	BonnyBong	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
N2Z2	N2Z2	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
TORO	TORO	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Cico	Cico	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Manolo10	Manolo10	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Feder_X	Feder_X	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
ChuckNorris10	ChuckNorris10	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
GustavoLaFessa	GustavoLaFessa	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
DarC12	DarC12	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
L_MAMA	L_MAMA	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
ZORO15	ZORO15	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
Misellazzo	Misellazzo	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
xGabiix	xGabiix	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
Miky77	Miky77	Global	Season 2026	45	2	0	0	2026-08-21 17:27:05.551398	challonge
DaggerFrederik	DaggerFrederik	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Blader_Richi22	Blader_Richi22	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
unicornorologio	unicornorologio	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Sylveon11	Sylveon11	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
BabboBurstale	BabboBurstale	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
Tonix93	Tonix93	Global	Season 2026	70	1	0	0	2026-08-21 17:27:05.551398	challonge
Vally34	Vally34	Global	Season 2026	45	1	0	0	2026-08-21 17:27:05.551398	challonge
Cosmo89xD	Cosmo89xD	Global	Season 2026	30	1	0	0	2026-08-21 17:27:05.551398	challonge
Sneezyreal_10	Sneezyreal_10	Global	Season 2026	15	1	0	0	2026-08-21 17:27:05.551398	challonge
DonLorenz0	DonLorenz0	Global	Season 2026	10	1	0	0	2026-08-21 17:27:05.551398	challonge
\.


--
-- Data for Name: ratchet_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ratchet_stats (ratchet, primi_posti, secondi_posti, terzi_posti, punteggio_totale, season, quarti_posti) FROM stdin;
9-80	0	0	0	0	Off Season 2025	0
1-60	9	8	15	4071	Off Season 2025	0
0-80	0	0	0	0	Off Season 2025	0
3-70	0	1	1	144	Off Season 2025	0
6-60	0	1	1	149	Off Season 2025	0
3-80	0	0	1	40	Off Season 2025	0
4-80	0	0	0	0	Off Season 2025	0
9-70	1	1	1	616	Off Season 2025	0
0-60	0	0	0	0	Off Season 2025	0
5-60	1	2	6	1091	Off Season 2025	0
7-60	0	0	2	160	Off Season 2025	0
4-60	1	1	4	650	Off Season 2025	0
6-80	0	0	0	0	Off Season 2025	0
6-70	0	0	0	0	Off Season 2025	0
4-50	3	2	0	708	Off Season 2025	0
7-80	0	0	0	0	Off Season 2025	0
7-70	0	0	0	0	Off Season 2025	0
2-70	0	0	0	0	Off Season 2025	0
3-60	1	4	14	1991	Off Season 2025	0
2-60	0	0	0	0	Off Season 2025	0
5-70	0	0	0	0	Off Season 2025	0
M-85	0	0	0	0	Off Season 2025	0
9-60	8	7	10	3557	Off Season 2025	0
0-70	0	0	0	0	Off Season 2025	0
1-70	6	2	2	1551	Off Season 2025	0
9-65	0	0	0	0	Off Season 2025	0
1-80	0	0	0	0	Off Season 2025	0
5-80	0	0	0	0	Off Season 2025	0
4-70	0	0	0	0	Off Season 2025	0
None	0	1	0	56	Off Season 2025	0
4-55	0	0	0	0	Off Season 2025	0
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version, name, checksum, applied_at) FROM stdin;
0000	0000_mushy_lucky_pierre.sql	57ab8284d316e1df	2026-08-21 14:51:56.02123+00
0001	0001_add_tournaments.sql	b3bd770a6117416a	2026-08-21 14:51:56.02123+00
0002	0002_cm_refactor.sql	6b82c3fb0c0fc0b2	2026-08-21 14:51:56.02123+00
0003	0003_external_player_combos_scoring.sql	28e45c677b76e93a	2026-08-21 14:51:56.02123+00
0004	0004_update_external_player_combos_fk.sql	e6c01737a6fff683	2026-08-21 14:51:56.02123+00
0005	0005_add_season_to_combo_stats_pk.sql	cfff68e75c2aa354	2026-08-21 14:51:56.02123+00
0006	0006_add_missing_stats_pks.sql	cbd4f4a8f51dfd12	2026-08-21 14:51:56.02123+00
0007	0007_unified_meta_view.sql	c989122e2caaa5ce	2026-08-21 14:51:56.02123+00
0008	0008_stats_season_primary_keys.sql	051222be9b948927	2026-08-21 14:51:56.02123+00
0009	0009_add_tournament_name_to_challonge_combos.sql	9fa4499120a139b2	2026-08-21 14:51:56.02123+00
0010	0010_rag_foundations.sql	d0a437e879f9f2c9	2026-08-21 19:13:53.159487+00
0011	0011_merge_knight_shield.sql	f5c97a5e016b9801	2026-08-21 19:25:36.678373+00
0012	0012_meta_snapshot.sql	f3ff97c6f3b5cd29	2026-08-22 13:50:34.643368+00
0013	0013_chat.sql	d64666a9f080ab72	2026-08-22 14:03:37.883253+00
0014	0014_chat_quota.sql	8b35fd811d6b1d2f	2026-08-24 10:30:12.887753+00
0015	0015_chat_error.sql	ed55b8fa1f283569	2026-08-24 10:30:12.887753+00
0016	0016_unaccent_search.sql	cb9de14c45bfcff5	2026-08-24 10:30:12.887753+00
0017	0017_merge_quetzalcoatlus.sql	34a3c7eed8938cdf	2026-08-24 10:30:26.904463+00
0018	0018_merge_t_rex.sql	03f91b29f371a3a2	2026-08-24 10:36:31.000886+00
0019	0019_spinosaurus_is_not_tyrannoroar.sql	fb85fef330ca1cc0	2026-08-24 10:44:57.80214+00
0020	0020_drop_wikitext_aliases.sql	c759c54adfc6d23b	2026-08-24 10:47:08.145626+00
\.


--
-- Name: challonge_match_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.challonge_match_results_id_seq', 775, true);


--
-- Name: challonge_reported_combos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.challonge_reported_combos_id_seq', 73, true);


--
-- Name: chat_error_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_error_id_seq', 5, true);


--
-- Name: chat_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_message_id_seq', 60, true);


--
-- Name: chat_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_session_id_seq', 44, true);


--
-- Name: clubs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clubs_id_seq', 18, true);


--
-- Name: kb_chunk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kb_chunk_id_seq', 2504, true);


--
-- Name: kb_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kb_document_id_seq', 1206, true);


--
-- Name: kb_ingest_run_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kb_ingest_run_id_seq', 29, true);


--
-- Name: meta_snapshot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meta_snapshot_id_seq', 755, true);


--
-- Name: user_aliases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_aliases_id_seq', 42, true);


--
-- Name: admin_audit_logs admin_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_logs
    ADD CONSTRAINT admin_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: assist_blade_stats assist_blade_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assist_blade_stats
    ADD CONSTRAINT assist_blade_stats_pkey PRIMARY KEY (assist_blade, season);


--
-- Name: bit_stats bit_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bit_stats
    ADD CONSTRAINT bit_stats_pkey PRIMARY KEY ("bit", season);


--
-- Name: blade_stats blade_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blade_stats
    ADD CONSTRAINT blade_stats_pkey PRIMARY KEY (blade, season);


--
-- Name: challonge_match_results challonge_match_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challonge_match_results
    ADD CONSTRAINT challonge_match_results_pkey PRIMARY KEY (id);


--
-- Name: challonge_match_results challonge_match_results_tournament_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challonge_match_results
    ADD CONSTRAINT challonge_match_results_tournament_id_unique UNIQUE (tournament_id);


--
-- Name: challonge_players challonge_players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challonge_players
    ADD CONSTRAINT challonge_players_pkey PRIMARY KEY (id);


--
-- Name: challonge_reported_combos challonge_reported_combos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challonge_reported_combos
    ADD CONSTRAINT challonge_reported_combos_pkey PRIMARY KEY (id);


--
-- Name: chat_error chat_error_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_error
    ADD CONSTRAINT chat_error_pkey PRIMARY KEY (id);


--
-- Name: chat_error chat_error_reference_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_error
    ADD CONSTRAINT chat_error_reference_key UNIQUE (reference);


--
-- Name: chat_message chat_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_pkey PRIMARY KEY (id);


--
-- Name: chat_session chat_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_session
    ADD CONSTRAINT chat_session_pkey PRIMARY KEY (id);


--
-- Name: clubs clubs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clubs
    ADD CONSTRAINT clubs_pkey PRIMARY KEY (id);


--
-- Name: cm_match_results cm_match_results_tournament_id_player_id_combo_number_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cm_match_results
    ADD CONSTRAINT cm_match_results_tournament_id_player_id_combo_number_pk PRIMARY KEY (tournament_id, player_id, combo_number);


--
-- Name: cm_players cm_players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cm_players
    ADD CONSTRAINT cm_players_pkey PRIMARY KEY (id);


--
-- Name: combo_stats combo_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.combo_stats
    ADD CONSTRAINT combo_stats_pkey PRIMARY KEY (blade, assist_blade, ratchet, "bit", lock_chip, season);


--
-- Name: component_alias component_alias_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component_alias
    ADD CONSTRAINT component_alias_pkey PRIMARY KEY (alias_norm, slug);


--
-- Name: component_registry component_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component_registry
    ADD CONSTRAINT component_registry_pkey PRIMARY KEY (slug);


--
-- Name: component_registry component_registry_slot_canonical_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component_registry
    ADD CONSTRAINT component_registry_slot_canonical_name_key UNIQUE (slot, canonical_name);


--
-- Name: external_api_cache external_api_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_api_cache
    ADD CONSTRAINT external_api_cache_pkey PRIMARY KEY (cache_key);


--
-- Name: external_player_combos external_player_combos_tournament_id_player_id_combo_number_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_player_combos
    ADD CONSTRAINT external_player_combos_tournament_id_player_id_combo_number_pk PRIMARY KEY (tournament_id, player_id, combo_number);


--
-- Name: favorite_combos favorite_combos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_combos
    ADD CONSTRAINT favorite_combos_pkey PRIMARY KEY (id);


--
-- Name: favorite_deck_combos favorite_deck_combos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_deck_combos
    ADD CONSTRAINT favorite_deck_combos_pkey PRIMARY KEY (id);


--
-- Name: favorite_decks favorite_decks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_decks
    ADD CONSTRAINT favorite_decks_pkey PRIMARY KEY (id);


--
-- Name: kb_chunk kb_chunk_document_id_ordinal_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_chunk
    ADD CONSTRAINT kb_chunk_document_id_ordinal_key UNIQUE (document_id, ordinal);


--
-- Name: kb_chunk kb_chunk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_chunk
    ADD CONSTRAINT kb_chunk_pkey PRIMARY KEY (id);


--
-- Name: kb_document kb_document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_document
    ADD CONSTRAINT kb_document_pkey PRIMARY KEY (id);


--
-- Name: kb_ingest_run kb_ingest_run_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_ingest_run
    ADD CONSTRAINT kb_ingest_run_pkey PRIMARY KEY (id);


--
-- Name: lock_chip_stats lock_chip_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lock_chip_stats
    ADD CONSTRAINT lock_chip_stats_pkey PRIMARY KEY (lock_chip, season);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: meta_snapshot meta_snapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meta_snapshot
    ADD CONSTRAINT meta_snapshot_pkey PRIMARY KEY (id);


--
-- Name: player_regional_stats player_regional_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_regional_stats
    ADD CONSTRAINT player_regional_stats_pkey PRIMARY KEY (player_id, region, season, platform);


--
-- Name: ratchet_stats ratchet_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ratchet_stats
    ADD CONSTRAINT ratchet_stats_pkey PRIMARY KEY (ratchet, season);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: user_aliases user_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_aliases
    ADD CONSTRAINT user_aliases_pkey PRIMARY KEY (id);


--
-- Name: users users_challonge_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_challonge_id_key UNIQUE (challonge_id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: admin_audit_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_action_idx ON public.admin_audit_logs USING btree (action);


--
-- Name: admin_audit_tournament_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_tournament_idx ON public.admin_audit_logs USING btree (tournament_id);


--
-- Name: chat_error_kind_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_error_kind_idx ON public.chat_error USING btree (kind, created_at DESC);


--
-- Name: chat_error_recent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_error_recent_idx ON public.chat_error USING btree (created_at DESC);


--
-- Name: chat_message_abstained_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_abstained_idx ON public.chat_message USING btree (created_at DESC) WHERE abstained;


--
-- Name: chat_message_feedback_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_feedback_idx ON public.chat_message USING btree (feedback) WHERE (feedback <> 0);


--
-- Name: chat_message_phantom_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_phantom_idx ON public.chat_message USING btree (created_at) WHERE (phantom_citations <> '[]'::jsonb);


--
-- Name: chat_message_session_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_session_idx ON public.chat_message USING btree (session_id, created_at);


--
-- Name: chat_session_ip_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_session_ip_idx ON public.chat_session USING btree (client_ip, created_at DESC) WHERE (client_ip IS NOT NULL);


--
-- Name: chat_session_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_session_user_idx ON public.chat_session USING btree (user_id, last_message_at DESC);


--
-- Name: cm_match_results_player_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cm_match_results_player_idx ON public.cm_match_results USING btree (player_id);


--
-- Name: cm_match_results_tournament_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cm_match_results_tournament_idx ON public.cm_match_results USING btree (tournament_id);


--
-- Name: component_alias_norm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX component_alias_norm_idx ON public.component_alias USING btree (alias_norm);


--
-- Name: component_alias_trgm_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX component_alias_trgm_idx ON public.component_alias USING gin (alias_norm public.gin_trgm_ops);


--
-- Name: external_player_combos_combo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX external_player_combos_combo_idx ON public.external_player_combos USING btree (blade, ratchet, "bit");


--
-- Name: external_player_combos_player_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX external_player_combos_player_idx ON public.external_player_combos USING btree (player_id);


--
-- Name: external_player_combos_tournament_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX external_player_combos_tournament_idx ON public.external_player_combos USING btree (tournament_id);


--
-- Name: idx_user_aliases_lower_alias; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_aliases_lower_alias ON public.user_aliases USING btree (lower(alias));


--
-- Name: kb_chunk_code_tokens_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kb_chunk_code_tokens_idx ON public.kb_chunk USING gin (code_tokens);


--
-- Name: kb_chunk_document_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kb_chunk_document_idx ON public.kb_chunk USING btree (document_id);


--
-- Name: kb_chunk_embedding_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kb_chunk_embedding_idx ON public.kb_chunk USING hnsw (embedding public.vector_cosine_ops) WITH (m='16', ef_construction='64');


--
-- Name: kb_chunk_meta_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kb_chunk_meta_idx ON public.kb_chunk USING gin (meta jsonb_path_ops);


--
-- Name: kb_chunk_tsv_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kb_chunk_tsv_idx ON public.kb_chunk USING gin (tsv);


--
-- Name: kb_document_live_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX kb_document_live_source_idx ON public.kb_document USING btree (source_path) WHERE (superseded_at IS NULL);


--
-- Name: kb_document_slug_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kb_document_slug_idx ON public.kb_document USING btree (slug) WHERE (superseded_at IS NULL);


--
-- Name: login_attempts_attempted_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX login_attempts_attempted_at_idx ON public.login_attempts USING btree (attempted_at);


--
-- Name: login_attempts_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX login_attempts_email_idx ON public.login_attempts USING btree (email);


--
-- Name: login_attempts_ip_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX login_attempts_ip_idx ON public.login_attempts USING btree (ip_address);


--
-- Name: meta_snapshot_bit_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX meta_snapshot_bit_idx ON public.meta_snapshot USING btree ("bit");


--
-- Name: meta_snapshot_blade_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX meta_snapshot_blade_idx ON public.meta_snapshot USING btree (blade);


--
-- Name: meta_snapshot_ratchet_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX meta_snapshot_ratchet_idx ON public.meta_snapshot USING btree (ratchet);


--
-- Name: meta_snapshot_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX meta_snapshot_source_idx ON public.meta_snapshot USING btree (source, captured_at DESC);


--
-- Name: player_platform_stats_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX player_platform_stats_idx ON public.player_platform_stats USING btree (nickname, platform);


--
-- Name: session_expire_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX session_expire_idx ON public.session USING btree (expire);


--
-- Name: top_component_snapshot_ct_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX top_component_snapshot_ct_idx ON public.top_component_snapshot USING btree (component_type);


--
-- Name: top_component_snapshot_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX top_component_snapshot_name_idx ON public.top_component_snapshot USING btree (name);


--
-- Name: top_component_snapshot_score_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX top_component_snapshot_score_idx ON public.top_component_snapshot USING btree (punteggio_totale DESC);


--
-- Name: top_component_snapshot_season_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX top_component_snapshot_season_idx ON public.top_component_snapshot USING btree (season);


--
-- Name: top_component_snapshot_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX top_component_snapshot_unique ON public.top_component_snapshot USING btree (component_type, name, season);


--
-- Name: unique_user_tournament_combo_num_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_user_tournament_combo_num_idx ON public.challonge_reported_combos USING btree (user_id, tournament_id, combo_number);


--
-- Name: user_aliases_alias_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_aliases_alias_idx ON public.user_aliases USING btree (alias);


--
-- Name: user_aliases_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_aliases_user_id_idx ON public.user_aliases USING btree (user_id);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_token_idx ON public.users USING btree (verification_token);


--
-- Name: admin_audit_logs admin_audit_logs_admin_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_logs
    ADD CONSTRAINT admin_audit_logs_admin_user_id_users_id_fk FOREIGN KEY (admin_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: challonge_reported_combos challonge_reported_combos_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challonge_reported_combos
    ADD CONSTRAINT challonge_reported_combos_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_error chat_error_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_error
    ADD CONSTRAINT chat_error_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_session(id) ON DELETE SET NULL;


--
-- Name: chat_message chat_message_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.chat_session(id) ON DELETE CASCADE;


--
-- Name: chat_session chat_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_session
    ADD CONSTRAINT chat_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: cm_match_results cm_match_results_player_id_cm_players_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cm_match_results
    ADD CONSTRAINT cm_match_results_player_id_cm_players_id_fk FOREIGN KEY (player_id) REFERENCES public.cm_players(id) ON DELETE CASCADE;


--
-- Name: component_alias component_alias_slug_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component_alias
    ADD CONSTRAINT component_alias_slug_fkey FOREIGN KEY (slug) REFERENCES public.component_registry(slug) ON DELETE CASCADE;


--
-- Name: external_player_combos external_player_combos_player_id_cm_players_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_player_combos
    ADD CONSTRAINT external_player_combos_player_id_cm_players_id_fk FOREIGN KEY (player_id) REFERENCES public.cm_players(id) ON DELETE CASCADE;


--
-- Name: favorite_combos favorite_combos_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_combos
    ADD CONSTRAINT favorite_combos_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: favorite_deck_combos favorite_deck_combos_deck_id_favorite_decks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_deck_combos
    ADD CONSTRAINT favorite_deck_combos_deck_id_favorite_decks_id_fk FOREIGN KEY (deck_id) REFERENCES public.favorite_decks(id) ON DELETE CASCADE;


--
-- Name: favorite_decks favorite_decks_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorite_decks
    ADD CONSTRAINT favorite_decks_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kb_chunk kb_chunk_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_chunk
    ADD CONSTRAINT kb_chunk_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.kb_document(id) ON DELETE CASCADE;


--
-- Name: kb_document kb_document_slug_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_document
    ADD CONSTRAINT kb_document_slug_fkey FOREIGN KEY (slug) REFERENCES public.component_registry(slug) ON DELETE RESTRICT;


--
-- Name: player_platform_stats; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.player_platform_stats;


--
-- Name: top_component_snapshot; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.top_component_snapshot;


--
-- PostgreSQL database dump complete
--

\unrestrict AZyNHf6cS8Vq5wOXzkWubN06zyWp85c5G8SveYyQ0MPVT7MDGJGIwuzaOVnave9

